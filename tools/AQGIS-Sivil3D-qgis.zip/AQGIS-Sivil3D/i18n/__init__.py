"""Idioma de la interfaz: ingles (por defecto) o castellano.

El texto original del codigo esta en **ingles**, que es el idioma por defecto del
plugin. Traducir consiste en buscar ese texto en el catalogo del idioma elegido;
si no esta, se devuelve el original. Asi una traduccion incompleta degrada al
ingles, que es justo lo que se quiere: nunca se ve una cadena rota.

Se usa un catalogo Python en vez de los ``.ts``/``.qm`` de Qt a proposito:

* no hace falta ``pylupdate``/``lrelease`` para construir el plugin, asi que
  ``empaquetar.py`` sigue siendo un script sin dependencias;
* funciona en los tests, que corren sin QGIS;
* permite que el idioma sea **una eleccion del usuario dentro del plugin**, y no
  el locale de QGIS: un ``QTranslator`` instalado por el mecanismo estandar se
  ata al idioma de la aplicacion y no se puede cambiar por separado.

Uso::

    from ..i18n import t

    t("Compute")
    t("The group '{nombre}' has no vector layers.", nombre=grupo.name())

Las cadenas con huecos se escriben con ``str.format`` y **huecos con nombre**:
el traductor puede reordenarlos sin tocar el codigo.
"""

from __future__ import annotations

#: Codigos de idioma admitidos, en el orden en que se ofrecen.
IDIOMAS = ("en", "es")

#: Nombre de cada idioma en si mismo, para el selector.
NOMBRES = {"en": "English", "es": "Espanol"}

#: Idioma por defecto del plugin.
POR_DEFECTO = "en"

#: Clave del ajuste en el perfil de QGIS.
CLAVE_AJUSTE = "aqgis_sivil3d/idioma"

#: Idioma en uso. ``None`` mientras no se haya leido el ajuste.
_actual = None

#: Catalogo del idioma en uso, ``{original_ingles: traduccion}``.
_catalogo: dict = {}


def _leer_ajuste() -> str:
    """Idioma guardado en el perfil de QGIS, o el de por defecto.

    Fuera de QGIS (tests, uso de ``core`` desde un script) no hay ajustes: se
    devuelve el idioma por defecto sin considerarlo un error.
    """
    try:
        from qgis.core import QgsSettings
    except ImportError:
        return POR_DEFECTO
    try:
        valor = QgsSettings().value(CLAVE_AJUSTE, POR_DEFECTO)
    except Exception:  # noqa: BLE001 - un ajuste ilegible no puede tumbar el plugin
        return POR_DEFECTO
    valor = str(valor or "").strip().lower()
    return valor if valor in IDIOMAS else POR_DEFECTO


def _cargar_catalogo(codigo: str) -> dict:
    """Catalogo del idioma. El ingles es el original: no necesita catalogo."""
    if codigo == "en":
        return {}
    try:
        from . import es

        return es.TEXTOS
    except ImportError:
        return {}


def idioma() -> str:
    """Idioma en uso, leyendo el ajuste la primera vez."""
    global _actual, _catalogo
    if _actual is None:
        _actual = _leer_ajuste()
        _catalogo = _cargar_catalogo(_actual)
    return _actual


def _guardar_ajuste(codigo: str) -> bool:
    """Escribe el idioma en el perfil de QGIS. ``False`` si no se ha podido.

    Fuera de QGIS (tests, uso de ``core`` desde un script) no hay ajustes, y eso
    no es un error: el idioma vale para esta sesion y ya esta. Que no se haya
    podido guardar queda anotado en el registro, no tragado en silencio.
    """
    try:
        from qgis.core import QgsSettings

        QgsSettings().setValue(CLAVE_AJUSTE, codigo)
    except Exception as exc:  # noqa: BLE001 - el idioma no puede tumbar el plugin
        from ..gis.registro import avisar

        avisar("no se ha podido guardar el idioma en el perfil", exc)
        return False
    return True


def set_idioma(codigo: str, guardar: bool = True) -> str:
    """Cambia el idioma. Devuelve el que ha quedado puesto.

    Lo que ya esta construido no cambia: los dialogos se traducen al volver a
    abrirlos y los paneles acoplados y el menu, solo al reiniciar QGIS. Quien
    llama a esto avisa de ello.
    """
    global _actual, _catalogo
    codigo = str(codigo or "").strip().lower()
    if codigo not in IDIOMAS:
        codigo = POR_DEFECTO
    _actual = codigo
    _catalogo = _cargar_catalogo(codigo)
    if guardar:
        _guardar_ajuste(codigo)
    return codigo


def t(texto: str, **huecos) -> str:
    """Traduce ``texto`` al idioma en uso y rellena los huecos con nombre.

    Si la cadena no esta en el catalogo se devuelve tal cual, en ingles. Si el
    formateo falla -- una traduccion con un hueco mal escrito -- se devuelve el
    texto sin formatear antes que reventar la interfaz.
    """
    idioma()  # asegura que el catalogo esta cargado
    salida = _catalogo.get(texto, texto)
    if not huecos:
        return salida
    try:
        return salida.format(**huecos)
    except (KeyError, IndexError, ValueError):
        try:
            return texto.format(**huecos)
        except (KeyError, IndexError, ValueError):
            return salida


def numero(valor, decimales: int = 0, signo: bool = False) -> str:
    """Numero con el separador de miles y de decimales del idioma.

    Ingles ``1,234.5``; castellano ``1.234,5``. Se escribe con la convencion
    inglesa y se le da la vuelta, que es mas corto que montar un ``locale``: el
    plugin no puede cambiar el locale del proceso, que es de QGIS.
    """
    txt = f"{valor:{'+' if signo else ''},.{decimales}f}"
    if idioma() == "es":
        # Se pasa por un caracter que no aparece en un numero para no pisar lo
        # que se acaba de cambiar.
        txt = txt.replace(",", "\x00").replace(".", ",").replace("\x00", ".")
    return txt


def en_idioma(texto: str, codigo: str, **huecos) -> str:
    """Como :func:`t` pero en un idioma concreto, sin cambiar el que esta puesto.

    Hace falta para construir a la vez las dos versiones de algo -- el catalogo
    de secciones de arranque -- y para reconocer un nombre de capa escrito en el
    otro idioma.
    """
    catalogo = _catalogo if codigo == _actual else _cargar_catalogo(codigo)
    salida = catalogo.get(texto, texto)
    if not huecos:
        return salida
    try:
        return salida.format(**huecos)
    except (KeyError, IndexError, ValueError):
        return salida


def todas_las_formas(texto: str) -> tuple:
    """El texto en todos los idiomas, sin repetir.

    Sirve para reconocer algo que se escribio en una sesion con otro idioma: el
    nombre de una capa de un GeoPackage exportado, por ejemplo.
    """
    formas = []
    for codigo in IDIOMAS:
        forma = en_idioma(texto, codigo)
        if forma not in formas:
            formas.append(forma)
    return tuple(formas)


def _reset_para_tests() -> None:
    """Olvida el idioma leido. Solo para los tests."""
    global _actual, _catalogo
    _actual = None
    _catalogo = {}


__all__ = [
    "IDIOMAS",
    "NOMBRES",
    "POR_DEFECTO",
    "CLAVE_AJUSTE",
    "idioma",
    "set_idioma",
    "t",
    "numero",
    "en_idioma",
    "todas_las_formas",
]
