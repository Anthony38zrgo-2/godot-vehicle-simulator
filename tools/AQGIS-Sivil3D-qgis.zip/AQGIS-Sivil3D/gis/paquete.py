"""Exportacion e importacion de un corredor completo como un solo archivo.

Un corredor calculado son capas en memoria: si se cierra QGIS, se pierden. Aqui
se empaqueta todo en dos archivos hermanos:

``<nombre>.gpkg``
    Un GeoPackage con **todas** las capas del grupo, cada una con su estilo
    guardado dentro (tabla ``layer_styles``). Es un formato abierto que se abre en
    cualquier SIG y en CAD.

``<nombre>.corredor.json``
    Las secciones resueltas: linea de terreno, cota del eje, codigos de cada
    vertice. Es lo que el GeoPackage **no** puede guardar y sin lo cual el visor
    de perfiles, las mediciones y los planos no se pueden reconstruir. Al
    importar, si esta al lado del ``.gpkg``, el corredor vuelve entero y se puede
    seguir trabajando sin el DEM y sin recalcular.

Si solo se quiere el dibujo, el ``.gpkg`` por si solo vale.
"""

from __future__ import annotations

import os
from typing import Optional, Sequence

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransformContext,
    QgsLayerTreeGroup,
    QgsLayerTreeLayer,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

from ..core import sesion
from .outputs import cargar_en_grupo, nombre_de_grupo_libre, ordenar_para_dibujo

from .registro import avisar


SUFIJO_JSON = ".corredor.json"

#: Tablas internas del GeoPackage que no son capas del corredor.
INTERNAS = {"layer_styles", "qgis_projects"}


def ruta_json(ruta_gpkg: str) -> str:
    """``x.gpkg`` -> ``x.corredor.json``."""
    base = ruta_gpkg[:-5] if ruta_gpkg.lower().endswith(".gpkg") else ruta_gpkg
    return base + SUFIJO_JSON


def _nombre_de_tabla(nombre: str) -> str:
    """Nombre valido de tabla de GeoPackage a partir del de la capa."""
    limpio = "".join(c if c.isalnum() or c in "_" else "_" for c in nombre.strip())
    limpio = limpio.strip("_") or "capa"
    if limpio[0].isdigit():
        limpio = "c_" + limpio
    return limpio[:60]


def capas_de_grupo(grupo: QgsLayerTreeGroup) -> list:
    """Capas vectoriales del grupo, en el orden en que estan."""
    salida = []
    for hijo in grupo.children():
        if isinstance(hijo, QgsLayerTreeLayer):
            capa = hijo.layer()
            if isinstance(capa, QgsVectorLayer) and capa.isValid():
                salida.append(capa)
        elif isinstance(hijo, QgsLayerTreeGroup):
            salida.extend(capas_de_grupo(hijo))
    return salida


# --------------------------------------------------------------------------


def exportar(
    capas: Sequence,
    ruta_gpkg: str,
    result=None,
    nombre: str = "",
    crs: Optional[QgsCoordinateReferenceSystem] = None,
) -> tuple:
    """Escribe las capas en un GeoPackage. Devuelve ``(ok, mensajes)``.

    Cada capa va como una tabla, con su estilo guardado dentro del propio
    GeoPackage, de modo que al reabrirlo tiene el aspecto que tenia.
    """
    mensajes: list = []
    utiles = [c for c in capas if c is not None and c.isValid()]
    if not utiles:
        return False, ["no hay capas que exportar"]
    if not ruta_gpkg.lower().endswith(".gpkg"):
        ruta_gpkg += ".gpkg"
    error = _limpiar_destino(ruta_gpkg)
    if error:
        return False, [error]

    contexto = QgsProject.instance().transformContext()
    usados: set = set()
    primera = True
    for capa in utiles:
        tabla = _tabla_libre(capa.name(), usados)
        ok, aviso = _escribir_capa(capa, ruta_gpkg, tabla, contexto, primera)
        if aviso:
            mensajes.append(aviso)
        if not ok:
            continue
        primera = False
        aviso = _guardar_estilo(capa, ruta_gpkg, tabla)
        if aviso:
            mensajes.append(aviso)

    if primera:
        return False, mensajes or ["no se ha podido escribir ninguna capa"]
    mensajes.insert(0, f"{len(usados)} capas escritas en {ruta_gpkg}")
    if result is not None:
        mensajes.append(_guardar_secciones(result, ruta_gpkg, nombre, crs))
    return True, [m for m in mensajes if m]


def _limpiar_destino(ruta_gpkg: str) -> str:
    """Borra el GeoPackage anterior y sus archivos de servicio.

    Se empieza de cero: dejar tablas viejas de otra ejecucion mezcladas con las
    nuevas confunde mas que ayuda. Devuelve el mensaje de error, si lo hay.
    """
    for sufijo in ("", "-wal", "-shm", "-journal"):
        try:
            if os.path.exists(ruta_gpkg + sufijo):
                os.remove(ruta_gpkg + sufijo)
        except OSError as exc:
            return f"no se puede sobrescribir {ruta_gpkg}: {exc}"
    return ""


def _tabla_libre(nombre: str, usados: set) -> str:
    """Nombre de tabla valido y no repetido dentro del GeoPackage."""
    tabla = _nombre_de_tabla(nombre)
    base, n = tabla, 2
    while tabla in usados:
        tabla = f"{base}_{n}"
        n += 1
    usados.add(tabla)
    return tabla


def _escribir_capa(capa, ruta_gpkg: str, tabla: str, contexto, primera: bool) -> tuple:
    """Escribe una capa como tabla del GeoPackage. ``(ok, aviso)``."""
    opciones = QgsVectorFileWriter.SaveVectorOptions()
    opciones.driverName = "GPKG"
    opciones.layerName = tabla
    opciones.fileEncoding = "UTF-8"
    # El nombre de tabla no admite espacios, asi que el nombre bonito de la capa
    # se guarda en gpkg_contents.identifier y se recupera al importar.
    opciones.layerOptions = [f"IDENTIFIER={capa.name()}"]
    opciones.actionOnExistingFile = (
        QgsVectorFileWriter.CreateOrOverwriteFile
        if primera
        else QgsVectorFileWriter.CreateOrOverwriteLayer
    )
    # No se transforma nada: cada capa se escribe en su propio sistema, y las de
    # espacio papel no tienen ninguno porque sus unidades son milimetros.
    resultado = QgsVectorFileWriter.writeAsVectorFormatV3(
        capa, ruta_gpkg, contexto, opciones
    )
    codigo = resultado[0] if isinstance(resultado, (tuple, list)) else resultado
    if codigo != QgsVectorFileWriter.NoError:
        detalle = resultado[1] if isinstance(resultado, (tuple, list)) else ""
        return False, f"'{capa.name()}' no se ha podido escribir: {detalle}"
    return True, ""


def _guardar_estilo(capa, ruta_gpkg: str, tabla: str) -> str:
    """Guarda el estilo dentro del propio GeoPackage. Devuelve el aviso, si hay.

    Una tabla sin geometria no tiene simbologia, y eso no es un problema.
    """
    try:
        guardada = QgsVectorLayer(
            f"{ruta_gpkg}|layername={tabla}", capa.name(), "ogr"
        )
        if guardada.isValid() and capa.renderer() is not None:
            guardada.setRenderer(capa.renderer().clone())
            if capa.labelsEnabled() and capa.labeling() is not None:
                guardada.setLabeling(capa.labeling().clone())
                guardada.setLabelsEnabled(True)
            guardada.saveStyleToDatabase(
                capa.name(), f"estilo de {capa.name()}", True, ""
            )
    except Exception as exc:  # noqa: BLE001 - el estilo es un extra
        return f"estilo de '{capa.name()}' no guardado: {exc}"
    return ""


def _guardar_secciones(result, ruta_gpkg: str, nombre: str, crs) -> str:
    """Escribe el JSON hermano con las secciones resueltas."""
    ruta = ruta_json(ruta_gpkg)
    try:
        sesion.guardar(
            result,
            ruta,
            nombre=nombre,
            crs=crs.authid() if crs is not None and crs.isValid() else "",
        )
    except OSError as exc:
        return f"no se han podido guardar las secciones: {exc}"
    return (
        f"secciones guardadas en {os.path.basename(ruta)} "
        f"(el visor de perfiles se podra reconstruir)"
    )


# --------------------------------------------------------------------------


def importar(
    ruta_gpkg: str, nombre_grupo: str = "", proyecto=None
) -> tuple:
    """Carga un GeoPackage exportado. Devuelve ``(grupo, corredor, mensajes)``.

    ``corredor`` es un :class:`~aqgis_sivil3d.core.sesion.CorredorGuardado` si
    estaba el JSON hermano, y ``None`` si no: entonces se recuperan las capas pero
    no el visor de perfiles.
    """
    from osgeo import ogr

    mensajes: list = []
    proyecto = proyecto or QgsProject.instance()
    if not os.path.exists(ruta_gpkg):
        return None, None, [f"no existe {ruta_gpkg}"]

    tablas, nombres = _tablas_del_gpkg(ruta_gpkg, ogr)
    if tablas is None:
        return None, None, [f"{ruta_gpkg} no es un GeoPackage legible"]
    if not tablas:
        return None, None, [f"{ruta_gpkg} no tiene ninguna capa"]

    capas = []
    for tabla in tablas:
        capa = _cargar_tabla(ruta_gpkg, tabla, nombres.get(tabla, tabla))
        if capa is None:
            mensajes.append(f"'{tabla}' no se ha podido cargar")
            continue
        capas.append(capa)
    if not capas:
        return None, None, mensajes or ["ninguna capa valida"]

    base = nombre_grupo or os.path.splitext(os.path.basename(ruta_gpkg))[0]
    grupo = cargar_en_grupo(
        ordenar_para_dibujo(capas),
        nombre_de_grupo_libre(proyecto.layerTreeRoot(), base),
        proyecto,
    )
    mensajes.insert(0, f"{len(capas)} capas cargadas en el grupo '{grupo.name()}'")
    corredor, aviso = _recuperar_corredor(ruta_gpkg, base)
    mensajes.append(aviso)
    return grupo, corredor, [m for m in mensajes if m]


def _tablas_del_gpkg(ruta_gpkg: str, ogr) -> tuple:
    """``(tablas del corredor, nombres bonitos)``. ``(None, {})`` si no se abre.

    El nombre de tabla de un GeoPackage no admite espacios, asi que el nombre
    original de la capa viaja en ``gpkg_contents.identifier``.
    """
    fuente = ogr.Open(ruta_gpkg)
    if fuente is None:
        return None, {}
    tablas = [
        fuente.GetLayerByIndex(i).GetName() for i in range(fuente.GetLayerCount())
    ]
    nombres: dict = {}
    try:
        consulta = fuente.ExecuteSQL(
            "SELECT table_name, identifier FROM gpkg_contents"
        )
        if consulta is not None:
            for fila in consulta:
                nombres[fila.GetField(0)] = fila.GetField(1) or fila.GetField(0)
            fuente.ReleaseResultSet(consulta)
    except Exception as exc:  # noqa: BLE001 - si no, se usa el de la tabla
        avisar("no se han podido leer los nombres de gpkg_contents", exc)
    fuente = None
    # Las tablas de servicio del GeoPackage no son capas del corredor.
    return [t for t in tablas if t not in INTERNAS and not t.startswith("gpkg_")], nombres


def _cargar_tabla(ruta_gpkg: str, tabla: str, nombre: str):
    """Capa de una tabla del GeoPackage, con su estilo guardado si lo tiene."""
    capa = QgsVectorLayer(f"{ruta_gpkg}|layername={tabla}", nombre, "ogr")
    if not capa.isValid():
        return None
    try:
        _texto, ok = capa.loadDefaultStyle()
        if not ok:
            capa.loadNamedStyle(f"{ruta_gpkg}|layername={tabla}")
    except Exception as exc:  # noqa: BLE001
        avisar(f"'{tabla}' se ha cargado sin su estilo guardado", exc)
    return capa


def _recuperar_corredor(ruta_gpkg: str, base: str) -> tuple:
    """``(corredor, aviso)`` a partir del JSON hermano, si esta."""
    ruta = ruta_json(ruta_gpkg)
    if not os.path.exists(ruta):
        return None, (
            f"no se ha encontrado {os.path.basename(ruta)}: se recuperan las capas "
            f"pero no las secciones, asi que el visor de perfiles no tendra datos."
        )
    try:
        corredor = sesion.cargar(ruta)
    except Exception as exc:  # noqa: BLE001
        return None, f"el archivo de secciones no se ha podido leer: {exc}"
    if not corredor.nombre:
        corredor.nombre = base
    return corredor, (
        f"corredor recuperado: {corredor.stats()}. Ya se puede usar el visor de "
        f"perfiles y generar planos."
    )


__all__ = [
    "SUFIJO_JSON",
    "INTERNAS",
    "ruta_json",
    "capas_de_grupo",
    "exportar",
    "importar",
]
