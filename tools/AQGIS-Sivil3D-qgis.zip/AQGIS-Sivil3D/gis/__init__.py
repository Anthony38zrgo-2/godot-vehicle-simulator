"""Capa de integracion con QGIS.

Aqui vive todo lo que necesita ``qgis.core``: leer el DEM, recorrer la capa de
directrices, evaluar expresiones y escribir las capas de salida. El calculo
geometrico esta en ``aqgis_sivil3d.core``, que es Python puro.

El paquete se llama ``gis`` y no ``qgis`` a proposito, para no confundirlo con
el paquete ``qgis`` de la aplicacion.
"""
