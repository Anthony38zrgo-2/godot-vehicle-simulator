"""Muestreo del terreno: convierte cualquier DEM de QGIS en una funcion ``tz``.

El nucleo de calculo solo pide ``tz(x, y) -> cota | None``. Este modulo
construye esa funcion a partir de:

* un raster (:class:`RasterTerrain`) -- cualquier formato que lea GDAL: GeoTIFF,
  ASC/Arc Grid, IMG, DEM, HGT, VRT, ECW..., incluidos rasters virtuales que
  combinen varias hojas;
* una capa de malla (:class:`MeshTerrain`) -- TIN en 2DM, Ugrid, etc.

Dos detalles que importan para la calidad del resultado:

**Interpolacion bilineal.** ``QgsRasterDataProvider.sample()`` devuelve el valor
del pixel, o sea un terreno escalonado. Con escalones, la busqueda del corte del
talud con el terreno da saltos y la linea de daylight sale con dientes de sierra.
Aqui se interpola bilinealmente entre los centros de los cuatro pixeles vecinos.

**Lectura por teselas con cache.** Llamar al proveedor una vez por punto es muy
lento (y se llama muchisimas veces: cada biseccion son ~40 muestras). Se leen
bloques de 256x256 pixeles y se guardan en un diccionario, asi un corredor
recorre el DEM una sola vez.
"""

from __future__ import annotations

import math
from typing import Optional

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsMeshDatasetIndex,
    QgsPointXY,
    QgsProject,
    QgsRasterLayer,
    QgsRectangle,
)

#: Lado de la tesela de lectura, en pixeles.
TILE = 256


class TerrainError(RuntimeError):
    """La fuente de terreno no se puede usar."""


from .registro import avisar


class BaseTerrain:
    """Interfaz comun. ``__call__`` es lo que consume el nucleo."""

    #: Resolucion caracteristica de la fuente (m). Se usa como valor por
    #: defecto del paso de muestreo y del tamano de celda de la fusion.
    resolucion: float = 1.0

    def z(self, x: float, y: float) -> Optional[float]:  # pragma: no cover
        raise NotImplementedError

    def __call__(self, x: float, y: float) -> Optional[float]:
        return self.z(x, y)

    def stats(self) -> str:
        return f"{type(self).__name__} res={self.resolucion:.3g} m"


# --------------------------------------------------------------------------


def _datos_del_bloque(block, cols: int, rows: int) -> list:
    """Bloque del proveedor como lista plana de ``float | None``.

    Con numpy se saca de la memoria del bloque de una vez. Sin el habria que
    llamar a ``value()`` e ``isNoData()`` celda a celda: son dos llamadas a C++
    por pixel, 130.000 por tesela, y eso es lo que hacia que muestrear un perfil
    sobre un DEM grande tardase segundos.
    """
    try:
        import numpy as np

        tipos = {
            1: "uint8", 2: "uint16", 3: "int16", 4: "uint32", 5: "int32",
            6: "float32", 7: "float64",
        }
        dtype = tipos.get(int(block.dataType()))
        if dtype is not None:
            crudo = np.frombuffer(block.data(), dtype=dtype, count=cols * rows)
            valores = crudo.astype("float64")
            if block.hasNoDataValue():
                nodata = float(block.noDataValue())
                if nodata == nodata:  # descarta un NoData que sea NaN
                    valores = np.where(valores == nodata, np.nan, valores)
            # Se devuelve el propio array: convertirlo a lista costaria recorrer
            # 65.000 valores en Python por tesela. El NoData va como NaN, y quien
            # lee lo traduce a None.
            return valores
    except Exception:  # noqa: BLE001 - se cae al camino lento, que siempre vale
        avisar("lectura rapida de la tesela no disponible; se usa la lenta")
    datos = [None] * (cols * rows)
    for r in range(rows):
        base = r * cols
        for c in range(cols):
            if not block.isNoData(r, c):
                datos[base + c] = block.value(r, c)
    return datos


class RasterTerrain(BaseTerrain):
    """Terreno leido de un raster, con interpolacion bilineal y cache."""

    def __init__(
        self,
        layer: QgsRasterLayer,
        crs_trabajo: Optional[QgsCoordinateReferenceSystem] = None,
        banda: int = 1,
        factor_z: float = 1.0,
        offset_z: float = 0.0,
        transform_context=None,
    ):
        if layer is None or not layer.isValid():
            raise TerrainError("la capa de DEM no es valida")
        self.layer = layer
        self.provider = layer.dataProvider()
        if self.provider is None:
            raise TerrainError("el DEM no tiene proveedor de datos")
        self.banda = int(banda)
        if self.banda < 1 or self.banda > layer.bandCount():
            raise TerrainError(
                f"banda {self.banda} fuera de rango (el DEM tiene "
                f"{layer.bandCount()})"
            )
        self.factor_z = float(factor_z)
        self.offset_z = float(offset_z)

        self.ext = self.provider.extent()
        self.ncols = int(self.provider.xSize())
        self.nrows = int(self.provider.ySize())
        if self.ncols <= 0 or self.nrows <= 0:
            raise TerrainError(
                "el DEM no declara tamano en pixeles; conviertelo a GeoTIFF"
            )
        self.px = self.ext.width() / self.ncols
        self.py = self.ext.height() / self.nrows
        self.resolucion = float(min(self.px, self.py))

        # Transformacion de coordenadas solo si hace falta.
        self.xform = None
        crs_dem = layer.crs()
        if (
            crs_trabajo is not None
            and crs_trabajo.isValid()
            and crs_dem.isValid()
            and crs_trabajo != crs_dem
        ):
            ctx = transform_context or QgsProject.instance().transformContext()
            self.xform = QgsCoordinateTransform(crs_trabajo, crs_dem, ctx)

        self._tiles: dict = {}
        self.lecturas = 0

    # -- teselas ----------------------------------------------------------
    def _tile(self, ti: int, tj: int):
        """Bloque ``(ti, tj)`` de ``TILE x TILE`` pixeles, o ``None`` si vacio."""
        clave = (ti, tj)
        if clave in self._tiles:
            return self._tiles[clave]
        c0, r0 = ti * TILE, tj * TILE
        cols = min(TILE, self.ncols - c0)
        rows = min(TILE, self.nrows - r0)
        if cols <= 0 or rows <= 0:
            self._tiles[clave] = None
            return None
        rect = QgsRectangle(
            self.ext.xMinimum() + c0 * self.px,
            self.ext.yMaximum() - (r0 + rows) * self.py,
            self.ext.xMinimum() + (c0 + cols) * self.px,
            self.ext.yMaximum() - r0 * self.py,
        )
        block = self.provider.block(self.banda, rect, cols, rows)
        self.lecturas += 1
        if block is None or not block.isValid():
            self._tiles[clave] = None
            return None
        # Se cachea como lista plana de float | None: mas ligero que el
        # QgsRasterBlock y sin depender de su ciclo de vida.
        self._tiles[clave] = (_datos_del_bloque(block, cols, rows), cols, rows)
        return self._tiles[clave]

    def _pixel(self, col: int, row: int) -> Optional[float]:
        if col < 0 or row < 0 or col >= self.ncols or row >= self.nrows:
            return None
        t = self._tile(col // TILE, row // TILE)
        if t is None:
            return None
        datos, cols, _rows = t
        v = datos[(row % TILE) * cols + (col % TILE)]
        # NaN es el NoData de las teselas leidas con numpy; None, el de las lentas.
        return None if v is None or v != v else float(v)

    # -- muestreo ---------------------------------------------------------
    def z(self, x: float, y: float) -> Optional[float]:
        if self.xform is not None:
            try:
                p = self.xform.transform(QgsPointXY(x, y))
            except Exception:
                return None
            x, y = p.x(), p.y()
        # Coordenada continua en "indices de centro de pixel".
        cf = (x - self.ext.xMinimum()) / self.px - 0.5
        rf = (self.ext.yMaximum() - y) / self.py - 0.5
        c0 = int(math.floor(cf))
        r0 = int(math.floor(rf))
        fx = cf - c0
        fy = rf - r0
        v00 = self._pixel(c0, r0)
        v10 = self._pixel(c0 + 1, r0)
        v01 = self._pixel(c0, r0 + 1)
        v11 = self._pixel(c0 + 1, r0 + 1)
        pesos = (
            (v00, (1.0 - fx) * (1.0 - fy)),
            (v10, fx * (1.0 - fy)),
            (v01, (1.0 - fx) * fy),
            (v11, fx * fy),
        )
        num = 0.0
        den = 0.0
        for v, w in pesos:
            if v is None or w <= 0.0:
                continue
            num += v * w
            den += w
        if den <= 0.0:
            # Los cuatro vecinos con peso son NoData: puede que el punto caiga
            # justo en el borde. Se prueba el pixel que lo contiene.
            v = self._pixel(
                int((x - self.ext.xMinimum()) / self.px),
                int((self.ext.yMaximum() - y) / self.py),
            )
            if v is None:
                return None
            return v * self.factor_z + self.offset_z
        return (num / den) * self.factor_z + self.offset_z

    def stats(self) -> str:
        return (
            f"raster {self.ncols}x{self.nrows} px de {self.px:.3g}x{self.py:.3g} m, "
            f"{self.lecturas} teselas leidas"
        )


# --------------------------------------------------------------------------


class MeshTerrain(BaseTerrain):
    """Terreno leido de una capa de malla (TIN 2DM, Ugrid...).

    Va por ``QgsMeshLayer.datasetValue``, que interpola dentro de la cara. Es
    mas lento que el raster porque no hay cache posible, pero permite usar
    directamente un TIN como terreno base (por ejemplo el resultado de un
    corredor anterior, para encajar dos obras seguidas).
    """

    def __init__(
        self,
        layer,
        crs_trabajo: Optional[QgsCoordinateReferenceSystem] = None,
        grupo: int = 0,
        transform_context=None,
    ):
        if layer is None or not layer.isValid():
            raise TerrainError("la capa de malla no es valida")
        self.layer = layer
        self.index = QgsMeshDatasetIndex(int(grupo), 0)
        self.xform = None
        if (
            crs_trabajo is not None
            and crs_trabajo.isValid()
            and layer.crs().isValid()
            and crs_trabajo != layer.crs()
        ):
            ctx = transform_context or QgsProject.instance().transformContext()
            self.xform = QgsCoordinateTransform(crs_trabajo, layer.crs(), ctx)
        ext = layer.extent()
        # Estimacion grosera de la resolucion: lado medio de una cara cuadrada
        # equivalente.
        try:
            n = max(1, layer.meshFaceCount())
        except Exception:
            n = 1
        self.resolucion = max(
            1e-3, math.sqrt(max(ext.width() * ext.height(), 1e-6) / n)
        )

    def z(self, x: float, y: float) -> Optional[float]:
        if self.xform is not None:
            try:
                p = self.xform.transform(QgsPointXY(x, y))
            except Exception:
                return None
        else:
            p = QgsPointXY(x, y)
        try:
            val = self.layer.datasetValue(self.index, p)
        except Exception:
            return None
        if val is None or not val.isValid():
            return None
        z = val.scalar()
        if z is None or not math.isfinite(z):
            return None
        return float(z)

    def stats(self) -> str:
        return f"malla, resolucion estimada {self.resolucion:.3g} m"


# --------------------------------------------------------------------------


def make_terrain(
    layer,
    crs_trabajo: Optional[QgsCoordinateReferenceSystem] = None,
    banda: int = 1,
    factor_z: float = 1.0,
    offset_z: float = 0.0,
    transform_context=None,
) -> BaseTerrain:
    """Devuelve el muestreador que corresponda al tipo de capa."""
    if layer is None:
        raise TerrainError("no se ha indicado capa de terreno")
    if isinstance(layer, QgsRasterLayer):
        return RasterTerrain(
            layer, crs_trabajo, banda, factor_z, offset_z, transform_context
        )
    if hasattr(layer, "datasetValue") and hasattr(layer, "meshFaceCount"):
        return MeshTerrain(layer, crs_trabajo, 0, transform_context)
    raise TerrainError(
        f"tipo de capa no soportado como terreno: {type(layer).__name__}. "
        f"Usa un raster (cualquier formato GDAL) o una capa de malla."
    )


__all__ = [
    "BaseTerrain",
    "RasterTerrain",
    "MeshTerrain",
    "TerrainError",
    "make_terrain",
]
