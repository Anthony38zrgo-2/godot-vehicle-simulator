"""Registro de lo que se ha tenido que dejar sin hacer.

Hay cosas que el plugin intenta y que pueden no estar disponibles: un enum que
QGIS ha movido de sitio entre versiones, un estilo que no se puede aplicar, una
propiedad de etiquetado que en esa version no existe. Ninguna de ellas debe
romper el calculo, pero **tragarselas en silencio tampoco vale**: si un dia el
plano sale sin rotar o la capa sin estilo, hay que poder saber por que.

De ahi este modulo: un sitio unico donde dejar constancia, en el panel de
*Registro de mensajes* de QGIS, bajo la etiqueta ``AQGIS-Sivil3D``.
"""

from __future__ import annotations

import sys

#: Etiqueta con la que salen los mensajes en el registro de QGIS.
ETIQUETA = "AQGIS-Sivil3D"


def avisar(contexto: str, exc: BaseException = None) -> str:
    """Anota que ``contexto`` no se ha podido completar. Devuelve el texto anotado.

    Se usa en los ``except`` de lo que es opcional. Nunca levanta: si ni siquiera
    se puede escribir en el registro de QGIS (por ejemplo en los tests, sin
    aplicacion), el mensaje sale por la salida de error.
    """
    texto = contexto if exc is None else f"{contexto}: {exc}"
    try:
        from qgis.core import Qgis, QgsMessageLog

        nivel = getattr(
            getattr(Qgis, "MessageLevel", Qgis), "Info", None
        )
        if nivel is None:
            QgsMessageLog.logMessage(texto, ETIQUETA)
        else:
            QgsMessageLog.logMessage(texto, ETIQUETA, nivel)
    except Exception as fallo:  # noqa: BLE001 - el registro no puede ser el problema
        sys.stderr.write(f"[{ETIQUETA}] {texto} (registro no disponible: {fallo})\n")
    return texto


__all__ = ["ETIQUETA", "avisar"]
