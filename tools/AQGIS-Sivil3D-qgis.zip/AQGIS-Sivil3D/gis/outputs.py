"""Conversion del resultado a capas de QGIS.

Se definen los campos y los generadores de features una sola vez y se usan
tanto desde el algoritmo de Processing (que escribe en *sinks*) como desde el
dialogo (que crea capas en memoria).

Todas las geometrias salen con Z.
"""

from __future__ import annotations

import math
from typing import Iterator, Optional

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsLayerTreeGroup,
    QgsLineString,
    QgsPoint,
    QgsPolygon,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QMetaType

from ..core.schema import codigos_del_eje
from ..core.tin import ORIGEN_TERRENO, Mesh, daylight_lines, feature_lines
from .alignment import azimut, formato_pk

# --------------------------------------------------------------------------
# Compatibilidad de tipos de campo: QGIS 3.38+ prefiere QMetaType.Type y en
# QGIS 4 los QVariant.Type ya no valen.
# --------------------------------------------------------------------------
T_INT = QMetaType.Type.Int
T_DOUBLE = QMetaType.Type.Double
T_STRING = QMetaType.Type.QString


def _f(nombre: str, tipo, largo: int = 0, prec: int = 0) -> QgsField:
    return QgsField(nombre, tipo, len=largo, prec=prec)


def fields_secciones() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("seccion", T_STRING, 80),
        _f("pk", T_DOUBLE, 12, 3),
        _f("es_vertice", T_INT),
        _f("z_eje", T_DOUBLE, 12, 3),
        _f("modo_izq", T_STRING, 20),
        _f("modo_der", T_STRING, 20),
        _f("ancho_izq", T_DOUBLE, 10, 3),
        _f("ancho_der", T_DOUBLE, 10, 3),
        _f("cota_roja", T_DOUBLE, 10, 3),
        _f("area_des", T_DOUBLE, 12, 3),
        _f("area_ter", T_DOUBLE, 12, 3),
        _f("ok", T_INT),
        _f("avisos", T_STRING, 500),
    ):
        f.append(c)
    return f


def fields_lineas() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("codigo", T_STRING, 60),
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("seccion", T_STRING, 80),
        _f("n_puntos", T_INT),
        _f("long_3d", T_DOUBLE, 14, 3),
    ):
        f.append(c)
    return f


def fields_huella() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("seccion", T_STRING, 80),
        _f("pk_ini", T_DOUBLE, 12, 3),
        _f("pk_fin", T_DOUBLE, 12, 3),
        _f("area", T_DOUBLE, 16, 3),
    ):
        f.append(c)
    return f


#: Valores del campo ``zona`` de la capa de triangulos.
ZONA_DESMONTE = "desmonte"
ZONA_TERRAPLEN = "terraplen"
ZONA_COTA = "a cota"
ZONA_TERRENO = "terreno natural"

#: Por debajo de este desnivel proyecto-terreno el triangulo no es ni desmonte
#: ni terraplen: esta practicamente sobre el terreno (zona de daylight).
TOL_ZONA = 0.05


def fields_triangulos() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("id", T_INT),
        _f("zona", T_STRING, 20),
        _f("espesor", T_DOUBLE, 10, 3),
        _f("area_2d", T_DOUBLE, 14, 4),
        _f("z_min", T_DOUBLE, 12, 3),
        _f("z_max", T_DOUBLE, 12, 3),
        _f("z_med", T_DOUBLE, 12, 3),
        _f("pendiente", T_DOUBLE, 8, 2),
    ):
        f.append(c)
    return f


def fields_pk() -> QgsFields:
    """Campos con los nombres que esperan los estilos de rotulacion de PK.

    ``distance``, ``angle`` y ``P.K.`` se llaman asi a proposito: son los que
    genera *Puntos a lo largo de geometria* de QGIS, de modo que los QML del
    modelo "PK en QGIS" valen tal cual.
    """
    f = QgsFields()
    for c in (
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("distance", T_DOUBLE, 14, 3),
        _f("angle", T_DOUBLE, 10, 4),
        _f("P.K.", T_STRING, 100),
        _f("z", T_DOUBLE, 12, 3),
    ):
        f.append(c)
    return f


def fields_eje() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("seccion", T_STRING, 80),
        _f("pk_ini", T_DOUBLE, 12, 3),
        _f("pk_fin", T_DOUBLE, 12, 3),
        _f("longitud", T_DOUBLE, 14, 3),
    ):
        f.append(c)
    return f


def fields_puntos() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("pk", T_DOUBLE, 12, 3),
        _f("codigo", T_STRING, 60),
        _f("offset", T_DOUBLE, 10, 3),
        _f("z", T_DOUBLE, 12, 3),
        _f("tipo", T_STRING, 20),
    ):
        f.append(c)
    return f


# --------------------------------------------------------------------------
# Generadores de features
# --------------------------------------------------------------------------


def _linea_z(pts) -> QgsGeometry:
    return QgsGeometry(QgsLineString([QgsPoint(p[0], p[1], p[2]) for p in pts]))


def _long_3d(pts) -> float:
    return sum(math.dist(a, b) for a, b in zip(pts, pts[1:]))


def _areas_sec(sec) -> tuple:
    """Areas de la seccion, tolerante con secciones sin terreno guardado."""
    try:
        return sec.areas()
    except Exception:  # noqa: BLE001
        return (0.0, 0.0)


def features_secciones(result) -> Iterator[QgsFeature]:
    campos = fields_secciones()
    for run in result.runs:
        for sec in run.sections:
            pts = sec.world_points()
            if len(pts) < 2:
                continue
            ft = QgsFeature(campos)
            ft.setGeometry(_linea_z(pts))
            ft.setAttributes(
                [
                    run.alignment.fid,
                    run.alignment.part,
                    run.asm_nombre,
                    round(sec.station.s, 4),
                    1 if sec.station.es_vertice else 0,
                    round(sec.z_eje, 4) if math.isfinite(sec.z_eje) else None,
                    sec.modo_izq,
                    sec.modo_der,
                    round(sec.ancho_izq, 4),
                    round(sec.ancho_der, 4),
                    None if sec.cota_roja is None else round(sec.cota_roja, 4),
                    round(_areas_sec(sec)[0], 4),
                    round(_areas_sec(sec)[1], 4),
                    1 if sec.ok else 0,
                    "; ".join(sec.warnings)[:500],
                ]
            )
            yield ft


def features_lineas(result, incluir_daylight: bool = True) -> Iterator[QgsFeature]:
    campos = fields_lineas()
    for run in result.runs:
        validas = [s for s in run.sections if len(s.vertices) >= 2]
        lineas = feature_lines(validas)
        if incluir_daylight:
            lineas = lineas + daylight_lines(validas)
        for codigo, pts in lineas:
            if len(pts) < 2:
                continue
            ft = QgsFeature(campos)
            ft.setGeometry(_linea_z(pts))
            ft.setAttributes(
                [
                    codigo,
                    run.alignment.fid,
                    run.alignment.part,
                    run.asm_nombre,
                    len(pts),
                    round(_long_3d(pts), 4),
                ]
            )
            yield ft


def features_huella(result) -> Iterator[QgsFeature]:
    campos = fields_huella()
    for run in result.runs:
        if len(run.ring) < 3:
            continue
        anillo = list(run.ring)
        anillo.append(anillo[0])
        poly = QgsPolygon(QgsLineString([QgsPoint(p[0], p[1], p[2]) for p in anillo]))
        geom = QgsGeometry(poly)
        ft = QgsFeature(campos)
        ft.setGeometry(geom)
        pks = [s.station.s for s in run.sections] or [0.0]
        ft.setAttributes(
            [
                run.alignment.fid,
                run.alignment.part,
                run.asm_nombre,
                round(min(pks), 4),
                round(max(pks), 4),
                round(geom.area(), 4),
            ]
        )
        yield ft


def _zona(mesh: Mesh, n: int, centro, z_med: float, tz) -> tuple:
    """``(zona, espesor)`` de un triangulo. ``espesor`` = proyecto - terreno."""
    if mesh.origen(n) == ORIGEN_TERRENO:
        return ZONA_TERRENO, 0.0
    if tz is None:
        return "", None
    z_terreno = tz(centro[0], centro[1])
    if z_terreno is None:
        return "", None
    espesor = z_med - z_terreno
    if espesor > TOL_ZONA:
        return ZONA_TERRAPLEN, espesor
    if espesor < -TOL_ZONA:
        return ZONA_DESMONTE, espesor
    return ZONA_COTA, espesor


def features_triangulos(mesh: Mesh, tz=None) -> Iterator[QgsFeature]:
    """Un poligono por triangulo.

    Con ``tz`` (el muestreador del terreno) se clasifica cada triangulo en
    desmonte o terraplen comparando su cota media con la del terreno bajo su
    centroide, y se guarda el espesor con signo. Sin ``tz`` el campo ``zona``
    queda vacio y la capa sale sin colorear.
    """
    campos = fields_triangulos()
    for n, (i, j, k) in enumerate(mesh.tris, start=1):
        a, b, c = mesh.nodes[i], mesh.nodes[j], mesh.nodes[k]
        anillo = QgsLineString(
            [
                QgsPoint(a[0], a[1], a[2]),
                QgsPoint(b[0], b[1], b[2]),
                QgsPoint(c[0], c[1], c[2]),
                QgsPoint(a[0], a[1], a[2]),
            ]
        )
        ft = QgsFeature(campos)
        ft.setGeometry(QgsGeometry(QgsPolygon(anillo)))
        zs = (a[2], b[2], c[2])
        z_med = sum(zs) / 3.0
        centro = ((a[0] + b[0] + c[0]) / 3.0, (a[1] + b[1] + c[1]) / 3.0)
        zona, espesor = _zona(mesh, n - 1, centro, z_med, tz)
        area2 = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        ft.setAttributes(
            [
                n,
                zona,
                None if espesor is None else round(espesor, 4),
                round(abs(0.5 * area2), 5),
                round(min(zs), 4),
                round(max(zs), 4),
                round(z_med, 4),
                round(_pendiente_pct(a, b, c), 3),
            ]
        )
        yield ft


def features_pk(result) -> Iterator[QgsFeature]:
    """Puntos de PK redondos, con la etiqueta ``km+m`` y el azimut."""
    campos = fields_pk()
    for run in result.runs:
        for st in run.pks:
            z = st.z if st.z is not None else 0.0
            ft = QgsFeature(campos)
            ft.setGeometry(QgsGeometry(QgsPoint(st.x, st.y, z)))
            ft.setAttributes(
                [
                    run.alignment.fid,
                    run.alignment.part,
                    round(st.s, 3),
                    round(azimut(st), 4),
                    formato_pk(st.s),
                    round(z, 4),
                ]
            )
            yield ft


def features_eje(result) -> Iterator[QgsFeature]:
    """El eje de cada tramo como polilinea 3D, con la cota de proyecto."""
    campos = fields_eje()
    # El corredor pudo calcularse en otro idioma: el codigo guardado seria 'EJE'
    # en vez de 'AXIS'. Se prueban todas las formas.
    codigos = codigos_del_eje()
    for run in result.runs:
        pts = []
        for sec in run.sections:
            v = next(
                (w for w in (sec.vertex_by_code(c) for c in codigos) if w is not None),
                None,
            )
            if v is not None:
                pts.append(sec.world(v))
        if len(pts) < 2:
            continue
        ft = QgsFeature(campos)
        ft.setGeometry(_linea_z(pts))
        pks = [s.station.s for s in run.sections] or [0.0]
        ft.setAttributes(
            [
                run.alignment.fid,
                run.alignment.part,
                run.asm_nombre,
                round(min(pks), 4),
                round(max(pks), 4),
                round(_long_3d(pts), 4),
            ]
        )
        yield ft


def _pendiente_pct(a, b, c) -> float:
    """Pendiente maxima del plano del triangulo, en %."""
    ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
    vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    horiz = math.hypot(nx, ny)
    if abs(nz) < 1e-12:
        return 1.0e4
    return 100.0 * horiz / abs(nz)


def features_puntos(result) -> Iterator[QgsFeature]:
    campos = fields_puntos()
    for run in result.runs:
        for sec in run.sections:
            for v in sec.vertices:
                x, y, z = sec.world(v)
                ft = QgsFeature(campos)
                ft.setGeometry(QgsGeometry(QgsPoint(x, y, z)))
                ft.setAttributes(
                    [
                        run.alignment.fid,
                        run.alignment.part,
                        round(sec.station.s, 4),
                        v.code,
                        round(v.offset, 4),
                        round(v.z, 4),
                        v.kind,
                    ]
                )
                yield ft


# --------------------------------------------------------------------------
# Capas en memoria (para el dialogo)
# --------------------------------------------------------------------------

_WKB_NOMBRE = {
    QgsWkbTypes.LineStringZ: "LineStringZ",
    QgsWkbTypes.PolygonZ: "PolygonZ",
    QgsWkbTypes.PointZ: "PointZ",
}


def memory_layer(
    nombre: str,
    wkb,
    crs: QgsCoordinateReferenceSystem,
    campos: QgsFields,
    features,
) -> QgsVectorLayer:
    """Crea una capa en memoria y le mete los features."""
    tipo = _WKB_NOMBRE.get(wkb, "LineStringZ")
    uri = f"{tipo}?crs={crs.authid() if crs.isValid() else ''}"
    capa = QgsVectorLayer(uri, nombre, "memory")
    dp = capa.dataProvider()
    dp.addAttributes(list(campos))
    capa.updateFields()
    lote = list(features)
    if lote:
        dp.addFeatures(lote)
    capa.updateExtents()
    return capa


def nombre_de_grupo_libre(raiz, base: str) -> str:
    """``base``, o ``base (2)``, ``base (3)``... si ya hay un grupo asi.

    Cada calculo es una alternativa distinta, asi que no se reutiliza el grupo
    anterior: se crea uno nuevo al lado para poder comparar.
    """
    usados = {
        h.name()
        for h in raiz.children()
        if isinstance(h, QgsLayerTreeGroup)
    }
    if base not in usados:
        return base
    n = 2
    while f"{base} ({n})" in usados:
        n += 1
    return f"{base} ({n})"


#: Nombre visible de cada capa de salida, en ingles (el texto original). La
#: **clave** es interna y no se traduce nunca: es con lo que se decide el orden
#: de dibujo y que estilo le toca a cada capa. El nombre si se traduce, porque es
#: lo que se lee en el panel de capas.
ETIQUETAS_CAPA = {
    "mediciones": "earthworks",
    "pk": "stations",
    "puntos": "points",
    "lineas": "feature lines",
    "secciones": "cross sections",
    "eje": "axis",
    "huella": "footprint",
    "tin": "TIN",
    "tin_fusionado": "merged TIN",
}

#: Orden de dibujo de las capas de salida, de arriba abajo en el panel. El TIN
#: va al fondo porque es el unico relleno opaco; los PK arriba para que sus
#: etiquetas no queden tapadas.
ORDEN_CAPAS = (
    "mediciones",
    "pk",
    "puntos",
    "lineas",
    "secciones",
    "eje",
    "huella",
    "tin",
)


def etiqueta_capa(clave: str) -> str:
    """Nombre visible de una capa de salida, en el idioma que este puesto."""
    from ..i18n import t

    return t(ETIQUETAS_CAPA.get(clave, clave))


def clave_de_etiqueta(etiqueta: str) -> str:
    """Clave interna a partir del nombre de la capa, en **cualquier** idioma.

    Se reconocen todos los idiomas a proposito: un GeoPackage exportado desde una
    sesion en castellano trae las capas con el nombre castellano, y al importarlo
    en una sesion en ingles tiene que seguir recibiendo su estilo y su orden.
    """
    from ..i18n import todas_las_formas

    etiqueta = (etiqueta or "").strip()
    for clave, original in ETIQUETAS_CAPA.items():
        if etiqueta in todas_las_formas(original):
            return clave
    # El TIN lleva sufijos ('TIN fusionado', 'merged TIN'): basta con que la
    # etiqueta empiece o acabe por la palabra, que es igual en los dos idiomas.
    if "TIN" in etiqueta:
        return "tin"
    return ""


def _etiqueta_de_capa(capa) -> str:
    """Ultimo tramo del nombre: dentro de un grupo las capas van sin prefijo."""
    return capa.name().split(" - ")[-1]


def _prioridad(capa) -> int:
    clave = clave_de_etiqueta(_etiqueta_de_capa(capa))
    # El TIN fusionado ocupa el sitio del TIN: es el mismo relleno opaco.
    if clave == "tin_fusionado":
        clave = "tin"
    return ORDEN_CAPAS.index(clave) if clave in ORDEN_CAPAS else len(ORDEN_CAPAS)


def ordenar_para_dibujo(capas: list) -> list:
    """Ordena las capas de arriba abajo segun :data:`ORDEN_CAPAS`."""
    return sorted(capas, key=_prioridad)


def cargar_en_grupo(capas: list, nombre: str, proyecto=None):
    """Mete las capas en un grupo nuevo, arriba del panel de capas.

    Las capas se anaden con ``addMapLayer(capa, False)`` para que no aparezcan
    tambien en la raiz. ``addLayer`` va anadiendo por abajo, asi que se recorren
    en el orden de dibujo deseado: la primera queda arriba.
    """
    proyecto = proyecto or QgsProject.instance()
    raiz = proyecto.layerTreeRoot()
    grupo = raiz.insertGroup(0, nombre_de_grupo_libre(raiz, nombre))
    for capa in ordenar_para_dibujo(capas):
        proyecto.addMapLayer(capa, False)
        grupo.addLayer(capa)
    return grupo


def fields_medicion() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("tramo", T_STRING, 40),
        _f("pk_ini", T_DOUBLE, 14, 3),
        _f("pk_fin", T_DOUBLE, 14, 3),
        _f("longitud", T_DOUBLE, 12, 3),
        _f("area_des_ini", T_DOUBLE, 12, 3),
        _f("area_des_fin", T_DOUBLE, 12, 3),
        _f("area_ter_ini", T_DOUBLE, 12, 3),
        _f("area_ter_fin", T_DOUBLE, 12, 3),
        _f("vol_desmonte", T_DOUBLE, 16, 3),
        _f("vol_terraplen", T_DOUBLE, 16, 3),
        _f("vol_neto", T_DOUBLE, 16, 3),
        _f("acumulado", T_DOUBLE, 16, 3),
    ):
        f.append(c)
    return f


def features_medicion(result, esponjamiento: float = 1.0) -> Iterator[QgsFeature]:
    """Una fila por tramo entre secciones consecutivas, con sus volumenes."""
    from ..core.medicion import medir

    campos = fields_medicion()
    for run in result.runs:
        secs = [s for s in run.sections if s.vertices]
        m = medir(secs, esponjamiento=esponjamiento)
        acumulados = dict(m.masas)
        areas = {round(a.pk, 6): a for a in m.areas}
        for v in m.volumenes:
            a1 = areas.get(round(v.pk_ini, 6))
            a2 = areas.get(round(v.pk_fin, 6))
            ft = QgsFeature(campos)
            ft.setAttributes(
                [
                    run.etiqueta,
                    round(v.pk_ini, 4),
                    round(v.pk_fin, 4),
                    round(v.longitud, 4),
                    round(a1.desmonte, 4) if a1 else None,
                    round(a2.desmonte, 4) if a2 else None,
                    round(a1.terraplen, 4) if a1 else None,
                    round(a2.terraplen, 4) if a2 else None,
                    round(v.desmonte, 4),
                    round(v.terraplen, 4),
                    round(v.neto, 4),
                    round(acumulados.get(v.pk_fin, 0.0), 4),
                ]
            )
            yield ft


def tabla_medicion(result, nombre: str = "", esponjamiento: float = 1.0):
    """Capa sin geometria con la medicion de tierras."""
    nombre = nombre or etiqueta_capa("mediciones")
    campos = fields_medicion()
    capa = QgsVectorLayer("None", nombre, "memory")
    dp = capa.dataProvider()
    dp.addAttributes(list(campos))
    capa.updateFields()
    lote = list(features_medicion(result, esponjamiento))
    if lote:
        dp.addFeatures(lote)
    return capa


def nombre_grupo(capa_directrices) -> str:
    """Nombre del grupo de salida: ``<alineacion>-corredor``."""
    from ..i18n import t

    base = ""
    if capa_directrices is not None:
        try:
            base = capa_directrices.name() or ""
        except Exception:  # noqa: BLE001
            base = ""
    return f"{base or t('alignment')}-{t('corridor')}"


def _nombre_capa(prefijo: str, etiqueta: str) -> str:
    """Dentro de un grupo las capas van sin prefijo; sueltas, con el."""
    return f"{prefijo} - {etiqueta}" if prefijo else etiqueta


def layers_from_result(
    result,
    crs: QgsCoordinateReferenceSystem,
    prefijo: str = "",
    con_puntos: bool = False,
    con_triangulos: bool = True,
    fusionada: bool = False,
    tz=None,
    con_pk: bool = True,
) -> list:
    """Capas de salida en memoria, ya ordenadas para dibujar y con estilo.

    El orden es el de :data:`ORDEN_CAPAS`: de arriba abajo en el panel de capas,
    con el TIN al fondo y los PK arriba.

    ``tz`` es el muestreador del terreno; con el, los triangulos salen
    clasificados en desmonte / terraplen y con estilo aplicado.
    """
    capas = []
    if con_pk:
        capas.append(
            memory_layer(
                _nombre_capa(prefijo, etiqueta_capa("pk")),
                QgsWkbTypes.PointZ,
                crs,
                fields_pk(),
                features_pk(result),
            )
        )
    if con_triangulos:
        malla = result.mesh_final if fusionada else result.mesh
        etiqueta = etiqueta_capa("tin_fusionado" if fusionada else "tin")
        capas.append(
            memory_layer(
                _nombre_capa(prefijo, etiqueta),
                QgsWkbTypes.PolygonZ,
                crs,
                fields_triangulos(),
                features_triangulos(malla, tz),
            )
        )
    capas.append(
        memory_layer(
            _nombre_capa(prefijo, etiqueta_capa("huella")),
            QgsWkbTypes.PolygonZ,
            crs,
            fields_huella(),
            features_huella(result),
        )
    )
    capas.append(
        memory_layer(
            _nombre_capa(prefijo, etiqueta_capa("secciones")),
            QgsWkbTypes.LineStringZ,
            crs,
            fields_secciones(),
            features_secciones(result),
        )
    )
    capas.append(
        memory_layer(
            _nombre_capa(prefijo, etiqueta_capa("lineas")),
            QgsWkbTypes.LineStringZ,
            crs,
            fields_lineas(),
            features_lineas(result),
        )
    )
    if con_puntos:
        capas.append(
            memory_layer(
                _nombre_capa(prefijo, etiqueta_capa("puntos")),
                QgsWkbTypes.PointZ,
                crs,
                fields_puntos(),
                features_puntos(result),
            )
        )
    # El eje va justo encima del TIN pero debajo del resto de lineas, y con el
    # simbolo de carretera: es la "linea pekateada" sobre la que se rotulan los
    # PK. Se inserta antes de la huella para que quede en ese orden.
    capas.append(
        memory_layer(
            _nombre_capa(prefijo, etiqueta_capa("eje")),
            QgsWkbTypes.LineStringZ,
            crs,
            fields_eje(),
            features_eje(result),
        )
    )
    # Import diferido: 'estilos' necesita las constantes ZONA_* de este modulo,
    # asi que importarlo arriba seria circular.
    from .estilos import aplicar_estilos

    capas = ordenar_para_dibujo(capas)
    aplicar_estilos(capas)
    return capas


__all__ = [
    "fields_secciones",
    "fields_lineas",
    "fields_huella",
    "fields_triangulos",
    "fields_puntos",
    "features_secciones",
    "features_lineas",
    "features_huella",
    "features_triangulos",
    "features_puntos",
    "features_pk",
    "features_eje",
    "features_medicion",
    "fields_medicion",
    "tabla_medicion",
    "fields_pk",
    "fields_eje",
    "ZONA_DESMONTE",
    "ZONA_TERRAPLEN",
    "ZONA_COTA",
    "ZONA_TERRENO",
    "memory_layer",
    "layers_from_result",
    "nombre_grupo",
    "nombre_de_grupo_libre",
    "cargar_en_grupo",
    "ordenar_para_dibujo",
    "ORDEN_CAPAS",
    "ETIQUETAS_CAPA",
    "etiqueta_capa",
    "clave_de_etiqueta",
]
