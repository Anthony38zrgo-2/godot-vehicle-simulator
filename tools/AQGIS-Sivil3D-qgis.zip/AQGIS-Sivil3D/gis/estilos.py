"""Simbologia por defecto de las capas de salida.

El resultado tiene que entenderse sin que el usuario toque nada: el desmonte y
el terraplen en colores distintos, el eje con simbolo de carretera y los PK
rotulados como en el modelo "PK en QGIS".

Los colores son los mismos que usa la previsualizacion del editor
(``ui/section_preview.py``), para que lo que se ve al definir la seccion y lo
que sale en el mapa se lean igual.
"""

from __future__ import annotations

import os

from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsMarkerSymbol,
    QgsRendererCategory,
    QgsRuleBasedRenderer,
    QgsSimpleLineSymbolLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtGui import QColor

from .outputs import ZONA_COTA, ZONA_DESMONTE, ZONA_TERRAPLEN, ZONA_TERRENO
from .registro import avisar

CARPETA_ESTILOS = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "styles"
)

#: Los mismos colores que la previsualizacion de la seccion.
COLOR_DESMONTE = QColor(214, 170, 60)
COLOR_TERRAPLEN = QColor(90, 170, 90)
COLOR_COTA = QColor(150, 150, 150)
COLOR_TERRENO = QColor(196, 178, 150)

#: Etiqueta y color de cada zona, en el orden en que sale la leyenda.
ZONAS = (
    (ZONA_DESMONTE, "Desmonte (excavacion)", COLOR_DESMONTE),
    (ZONA_TERRAPLEN, "Terraplen (relleno)", COLOR_TERRAPLEN),
    (ZONA_COTA, "A cota (daylight)", COLOR_COTA),
    (ZONA_TERRENO, "Terreno natural", COLOR_TERRENO),
)


def _relleno(color: QColor, borde: QColor = None, ancho: float = 0.0):
    sym = QgsFillSymbol.createSimple(
        {
            "color": f"{color.red()},{color.green()},{color.blue()},190",
            "outline_style": "no" if borde is None else "solid",
            "outline_width": str(ancho),
        }
    )
    if borde is not None:
        sym.symbolLayer(0).setStrokeColor(borde)
    return sym


#: Rampa de la lamina de agua del vaso de un embalse: azul oscuro en el fondo y
#: azul claro cada vez mas transparente en la orilla, para que se vea el terreno
#: por debajo justo donde el calado es pequeno. Cada parada es
#: ``(posicion relativa, color, alfa)``; las posiciones se reparten entre la cota
#: minima y la maxima del recorte, asi que la rampa entra completa en cualquier
#: vaso sin tocar nada.
RAMPA_VASO = (
    (0.00, "#08306b", 255),
    (0.10, "#08519c", 255),
    (0.22, "#2171b5", 255),
    (0.35, "#4292c6", 255),
    (0.48, "#6baed6", 255),
    (0.61, "#9ecae1", 255),
    (0.74, "#b1d1ef", 188),
    (0.87, "#bddbf7", 162),
    (1.00, "#baefff", 102),
)


def estilo_vaso(capa, cota_min: float, cota_max: float) -> bool:
    """Pinta un raster de vaso de embalse como lamina de agua.

    ``cota_min`` y ``cota_max`` son las del propio recorte: la rampa se estira
    entre ellas, que es lo que hace que el mismo estilo valga para una balsa de
    3 m de calado y para un embalse de 60.
    """
    from qgis.core import (
        QgsColorRampShader,
        QgsRasterShader,
        QgsRasterTransparency,
        QgsSingleBandPseudoColorRenderer,
    )

    prov = getattr(capa, "dataProvider", None)
    if prov is None or not capa.isValid():
        return False
    if not (cota_max > cota_min):
        cota_max = cota_min + 1.0

    rampa = QgsColorRampShader(cota_min, cota_max)
    rampa.setColorRampType(QgsColorRampShader.Interpolated)
    rampa.setClip(True)
    items = []
    for t, hexa, alfa in RAMPA_VASO:
        valor = cota_min + (cota_max - cota_min) * t
        color = QColor(hexa)
        color.setAlpha(alfa)
        items.append(QgsColorRampShader.ColorRampItem(valor, color, f"{valor:.2f}"))
    rampa.setColorRampItemList(items)

    shader = QgsRasterShader()
    shader.setRasterShaderFunction(rampa)
    renderer = QgsSingleBandPseudoColorRenderer(capa.dataProvider(), 1, shader)
    renderer.setClassificationMin(cota_min)
    renderer.setClassificationMax(cota_max)

    # El 0 de un recorte es hueco, no una cota: se deja transparente.
    transparencia = QgsRasterTransparency()
    fila = QgsRasterTransparency.TransparentSingleValuePixel()
    fila.min = 0.0
    fila.max = 0.0
    fila.percentTransparent = 100.0
    transparencia.setTransparentSingleValuePixelList([fila])
    renderer.setRasterTransparency(transparencia)

    capa.setRenderer(renderer)
    capa.triggerRepaint()
    return True


def estilo_tin(capa) -> bool:
    """Categoriza el TIN por el campo ``zona``. Sin ese campo no hace nada."""
    if capa.fields().lookupField("zona") < 0:
        return False
    valores = {f["zona"] for f in capa.getFeatures()}
    if not valores or valores == {""}:
        return False  # no se paso el terreno: sin clasificar, mejor no colorear
    categorias = []
    for valor, etiqueta, color in ZONAS:
        if valor not in valores:
            continue
        categorias.append(
            QgsRendererCategory(valor, _relleno(color), etiqueta, True)
        )
    if not categorias:
        return False
    # Los triangulos sin clasificar (NoData bajo el centroide) en gris claro.
    categorias.append(
        QgsRendererCategory("", _relleno(QColor(220, 220, 220)), "sin clasificar", True)
    )
    capa.setRenderer(QgsCategorizedSymbolRenderer("zona", categorias))
    capa.setOpacity(0.85)
    capa.triggerRepaint()
    return True


def estilo_huella(capa) -> bool:
    """Solo contorno: la huella no debe tapar el TIN."""
    sym = QgsFillSymbol.createSimple(
        {
            "style": "no",
            "outline_style": "solid",
            "outline_color": "30,30,30,255",
            "outline_width": "0.5",
        }
    )
    capa.setRenderer(_renderer_simple(sym))
    capa.triggerRepaint()
    return True


def estilo_secciones(capa) -> bool:
    """Gris finas, y en rojo las que traen aviso, para localizarlas de un vistazo."""
    if capa.fields().lookupField("ok") < 0:
        return False
    base = QgsLineSymbol.createSimple({"color": "120,120,120,160", "width": "0.2"})
    raiz = QgsRuleBasedRenderer.Rule(None)
    mala = QgsRuleBasedRenderer.Rule(
        QgsLineSymbol.createSimple({"color": "200,40,40,255", "width": "0.6"}),
        filterExp='"ok" = 0',
        label="con aviso",
    )
    buena = QgsRuleBasedRenderer.Rule(base, filterExp="ELSE", label="seccion")
    raiz.appendChild(mala)
    raiz.appendChild(buena)
    capa.setRenderer(QgsRuleBasedRenderer(raiz))
    capa.triggerRepaint()
    return True


def estilo_lineas(capa) -> bool:
    """Lineas caracteristicas azules; las de daylight, mas gruesas y verdes."""
    if capa.fields().lookupField("codigo") < 0:
        return False
    raiz = QgsRuleBasedRenderer.Rule(None)
    raiz.appendChild(
        QgsRuleBasedRenderer.Rule(
            QgsLineSymbol.createSimple({"color": "0,130,60,255", "width": "0.6"}),
            filterExp="\"codigo\" LIKE 'DAYLIGHT%'",
            label="daylight",
        )
    )
    raiz.appendChild(
        QgsRuleBasedRenderer.Rule(
            QgsLineSymbol.createSimple({"color": "20,90,190,255", "width": "0.3"}),
            filterExp="ELSE",
            label="linea caracteristica",
        )
    )
    capa.setRenderer(QgsRuleBasedRenderer(raiz))
    capa.triggerRepaint()
    return True


def estilo_puntos(capa) -> bool:
    sym = QgsMarkerSymbol.createSimple(
        {"name": "circle", "size": "1.2", "color": "20,90,190,200", "outline_style": "no"}
    )
    capa.setRenderer(_renderer_simple(sym))
    capa.triggerRepaint()
    return True


def _renderer_simple(simbolo):
    from qgis.core import QgsSingleSymbolRenderer

    return QgsSingleSymbolRenderer(simbolo)


# --------------------------------------------------------------------------
# Estilos que vienen de archivo (los del modelo "PK en QGIS")
# --------------------------------------------------------------------------


def aplicar_qml(capa, nombre: str) -> bool:
    """Carga un ``.qml`` de la carpeta ``styles`` del plugin."""
    ruta = os.path.join(CARPETA_ESTILOS, nombre)
    if not os.path.exists(ruta):
        return False
    try:
        _mensaje, ok = capa.loadNamedStyle(ruta)
    except Exception:  # noqa: BLE001
        return False
    if ok:
        capa.triggerRepaint()
    return bool(ok)


def estilo_pk(capa) -> bool:
    """Rotulacion de PK: etiqueta ``km+m`` girada y separada del eje.

    Se aplica el QML del modelo "PK en QGIS", que espera los campos ``P.K.`` y
    ``angle``; :func:`~aqgis_sivil3d.gis.outputs.fields_pk` los crea con
    esos nombres justamente para esto. Si el archivo no esta, se cae a un estilo
    equivalente construido a mano.
    """
    if aplicar_qml(capa, "pk_puntos.qml"):
        return True
    return _estilo_pk_manual(capa)


def _estilo_pk_manual(capa) -> bool:
    """Alternativa sin QML: marca perpendicular al eje y etiqueta girada."""
    from qgis.core import (
        QgsPalLayerSettings,
        QgsProperty,
        QgsTextFormat,
        QgsVectorLayerSimpleLabeling,
    )

    marca = QgsMarkerSymbol.createSimple(
        {"name": "line", "size": "3", "color": "183,72,75,255", "angle": "0"}
    )
    # La marca se gira con el azimut para que quede perpendicular al eje.
    capa_marca = marca.symbolLayer(0)
    try:
        from qgis.core import QgsSymbolLayer

        capa_marca.setDataDefinedProperty(
            QgsSymbolLayer.PropertyAngle, QgsProperty.fromExpression('-"angle"')
        )
    except Exception as exc:  # noqa: BLE001
        avisar("marca de PK sin giro por atributo", exc)
    capa.setRenderer(_renderer_simple(marca))

    ajustes = QgsPalLayerSettings()
    ajustes.fieldName = '"P.K."'
    ajustes.isExpression = True
    fmt = QgsTextFormat()
    fmt.setSize(9)
    ajustes.setFormat(fmt)
    try:
        ajustes.dataDefinedProperties().setProperty(
            QgsPalLayerSettings.LabelRotation, QgsProperty.fromExpression('-"angle"')
        )
        ajustes.dataDefinedProperties().setProperty(
            QgsPalLayerSettings.PositionX,
            QgsProperty.fromExpression('$x + 10 * cos(pi() - ("angle" * pi() / 180))'),
        )
        ajustes.dataDefinedProperties().setProperty(
            QgsPalLayerSettings.PositionY,
            QgsProperty.fromExpression('$y + 10 * sin(pi() - ("angle" * pi() / 180))'),
        )
    except Exception as exc:  # noqa: BLE001
        avisar("rotulos de PK sin giro ni desplazamiento por atributo", exc)
    capa.setLabeling(QgsVectorLayerSimpleLabeling(ajustes))
    capa.setLabelsEnabled(True)
    capa.triggerRepaint()
    return True


def estilo_eje(capa) -> bool:
    """Simbolo de carretera para el eje (el QML del modelo, o uno equivalente)."""
    if aplicar_qml(capa, "pk_eje.qml"):
        return True
    sym = QgsLineSymbol.createSimple({"color": "255,255,255,255", "width": "1.4"})
    for offset in (-0.7, 0.7):
        borde = QgsSimpleLineSymbolLayer(QColor(219, 30, 42), 0.66)
        borde.setOffset(offset)
        sym.appendSymbolLayer(borde)
    capa.setRenderer(_renderer_simple(sym))
    capa.triggerRepaint()
    return True


# --------------------------------------------------------------------------

#: Clave interna de la capa -> funcion de estilo. La clave se deduce del nombre
#: de la capa en ``outputs.clave_de_etiqueta``, que reconoce el nombre en
#: cualquiera de los idiomas: asi un GeoPackage exportado en castellano tambien
#: recibe su estilo al abrirlo en una sesion en ingles.
POR_CLAVE = {
    "pk": estilo_pk,
    "eje": estilo_eje,
    "tin": estilo_tin,
    "tin_fusionado": estilo_tin,
    "huella": estilo_huella,
    "secciones": estilo_secciones,
    "lineas": estilo_lineas,
    "puntos": estilo_puntos,
}


def aplicar_estilos(capas) -> None:
    """Aplica a cada capa el estilo que le corresponda por su nombre."""
    from .outputs import clave_de_etiqueta

    for capa in capas:
        if capa is None or not capa.isValid():
            continue
        nombre = capa.name()
        # Dentro de un grupo las capas van sin prefijo; sueltas, con el.
        funcion = POR_CLAVE.get(clave_de_etiqueta(nombre.split(" - ")[-1]))
        if funcion is None:
            continue
        try:
            funcion(capa)
        except Exception as exc:  # noqa: BLE001 - no debe romper nada
            avisar(f"capa '{nombre}' sin estilo por defecto", exc)


# --------------------------------------------------------------------------
# Capas de dibujo en espacio papel
# --------------------------------------------------------------------------

#: Grosor de linea de cada clase de entidad, en mm de papel. Los valores son los
#: habituales de delineacion: la rejilla fina apenas se ve, el proyecto manda.
GROSOR_LAMINA = {
    "proyecto": ("20,90,190,255", "0.5"),
    "terreno": ("120,80,40,255", "0.35"),
    "eje": ("120,120,120,255", "0.2"),
    "marco": ("40,40,40,255", "0.3"),
    "rejilla": ("190,190,190,255", "0.15"),
    "rejilla_fina": ("215,215,215,255", "0.1"),
    "guitarra": ("60,60,60,255", "0.2"),
    # La traza de OTRO corredor: morada y a trazos, para que no se confunda con
    # el proyecto que se esta dibujando.
    "otro_corredor": ("120,60,170,255", "0.35"),
}

#: Clases de linea que se dibujan discontinuas.
DISCONTINUAS = {"otro_corredor": "2;1.2"}


def estilo_lamina_lineas(capa) -> bool:
    """Cada clase de linea con su color y grosor de delineacion."""
    if capa.fields().lookupField("clase") < 0:
        return False
    raiz = QgsRuleBasedRenderer.Rule(None)
    for clase, (color, ancho) in GROSOR_LAMINA.items():
        ajustes = {"color": color, "width": ancho}
        trazo = DISCONTINUAS.get(clase)
        if trazo:
            ajustes["line_style"] = "dash"
            ajustes["use_custom_dash"] = "1"
            ajustes["customdash"] = trazo
        raiz.appendChild(
            QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple(ajustes),
                filterExp=f"\"clase\" = '{clase}'",
                label=clase,
            )
        )
    raiz.appendChild(
        QgsRuleBasedRenderer.Rule(
            QgsLineSymbol.createSimple({"color": "80,80,80,255", "width": "0.2"}),
            filterExp="ELSE",
            label="otras",
        )
    )
    capa.setRenderer(QgsRuleBasedRenderer(raiz))
    capa.triggerRepaint()
    return True


def estilo_lamina_poligonos(capa) -> bool:
    """Desmonte y terraplen con los mismos colores que el TIN; marco sin relleno."""
    if capa.fields().lookupField("clase") < 0:
        return False
    categorias = [
        QgsRendererCategory(
            "desmonte", _relleno(COLOR_DESMONTE), "Desmonte", True
        ),
        QgsRendererCategory(
            "terraplen", _relleno(COLOR_TERRAPLEN), "Terraplen", True
        ),
    ]
    for clase, etiqueta in (("marco", "Marco"), ("guitarra", "Guitarra")):
        sym = QgsFillSymbol.createSimple(
            {
                "style": "no",
                "outline_style": "solid",
                "outline_color": "40,40,40,255",
                "outline_width": "0.3",
            }
        )
        categorias.append(QgsRendererCategory(clase, sym, etiqueta, True))
    capa.setRenderer(QgsCategorizedSymbolRenderer("clase", categorias))
    capa.triggerRepaint()
    return True


def _sin_descarte(ajustes) -> None:
    """Que no se descarte ninguna etiqueta por colision.

    En un plano las cifras tienen que estar todas aunque se toquen: si QGIS decide
    cuales quita, la tabla queda con huecos.
    """
    for atributo, valor in (
        ("displayAll", True),          # no descartar ninguna etiqueta
        ("obstacle", False),           # ni estorbar a las demas
        ("labelPerPart", False),
    ):
        try:
            setattr(ajustes, atributo, valor)
        except Exception as exc:  # noqa: BLE001
            avisar(f"ajuste de etiquetado '{atributo}' no disponible", exc)


def _props_de_lamina(props, clase_ajustes, clase_prop):
    """Altura, giro y anclaje del rotulo, cada uno desde su campo de la capa."""
    for clave, expresion in (
        ("Size", '"altura"'),
        ("LabelRotation", '"angulo"'),
        ("Hali", '"hali"'),
        ("Vali", '"vali"'),
    ):
        prop = getattr(clase_ajustes, clave, None)
        if prop is None:
            continue
        try:
            props.setProperty(prop, clase_prop.fromExpression(expresion))
        except Exception as exc:  # noqa: BLE001
            avisar(f"propiedad de etiquetado '{clave}' no disponible", exc)
    return props


def estilo_lamina_rotulos(capa) -> bool:
    """Los rotulos son puntos invisibles: lo que se ve es la etiqueta.

    Tres cosas importan aqui, y las tres se sacan de campos de la capa:

    * la **altura** del texto va en milimetros de mapa, que en espacio papel son
      milimetros de papel de verdad;
    * el **anclaje** (``hali``/``vali``) es lo que evita que un rotulo se meta
      dentro del marco o pise la rejilla: las cotas van pegadas por la derecha al
      borde izquierdo, las abscisas colgando por debajo, etc.;
    * se **desactiva el descarte por colision**, porque en un plano las cifras
      tienen que estar todas aunque se toquen; si QGIS decide cuales quita, la
      tabla queda con huecos.
    """
    if capa.fields().lookupField("texto") < 0:
        return False
    from qgis.core import (
        QgsPalLayerSettings,
        QgsProperty,
        QgsTextFormat,
        QgsUnitTypes,
        QgsVectorLayerSimpleLabeling,
    )

    capa.setRenderer(
        _renderer_simple(
            QgsMarkerSymbol.createSimple(
                {"name": "circle", "size": "0", "outline_style": "no"}
            )
        )
    )

    ajustes = QgsPalLayerSettings()
    ajustes.fieldName = "texto"
    ajustes.isExpression = False
    fmt = QgsTextFormat()
    fmt.setSize(2.2)
    try:
        fmt.setSizeUnit(QgsUnitTypes.RenderMapUnits)
    except Exception as exc:  # noqa: BLE001
        avisar("altura de rotulo en unidades de mapa no disponible", exc)
    ajustes.setFormat(fmt)
    # Colocacion sobre el punto: es la unica que respeta hali/vali.
    ajustes.placement = _miembro_pal(QgsPalLayerSettings, "OverPoint", "Placement")
    _sin_descarte(ajustes)
    ajustes.setDataDefinedProperties(
        _props_de_lamina(ajustes.dataDefinedProperties(), QgsPalLayerSettings, QgsProperty)
    )
    capa.setLabeling(QgsVectorLayerSimpleLabeling(ajustes))
    capa.setLabelsEnabled(True)
    try:
        capa.setLabelsEnabled(True)
        capa.labeling().settings().setFormat(fmt)
    except Exception as exc:  # noqa: BLE001
        avisar("formato de rotulo de lamina no aplicado", exc)
    capa.triggerRepaint()
    return True


def _miembro_pal(clase, nombre: str, ambito: str):
    """Miembro de enum de etiquetado, con ambito (Qt6/QGIS4) o sin el."""
    sub = getattr(clase, ambito, None)
    if sub is not None and hasattr(sub, nombre):
        return getattr(sub, nombre)
    return getattr(clase, nombre)


def estilo_hojas(capa) -> bool:
    """Rectangulos de hoja: solo contorno, con el numero de hoja rotulado."""
    from qgis.core import (
        QgsPalLayerSettings,
        QgsTextFormat,
        QgsVectorLayerSimpleLabeling,
    )

    sym = QgsFillSymbol.createSimple(
        {
            "style": "no",
            "outline_style": "dash",
            "outline_color": "200,60,60,255",
            "outline_width": "0.4",
        }
    )
    capa.setRenderer(_renderer_simple(sym))
    if capa.fields().lookupField("hoja") >= 0:
        ajustes = QgsPalLayerSettings()
        ajustes.fieldName = "'Hoja ' || \"hoja\""
        ajustes.isExpression = True
        fmt = QgsTextFormat()
        fmt.setSize(9)
        ajustes.setFormat(fmt)
        capa.setLabeling(QgsVectorLayerSimpleLabeling(ajustes))
        capa.setLabelsEnabled(True)
    capa.triggerRepaint()
    return True


__all__ = [
    "aplicar_estilos",
    "aplicar_qml",
    "estilo_lamina_lineas",
    "estilo_lamina_poligonos",
    "estilo_lamina_rotulos",
    "estilo_hojas",
    "estilo_tin",
    "estilo_huella",
    "estilo_secciones",
    "estilo_lineas",
    "estilo_puntos",
    "estilo_pk",
    "estilo_eje",
    "ZONAS",
]
