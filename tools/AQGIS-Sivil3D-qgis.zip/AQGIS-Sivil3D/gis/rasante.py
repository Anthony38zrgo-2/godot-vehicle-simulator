"""Escribir una cota en la Z de la directriz.

Sirve para pasar de «calculo con cota constante» a «la directriz lleva su propia
rasante»: se fija la Z de todos los vertices a una cota y a partir de ahi la capa
ya se puede usar con la opcion *cota del eje = Z de la directriz*, y editar la
rasante vertice a vertice si hace falta.

Un limite que no se puede sortear: **el tipo de geometria lo fija el proveedor de
la capa**. Si la capa es ``LineString`` a secas, no hay forma de meterle Z sin
recrearla; el proveedor la descartaria al guardar. Por eso hay dos caminos:

* la capa **ya admite Z** (``LineStringZ``): se edita en el sitio, dentro de una
  sesion de edicion normal, y queda en el historial de deshacer de QGIS;
* la capa **es 2D**: se crea una capa nueva con los mismos campos y atributos,
  con la Z puesta, y se deja al usuario decidir si sustituye la original.
"""

from __future__ import annotations

import math
from typing import Optional, Sequence

from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsLineString,
    QgsMultiLineString,
    QgsPoint,
    QgsVectorLayer,
    QgsWkbTypes,
)


def admite_z(capa) -> bool:
    """True si el proveedor de la capa puede guardar coordenada Z."""
    return bool(capa is not None and QgsWkbTypes.hasZ(capa.wkbType()))


def puede_editar_geometrias(capa) -> bool:
    caps = capa.dataProvider().capabilities()
    return bool(caps & capa.dataProvider().ChangeGeometries)


def con_z(geom: QgsGeometry, cota: float) -> Optional[QgsGeometry]:
    """Copia de la geometria con **todos** los vertices a la cota dada.

    Se quita la Z que hubiera y se vuelve a poner: asi el resultado es uniforme
    tanto si la geometria era 2D como si ya tenia cotas distintas.
    """
    if geom is None or geom.isEmpty():
        return None
    interna = geom.constGet().clone()
    if QgsWkbTypes.hasZ(interna.wkbType()):
        interna.dropZValue()
    if not interna.addZValue(float(cota)):
        return None
    return QgsGeometry(interna)


def con_z_variable(geom: QgsGeometry, z_de) -> Optional[QgsGeometry]:
    """Copia de la geometria con la Z que devuelva ``z_de(x, y)`` en cada vertice.

    Es el drapeado: la linea se apoya en el terreno. Si el terreno no tiene datos
    en algun vertice, ``z_de`` devuelve ``None`` y aqui se devuelve ``None``: mejor
    dejar ese feature sin tocar que meterle una cota inventada.
    """
    if geom is None or geom.isEmpty():
        return None
    partes = []
    for parte in geom.constParts():
        puntos = []
        for v in parte.vertices():
            z = z_de(v.x(), v.y())
            if z is None:
                return None
            puntos.append(QgsPoint(v.x(), v.y(), float(z)))
        if len(puntos) < 2:
            return None
        partes.append(QgsLineString(puntos))
    if not partes:
        return None
    if len(partes) == 1 and not QgsWkbTypes.isMultiType(geom.wkbType()):
        return QgsGeometry(partes[0])
    multi = QgsMultiLineString()
    for linea in partes:
        multi.addGeometry(linea)
    return QgsGeometry(multi)


def _capa_z(original, nombre: str) -> QgsVectorLayer:
    """Capa en memoria con Z, con los mismos campos y sistema de referencia."""
    tipo = QgsWkbTypes.displayString(
        QgsWkbTypes.addZ(QgsWkbTypes.singleType(original.wkbType()))
    )
    if QgsWkbTypes.isMultiType(original.wkbType()):
        tipo = QgsWkbTypes.displayString(QgsWkbTypes.addZ(original.wkbType()))
    crs = original.crs()
    uri = f"{tipo}?crs={crs.authid()}" if crs.isValid() else tipo
    capa = QgsVectorLayer(uri, nombre, "memory")
    dp = capa.dataProvider()
    dp.addAttributes(list(original.fields()))
    capa.updateFields()
    return capa


def asignar_cota(
    capa,
    cota: float,
    solo_seleccionados: bool = False,
    terreno=None,
    offset: float = 0.0,
    nombre_copia: str = "",
) -> tuple:
    """Escribe la Z de la directriz.

    Con ``terreno`` se **drapea**: cada vertice toma la cota del terreno mas
    ``offset``. Sin ``terreno`` se pone la cota fija ``cota`` en todos.

    Devuelve ``(ok, mensajes, capa_nueva)``. ``capa_nueva`` es ``None`` cuando se
    ha podido editar la capa original; si la capa era 2D, trae la copia con Z.
    """
    if capa is None or not capa.isValid():
        return False, ["la capa no es valida"], None
    if capa.geometryType() != QgsWkbTypes.LineGeometry:
        return False, ["la directriz tiene que ser una capa de lineas"], None
    if solo_seleccionados and not list(capa.selectedFeatureIds()):
        return False, ["no hay ningun feature seleccionado"], None

    calcula, etiqueta, sufijo = _calculadora(cota, terreno, offset, nombre_copia)
    origen = capa.selectedFeatures() if solo_seleccionados else capa.getFeatures()
    if admite_z(capa) and puede_editar_geometrias(capa):
        return _cota_en_el_sitio(capa, origen, calcula, etiqueta)
    return _cota_en_copia(capa, origen, calcula, etiqueta, sufijo)


def _calculadora(cota, terreno, offset, nombre_copia) -> tuple:
    """``(calcula, etiqueta, sufijo)`` segun se drape o se ponga cota fija."""
    if terreno is None:
        return (
            lambda g: con_z(g, cota),
            f"{cota:.3f} m",
            nombre_copia or f"Z={cota:g}",
        )

    def z_de(x, y):
        """Cota del terreno mas el offset, o None si el DEM no tiene datos."""
        z = terreno(x, y)
        return None if z is None else z + offset

    return (
        lambda g: con_z_variable(g, z_de),
        f"terreno {offset:+.3f} m",
        nombre_copia or f"Z=terreno{offset:+g}",
    )


def _omitidas(n: int) -> list:
    """Mensaje de las features que se han quedado sin tocar, si ha habido alguna."""
    if not n:
        return []
    return [
        f"{n} features omitidas (geometria vacia o el terreno no tiene datos en "
        "algun vertice)"
    ]


def _cota_en_el_sitio(capa, origen, calcula, etiqueta: str) -> tuple:
    """Camino 1: la capa admite Z, asi que se edita en una sesion de edicion."""
    cambios = {}
    saltados = 0
    for f in origen:
        g = calcula(f.geometry())
        if g is None:
            saltados += 1
            continue
        cambios[f.id()] = g
    if not cambios:
        return False, ["ninguna geometria se ha podido modificar"], None
    if not capa.isEditable() and not capa.startEditing():
        return False, ["no se puede poner la capa en edicion"], None
    if not capa.dataProvider().changeGeometryValues(cambios):
        capa.rollBack()
        return False, ["el proveedor ha rechazado el cambio de geometrias"], None
    if not capa.commitChanges():
        errores = "; ".join(capa.commitErrors()[:3])
        capa.rollBack()
        return False, [f"no se han podido guardar los cambios: {errores}"], None
    capa.triggerRepaint()
    mensajes = [
        f"'{capa.name()}': Z puesta a {etiqueta} en {len(cambios)} "
        f"{'feature' if len(cambios) == 1 else 'features'}"
    ]
    return True, mensajes + _omitidas(saltados), None


def _cota_en_copia(capa, origen, calcula, etiqueta: str, sufijo: str) -> tuple:
    """Camino 2: la capa es 2D, asi que se crea una nueva con la Z puesta."""
    nueva = _capa_z(capa, f"{capa.name()} ({sufijo})")
    feats = []
    saltados = 0
    for f in origen:
        g = calcula(f.geometry())
        if g is None:
            saltados += 1
            continue
        nf = QgsFeature(nueva.fields())
        nf.setGeometry(g)
        nf.setAttributes(f.attributes())
        feats.append(nf)
    if not feats:
        return False, ["ninguna geometria se ha podido convertir"], None
    nueva.dataProvider().addFeatures(feats)
    nueva.updateExtents()
    razon = (
        "la capa original es 2D y su proveedor no puede guardar Z"
        if not admite_z(capa)
        else "la capa original no admite cambios de geometria"
    )
    mensajes = [
        f"{razon}, asi que se ha creado '{nueva.name()}' con {len(feats)} "
        f"{'feature' if len(feats) == 1 else 'features'} y la Z a {etiqueta}"
    ]
    return True, mensajes + _omitidas(saltados), nueva


# ------------------------------------------------------- rasante proyectada
def abscisas(pts) -> list:
    """Abscisa acumulada de cada vertice de la polilinea ``[(x, y, z|None)]``."""
    salida = [0.0]
    for (x0, y0, *_r0), (x1, y1, *_r1) in zip(pts, pts[1:]):
        salida.append(salida[-1] + math.hypot(x1 - x0, y1 - y0))
    return salida


def punto_en(pts, s: float, acum=None) -> tuple:
    """``(x, y)`` de la polilinea a la abscisa ``s``, interpolando en el tramo.

    ``acum`` son las abscisas acumuladas, si ya se tienen: calcularlas aqui costaria
    recorrer la polilinea entera **en cada llamada**, y eso convierte en cuadratico
    lo que deberia ser lineal.
    """
    if acum is None:
        acum = abscisas(pts)
    if s <= acum[0]:
        return (pts[0][0], pts[0][1])
    if s >= acum[-1]:
        return (pts[-1][0], pts[-1][1])
    # Busqueda binaria del tramo que contiene s.
    lo, hi = 0, len(acum) - 1
    while hi - lo > 1:
        medio = (lo + hi) // 2
        if acum[medio] <= s:
            lo = medio
        else:
            hi = medio
    largo = acum[hi] - acum[lo]
    t = 0.0 if largo < 1e-12 else (s - acum[lo]) / largo
    x0, y0 = pts[lo][0], pts[lo][1]
    x1, y1 = pts[hi][0], pts[hi][1]
    return (x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)


def perfil_del_terreno(pts, terreno, paso: float = 5.0) -> list:
    """Perfil longitudinal del terreno bajo la directriz: ``[(s, z)]``.

    Se muestrea al paso pedido y **siempre en los vertices**, que es donde el
    terreno puede quebrarse porque la directriz cambia de direccion. Los puntos
    sin dato del DEM se omiten en vez de inventarlos.
    """
    if len(pts) < 2 or terreno is None:
        return []
    acum = abscisas(pts)
    total = acum[-1]
    marcas = set(acum)
    n = max(1, int(math.ceil(total / max(paso, 1e-6))))
    marcas.update(total * i / n for i in range(n + 1))
    salida = []
    for s in sorted(marcas):
        x, y = punto_en(pts, s, acum)
        z = terreno(x, y)
        if z is None:
            continue
        salida.append((s, float(z)))
    return salida


def rasante_de_geometria(pts, tolerancia: float = 0.05) -> "object":
    """Rasante sacada de la Z que ya tiene la directriz.

    Es el punto de partida cuando la capa ya lleva una rasante proyectada: se
    lee, se edita en el editor y se vuelve a escribir.

    ``tolerancia`` **simplifica** al leer, en metros de cota. Hace falta porque
    una directriz puede tener cientos de vertices —y mas si la rasante se escribio
    densificada—, y arrastrar eso vertice a vertice no hay quien lo maneje. Con 0
    se leen todos.
    """
    from ..core.rasante_geom import Rasante

    acum = abscisas(pts)
    puntos = [
        (s, float(p[2]))
        for s, p in zip(acum, pts)
        if len(p) > 2 and p[2] is not None
    ]
    if len(puntos) < 2:
        return Rasante()
    return Rasante.de_puntos(puntos, tolerancia=tolerancia)


def puntos_con_rasante(pts, rasante, paso: float = 0.0) -> Optional[list]:
    """``[(x, y, z)]`` de la directriz con la Z que le da la rasante.

    Con ``paso`` mayor que cero se **densifica**: se meten vertices intermedios a
    ese paso ademas de los que ya hay. Hace falta cuando la rasante lleva
    acuerdos o segmentos curvos, porque una parabola entre dos vertices lejanos
    se perderia al escribir solo sus extremos.
    """
    if len(pts) < 2 or rasante is None or rasante.vacia:
        return None
    acum = abscisas(pts)
    marcas = set(acum)
    if paso > 0.0:
        total = acum[-1]
        n = max(1, int(math.ceil(total / paso)))
        marcas.update(total * i / n for i in range(n + 1))
        # Y los puntos singulares de la rasante: vertices y extremos de acuerdo.
        for pieza in rasante.piezas():
            marcas.add(min(max(pieza.s_ini, 0.0), total))
            marcas.add(min(max(pieza.s_fin, 0.0), total))
    orden = sorted(marcas)
    cotas = rasante.cotas_en(orden)
    salida = []
    for s, z in zip(orden, cotas):  # noqa: B007 - se usan los dos
        if z is None:
            # Fuera del rango de la rasante se prolonga con su extremo: mejor eso
            # que dejar el vertice sin cota y perder la geometria entera.
            z = rasante.z_en(min(max(s, rasante.s_ini), rasante.s_fin))
        if z is None:
            return None
        x, y = punto_en(pts, s, acum)
        salida.append((x, y, float(z)))
    return salida


def aplicar_rasante(
    capa,
    rasante,
    fid: int,
    part: int = 0,
    paso: float = 5.0,
    nombre_copia: str = "",
) -> tuple:
    """Escribe la rasante en la Z del feature ``fid`` de la directriz.

    Devuelve ``(ok, mensajes, capa_nueva)`` igual que :func:`asignar_cota`: si la
    capa admite Z se edita en el sitio, y si es 2D se crea una copia con Z.
    """
    from qgis.core import QgsFeatureRequest

    if capa is None or not capa.isValid():
        return False, ["la capa no es valida"], None
    if capa.geometryType() != QgsWkbTypes.LineGeometry:
        return False, ["la directriz tiene que ser una capa de lineas"], None
    if rasante is None or rasante.vacia:
        return False, ["la rasante necesita al menos dos vertices"], None

    feature = None
    for f in capa.getFeatures(QgsFeatureRequest().setFilterFid(fid)):
        feature = f
        break
    if feature is None:
        return False, [f"no se ha encontrado el feature {fid}"], None

    from .alignment import parts_of

    partes = parts_of(feature.geometry())
    if not (0 <= part < len(partes)):
        return False, [f"el feature {fid} no tiene la parte {part}"], None
    nuevos = puntos_con_rasante(partes[part], rasante, paso)
    if nuevos is None:
        return False, ["la rasante no cubre la directriz"], None

    geom = _geometria_con_parte(capa, partes, part, nuevos)
    detalle = (
        f"{len(nuevos)} vertices, cotas de {min(z for _x, _y, z in nuevos):.2f} a "
        f"{max(z for _x, _y, z in nuevos):.2f} m"
    )
    if admite_z(capa) and puede_editar_geometrias(capa):
        return _rasante_en_el_sitio(capa, fid, geom, detalle)
    return _rasante_en_copia(capa, feature, geom, detalle, nombre_copia)


def _geometria_con_parte(capa, partes, part: int, nuevos) -> QgsGeometry:
    """Geometria completa con la parte ``part`` sustituida por los puntos nuevos.

    Las demas partes se copian con la Z que tuvieran: escribir la rasante de un
    tramo no debe estropear el resto de una multilinea.
    """
    lineas = []
    for i, parte in enumerate(partes):
        if i == part:
            lineas.append(QgsLineString([QgsPoint(x, y, z) for x, y, z in nuevos]))
            continue
        lineas.append(
            QgsLineString(
                [
                    QgsPoint(
                        p[0],
                        p[1],
                        float(p[2]) if len(p) > 2 and p[2] is not None else 0.0,
                    )
                    for p in parte
                ]
            )
        )
    if len(lineas) == 1 and not QgsWkbTypes.isMultiType(capa.wkbType()):
        return QgsGeometry(lineas[0])
    multi = QgsMultiLineString()
    for linea in lineas:
        multi.addGeometry(linea)
    return QgsGeometry(multi)


def _rasante_en_el_sitio(capa, fid: int, geom, detalle: str) -> tuple:
    """La capa admite Z: se cambia la geometria del feature y se guarda."""
    if not capa.isEditable() and not capa.startEditing():
        return False, ["no se puede poner la capa en edicion"], None
    if not capa.dataProvider().changeGeometryValues({fid: geom}):
        capa.rollBack()
        return False, ["el proveedor ha rechazado el cambio de geometria"], None
    if not capa.commitChanges():
        errores = "; ".join(capa.commitErrors()[:3])
        capa.rollBack()
        return False, [f"no se han podido guardar los cambios: {errores}"], None
    capa.triggerRepaint()
    return True, [f"rasante escrita en '{capa.name()}' fid {fid}: {detalle}"], None


def _rasante_en_copia(capa, feature, geom, detalle: str, nombre_copia: str) -> tuple:
    """La capa es 2D: se crea una capa nueva con la rasante puesta."""
    nueva = _capa_z(capa, nombre_copia or f"{capa.name()} (rasante)")
    nf = QgsFeature(nueva.fields())
    nf.setGeometry(geom)
    nf.setAttributes(feature.attributes())
    nueva.dataProvider().addFeatures([nf])
    nueva.updateExtents()
    razon = (
        "la capa original es 2D y su proveedor no puede guardar Z"
        if not admite_z(capa)
        else "la capa original no admite cambios de geometria"
    )
    return (
        True,
        [f"{razon}, asi que se ha creado '{nueva.name()}' con la rasante: {detalle}"],
        nueva,
    )


__all__ = [
    "admite_z",
    "puede_editar_geometrias",
    "con_z",
    "con_z_variable",
    "asignar_cota",
    "abscisas",
    "punto_en",
    "perfil_del_terreno",
    "rasante_de_geometria",
    "puntos_con_rasante",
    "aplicar_rasante",
]
