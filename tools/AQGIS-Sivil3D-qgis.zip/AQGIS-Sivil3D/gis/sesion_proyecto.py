"""Corredores que sobreviven al cierre de QGIS.

Un corredor calculado vive en memoria: sus secciones resueltas no estan en
ninguna capa, y son lo que necesitan el visor de perfiles y el generador de
planos. Al cerrar QGIS se perdian, y al reabrir un proyecto con el grupo de capas
delante las herramientas decian «no hay corredores», que es exactamente lo que no
se espera.

Aqui estan las dos maneras de recuperarlos, y se usan las dos:

1. **El archivo de la sesion.** Al guardar el proyecto se escribe
   ``<proyecto>.sivil3d.json`` con los corredores registrados. Al abrirlo se
   leen. Es el camino normal y no necesita nada mas que guardar el proyecto.
2. **El JSON hermano de un GeoPackage exportado.** Si en el proyecto hay capas
   que salen de un ``.gpkg`` exportado con la herramienta de paquetes, al lado
   estara su ``.corredor.json``. Sirve aunque el proyecto no se haya guardado
   nunca, y es lo que recupera los corredores de un compañero.

El formato es el mismo de :mod:`core.sesion`, asi que un corredor recuperado se
usa igual que uno recien calculado.
"""

from __future__ import annotations

import json
import os
from typing import Optional

from qgis.core import QgsProject, QgsVectorLayer

from ..core import sesion
from .paquete import SUFIJO_JSON, ruta_json
from .registro import avisar

#: Sufijo del archivo de sesion, hermano del proyecto.
SUFIJO_SESION = ".sivil3d.json"


def ruta_de_sesion(proyecto=None) -> str:
    """``<proyecto>.sivil3d.json``, o cadena vacia si el proyecto no esta guardado."""
    proyecto = proyecto or QgsProject.instance()
    ruta = proyecto.fileName()
    if not ruta:
        return ""
    return os.path.splitext(ruta)[0] + SUFIJO_SESION


# ------------------------------------------------------------------ guardar
def guardar(corredores: dict, proyecto=None) -> str:
    """Escribe los corredores al lado del proyecto. Devuelve la ruta, o "".

    Si no hay corredores y el archivo existe, se borra: dejar uno vacio haria
    creer que la sesion se recupero y no habia nada.
    """
    ruta = ruta_de_sesion(proyecto)
    if not ruta:
        return ""
    if not corredores:
        if os.path.exists(ruta):
            try:
                os.remove(ruta)
            except OSError as exc:
                avisar(f"no se ha podido borrar {ruta}", exc)
        return ""
    datos = {
        "version": 1,
        "corredores": [
            sesion.a_dict(res, nombre) for nombre, res in corredores.items()
        ],
    }
    try:
        with open(ruta, "w", encoding="utf-8") as fh:
            json.dump(datos, fh, ensure_ascii=False)
    except OSError as exc:
        avisar(f"no se han podido guardar los corredores en {ruta}", exc)
        return ""
    return ruta


# ------------------------------------------------------------------ cargar
def cargar(proyecto=None) -> tuple:
    """``(corredores, mensajes)`` del archivo de sesion del proyecto."""
    ruta = ruta_de_sesion(proyecto)
    if not ruta or not os.path.exists(ruta):
        return {}, []
    try:
        with open(ruta, "r", encoding="utf-8") as fh:
            datos = json.load(fh)
    except (OSError, ValueError) as exc:
        return {}, [f"{os.path.basename(ruta)} no se ha podido leer: {exc}"]
    salida: dict = {}
    for bruto in datos.get("corredores", []):
        try:
            corredor = sesion.de_dict(bruto)
        except (KeyError, TypeError, ValueError) as exc:
            avisar("un corredor del archivo de sesion esta mal formado", exc)
            continue
        nombre = corredor.nombre or f"corredor {len(salida) + 1}"
        salida[nombre] = corredor
    if not salida:
        return {}, [f"{os.path.basename(ruta)} no tiene ningun corredor legible"]
    return salida, [
        f"{len(salida)} corredor(es) recuperados de {os.path.basename(ruta)}"
    ]


def _gpkg_de(capa) -> str:
    """Ruta del GeoPackage del que sale la capa, si sale de uno."""
    if not isinstance(capa, QgsVectorLayer) or capa.providerType() != "ogr":
        return ""
    fuente = capa.source().split("|")[0]
    return fuente if fuente.lower().endswith(".gpkg") else ""


def de_paquetes(proyecto=None) -> tuple:
    """``(corredores, mensajes)`` de los GeoPackages exportados que haya cargados.

    Recorre las capas del proyecto, se queda con los ``.gpkg`` distintos y busca
    el ``.corredor.json`` de cada uno.
    """
    proyecto = proyecto or QgsProject.instance()
    vistos: set = set()
    salida: dict = {}
    mensajes: list = []
    for capa in proyecto.mapLayers().values():
        gpkg = _gpkg_de(capa)
        if not gpkg or gpkg in vistos:
            continue
        vistos.add(gpkg)
        ruta = ruta_json(gpkg)
        if not os.path.exists(ruta):
            continue
        try:
            corredor = sesion.cargar(ruta)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            mensajes.append(f"{os.path.basename(ruta)} no se ha podido leer: {exc}")
            continue
        nombre = corredor.nombre or os.path.splitext(os.path.basename(gpkg))[0]
        salida[nombre] = corredor
        mensajes.append(
            f"'{nombre}' recuperado de {os.path.basename(ruta)}: {corredor.stats()}"
        )
    return salida, mensajes


# ------------------------------------------------------- filtrado por capas
def capas_de_directrices(proyecto=None) -> set:
    """Ids de las capas de linea que hay **en el arbol de capas**.

    Se mira el arbol y no el registro de capas: una capa se puede registrar sin
    colgarla del arbol, y lo que el usuario ve y entiende por «cargado» es el
    panel de capas.
    """
    proyecto = proyecto or QgsProject.instance()
    raiz = proyecto.layerTreeRoot()
    vivas = set()
    for nodo in raiz.findLayers():
        capa = nodo.layer()
        if capa is None:
            continue  # capa no resuelta (ruta rota): para esto es como si no estuviera
        vivas.add(capa.id())
    return vivas


def _grupos_de(proyecto) -> set:
    """Nombres de los grupos que hay en el arbol de capas."""
    raiz = proyecto.layerTreeRoot()
    try:
        grupos = raiz.findGroups(True)
    except TypeError:  # firma sin el argumento recursivo
        grupos = raiz.findGroups()
    return {g.name() for g in grupos}


def esta_cargado(nombre: str, corredor, grupos: set, capas: set) -> bool:
    """Si el corredor sigue teniendo presencia en el arbol de capas.

    Vale cualquiera de las dos pruebas de vida, porque las dos situaciones son
    normales:

    * **Su grupo de salida.** Es lo que el usuario ve y lo que borra cuando ya no
      quiere ese corredor. Suele ser la unica prueba que queda al reabrir un
      proyecto: las directrices pueden no haberse guardado en el.
    * **Su capa de directrices.** Es la prueba cuando se acaba de calcular y
      todavia no se ha cargado ningun grupo.

    Si no se cumple ninguna, del corredor no queda nada en el proyecto y
    ofrecerlo solo da alineaciones que no llevan a ninguna parte.
    """
    if nombre in grupos or any(g.startswith(nombre + " (") for g in grupos):
        return True
    return any(
        str(getattr(r.alignment, "capa_id", "") or "") in capas
        for r in getattr(corredor, "runs", []) or []
        if str(getattr(r.alignment, "capa_id", "") or "")
    )


def filtrar_por_capas(corredores: dict, proyecto=None) -> tuple:
    """``(corredores_vivos, mensajes)``: se cae lo que ya no esta cargado.

    Un corredor calculado vive en memoria, y el archivo de sesion lo devuelve al
    reabrir el proyecto sin comprobar nada. Si de aquel corredor ya no queda nada
    en el proyecto, el visor y los planos lo ofrecian igual: alineaciones viejas
    que no se pueden usar. Aqui se descartan.

    Todos los tramos de un corredor salen de la misma capa de directrices, asi
    que la decision es por corredor y no por tramo.
    """
    proyecto = proyecto or QgsProject.instance()
    grupos = _grupos_de(proyecto)
    capas = capas_de_directrices(proyecto)
    salida: dict = {}
    mensajes: list = []
    for nombre, corredor in (corredores or {}).items():
        if esta_cargado(nombre, corredor, grupos, capas):
            salida[nombre] = corredor
        else:
            mensajes.append(
                f"'{nombre}' se descarta: ni su grupo de capas ni su capa de "
                f"directrices siguen cargados en el proyecto."
            )
    return salida, mensajes


def recuperar(proyecto=None, ya_registrados: Optional[dict] = None) -> tuple:
    """Todo lo recuperable del proyecto actual: ``(corredores, mensajes)``.

    Primero el archivo de sesion y luego los GeoPackages, sin machacar lo que ya
    hubiese registrado en la sesion de trabajo (eso siempre es mas reciente), y
    descartando al final lo que no tenga su capa de directrices cargada.
    """
    ya = dict(ya_registrados or {})
    salida: dict = {}
    mensajes: list = []
    for fuente in (cargar, de_paquetes):
        encontrados, msgs = fuente(proyecto)
        mensajes += msgs
        for nombre, corredor in encontrados.items():
            if nombre in ya or nombre in salida:
                continue
            salida[nombre] = corredor
    salida, msgs = filtrar_por_capas(salida, proyecto)
    return salida, mensajes + msgs


__all__ = [
    "SUFIJO_JSON",
    "SUFIJO_SESION",
    "capas_de_directrices",
    "cargar",
    "de_paquetes",
    "esta_cargado",
    "filtrar_por_capas",
    "guardar",
    "recuperar",
    "ruta_de_sesion",
]
