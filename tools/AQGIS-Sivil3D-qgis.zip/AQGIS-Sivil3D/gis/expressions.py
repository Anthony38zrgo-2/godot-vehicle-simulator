"""Evaluacion de parametros dependientes del feature de la directriz.

Los parametros de la seccion se guardan en crudo, y pueden ser:

* un numero o un literal: ``3.5``, ``"1:1.5"``, ``"-2%"``;
* una referencia a campo: ``"@ancho"`` -> el valor del campo ``ancho`` del
  feature que se esta procesando;
* una expresion QGIS: ``"=if(\\"roca\\" = 1, '1:0.5', '1:1.5')"``.

Asi la misma seccion tipo se adapta tramo a tramo sin duplicarla. Esto se
evalua **una vez por feature**, en ``Assembly.materialize``.
"""

from __future__ import annotations

from typing import Any, Optional

from qgis.core import (
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsFeature,
    QgsVectorLayer,
)

from ..core.params import ParamError

PREFIJO_CAMPO = "@"
PREFIJO_EXPR = "="


class FeatureEvaluator:
    """Resuelve valores en crudo contra un feature concreto."""

    def __init__(
        self,
        layer: Optional[QgsVectorLayer] = None,
        feature: Optional[QgsFeature] = None,
    ):
        self.layer = layer
        self.feature = feature
        self.ctx = QgsExpressionContext()
        self.ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
        if feature is not None:
            self.ctx.setFeature(feature)
        self._campos = set()
        if feature is not None:
            try:
                self._campos = {f.name() for f in feature.fields()}
            except Exception:
                self._campos = set()

    # -- API ---------------------------------------------------------------
    def __call__(self, raw: Any) -> Any:
        if not isinstance(raw, str):
            return raw
        txt = raw.strip()
        if txt.startswith(PREFIJO_CAMPO):
            return self._campo(txt[1:].strip())
        if txt.startswith(PREFIJO_EXPR):
            return self._expr(txt[1:].strip())
        return raw

    # -- interno -----------------------------------------------------------
    def _campo(self, nombre: str) -> Any:
        if not nombre:
            raise ParamError("referencia a campo vacia ('@')")
        if self.feature is None:
            raise ParamError(
                f"'@{nombre}' necesita un feature de la directriz; no hay ninguno "
                f"en este contexto (previsualizacion?)"
            )
        if self._campos and nombre not in self._campos:
            cercanos = sorted(
                c for c in self._campos if c.lower().startswith(nombre[:3].lower())
            )
            pista = f" Campos parecidos: {cercanos}." if cercanos else ""
            raise ParamError(
                f"la capa de directrices no tiene el campo '{nombre}'.{pista}"
            )
        valor = self.feature.attribute(nombre)
        if valor is None or (hasattr(valor, "isNull") and valor.isNull()):
            raise ParamError(f"el campo '{nombre}' esta vacio en este feature")
        return valor

    def _expr(self, texto: str) -> Any:
        if not texto:
            raise ParamError("expresion vacia ('=')")
        exp = QgsExpression(texto)
        if exp.hasParserError():
            raise ParamError(f"expresion invalida: {exp.parserErrorString()}")
        valor = exp.evaluate(self.ctx)
        if exp.hasEvalError():
            raise ParamError(f"error al evaluar '{texto}': {exp.evalErrorString()}")
        if valor is None:
            raise ParamError(f"la expresion '{texto}' no devuelve valor")
        return valor


# --------------------------------------------------------------------------


def campos_usados(asm) -> list:
    """Campos a los que hace referencia la seccion, para validar por adelantado."""
    nombres = set()

    def mirar(v):
        if isinstance(v, str) and v.strip().startswith(PREFIJO_CAMPO):
            nombres.add(v.strip()[1:].strip())

    for clave in ("desnivel", "desplazamiento", "cota"):
        mirar(asm.eje.get(clave))
    for _side, _grupo, el in asm.elementos():
        for spec in el.definicion().params:
            mirar(el.raw(spec.name))
    return sorted(n for n in nombres if n)


def usa_expresiones(asm) -> bool:
    """True si algun parametro es campo o expresion (necesita feature)."""
    def dinamico(v):
        return isinstance(v, str) and v.strip()[:1] in (PREFIJO_CAMPO, PREFIJO_EXPR)

    if any(dinamico(asm.eje.get(k)) for k in ("desnivel", "desplazamiento", "cota")):
        return True
    for _side, _grupo, el in asm.elementos():
        if any(dinamico(el.raw(s.name)) for s in el.definicion().params):
            return True
    return False


__all__ = ["FeatureEvaluator", "campos_usados", "usa_expresiones"]
