"""Generacion de planos: composiciones de QGIS con atlas, y su exportacion.

Tres planos:

* **planta por hojas**, paginada con un atlas sobre la capa de rectangulos de
  hoja, con el mapa girado para que el eje salga horizontal;
* **perfil longitudinal**, sobre la capa de dibujo en espacio papel con su
  guitarra;
* **hojas de transversales**, tambien en espacio papel, una pagina por hoja.

El cajetin no se programa: si se indica una **plantilla** ``.qpt``, se carga y
solo se rellenan sus variables (``corredor_titulo``, ``corredor_pk_ini``...). Asi
el formato corporativo lo controla quien hace los planos, no este codigo.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional, Sequence

from qgis.core import (
    QgsExpressionContextUtils,
    QgsLayoutExporter,
    QgsLayoutItemLabel,
    QgsLayoutItemMap,
    QgsLayoutItemPage,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsPrintLayout,
    QgsProject,
    QgsReadWriteContext,
    QgsRectangle,
    QgsUnitTypes,
)
from qgis.PyQt.QtCore import QRectF
from qgis.PyQt.QtXml import QDomDocument

from .registro import avisar


MM = QgsUnitTypes.LayoutMillimeters

#: Tamanos de papel habituales, en mm (ancho, alto) en horizontal.
PAPELES = {
    "A4": (297.0, 210.0),
    "A3": (420.0, 297.0),
    "A2": (594.0, 420.0),
    "A1": (841.0, 594.0),
    "A0": (1189.0, 841.0),
}


@dataclass
class OpcionesPlano:
    """Ajustes comunes de los planos."""

    papel: str = "A3"
    margen: float = 12.0
    plantilla: str = ""  #: ruta a un .qpt con el cajetin
    titulo: str = "Corredor"
    subtitulo: str = ""
    #: Nombre del elemento de mapa dentro de la plantilla que hay que usar. Si no
    #: se encuentra, se crea uno nuevo ocupando la hoja.
    id_mapa: str = "mapa"
    variables: dict = field(default_factory=dict)

    def tamano(self) -> tuple:
        return PAPELES.get(self.papel.upper(), PAPELES["A3"])


# --------------------------------------------------------------------------


def tamano_de_pagina(layout: QgsPrintLayout, opts: OpcionesPlano) -> tuple:
    """Tamano real de la primera pagina, que con plantilla lo manda ella."""
    pagina = layout.pageCollection().page(0)
    if pagina is not None:
        t = pagina.pageSize()
        if t.width() > 1.0 and t.height() > 1.0:
            return (t.width(), t.height())
    return opts.tamano()


def _nuevo_layout(nombre: str, opts: OpcionesPlano, proyecto=None) -> QgsPrintLayout:
    """Layout vacio o cargado de la plantilla, con una pagina del tamano pedido."""
    proyecto = proyecto or QgsProject.instance()
    layout = QgsPrintLayout(proyecto)
    cargada = False
    if opts.plantilla and os.path.exists(opts.plantilla):
        doc = QDomDocument()
        try:
            with open(opts.plantilla, "r", encoding="utf-8") as fh:
                doc.setContent(fh.read())
            layout.loadFromTemplate(doc, QgsReadWriteContext(), True)
            cargada = True
        except Exception:  # noqa: BLE001 - si la plantilla falla, se sigue sin ella
            cargada = False
    if not cargada:
        layout.initializeDefaults()
        ancho, alto = opts.tamano()
        pagina = layout.pageCollection().page(0)
        if pagina is not None:
            pagina.setPageSize(QgsLayoutSize(ancho, alto, MM))
    layout.setName(nombre)
    for clave, valor in _variables(opts).items():
        QgsExpressionContextUtils.setLayoutVariable(layout, clave, valor)
    return layout


def _variables(opts: OpcionesPlano) -> dict:
    v = {
        "corredor_titulo": opts.titulo,
        "corredor_subtitulo": opts.subtitulo,
        "corredor_papel": opts.papel,
    }
    v.update(opts.variables or {})
    return v


def _mapa(layout: QgsPrintLayout, opts: OpcionesPlano) -> QgsLayoutItemMap:
    """El mapa de la plantilla, o uno nuevo que ocupa la hoja menos el margen.

    Si la plantilla trae un mapa se usa ese, aunque no se llame como
    ``opts.id_mapa``: crear uno nuevo encima taparia el cajetin, que es lo que
    pasaba antes.
    """
    existente = layout.itemById(opts.id_mapa)
    if isinstance(existente, QgsLayoutItemMap):
        return existente
    for item in layout.items():
        if isinstance(item, QgsLayoutItemMap):
            return item
    mapa = QgsLayoutItemMap(layout)
    mapa.setId(opts.id_mapa)
    ancho, alto = tamano_de_pagina(layout, opts)
    m = opts.margen
    mapa.attemptSetSceneRect(QRectF(m, m, ancho - 2 * m, alto - 2 * m))
    mapa.setFrameEnabled(True)
    layout.addLayoutItem(mapa)
    return mapa


def _titulo(layout: QgsPrintLayout, opts: OpcionesPlano, texto: str) -> None:
    """Rotulo de titulo, solo si la plantilla no trae ya uno."""
    if layout.itemById("titulo") is not None:
        return
    etiqueta = QgsLayoutItemLabel(layout)
    etiqueta.setId("titulo")
    etiqueta.setText(texto)
    etiqueta.attemptMove(QgsLayoutPoint(opts.margen, 3.0, MM))
    etiqueta.attemptResize(
        QgsLayoutSize(tamano_de_pagina(layout, opts)[0] - 2 * opts.margen, 8.0, MM)
    )
    layout.addLayoutItem(etiqueta)


def _encuadrar(mapa: QgsLayoutItemMap, extent: tuple, holgura: float = 0.04) -> None:
    """Encuadre ajustando el dibujo al marco. Solo para capas geograficas."""
    x0, y0, x1, y1 = extent
    dx = max((x1 - x0) * holgura, 1e-6)
    dy = max((y1 - y0) * holgura, 1e-6)
    mapa.zoomToExtent(QgsRectangle(x0 - dx, y0 - dy, x1 + dx, y1 + dy))


def encuadrar_a_escala(mapa: QgsLayoutItemMap, extent: tuple) -> None:
    """Encuadra una capa de espacio papel a escala 1:1 y centrada.

    Es la clave de todo el mecanismo: las coordenadas de la capa de dibujo ya son
    milimetros de papel, asi que el mapa tiene que mostrar **tantas unidades como
    milimetros mide el marco**. Con ``zoomToExtent``, QGIS reescalaria el dibujo
    para que encajase y la escala rotulada dejaria de ser cierta: el plano no
    seria acotable, que es justo lo que se queria evitar.
    """
    ancho = mapa.rect().width()
    alto = mapa.rect().height()
    x0, y0, x1, y1 = extent
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    mapa.setExtent(
        QgsRectangle(
            cx - ancho / 2.0, cy - alto / 2.0, cx + ancho / 2.0, cy + alto / 2.0
        )
    )


def papel_necesario(extent: tuple, margen: float = 12.0) -> Optional[str]:
    """Papel normalizado mas pequeno donde cabe el dibujo, o ``None``.

    Se prueban las dos orientaciones, porque una lamina de transversales suele ir
    en horizontal y un perfil longitudinal puede pedir formato alargado.
    """
    ancho = extent[2] - extent[0] + 2 * margen
    alto = extent[3] - extent[1] + 2 * margen
    for nombre in ("A4", "A3", "A2", "A1", "A0"):
        w, h = PAPELES[nombre]
        if (ancho <= w and alto <= h) or (ancho <= h and alto <= w):
            return nombre
    return None


# --------------------------------------------------------------------------


def layout_laminas(
    hojas: Sequence,
    capas: Sequence,
    opts: Optional[OpcionesPlano] = None,
    proyecto=None,
    ajustar_papel: bool = True,
    titulo: str = "",
    nombre: str = "Laminas",
) -> QgsPrintLayout:
    """Composicion de espacio papel con una pagina por :class:`Hoja`.

    Sirve igual para transversales, para el longitudinal paginado y para las
    hojas de cubicaciones: todas son laminas de dibujo en milimetros.

    Con ``ajustar_papel`` se escoge el formato normalizado mas pequeno en el que
    cabe la lamina; si no cabe en A0 se deja el pedido y el dibujo se recorta,
    porque cambiar la escala en silencio seria peor.
    """
    opts = opts or OpcionesPlano()
    if ajustar_papel and hojas and not opts.plantilla:
        necesario = papel_necesario(hojas[0].extent, opts.margen)
        if necesario:
            opts.papel = necesario
    layout = _nuevo_layout(nombre, opts, proyecto)
    mapa = _mapa(layout, opts)
    mapa.setLayers(list(capas))
    mapa.setKeepLayerSet(True)
    _titulo(layout, opts, titulo or opts.titulo)

    ancho, alto = tamano_de_pagina(layout, opts)
    coleccion = layout.pageCollection()
    # Una pagina por hoja: la primera ya existe.
    for _ in range(max(0, len(hojas) - coleccion.pageCount())):
        pagina = QgsLayoutItemPage(layout)
        pagina.setPageSize(QgsLayoutSize(ancho, alto, MM))
        coleccion.addPage(pagina)

    if hojas:
        encuadrar_a_escala(mapa, hojas[0].extent)
    # Un mapa por pagina, cada uno encuadrado en su hoja.
    for i, hoja in enumerate(hojas[1:], start=1):
        m = QgsLayoutItemMap(layout)
        m.setId(f"mapa_hoja_{hoja.numero}")
        m.attemptSetSceneRect(
            QRectF(
                opts.margen,
                opts.margen + i * (alto + coleccion.spaceBetweenPages()),
                ancho - 2 * opts.margen,
                alto - 2 * opts.margen,
            )
        )
        m.setFrameEnabled(True)
        m.setLayers(list(capas))
        m.setKeepLayerSet(True)
        layout.addLayoutItem(m)
        encuadrar_a_escala(m, hoja.extent)
    return layout


def layout_transversales(
    hojas: Sequence,
    capas: Sequence,
    opts: Optional[OpcionesPlano] = None,
    proyecto=None,
    ajustar_papel: bool = True,
) -> QgsPrintLayout:
    """Plano de secciones transversales."""
    opts = opts or OpcionesPlano()
    return layout_laminas(
        hojas,
        capas,
        opts,
        proyecto,
        ajustar_papel,
        titulo=f"{opts.titulo} — SECCIONES TRANSVERSALES",
        nombre="Transversales",
    )


def layout_longitudinal(
    hojas,
    capas: Sequence,
    opts: Optional[OpcionesPlano] = None,
    proyecto=None,
    ajustar_papel: bool = True,
) -> QgsPrintLayout:
    """Plano del perfil longitudinal con su guitarra, paginado.

    Acepta una lamina sola o una lista, que es lo normal: un perfil de varios
    kilometros no cabe en una hoja.
    """
    opts = opts or OpcionesPlano(papel="A3")
    lista = hojas if isinstance(hojas, (list, tuple)) else [hojas]
    lista = [h for h in lista if h is not None and h.entidades]
    return layout_laminas(
        lista,
        capas,
        opts,
        proyecto,
        ajustar_papel,
        titulo=f"{opts.titulo} — PERFIL LONGITUDINAL",
        nombre="Perfil longitudinal",
    )


def layout_planta(
    capa_hojas,
    capas: Sequence,
    opts: Optional[OpcionesPlano] = None,
    proyecto=None,
) -> QgsPrintLayout:
    """Plano de planta paginado con un atlas sobre la capa de hojas.

    El mapa se gira con el campo ``rotacion`` de cada hoja, de modo que el eje
    sale horizontal en todas las paginas.
    """
    opts = opts or OpcionesPlano()
    layout = _nuevo_layout("Planta", opts, proyecto)
    mapa = _mapa(layout, opts)
    mapa.setLayers(list(capas))
    mapa.setKeepLayerSet(True)
    mapa.setAtlasDriven(True)
    # 'Predefined' exige tener escalas predefinidas en el proyecto y, sin ellas,
    # el mapa no se encuadra en ninguna pagina. 'Auto' ajusta a cada hoja.
    mapa.setAtlasScalingMode(
        getattr(getattr(QgsLayoutItemMap, "AtlasScalingMode", QgsLayoutItemMap), "Auto")
    )
    mapa.setAtlasMargin(0.0)
    try:
        from qgis.core import QgsLayoutObject, QgsProperty

        mapa.dataDefinedProperties().setProperty(
            QgsLayoutObject.MapRotation, QgsProperty.fromField("rotacion")
        )
    except Exception as exc:  # noqa: BLE001 - sin ella, las hojas salen sin girar
        avisar("planta sin rotacion por atributo", exc)
    _titulo(layout, opts, f"{opts.titulo} — PLANTA")

    # Encuadre inicial: sin el, el mapa guiado por atlas tiene extent NaN hasta
    # que se entra en la vista previa del atlas, y el plano sale en blanco.
    try:
        primera = next(capa_hojas.getFeatures())
        caja = primera.geometry().boundingBox()
        mapa.zoomToExtent(caja)
        rot = primera.attribute("rotacion")
        if rot is not None:
            mapa.setMapRotation(float(rot))
    except (StopIteration, TypeError, ValueError):
        if not capa_hojas.extent().isEmpty():
            mapa.zoomToExtent(capa_hojas.extent())

    atlas = layout.atlas()
    atlas.setEnabled(True)
    atlas.setCoverageLayer(capa_hojas)
    atlas.setPageNameExpression('\'Hoja \' || "hoja"')
    atlas.setSortFeatures(True)
    atlas.setSortExpression('"hoja"')
    atlas.setFilenameExpression("'planta_hoja_' || \"hoja\"")
    # Sin esto el atlas no sabe cuantas paginas tiene y la exportacion saca una
    # sola hoja.
    try:
        atlas.updateFeatures()
    except Exception as exc:  # noqa: BLE001
        avisar("el atlas no ha podido contar sus paginas", exc)
    return layout


# --------------------------------------------------------------------------


def exportar_pdf(layout: QgsPrintLayout, ruta: str) -> tuple:
    """Exporta el layout a PDF. Con atlas activo, exporta todas las paginas."""
    ajustes = QgsLayoutExporter.PdfExportSettings()
    atlas = layout.atlas()
    error = ""
    if atlas is not None and atlas.enabled() and atlas.count():
        # Con atlas se usa la sobrecarga estatica, que saca todas las paginas a
        # un solo PDF. Devuelve (codigo, mensaje) en unas versiones y solo el
        # codigo en otras.
        devuelto = QgsLayoutExporter.exportToPdf(atlas, ruta, ajustes)
    else:
        devuelto = QgsLayoutExporter(layout).exportToPdf(ruta, ajustes)
    if isinstance(devuelto, (tuple, list)):
        resultado = devuelto[0]
        error = str(devuelto[1]) if len(devuelto) > 1 else ""
    else:
        resultado = devuelto
    ok = resultado == QgsLayoutExporter.Success
    return bool(ok), ("" if ok else f"exportacion fallida ({resultado}) {error}".strip())


def exportar_imagen(layout: QgsPrintLayout, ruta: str, dpi: float = 150.0) -> tuple:
    """Exporta la primera pagina del layout a imagen. Util para comprobar."""
    exportador = QgsLayoutExporter(layout)
    ajustes = QgsLayoutExporter.ImageExportSettings()
    ajustes.dpi = dpi
    resultado = exportador.exportToImage(ruta, ajustes)
    ok = resultado == QgsLayoutExporter.Success
    return bool(ok), ("" if ok else f"exportacion fallida ({resultado})")


def anadir_al_proyecto(layout: QgsPrintLayout, proyecto=None) -> QgsPrintLayout:
    """Mete el layout en el gestor de composiciones, con nombre libre."""
    proyecto = proyecto or QgsProject.instance()
    gestor = proyecto.layoutManager()
    base = layout.name()
    nombre, n = base, 2
    while gestor.layoutByName(nombre) is not None:
        nombre = f"{base} ({n})"
        n += 1
    layout.setName(nombre)
    gestor.addLayout(layout)
    return layout


__all__ = [
    "PAPELES",
    "layout_laminas",
    "tamano_de_pagina",
    "OpcionesPlano",
    "encuadrar_a_escala",
    "papel_necesario",
    "layout_transversales",
    "layout_longitudinal",
    "layout_planta",
    "exportar_pdf",
    "exportar_imagen",
    "anadir_al_proyecto",
]
