"""Orquestador: de la capa de directrices y el DEM al TIN del corredor.

Flujo
-----
Para cada *feature* de la capa de lineas (opcionalmente solo los
seleccionados):

1. Se elige la seccion tipo que le toca. Si se ha indicado un campo de seccion,
   se lee de ahi; si no, se usa la seccion por defecto. Asi una capa con tres
   tramos puede llevar tres secciones distintas.
2. Se materializa esa seccion contra el feature: los parametros ``@campo`` y
   ``=expresion`` se convierten en numeros una sola vez.
3. Se reparten los PKs (una tirada por parte de la geometria).
4. Se resuelve la seccion en cada PK contra el terreno.
5. Se teje el TIN de ese tramo y se guarda su huella en planta.

Al final, si se ha pedido, todos los TIN se fusionan con el terreno base para
dar una unica superficie continua.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from qgis.core import QgsVectorLayer, QgsWkbTypes

from ..core.merge import MergeOptions, merge_with_terrain
from ..core.params import ParamError
from ..core.resolver import Section, SectionOptions, resolve_section
from ..core.schema import Assembly
from ..core.tin import Mesh, boundary_ring, build_mesh, mesh_stats
from .alignment import Alignment, StationOptions, alignments_from_feature
from .expressions import FeatureEvaluator, campos_usados
from .terrain import BaseTerrain
from ..i18n import t

COTA_TERRENO = "terreno"
COTA_DIRECTRIZ = "directriz"
#: Cota del eje fijada a mano, la misma en todos los PK. Sirve para una
#: plataforma horizontal (una explanada, un vaso, una balsa) o para tantear una
#: rasante antes de tenerla proyectada.
COTA_CONSTANTE = "constante"
#: Cota del eje paralela al terreno, a una distancia dada por encima (positiva) o
#: por debajo (negativa). Es un desmonte o un terraplen de espesor constante.
COTA_OFFSET_TERRENO = "offset_terreno"


class NullFeedback:
    """Sustituto de ``QgsProcessingFeedback`` cuando no hay ninguno."""

    def setProgress(self, _p: float) -> None:
        pass

    def pushInfo(self, _t: str) -> None:
        pass

    def pushWarning(self, t: str) -> None:
        self.pushInfo(t)

    def reportError(self, t: str, _fatal: bool = False) -> None:
        self.pushInfo(t)

    def isCanceled(self) -> bool:
        return False


# --------------------------------------------------------------------------


@dataclass
class BuildOptions:
    """Todo lo configurable de una pasada de calculo."""

    stations: StationOptions = field(default_factory=StationOptions)
    section: SectionOptions = field(default_factory=SectionOptions)
    #: De donde sale la cota del eje: del terreno, de la Z de la directriz o de
    #: :attr:`cota_constante`.
    cota_eje: str = COTA_TERRENO
    #: Cota del eje cuando ``cota_eje`` es :data:`COTA_CONSTANTE`.
    cota_constante: float = 0.0
    #: Desnivel respecto al terreno cuando ``cota_eje`` es
    #: :data:`COTA_OFFSET_TERRENO`. Positivo por encima, negativo por debajo.
    offset_terreno: float = 0.0
    #: Campo de la capa de directrices con el nombre de la seccion tipo.
    campo_seccion: str = ""
    #: Seccion a usar cuando no hay campo o viene vacio.
    seccion_defecto: str = ""
    solo_seleccionados: bool = False
    #: Fusionar el resultado con el terreno base.
    fusionar: bool = False
    merge: MergeOptions = field(default_factory=MergeOptions)
    #: Extent de terreno a incluir en la fusion; ``None`` = huella + holgura.
    extent_fusion: Optional[tuple] = None
    #: Intervalo de los PK de rotulacion (m). Es independiente del paso de
    #: calculo: se calcula cada 5 m pero se rotula cada 100. 0 = sin PK.
    intervalo_pk: float = 100.0


@dataclass
class CorridorRun:
    """Resultado de un tramo (una parte de un feature)."""

    alignment: Alignment
    asm_nombre: str
    sections: list = field(default_factory=list)
    mesh: Mesh = field(default_factory=Mesh)
    ring: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    #: PK redondos para rotular, al intervalo de ``BuildOptions.intervalo_pk``.
    pks: list = field(default_factory=list)

    @property
    def etiqueta(self) -> str:
        return self.alignment.etiqueta

    @property
    def n_ok(self) -> int:
        return sum(1 for s in self.sections if s.ok)


@dataclass
class BuildResult:
    runs: list = field(default_factory=list)
    mesh: Mesh = field(default_factory=Mesh)
    mesh_fusion: Optional[Mesh] = None
    warnings: list = field(default_factory=list)
    #: Momento en que se registro el corredor, en ISO 8601. Es lo que permite
    #: ordenar las alineaciones por fecha de creacion en el selector.
    creado: str = ""

    @property
    def sections(self) -> list:
        return [s for r in self.runs for s in r.sections]

    @property
    def rings(self) -> list:
        return [r.ring for r in self.runs if r.ring]

    @property
    def mesh_final(self) -> Mesh:
        return self.mesh_fusion if self.mesh_fusion is not None else self.mesh

    def stats(self) -> str:
        n = len(self.sections)
        malas = sum(1 for s in self.sections if not s.ok)
        trozos = [
            t("{r} runs, {s} sections", r=len(self.runs), s=n)
            + (t(" ({n} with warnings)", n=malas) if malas else ""),
            t("corridor: {stats}", stats=mesh_stats(self.mesh)),
        ]
        if self.mesh_fusion is not None:
            trozos.append(
                t("merged: {stats}", stats=mesh_stats(self.mesh_fusion))
            )
        return "; ".join(trozos)


# --------------------------------------------------------------------------


def _elige_assembly(feature, opts: BuildOptions, assemblies: dict) -> tuple:
    """Devuelve ``(nombre, assembly)`` para el feature, o ``(nombre, None)``."""
    nombre = opts.seccion_defecto
    if opts.campo_seccion:
        try:
            v = feature.attribute(opts.campo_seccion)
        except (KeyError, IndexError):
            v = None
        if v is not None and not (hasattr(v, "isNull") and v.isNull()):
            texto = str(v).strip()
            if texto:
                nombre = texto
    if not nombre and len(assemblies) == 1:
        nombre = next(iter(assemblies))
    return nombre, assemblies.get(nombre)


def _cota_del_eje(st, opts: BuildOptions) -> Optional[float]:
    """Cota que se le impone al eje en ese PK, o ``None`` para apoyarlo en el terreno.

    Los modos «del terreno» y «offset desde el terreno» devuelven ``None``: es
    ``resolve_section`` quien muestrea el DEM, porque el eje puede ir desplazado
    sobre la normal y hay que muestrear donde cae de verdad.
    """
    if opts.cota_eje == COTA_CONSTANTE:
        return opts.cota_constante
    if opts.cota_eje == COTA_DIRECTRIZ:
        return st.z
    return None


def _resolver_tramo(
    al: Alignment,
    asm: Assembly,
    terrain: BaseTerrain,
    opts: BuildOptions,
    feedback,
) -> tuple:
    """Resuelve todas las secciones de un tramo. Devuelve ``(sections, avisos)``."""
    avisos: list = []
    sections: list = []
    sin_z = 0
    cruces = 0
    # Con offset, la cota sale del terreno: se deja z_eje en None y se le pasa el
    # desnivel a resolve_section, que es quien muestrea el terreno en el punto
    # correcto (el eje puede ir desplazado sobre la normal).
    offset = opts.offset_terreno if opts.cota_eje == COTA_OFFSET_TERRENO else 0.0
    for st in al.stations:
        if feedback.isCanceled():
            break
        z_eje = _cota_del_eje(st, opts)
        if opts.cota_eje == COTA_DIRECTRIZ and st.z is None:
            sin_z += 1
        try:
            sec = resolve_section(
                asm, st, terrain, opts.section, z_eje=z_eje, offset_terreno=offset
            )
        except ParamError as exc:
            avisos.append(f"PK {st.s:.2f}: {exc}")
            continue
        ancho = max(sec.ancho_izq, sec.ancho_der)
        if ancho > st.offset_critico:
            cruces += 1
        sections.append(sec)
    if sin_z:
        avisos.append(
            f"{sin_z} PK sin cota en la directriz: se ha apoyado el eje en el "
            f"terreno (la geometria no es 3D en ese tramo)"
        )
    if cruces:
        avisos.append(
            f"{cruces} PK en curva donde las secciones contiguas se cruzan por "
            f"el interior; reduce el paso entre PK o suaviza la directriz"
        )
    return sections, avisos


def _comprobar(
    layer: QgsVectorLayer,
    terrain: BaseTerrain,
    assemblies: dict,
    opts: BuildOptions,
    feedback,
) -> list:
    """Revisa entradas, ajusta lo automatico y devuelve los features a procesar.

    Levanta ``ValueError`` con lo que no tiene arreglo: sin capa valida, sin
    secciones o con una seccion que pide campos que la capa no tiene, seguir
    adelante solo daria un resultado incompleto sin explicar por que.
    """
    if layer is None or not layer.isValid():
        raise ValueError("la capa de directrices no es valida")
    if layer.geometryType() != QgsWkbTypes.LineGeometry:
        raise ValueError("la capa de directrices tiene que ser de tipo linea")
    if not assemblies:
        raise ValueError("no hay ninguna seccion tipo definida")

    # Ajustes automaticos a partir de la resolucion del terreno.
    if opts.section.paso <= 0.0:
        opts.section.paso = max(0.1, min(1.0, terrain.resolucion))
        feedback.pushInfo(
            f"paso de muestreo del DEM automatico: {opts.section.paso:.2f} m"
        )
    if opts.merge.celda <= 0.0:
        opts.merge.celda = max(terrain.resolucion, 0.5)

    features = list(
        layer.getSelectedFeatures() if opts.solo_seleccionados else layer.getFeatures()
    )
    if not features:
        raise ValueError(
            "no hay ningun feature que procesar"
            + (" (no hay nada seleccionado)" if opts.solo_seleccionados else "")
        )
    feedback.pushInfo(
        f"{len(features)} directrices a procesar. Terreno: {terrain.stats()}"
    )

    # Validacion temprana, pero solo de las secciones que realmente se van a
    # usar: la libreria puede tener muchas mas, y una que pida campos que esta
    # capa no tiene no es un problema si nadie la referencia.
    nombres_campos = {f.name() for f in layer.fields()}
    en_uso = {_elige_assembly(f, opts, assemblies)[0] for f in features}
    for nombre in sorted(n for n in en_uso if n in assemblies):
        asm = assemblies[nombre]
        faltan = [c for c in campos_usados(asm) if c not in nombres_campos]
        if faltan:
            raise ValueError(
                f"la seccion '{nombre}' usa campos que no existen en la capa de "
                f"directrices: {faltan}"
            )
        for e in asm.validate():
            feedback.pushWarning(f"[{nombre}] {e}")
    return features


def _procesar_feature(
    layer: QgsVectorLayer,
    feat,
    terrain: BaseTerrain,
    assemblies: dict,
    opts: BuildOptions,
    feedback,
    res: "BuildResult",
) -> None:
    """Resuelve un feature de la directriz y anade sus tramos al resultado.

    Lo que falla aqui es de ese feature y no del calculo entero: se avisa y se
    sigue con el siguiente.
    """
    nombre, asm = _elige_assembly(feat, opts, assemblies)
    if asm is None:
        res.warnings.append(
            f"fid {feat.id()}: seccion '{nombre}' desconocida; se salta. "
            f"Disponibles: {sorted(assemblies)}"
        )
        return
    try:
        mat = asm.materialize(FeatureEvaluator(layer, feat))
    except ParamError as exc:
        res.warnings.append(f"fid {feat.id()} [{nombre}]: {exc}; se salta")
        return
    try:
        partes = list(alignments_from_feature(feat, opts.stations, layer))
    except ValueError as exc:
        res.warnings.append(f"fid {feat.id()}: {exc}")
        return
    if not partes:
        res.warnings.append(
            f"fid {feat.id()}: geometria demasiado corta para el paso de PK "
            f"({opts.stations.paso} m); se salta"
        )
        return
    for al in partes:
        _procesar_tramo(al, mat, nombre, terrain, opts, feedback, res)


def _procesar_tramo(
    al: Alignment,
    mat: Assembly,
    nombre: str,
    terrain: BaseTerrain,
    opts: BuildOptions,
    feedback,
    res: "BuildResult",
) -> None:
    """Resuelve un tramo, lo malla y lo mete en el resultado."""
    sections, avisos = _resolver_tramo(al, mat, terrain, opts, feedback)
    run = CorridorRun(
        alignment=al,
        asm_nombre=nombre,
        sections=sections,
        warnings=avisos,
        pks=al.pk_stations(opts.intervalo_pk, opts.stations.pk_inicio),
    )
    validas = [s for s in sections if len(s.vertices) >= 2]
    if len(validas) < 2:
        run.warnings.append(
            "no hay secciones suficientes para mallar (revisa que el DEM cubra la "
            "directriz)"
        )
    else:
        if len(validas) < len(sections):
            run.warnings.append(
                f"{len(sections) - len(validas)} secciones vacias omitidas del "
                f"mallado"
            )
        run.mesh = build_mesh(validas)
        run.ring = boundary_ring(validas)
        res.mesh.extend(run.mesh)
    for a in run.warnings:
        feedback.pushWarning(f"[{run.etiqueta}] {a}")
    res.runs.append(run)
    feedback.pushInfo(
        f"[{run.etiqueta}] seccion '{nombre}', {len(sections)} PK, "
        f"{len(run.mesh.tris)} triangulos"
    )


def build_corridor(
    layer: QgsVectorLayer,
    terrain: BaseTerrain,
    assemblies: dict,
    opts: Optional[BuildOptions] = None,
    feedback=None,
) -> BuildResult:
    """Calcula el corredor completo. Es la unica funcion que hay que llamar."""
    opts = opts or BuildOptions()
    feedback = feedback or NullFeedback()
    res = BuildResult()

    features = _comprobar(layer, terrain, assemblies, opts, feedback)
    total = len(features)
    for i, feat in enumerate(features):
        if feedback.isCanceled():
            break
        feedback.setProgress(100.0 * i / total)
        _procesar_feature(layer, feat, terrain, assemblies, opts, feedback, res)

    feedback.setProgress(100.0)
    if res.mesh.is_empty:
        res.warnings.append("no se ha generado ningun triangulo")
        return res

    if opts.fusionar:
        feedback.pushInfo("fusionando con el terreno base...")
        malla, avisos = merge_with_terrain(
            res.mesh,
            res.rings,
            terrain,
            extent=opts.extent_fusion,
            opts=opts.merge,
        )
        res.mesh_fusion = malla
        res.warnings.extend(avisos)
        for a in avisos:
            feedback.pushInfo(f"  {a}")
    return res


def preview_sections(
    asm: Assembly,
    terrain,
    stations: list,
    opts: Optional[SectionOptions] = None,
) -> list:
    """Resuelve una lista de PKs con una seccion ya materializada.

    Atajo para la previsualizacion del editor, que no necesita capas.
    """
    opts = opts or SectionOptions()
    salida: list = []
    for st in stations:
        try:
            salida.append(resolve_section(asm, st, terrain, opts))
        except ParamError as exc:
            sec = Section(station=st, z_eje=float("nan"), ok=False, warnings=[str(exc)])
            salida.append(sec)
    return salida


__all__ = [
    "COTA_TERRENO",
    "COTA_DIRECTRIZ",
    "COTA_CONSTANTE",
    "COTA_OFFSET_TERRENO",
    "BuildOptions",
    "BuildResult",
    "CorridorRun",
    "NullFeedback",
    "build_corridor",
    "preview_sections",
]
