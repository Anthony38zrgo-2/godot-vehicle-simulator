"""Generacion de PKs a lo largo de la directriz.

Cada *feature* de la capa de lineas es un corredor independiente: se recorre por
separado y produce su propio TIN y su propia huella. Si la geometria es
multiparte, cada parte se trata tambien por separado (una multilinea con partes
sueltas no se debe coser entre partes).

Normal en los vertices
----------------------
En un vertice interior la direccion cambia de golpe. Si se usara la direccion de
uno de los dos tramos, la malla dejaria un hueco por fuera de la curva y un
solape por dentro. Se usa la **bisectriz**: la tangente en el vertice es la media
de las dos direcciones, igual que hace Civil 3D al colocar una seccion en un
punto de la geometria horizontal.

Cruce de secciones
------------------
Por el interior de una curva las normales convergen y a partir de cierta
distancia al eje las secciones contiguas se cruzan, lo que retorceria la malla.
Para cada PK se calcula esa distancia (``offset_critico``) a partir del angulo
de giro y de la separacion entre PKs; ``build`` avisa si el ancho de la seccion
la supera.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterator, Optional

from qgis.core import QgsFeature, QgsGeometry, QgsWkbTypes

from ..core.resolver import Station

#: Longitud por debajo de la cual un tramo se considera degenerado (m).
MIN_SEG = 1.0e-9


@dataclass
class StationOptions:
    """Como se reparten los PKs a lo largo de la directriz."""

    paso: float = 5.0  #: separacion entre PKs (m)
    incluir_vertices: bool = True  #: anadir un PK en cada vertice de la linea
    pk_inicio: float = 0.0  #: valor de PK del principio de cada feature
    tol: float = 1.0e-6  #: distancia por debajo de la cual dos PKs son el mismo

    def validar(self) -> None:
        if self.paso <= 0.0:
            raise ValueError("el paso entre PKs debe ser mayor que 0")


# --------------------------------------------------------------------------


def parts_of(geom: QgsGeometry) -> list:
    """Partes de la geometria como listas de ``(x, y, z | None)``.

    Acepta LineString, LineStringZ, MultiLineString y curvas (se segmentan).
    """
    if geom is None or geom.isEmpty():
        return []
    if QgsWkbTypes.geometryType(geom.wkbType()) != QgsWkbTypes.LineGeometry:
        raise ValueError(
            "la capa de directrices tiene que ser de tipo linea, no "
            f"{QgsWkbTypes.displayString(geom.wkbType())}"
        )
    g = QgsGeometry(geom)
    if QgsWkbTypes.isCurvedType(g.wkbType()):
        g = QgsGeometry(g.constGet().segmentize())
    tiene_z = QgsWkbTypes.hasZ(g.wkbType())
    salida = []
    for parte in g.constParts():
        pts = []
        for p in parte.vertices():
            z = p.z() if tiene_z else None
            if z is not None and not math.isfinite(z):
                z = None
            pts.append((p.x(), p.y(), z))
        pts = _dedupe_xy(pts)
        if len(pts) >= 2:
            salida.append(pts)
    return salida


def _dedupe_xy(pts: list) -> list:
    out = []
    for p in pts:
        if out and math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) < MIN_SEG:
            continue
        out.append(p)
    return out


# --------------------------------------------------------------------------


def _tangentes(pts: list) -> list:
    """Tangente unitaria en cada vertice: bisectriz en los interiores."""
    n = len(pts)
    dirs = []
    for a, b in zip(pts, pts[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        d = math.hypot(dx, dy)
        dirs.append((dx / d, dy / d) if d > MIN_SEG else (1.0, 0.0))
    tangentes = [dirs[0]]
    for i in range(1, n - 1):
        ax, ay = dirs[i - 1]
        bx, by = dirs[i]
        tx, ty = ax + bx, ay + by
        m = math.hypot(tx, ty)
        if m < 1.0e-9:
            # Giro de 180 grados (pico): no hay bisectriz posible. Se mantiene la
            # direccion de llegada; el aviso lo da el offset critico, que sale 0.
            tangentes.append((ax, ay))
        else:
            tangentes.append((tx / m, ty / m))
    tangentes.append(dirs[-1])
    return tangentes


def _giros(pts: list) -> list:
    """Angulo de giro (rad, sin signo) en cada vertice; 0 en los extremos."""
    n = len(pts)
    out = [0.0] * n
    for i in range(1, n - 1):
        ax = pts[i][0] - pts[i - 1][0]
        ay = pts[i][1] - pts[i - 1][1]
        bx = pts[i + 1][0] - pts[i][0]
        by = pts[i + 1][1] - pts[i][1]
        out[i] = abs(math.atan2(ax * by - ay * bx, ax * bx + ay * by))
    return out


def _acumuladas(pts: list) -> list:
    acum = [0.0]
    for a, b in zip(pts, pts[1:]):
        acum.append(acum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return acum


def _normal_derecha(tx: float, ty: float) -> tuple:
    """Normal unitaria a la derecha del sentido de avance."""
    return (ty, -tx)


def stations_along(
    pts: list,
    opts: StationOptions,
    fid: int = -1,
    part: int = 0,
) -> list:
    """PKs de una polilinea: multiplos del paso mas, opcionalmente, vertices."""
    opts.validar()
    acum = _acumuladas(pts)
    total = acum[-1]
    if total <= MIN_SEG:
        return []
    tang = _tangentes(pts)
    giros = _giros(pts)

    limpias = _marcas(acum, total, opts, len(pts))
    stations: list = []
    for s, iv in limpias:
        if iv is not None:
            x, y, z = pts[iv]
            tx, ty = tang[iv]
        else:
            x, y, z, tx, ty = _interpolar(pts, acum, tang, s)
        nx, ny = _normal_derecha(tx, ty)
        stations.append(
            Station(
                s=opts.pk_inicio + s,
                x=x,
                y=y,
                nx=nx,
                ny=ny,
                fid=fid,
                part=part,
                es_vertice=iv is not None,
                z=z,
                offset_critico=float("inf"),
            )
        )
    _marcar_offset_critico(stations, limpias, giros)
    return stations


def _marcas(acum: list, total: float, opts: StationOptions, n_pts: int) -> list:
    """``[(s, indice de vertice o None)]`` donde hay que poner una seccion.

    Los vertices ganan a los multiplos del paso cuando caen casi encima: en un
    vertice la normal es la bisectriz, y perder esa seccion abriria la superficie.
    """
    marcas: list = []
    n = int(math.floor(total / opts.paso))
    for i in range(n + 1):
        marcas.append((i * opts.paso, None))
    if total - n * opts.paso > opts.tol:
        marcas.append((total, None))
    if opts.incluir_vertices:
        for i in range(n_pts):
            marcas.append((acum[i], i))
    marcas.sort(key=lambda m: (m[0], m[1] is None))
    limpias: list = []
    for s, iv in marcas:
        if limpias and s - limpias[-1][0] <= opts.tol:
            if iv is not None and limpias[-1][1] is None:
                limpias[-1] = (s, iv)
            continue
        limpias.append((s, iv))
    return limpias


def _interpolar(pts: list, acum: list, tang: list, s: float) -> tuple:
    """Punto y tangente a la distancia ``s`` del principio de la polilinea."""
    # Busqueda binaria del tramo que contiene s.
    lo, hi = 0, len(acum) - 1
    while lo < hi - 1:
        mid = (lo + hi) // 2
        if acum[mid] <= s:
            lo = mid
        else:
            hi = mid
    a, b = pts[lo], pts[lo + 1]
    largo = acum[lo + 1] - acum[lo]
    t = 0.0 if largo <= MIN_SEG else (s - acum[lo]) / largo
    t = min(1.0, max(0.0, t))
    x = a[0] + (b[0] - a[0]) * t
    y = a[1] + (b[1] - a[1]) * t
    z = None
    if a[2] is not None and b[2] is not None:
        z = a[2] + (b[2] - a[2]) * t
    elif a[2] is not None and t <= 0.0:
        z = a[2]
    elif b[2] is not None and t >= 1.0:
        z = b[2]
    dx, dy = b[0] - a[0], b[1] - a[1]
    d = math.hypot(dx, dy)
    tx, ty = (dx / d, dy / d) if d > MIN_SEG else tang[lo]
    return x, y, z, tx, ty


def _marcar_offset_critico(stations: list, marcas: list, giros: list) -> None:
    """Distancia al eje a la que cada seccion choca con la contigua.

    Dos normales separadas ``L`` a lo largo del eje y girando ``dtheta`` entre
    si se cortan a ``L / (2 tan(dtheta/2))`` del eje por el lado interior de la
    curva. En un PK que no es vertice el giro es 0 y no hay cruce.
    """
    for k, st in enumerate(stations):
        iv = marcas[k][1]
        if iv is None or iv <= 0 or iv >= len(giros) - 1:
            continue
        giro = giros[iv]
        if giro <= 1.0e-9:
            continue
        antes = st.s - stations[k - 1].s if k > 0 else float("inf")
        despues = stations[k + 1].s - st.s if k < len(stations) - 1 else float("inf")
        L = min(antes, despues)
        if not math.isfinite(L):
            continue
        media = giro / 2.0
        if media >= math.pi / 2.0 - 1.0e-9:
            st.offset_critico = 0.0
        else:
            st.offset_critico = L / (2.0 * math.tan(media))


# --------------------------------------------------------------------------


def azimut(st: Station) -> float:
    """Azimut de la directriz en un PK: grados desde el norte, sentido horario.

    Es la convencion del campo ``angle`` que genera *Puntos a lo largo de
    geometria* de QGIS, que es la que esperan los estilos de rotulacion de PK
    (giran la etiqueta con ``angle`` y la desplazan con
    ``cos(pi - angle)``/``sin(pi - angle)``).
    """
    # La normal es (ty, -tx), asi que la tangente es (-ny, nx).
    tx, ty = -st.ny, st.nx
    return math.degrees(math.atan2(tx, ty)) % 360.0


def formato_pk(s: float) -> str:
    """``1250.0`` -> ``'1+250'``. Es el formato del modelo "PK en QGIS"."""
    km = math.floor(s / 1000.0)
    m = round(s - 1000.0 * km)
    if m >= 1000:  # el redondeo puede empujar al kilometro siguiente
        km += 1
        m -= 1000
    return f"{km:.0f}+{m:03.0f}"


@dataclass
class Alignment:
    """Un tramo de directriz listo para extruir."""

    fid: int
    part: int
    stations: list
    longitud: float
    tiene_z: bool
    #: Polilinea original ``[(x, y, z|None)]``. Se guarda porque los PK de
    #: rotulacion se reparten a su propio intervalo, independiente del paso de
    #: calculo, y hay que volver a recorrerla.
    pts: list = field(default_factory=list)
    #: Capa de directrices de la que sale este tramo. Con el ``fid`` a secas no
    #: se puede saber si la alineacion sigue existiendo: un corredor recuperado
    #: de la sesion cuya capa ya no esta cargada es una alineacion muerta, y hay
    #: que poder descartarla en vez de ofrecerla y fallar al usarla.
    capa_id: str = ""
    capa_nombre: str = ""

    @property
    def etiqueta(self) -> str:
        return f"fid {self.fid}" if self.part == 0 else f"fid {self.fid}/{self.part}"

    def pk_stations(self, intervalo: float, pk_inicio: float = 0.0) -> list:
        """PK redondos a lo largo del tramo, para rotular."""
        if intervalo <= 0.0 or len(self.pts) < 2:
            return []
        return stations_along(
            self.pts,
            StationOptions(paso=intervalo, incluir_vertices=False, pk_inicio=pk_inicio),
            fid=self.fid,
            part=self.part,
        )


def alignments_from_feature(
    feature: QgsFeature, opts: StationOptions, layer=None
) -> Iterator[Alignment]:
    """Un :class:`Alignment` por parte de la geometria del feature.

    ``layer`` es la capa de directrices de la que sale el feature. Se anota en
    cada tramo para poder comprobar mas adelante si la alineacion sigue cargada
    en el proyecto.
    """
    capa_id, capa_nombre = "", ""
    if layer is not None:
        try:
            capa_id, capa_nombre = layer.id(), layer.name()
        except (AttributeError, RuntimeError):
            # Capa borrada mientras se calculaba: se sigue sin la anotacion.
            capa_id, capa_nombre = "", ""
    for i, pts in enumerate(parts_of(feature.geometry())):
        stations = stations_along(pts, opts, fid=feature.id(), part=i)
        if len(stations) < 2:
            continue
        yield Alignment(
            fid=feature.id(),
            part=i,
            stations=stations,
            longitud=stations[-1].s - stations[0].s,
            tiene_z=all(s.z is not None for s in stations),
            pts=pts,
            capa_id=capa_id,
            capa_nombre=capa_nombre,
        )


__all__ = [
    "StationOptions",
    "Alignment",
    "azimut",
    "formato_pk",
    "parts_of",
    "stations_along",
    "alignments_from_feature",
]
