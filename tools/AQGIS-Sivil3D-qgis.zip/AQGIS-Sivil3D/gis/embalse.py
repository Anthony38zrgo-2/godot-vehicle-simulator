"""Curva de embalse dentro de QGIS: leer el DEM, recortarlo y estilarlo.

La aritmetica esta en :mod:`core.embalse`, que no sabe de QGIS. Aqui esta lo que
si depende de el:

* recorrer el raster por bloques, por GDAL cuando el DEM es un archivo y por el
  proveedor de QGIS cuando no lo es (un WCS, un raster en memoria);
* recortar el DEM con un poligono, que es lo que convierte «un DEM cualquiera» en
  «el vaso de esta balsa»;
* dejar el recorte cargado y estilado como una lamina de agua.
"""

from __future__ import annotations

import math
import os
import tempfile
from typing import Iterable, Optional, Tuple

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsRasterLayer,
    QgsRectangle,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

from ..core.embalse import Acumulador, CurvaEmbalse, cotas
from .registro import avisar

#: Lado del bloque de lectura, en pixeles. 1024 x 1024 en float64 son 8 MB.
LADO_BLOQUE = 1024


# ------------------------------------------------------------------ lectura
def info_raster(capa: QgsRasterLayer, banda: int = 1) -> dict:
    """Lo que hace falta saber del DEM antes de cubicar."""
    prov = capa.dataProvider()
    ancho, alto = capa.width(), capa.height()
    ext = capa.extent()
    res_x = ext.width() / ancho if ancho else 0.0
    res_y = ext.height() / alto if alto else 0.0
    stats = prov.bandStatistics(banda)
    nodata = None
    if prov.sourceHasNoDataValue(banda):
        nodata = float(prov.sourceNoDataValue(banda))
    return {
        "ancho": ancho,
        "alto": alto,
        "res": (res_x, res_y),
        "area_celda": res_x * res_y,
        "crs": capa.crs().authid() or capa.crs().description(),
        "nodata": nodata,
        "min": float(stats.minimumValue),
        "max": float(stats.maximumValue),
        "fuente": capa.source(),
    }


def _dtype_gdal(banda) -> str:
    from osgeo import gdal

    return gdal.GetDataTypeName(banda.DataType)


def bloques_gdal(
    ruta: str, banda: int = 1, nodata: Optional[float] = None, progreso=None
) -> Iterable:
    """Bloques de valores validos leyendo el archivo con GDAL.

    Es el camino rapido: GDAL lee por ventanas y no hay que traerse el raster
    entero a memoria, asi que un vaso de varios GB se cubica igual que uno
    pequeno.
    """
    from osgeo import gdal

    import numpy as np

    ds = gdal.Open(ruta, gdal.GA_ReadOnly)
    if ds is None:
        raise IOError(f"GDAL no ha podido abrir {ruta}")
    bnd = ds.GetRasterBand(banda)
    nd = bnd.GetNoDataValue() if nodata is None else nodata
    n_x = int(math.ceil(ds.RasterXSize / LADO_BLOQUE))
    n_y = int(math.ceil(ds.RasterYSize / LADO_BLOQUE))
    total = max(1, n_x * n_y)
    hecho = 0
    for j in range(n_y):
        for i in range(n_x):
            x = i * LADO_BLOQUE
            y = j * LADO_BLOQUE
            w = min(LADO_BLOQUE, ds.RasterXSize - x)
            h = min(LADO_BLOQUE, ds.RasterYSize - y)
            arr = bnd.ReadAsArray(x, y, w, h)
            if arr is None:
                continue
            v = np.asarray(arr, dtype="float64").ravel()
            if nd is not None and not math.isnan(nd):
                v = v[v != nd]
            v = v[np.isfinite(v)]
            hecho += 1
            if progreso is not None:
                progreso(100.0 * hecho / total)
            if v.size:
                yield v
    ds = None


def bloques_qgis(
    capa: QgsRasterLayer, banda: int = 1, nodata: Optional[float] = None, progreso=None
) -> Iterable:
    """Bloques de valores validos por el proveedor de QGIS.

    Vale para lo que GDAL no abre directamente (un WCS, un raster de memoria) y
    respeta el NoData que tenga declarado la capa.
    """
    import numpy as np

    prov = capa.dataProvider()
    ancho, alto = capa.width(), capa.height()
    ext = capa.extent()
    if not ancho or not alto or ext.isEmpty():
        return
    ventanas = list(_ventanas(ext, ancho, alto))
    total = max(1, len(ventanas))
    for hecho, (rect, w, h) in enumerate(ventanas, start=1):
        bloque = prov.block(banda, rect, w, h)
        if progreso is not None:
            progreso(100.0 * hecho / total)
        if bloque is None or not bloque.isValid():
            continue
        valores = _valores_del_bloque(bloque, w, h, nodata)
        if valores:
            yield np.asarray(valores, dtype="float64")


def _ventanas(ext, ancho: int, alto: int):
    """``(rectangulo, ancho, alto)`` de cada bloque en que se parte el raster."""
    pas_x = ext.width() / ancho
    pas_y = ext.height() / alto
    for j in range(int(math.ceil(alto / LADO_BLOQUE))):
        for i in range(int(math.ceil(ancho / LADO_BLOQUE))):
            px, py = i * LADO_BLOQUE, j * LADO_BLOQUE
            w = min(LADO_BLOQUE, ancho - px)
            h = min(LADO_BLOQUE, alto - py)
            yield (
                QgsRectangle(
                    ext.xMinimum() + px * pas_x,
                    ext.yMaximum() - (py + h) * pas_y,
                    ext.xMinimum() + (px + w) * pas_x,
                    ext.yMaximum() - py * pas_y,
                ),
                w,
                h,
            )


def _valores_del_bloque(bloque, w: int, h: int, nodata: Optional[float]) -> list:
    """Cotas validas de un bloque del proveedor, celda a celda."""
    valores = []
    for fila in range(h):
        for col in range(w):
            if bloque.isNoData(fila, col):
                continue
            v = bloque.value(fila, col)
            if nodata is not None and v == nodata:
                continue
            if math.isfinite(v):
                valores.append(v)
    return valores


def bloques(
    capa: QgsRasterLayer, banda: int = 1, nodata: Optional[float] = None, progreso=None
) -> Iterable:
    """Bloques del DEM por el camino que se pueda: GDAL si es un archivo."""
    ruta = capa.source().split("|")[0]
    if os.path.isfile(ruta):
        try:
            for bloque in bloques_gdal(ruta, banda, nodata, progreso):
                yield bloque
            return
        except Exception as exc:  # noqa: BLE001  -- se prueba con el proveedor
            avisar(f"GDAL no ha podido leer {ruta}; se usa el proveedor", exc)
    for bloque in bloques_qgis(capa, banda, nodata, progreso):
        yield bloque


def calcular_curva(
    capa: QgsRasterLayer,
    cota_ini: Optional[float] = None,
    cota_fin: Optional[float] = None,
    paso: float = 0.1,
    banda: int = 1,
    nodata: Optional[float] = None,
    progreso=None,
) -> CurvaEmbalse:
    """Curva cota-volumen-area del DEM completo tal y como esta cargado.

    Sin cotas se cubica entre el minimo y el maximo del raster, que es lo que se
    quiere cuando el DEM ya viene recortado al vaso.
    """
    info = info_raster(capa, banda)
    ini = info["min"] if cota_ini is None else cota_ini
    fin = info["max"] if cota_fin is None else cota_fin
    if fin <= ini:
        fin = ini + max(paso, 1e-6)
    vector = cotas(ini, fin, paso)
    acc = Acumulador(vector)
    for bloque in bloques(capa, banda, nodata, progreso):
        acc.anadir(bloque)
    return acc.curva(info["area_celda"])


# ------------------------------------------------------------------ recorte
def _cutline(capa_poligonos: QgsVectorLayer, crs_destino, solo_seleccionados: bool):
    """Escribe las geometrias de recorte en un GeoJSON temporal, ya reproyectadas."""
    origen = capa_poligonos.crs()
    ct = None
    if crs_destino.isValid() and origen.isValid() and origen != crs_destino:
        ct = QgsCoordinateTransform(origen, crs_destino, QgsProject.instance())
    capa = QgsVectorLayer(
        f"Polygon?crs={crs_destino.authid() or 'EPSG:4326'}", "cutline", "memory"
    )
    feats = []
    fuente = (
        capa_poligonos.getSelectedFeatures()
        if solo_seleccionados
        else capa_poligonos.getFeatures()
    )
    for f in fuente:
        g = f.geometry()
        if g.isEmpty():
            continue
        if ct is not None:
            g = type(g)(g)
            if g.transform(ct) != 0:
                continue
        nuevo = f.__class__(capa.fields())
        nuevo.setGeometry(g)
        feats.append(nuevo)
    if not feats:
        return None, 0
    capa.dataProvider().addFeatures(feats)
    capa.updateExtents()
    ruta = os.path.join(tempfile.mkdtemp(prefix="sivil3d_cutline_"), "recorte.geojson")
    opciones = QgsVectorFileWriter.SaveVectorOptions()
    opciones.driverName = "GeoJSON"
    escrito = QgsVectorFileWriter.writeAsVectorFormatV3(
        capa, ruta, QgsProject.instance().transformContext(), opciones
    )
    codigo = escrito[0] if isinstance(escrito, (tuple, list)) else escrito
    if codigo != QgsVectorFileWriter.NoError or not os.path.isfile(ruta):
        return None, 0
    return ruta, len(feats)


def recortar(
    capa: QgsRasterLayer,
    capa_poligonos: QgsVectorLayer,
    destino: str = "",
    solo_seleccionados: bool = False,
    banda: int = 1,
) -> Tuple[Optional[str], list]:
    """Recorta el DEM por el poligono y devuelve ``(ruta, mensajes)``.

    Se recorta de verdad, no se enmascara al dibujar: el raster resultante solo
    tiene celdas dentro del vaso, y por eso su minimo y su maximo ya son los del
    embalse y la curva sale sola.
    """
    mensajes: list = []
    ruta_origen = capa.source().split("|")[0]
    if not os.path.isfile(ruta_origen):
        return None, ["Para recortar hace falta que el DEM sea un archivo en disco."]
    cutline, n = _cutline(capa_poligonos, capa.crs(), solo_seleccionados)
    if cutline is None:
        cual = "seleccionados" if solo_seleccionados else "de la capa"
        return None, [f"No hay poligonos {cual} que sirvan para recortar."]
    if not destino:
        destino = os.path.join(
            tempfile.mkdtemp(prefix="sivil3d_vaso_"),
            os.path.splitext(os.path.basename(ruta_origen))[0] + "_vaso.tif",
        )
    prov = capa.dataProvider()
    nodata = (
        float(prov.sourceNoDataValue(banda))
        if prov.sourceHasNoDataValue(banda)
        else -9999.0
    )
    try:
        from osgeo import gdal

        gdal.UseExceptions()
        opciones = gdal.WarpOptions(
            format="GTiff",
            cutlineDSName=cutline,
            cropToCutline=True,
            dstNodata=nodata,
            srcNodata=nodata if prov.sourceHasNoDataValue(banda) else None,
            creationOptions=["COMPRESS=DEFLATE", "TILED=YES"],
        )
        salida = gdal.Warp(destino, ruta_origen, options=opciones)
        if salida is None:
            return None, ["GDAL no ha podido recortar el DEM."]
        salida = None
    except Exception as exc:  # noqa: BLE001
        return None, [f"Error al recortar con GDAL: {exc}"]
    mensajes.append(f"DEM recortado con {n} poligono(s): {destino}")
    return destino, mensajes


def capa_de_vaso(ruta: str, nombre: str = "") -> Optional[QgsRasterLayer]:
    """Carga el recorte como capa raster, ya estilada como lamina de agua."""
    from .estilos import estilo_vaso

    capa = QgsRasterLayer(ruta, nombre or os.path.basename(ruta))
    if not capa.isValid():
        return None
    stats = capa.dataProvider().bandStatistics(1)
    estilo_vaso(capa, float(stats.minimumValue), float(stats.maximumValue))
    return capa


__all__ = [
    "LADO_BLOQUE",
    "bloques",
    "bloques_gdal",
    "bloques_qgis",
    "calcular_curva",
    "capa_de_vaso",
    "info_raster",
    "recortar",
]
