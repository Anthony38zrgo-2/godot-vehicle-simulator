"""De espacio papel a capas de QGIS, y hojas de planta para el atlas.

``core.paperspace`` produce entidades en milimetros de papel. Aqui se convierten
en capas de memoria (una de lineas, una de poligonos y una de rotulos), que es lo
que puede ver un mapa de composicion y lo que se exporta a DXF.

Las capas de dibujo **no llevan sistema de referencia**: sus coordenadas son
milimetros de papel, no metros de terreno. Es a proposito, y por eso van siempre
en su propio grupo, separadas de las capas geograficas.
"""

from __future__ import annotations

import math
from typing import Optional, Sequence

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsLineString,
    QgsPoint,
    QgsPointXY,
    QgsPolygon,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QMetaType

from ..core.paperspace import (
    CLASE_ACOTACION,
    CLASE_DESMONTE,
    CLASE_EJE,
    CLASE_GUITARRA,
    CLASE_MARCO,
    CLASE_PROYECTO,
    CLASE_REJILLA,
    CLASE_REJILLA_FINA,
    CLASE_TERRAPLEN,
    CLASE_TERRENO,
    CLASE_TEXTO,
    Escala,
)

from .registro import avisar


T_INT = QMetaType.Type.Int
T_DOUBLE = QMetaType.Type.Double
T_STRING = QMetaType.Type.QString


def _f(nombre, tipo, largo=0, prec=0) -> QgsField:
    return QgsField(nombre, tipo, len=largo, prec=prec)


def campos_dibujo(con_texto: bool = False) -> QgsFields:
    f = QgsFields()
    for c in (
        _f("clase", T_STRING, 24),
        _f("hoja", T_INT),
        _f("pk", T_DOUBLE, 14, 3),
        _f("fila", T_STRING, 24),
        _f("area", T_DOUBLE, 14, 4),
    ):
        f.append(c)
    if con_texto:
        f.append(_f("texto", T_STRING, 120))
        f.append(_f("angulo", T_DOUBLE, 8, 3))
        f.append(_f("altura", T_DOUBLE, 8, 3))
        # Alineacion horizontal y vertical del rotulo respecto a su punto, en
        # los valores que espera el etiquetado de QGIS.
        f.append(_f("hali", T_STRING, 10))
        f.append(_f("vali", T_STRING, 10))
    return f


def campos_hojas() -> QgsFields:
    f = QgsFields()
    for c in (
        _f("hoja", T_INT),
        _f("fid_dir", T_INT),
        _f("parte", T_INT),
        _f("pk_ini", T_DOUBLE, 14, 3),
        _f("pk_fin", T_DOUBLE, 14, 3),
        _f("azimut", T_DOUBLE, 10, 4),
        _f("rotacion", T_DOUBLE, 10, 4),
        _f("escala", T_DOUBLE, 12, 2),
    ):
        f.append(c)
    return f


def _capa(nombre: str, tipo: str, campos: QgsFields, crs=None) -> QgsVectorLayer:
    autoridad = ""
    if crs is not None and crs.isValid():
        autoridad = f"?crs={crs.authid()}"
    capa = QgsVectorLayer(f"{tipo}{autoridad}", nombre, "memory")
    if crs is None or not crs.isValid():
        # Sin sistema de referencia a proposito: las coordenadas son milimetros
        # de papel. El proveedor de memoria pone WGS84 por defecto, y eso haria
        # que QGIS intentase reproyectar milimetros como si fueran grados.
        capa.setCrs(QgsCoordinateReferenceSystem())
    dp = capa.dataProvider()
    dp.addAttributes(list(campos))
    capa.updateFields()
    return capa


#: Anclaje del espacio papel -> (alineacion horizontal, vertical) de QGIS.
ANCLAJES = {
    "centro": ("Center", "Half"),
    "izquierda": ("Left", "Half"),
    "derecha": ("Right", "Half"),
    "arriba": ("Center", "Top"),
    "abajo": ("Center", "Bottom"),
    "abajo_izquierda": ("Left", "Bottom"),
    "arriba_izquierda": ("Left", "Top"),
}


def _atributos(ent, campos: QgsFields, con_texto: bool) -> list:
    a = ent.atributos or {}
    valores = [
        ent.clase,
        a.get("hoja"),
        a.get("pk"),
        a.get("fila"),
        a.get("area"),
    ]
    if con_texto:
        hali, vali = ANCLAJES.get(ent.anclaje, ANCLAJES["centro"])
        valores.extend([ent.texto, ent.angulo, ent.altura or 2.2, hali, vali])
    return valores


def capas_de_hojas(hojas: Sequence, prefijo: str = "Lamina") -> list:
    """Tres capas de dibujo (poligonos, lineas y rotulos) con todas las hojas."""
    entidades = [e for h in hojas for e in h.entidades]
    campos_l = campos_dibujo(False)
    campos_p = campos_dibujo(False)
    campos_t = campos_dibujo(True)

    capa_pol = _capa(f"{prefijo} - rellenos", "Polygon", campos_p)
    capa_lin = _capa(f"{prefijo} - lineas", "LineString", campos_l)
    capa_txt = _capa(f"{prefijo} - rotulos", "Point", campos_t)

    fs_pol, fs_lin, fs_txt = [], [], []
    for ent in entidades:
        if not ent.puntos:
            continue
        if ent.texto and len(ent.puntos) == 1:
            ft = QgsFeature(campos_t)
            ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(*ent.puntos[0])))
            ft.setAttributes(_atributos(ent, campos_t, True))
            fs_txt.append(ft)
        elif ent.poligono and len(ent.puntos) >= 3:
            anillo = list(ent.puntos) + [ent.puntos[0]]
            ft = QgsFeature(campos_p)
            ft.setGeometry(
                QgsGeometry(QgsPolygon(QgsLineString([QgsPoint(*p) for p in anillo])))
            )
            ft.setAttributes(_atributos(ent, campos_p, False))
            fs_pol.append(ft)
        elif len(ent.puntos) >= 2:
            ft = QgsFeature(campos_l)
            ft.setGeometry(
                QgsGeometry.fromPolylineXY([QgsPointXY(*p) for p in ent.puntos])
            )
            ft.setAttributes(_atributos(ent, campos_l, False))
            fs_lin.append(ft)
    for capa, fs in ((capa_pol, fs_pol), (capa_lin, fs_lin), (capa_txt, fs_txt)):
        if fs:
            capa.dataProvider().addFeatures(fs)
        capa.updateExtents()
    from .estilos import estilo_lamina_lineas, estilo_lamina_poligonos, estilo_lamina_rotulos

    estilo_lamina_poligonos(capa_pol)
    estilo_lamina_lineas(capa_lin)
    estilo_lamina_rotulos(capa_txt)
    # De abajo arriba en el dibujo: rellenos, lineas, rotulos.
    return [capa_txt, capa_lin, capa_pol]


# --------------------------------------------------------------------------
# Hojas de planta para el atlas
# --------------------------------------------------------------------------


def hojas_de_planta(
    alignment,
    ancho_papel_mm: float = 297.0,
    alto_papel_mm: float = 210.0,
    escala: float = 1000.0,
    solape: float = 0.05,
    crs: Optional[QgsCoordinateReferenceSystem] = None,
    margen_mm: float = 20.0,
) -> QgsVectorLayer:
    """Capa de rectangulos de hoja a lo largo de la directriz.

    Se usa como **cobertura de atlas**: una pagina por rectangulo, con el mapa
    girado segun el campo ``rotacion`` para que el eje salga horizontal.

    ``solape`` es la fraccion de la longitud de hoja que se repite entre hojas
    consecutivas, para que no quede una junta seca en el plano.
    """
    capa = _capa("Hojas de planta", "Polygon", campos_hojas(), crs)
    stations = list(alignment.stations)
    if len(stations) < 2:
        capa.updateExtents()
        return capa

    util_mm = max(10.0, ancho_papel_mm - 2 * margen_mm)
    alto_util_mm = max(10.0, alto_papel_mm - 2 * margen_mm)
    largo_hoja = util_mm * escala / 1000.0  # m de terreno por hoja
    ancho_hoja = alto_util_mm * escala / 1000.0
    avance = max(1.0, largo_hoja * (1.0 - max(0.0, min(0.9, solape))))

    s_ini = stations[0].s
    s_fin = stations[-1].s
    feats = []
    n = 0
    s = s_ini
    while s < s_fin - 1e-9:
        s2 = min(s + largo_hoja, s_fin)
        a = _station_en(stations, s)
        b = _station_en(stations, s2)
        if a is None or b is None:
            break
        n += 1
        # Rectangulo alineado con la cuerda de la hoja.
        dx, dy = b.x - a.x, b.y - a.y
        largo = math.hypot(dx, dy)
        if largo < 1e-9:
            break
        ux, uy = dx / largo, dy / largo
        vx, vy = uy, -ux  # normal a la derecha
        h = ancho_hoja / 2.0
        esquinas = [
            (a.x + vx * h, a.y + vy * h),
            (b.x + vx * h, b.y + vy * h),
            (b.x - vx * h, b.y - vy * h),
            (a.x - vx * h, a.y - vy * h),
        ]
        azimut = math.degrees(math.atan2(ux, uy)) % 360.0
        ft = QgsFeature(capa.fields())
        ft.setGeometry(
            QgsGeometry.fromPolygonXY([[QgsPointXY(*p) for p in esquinas] + [QgsPointXY(*esquinas[0])]])
        )
        ft.setAttributes(
            [
                n,
                alignment.fid,
                alignment.part,
                round(s, 3),
                round(s2, 3),
                round(azimut, 4),
                round(rotacion_para_horizontal(azimut), 4),
                escala,
            ]
        )
        feats.append(ft)
        if s2 >= s_fin - 1e-9:
            break
        s += avance
    if feats:
        capa.dataProvider().addFeatures(feats)
    capa.updateExtents()
    return capa


def hojas_de_planta_varias(
    alineaciones: Sequence,
    ancho_papel_mm: float = 297.0,
    alto_papel_mm: float = 210.0,
    escala: float = 1000.0,
    solape: float = 0.05,
    crs: Optional[QgsCoordinateReferenceSystem] = None,
    margen_mm: float = 20.0,
) -> QgsVectorLayer:
    """Una sola capa de hojas con las de **todas** las alineaciones.

    El atlas recorre las hojas de una alineacion tras otra, con la numeracion
    seguida. Cada hoja sigue llevando su ``fid_dir`` y su ``parte``, asi que en el
    cajetin se puede rotular de que alineacion es.
    """
    capa = _capa("Hojas de planta", "Polygon", campos_hojas(), crs)
    feats = []
    n = 0
    for al in alineaciones:
        parcial = hojas_de_planta(
            al, ancho_papel_mm, alto_papel_mm, escala, solape, crs, margen_mm
        )
        for ft in parcial.getFeatures():
            n += 1
            nuevo = QgsFeature(capa.fields())
            nuevo.setGeometry(ft.geometry())
            atributos = list(ft.attributes())
            atributos[0] = n  # numeracion seguida entre alineaciones
            nuevo.setAttributes(atributos)
            feats.append(nuevo)
    if feats:
        capa.dataProvider().addFeatures(feats)
    capa.updateExtents()
    return capa


def rotacion_para_horizontal(azimut: float) -> float:
    """Rotacion de mapa que pone un eje de ese azimut horizontal, PK a la derecha.

    ``QgsLayoutItemMap.setMapRotation`` gira el **contenido** en sentido horario.
    Un eje con azimut 90 (hacia el este) ya sale horizontal, asi que la rotacion
    es 0; uno con azimut 0 (hacia el norte) hay que girarlo -90.
    """
    return (90.0 - azimut) % 360.0 - 360.0 if (90.0 - azimut) % 360.0 > 180.0 else (
        90.0 - azimut
    ) % 360.0


def _station_en(stations: Sequence, s: float):
    """PK interpolado por posicion a lo largo de la lista de estaciones."""
    if not stations:
        return None
    if s <= stations[0].s:
        return stations[0]
    if s >= stations[-1].s:
        return stations[-1]
    for a, b in zip(stations, stations[1:]):
        if s <= b.s:
            if b.s - a.s < 1e-12:
                return b
            t = (s - a.s) / (b.s - a.s)
            from ..core.resolver import Station

            return Station(
                s=s,
                x=a.x + (b.x - a.x) * t,
                y=a.y + (b.y - a.y) * t,
                nx=a.nx,
                ny=a.ny,
                fid=a.fid,
                part=a.part,
            )
    return stations[-1]


# --------------------------------------------------------------------------
# DXF
# --------------------------------------------------------------------------


def exportar_dxf(
    capas: Sequence,
    ruta: str,
    escala: float = 1.0,
    crs: Optional[QgsCoordinateReferenceSystem] = None,
) -> tuple:
    """Exporta las capas a DXF. Devuelve ``(ok, mensaje)``.

    Para las capas de dibujo la escala es 1 (las coordenadas ya son milimetros de
    papel); para capas geograficas se puede dar la escala del plano.
    """
    from qgis.core import QgsDxfExport

    utiles = [c for c in capas if c is not None and c.isValid()]
    if not utiles:
        return False, "no hay capas que exportar"
    dxf = QgsDxfExport()
    try:
        detalles = []
        for c in utiles:
            d = QgsDxfExport.DxfLayer(c)
            detalles.append(d)
        dxf.addLayers(detalles)
    except Exception as exc:  # noqa: BLE001
        return False, f"no se han podido anadir las capas: {exc}"
    dxf.setSymbologyScale(escala)
    try:
        dxf.setSymbologyExport(QgsDxfExport.FeatureSymbology)
    except Exception as exc:  # noqa: BLE001 - enum movido de sitio segun version
        avisar("DXF sin simbologia por feature", exc)
    if crs is not None and crs.isValid():
        dxf.setDestinationCrs(crs)
    return _escribir_dxf(dxf, ruta, QgsDxfExport)


def _escribir_dxf(dxf, ruta: str, clase_dxf) -> tuple:
    """Volcado del DXF al archivo. ``writeToFile`` quiere un QIODevice."""
    from qgis.PyQt.QtCore import QFile, QIODevice

    archivo = QFile(ruta)
    modo = getattr(getattr(QIODevice, "OpenModeFlag", QIODevice), "WriteOnly")
    if not archivo.open(modo):
        return False, f"no se puede escribir en {ruta}"
    try:
        resultado = dxf.writeToFile(archivo, "UTF-8")
    except Exception as exc:  # noqa: BLE001
        return False, f"error al escribir el DXF: {exc}"
    finally:
        archivo.close()
    # QGIS 3 devuelve 0; QGIS 4, QgsDxfExport.ExportResult.Success.
    exito = getattr(getattr(clase_dxf, "ExportResult", clase_dxf), "Success", 0)
    ok = resultado is None or resultado == exito or resultado == 0
    return bool(ok), ("" if ok else f"QgsDxfExport ha devuelto {resultado}")


__all__ = [
    "ANCLAJES",
    "campos_dibujo",
    "campos_hojas",
    "capas_de_hojas",
    "hojas_de_planta",
    "hojas_de_planta_varias",
    "rotacion_para_horizontal",
    "exportar_dxf",
]
