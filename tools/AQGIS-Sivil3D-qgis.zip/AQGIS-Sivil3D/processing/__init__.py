"""Integracion con Processing: proveedor y algoritmos.

Tener el calculo como algoritmo de Processing (y no solo como dialogo) es lo que
permite meter el corredor en un modelo, lanzarlo en lote sobre varias capas o
llamarlo desde la consola con ``processing.run``.
"""
