"""Puente entre las APIs de QGIS 3.3x y QGIS 4.x.

Los enums pasaron de planos (``QgsProcessing.TypeVectorLine``) a con ambito
(``QgsProcessing.SourceType.TypeVectorLine``) y algunos alias antiguos ya no
existen en QGIS 4. Se resuelve una vez aqui para no repetir try/except.
"""

from __future__ import annotations

from qgis.core import (
    QgsProcessing,
    QgsProcessingParameterDefinition,
    QgsProcessingParameterNumber,
    QgsWkbTypes,
)


def _enum(clase, ambito: str, *nombres):
    """Primer atributo que exista, probando con ambito y sin el."""
    scoped = getattr(clase, ambito, None)
    for fuente in (scoped, clase):
        if fuente is None:
            continue
        for n in nombres:
            v = getattr(fuente, n, None)
            if v is not None:
                return v
    raise AttributeError(f"{clase.__name__}: no se encuentra {nombres}")


TIPO_LINEA = _enum(QgsProcessing, "SourceType", "TypeVectorLine", "VectorLine")
TIPO_POLIGONO = _enum(
    QgsProcessing, "SourceType", "TypeVectorPolygon", "VectorPolygon"
)
TIPO_PUNTO = _enum(QgsProcessing, "SourceType", "TypeVectorPoint", "VectorPoint")

WKB_LINEA_Z = _enum(QgsWkbTypes, "Type", "LineStringZ")
WKB_POLIGONO_Z = _enum(QgsWkbTypes, "Type", "PolygonZ")
WKB_PUNTO_Z = _enum(QgsWkbTypes, "Type", "PointZ")

NUM_DOUBLE = _enum(QgsProcessingParameterNumber, "Type", "Double")
NUM_ENTERO = _enum(QgsProcessingParameterNumber, "Type", "Integer")
FLAG_AVANZADO = _enum(QgsProcessingParameterDefinition, "Flag", "FlagAdvanced")


def marcar_avanzado(param):
    """Manda el parametro a la seccion "Avanzado" del dialogo."""
    param.setFlags(param.flags() | FLAG_AVANZADO)
    return param


__all__ = [
    "TIPO_LINEA",
    "TIPO_POLIGONO",
    "TIPO_PUNTO",
    "WKB_LINEA_Z",
    "WKB_POLIGONO_Z",
    "WKB_PUNTO_Z",
    "NUM_DOUBLE",
    "NUM_ENTERO",
    "FLAG_AVANZADO",
    "marcar_avanzado",
]
