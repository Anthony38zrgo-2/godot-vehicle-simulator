"""Algoritmo de Processing: extruye secciones tipo a lo largo de una directriz."""

from __future__ import annotations

import os

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingLayerPostProcessorInterface,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterMapLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
)
from qgis.PyQt.QtCore import QCoreApplication

from ..core.library import AssemblyLibrary, default_library
from ..core.merge import MergeOptions
from ..core.params import ParamError
from ..core.resolver import SectionOptions
from ..core.tin import write_2dm
from ..gis.alignment import StationOptions
from ..gis.build import (
    COTA_CONSTANTE,
    COTA_DIRECTRIZ,
    COTA_OFFSET_TERRENO,
    COTA_TERRENO,
    BuildOptions,
    build_corridor,
)

from ..gis.registro import avisar


#: Modos de cota del eje, en el orden de la enumeracion del algoritmo.
MODOS_COTA = (COTA_TERRENO, COTA_DIRECTRIZ, COTA_CONSTANTE, COTA_OFFSET_TERRENO)
from ..gis.estilos import CARPETA_ESTILOS
from ..gis.outputs import (
    features_eje,
    features_huella,
    features_lineas,
    features_pk,
    features_puntos,
    features_secciones,
    features_triangulos,
    fields_eje,
    fields_huella,
    fields_lineas,
    fields_pk,
    fields_puntos,
    fields_secciones,
    fields_triangulos,
    nombre_grupo,
)
from ..gis.terrain import TerrainError, make_terrain
from .compat import (
    NUM_DOUBLE,
    NUM_ENTERO,
    TIPO_LINEA,
    TIPO_POLIGONO,
    TIPO_PUNTO,
    WKB_LINEA_Z,
    WKB_POLIGONO_Z,
    WKB_PUNTO_Z,
    marcar_avanzado,
)


from ..i18n import t  # noqa: E402 - detras de los imports de QGIS


def tr(texto: str, **huecos) -> str:
    """Traduce con el catalogo del plugin.

    Antes delegaba en ``QCoreApplication.translate``, que sin un ``.qm``
    detras devolvia el texto tal cual. El idioma del plugin es una eleccion
    del usuario y no el locale de QGIS, asi que se traduce con ``t()``.
    """
    return t(texto, **huecos)


class _Estilador(QgsProcessingLayerPostProcessorInterface):
    """Aplica un .qml a la capa justo cuando Processing la carga.

    Processing crea las capas de salida despues de que el algoritmo termine, asi
    que el estilo no se puede poner dentro de ``processAlgorithm``: hay que
    dejar este post-procesador en el contexto. QGIS exige mantener una
    referencia viva, de ahi la lista ``_ESTILADORES``.
    """

    def __init__(self, ruta_qml: str):
        super().__init__()
        self.ruta = ruta_qml
        _ESTILADORES.append(self)

    def postProcessLayer(self, capa, _context, _feedback):
        try:
            capa.loadNamedStyle(self.ruta)
            capa.triggerRepaint()
        except Exception as exc:  # noqa: BLE001 - no debe romper el calculo
            avisar(f"capa de salida sin el estilo {self.ruta}", exc)


#: QGIS no toma posesion de los post-procesadores; si se recogen basura, casca.
_ESTILADORES: list = []


class CorridorAlgorithm(QgsProcessingAlgorithm):
    """Corredor: secciones tipo + directriz + DEM -> TIN."""

    DIRECTRICES = "DIRECTRICES"
    DEM = "DEM"
    BANDA = "BANDA"
    FACTOR_Z = "FACTOR_Z"
    OFFSET_Z = "OFFSET_Z"
    LIBRERIA = "LIBRERIA"
    SECCIONES_JSON = "SECCIONES_JSON"
    CAMPO_SECCION = "CAMPO_SECCION"
    SECCION_DEFECTO = "SECCION_DEFECTO"
    PASO_PK = "PASO_PK"
    INCLUIR_VERTICES = "INCLUIR_VERTICES"
    PK_INICIO = "PK_INICIO"
    COTA_EJE = "COTA_EJE"
    COTA_CONSTANTE = "COTA_CONSTANTE"
    OFFSET_TERRENO = "OFFSET_TERRENO"
    PASO_MUESTREO = "PASO_MUESTREO"
    ANCHO_MAX = "ANCHO_MAX"
    FUSIONAR = "FUSIONAR"
    CELDA_FUSION = "CELDA_FUSION"
    HOLGURA = "HOLGURA"
    EXTENT_FUSION = "EXTENT_FUSION"
    INTERVALO_PK = "INTERVALO_PK"
    GRUPO = "GRUPO"

    OUT_TIN = "OUT_TIN"
    OUT_SECCIONES = "OUT_SECCIONES"
    OUT_LINEAS = "OUT_LINEAS"
    OUT_HUELLA = "OUT_HUELLA"
    OUT_PUNTOS = "OUT_PUNTOS"
    OUT_PK = "OUT_PK"
    OUT_EJE = "OUT_EJE"
    OUT_2DM = "OUT_2DM"

    # -- identidad --------------------------------------------------------
    def name(self) -> str:
        return "corredor"

    def displayName(self) -> str:
        return tr("Extrude typical cross section (corridor)")

    def group(self) -> str:
        return tr("Corridor")

    def groupId(self) -> str:
        return "corridor"

    def createInstance(self):
        return CorridorAlgorithm()

    def shortHelpString(self) -> str:
        return tr(
            "<p>Extrudes one or more typical cross sections along a line "
            "layer, clipping them against the terrain, and returns the TIN "
            "of the resulting surface.</p>"
            "<p><b>One section per run.</b> Each feature of the alignment "
            "layer is processed separately. If a section field is given, its "
            "value chooses which section of the library applies to that run; "
            "otherwise the default section is used.</p>"
            "<p><b>Sections.</b> They are read from a library JSON file (the "
            "one the section editor saves). With no file, the example "
            "templates shipped with the plugin are used.</p>"
            "<p><b>Dynamic parameters.</b> Inside the section, a parameter "
            "can be a number, a <i>V:H</i> slope such as <tt>1:1.5</tt>, a "
            "field reference such as <tt>@width</tt> or a QGIS expression "
            "such as <tt>=if(\"rock\", '1:0.5', '1:1.5')</tt>.</p>"
            "<p><b>Axis elevation.</b> It can come from the DEM (the axis "
            "rests on the terrain), from the alignment Z (a grade line "
            "already designed), from a constant value, which leaves the "
            "platform level at the given elevation, or from an offset over "
            "the terrain, which gives a grade line parallel to it and "
            "therefore a constant earthwork thickness.</p>"
            "<p><b>Merge with the terrain.</b> With the option on, the "
            "output TIN also includes the original terrain around the "
            "corridor, stitched to the daylight line, so a single continuous "
            "surface is obtained.</p>"
        )

    # -- parametros -------------------------------------------------------
    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.DIRECTRICES, tr("Alignments (lines)"), [TIPO_LINEA]
            )
        )
        self.addParameter(
            QgsProcessingParameterMapLayer(
                self.DEM, tr("Terrain (DEM raster or mesh layer)")
            )
        )
        self.addParameter(
            QgsProcessingParameterFile(
                self.LIBRERIA,
                tr("Section library (.json)"),
                extension="json",
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.CAMPO_SECCION,
                tr("Field with the section name"),
                parentLayerParameterName=self.DIRECTRICES,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.SECCION_DEFECTO,
                tr("Default section"),
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.PASO_PK,
                tr("Station interval (m)"),
                NUM_DOUBLE,
                defaultValue=5.0,
                minValue=0.01,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUIR_VERTICES,
                tr("Add a station at every alignment vertex"),
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.INTERVALO_PK,
                tr("Interval of the labelled stations (m, 0 = no stations layer)"),
                NUM_DOUBLE,
                defaultValue=100.0,
                minValue=0.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.COTA_EJE,
                tr("Axis elevation"),
                options=[
                    tr("From the terrain (DEM)"),
                    tr("From the alignment Z"),
                    tr("Constant value"),
                    tr("Offset from the terrain"),
                ],
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.COTA_CONSTANTE,
                tr("Axis elevation if 'Constant value' was chosen (m)"),
                NUM_DOUBLE,
                defaultValue=0.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OFFSET_TERRENO,
                tr(
                    "Height over the terrain if 'Offset from the terrain' "
                    "was chosen (m, positive above)"
                ),
                NUM_DOUBLE,
                defaultValue=0.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.FUSIONAR,
                tr("Merge the result with the base terrain"),
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.CELDA_FUSION,
                tr("Merge: terrain cell size (m, 0 = DEM resolution)"),
                NUM_DOUBLE,
                defaultValue=0.0,
                minValue=0.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.HOLGURA,
                tr("Merge: terrain margin around the corridor (m)"),
                NUM_DOUBLE,
                defaultValue=50.0,
                minValue=0.0,
            )
        )

        # --- avanzados ---
        for p in (
            QgsProcessingParameterNumber(
                self.PASO_MUESTREO,
                tr("DEM sampling step when seeking the cut (m, 0 = auto)"),
                NUM_DOUBLE,
                defaultValue=0.0,
                minValue=0.0,
            ),
            QgsProcessingParameterNumber(
                self.ANCHO_MAX,
                tr("Maximum search half-width from the axis (m)"),
                NUM_DOUBLE,
                defaultValue=200.0,
                minValue=1.0,
            ),
            QgsProcessingParameterNumber(
                self.PK_INICIO,
                tr("Start station of each alignment"),
                NUM_DOUBLE,
                defaultValue=0.0,
            ),
            QgsProcessingParameterNumber(
                self.BANDA,
                tr("DEM band"),
                NUM_ENTERO,
                defaultValue=1,
                minValue=1,
            ),
            QgsProcessingParameterNumber(
                self.FACTOR_Z,
                tr("Factor to apply to the DEM elevation"),
                NUM_DOUBLE,
                defaultValue=1.0,
            ),
            QgsProcessingParameterNumber(
                self.OFFSET_Z,
                tr("Offset to add to the DEM elevation (m)"),
                NUM_DOUBLE,
                defaultValue=0.0,
            ),
            QgsProcessingParameterExtent(
                self.EXTENT_FUSION,
                tr("Merge: extent of terrain to include"),
                optional=True,
            ),
            QgsProcessingParameterString(
                self.GRUPO,
                tr("Group in the layers panel (empty = <alignment>-corridor)"),
                optional=True,
            ),
            QgsProcessingParameterString(
                self.SECCIONES_JSON,
                tr("Section library as JSON (instead of a file)"),
                multiLine=True,
                optional=True,
            ),
        ):
            self.addParameter(marcar_avanzado(p))

        # --- salidas ---
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_TIN, tr("TIN (triangles)"), TIPO_POLIGONO
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_SECCIONES, tr("Cross sections"), TIPO_LINEA
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_LINEAS, tr("Feature lines"), TIPO_LINEA
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_HUELLA, tr("Corridor footprint"), TIPO_POLIGONO
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_EJE, tr("Axis (stationed line)"), TIPO_LINEA
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUT_PK, tr("Labelled stations"), TIPO_PUNTO
            )
        )
        p = QgsProcessingParameterFeatureSink(
            self.OUT_PUNTOS,
            tr("Points of the sections"),
            TIPO_PUNTO,
            optional=True,
            createByDefault=False,
        )
        self.addParameter(p)
        p = QgsProcessingParameterFileDestination(
            self.OUT_2DM,
            tr("TIN as a 2DM mesh (loaded as a mesh layer)"),
            fileFilter="Malla SMS 2DM (*.2dm)",
            optional=True,
            createByDefault=False,
        )
        self.addParameter(p)

    # -- ejecucion --------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        origen = self.parameterAsSource(parameters, self.DIRECTRICES, context)
        if origen is None:
            raise QgsProcessingException(tr("the alignment layer is missing"))
        capa_dir = self.parameterAsVectorLayer(parameters, self.DIRECTRICES, context)
        crs = origen.sourceCrs()

        capa_dem = self.parameterAsLayer(parameters, self.DEM, context)
        try:
            terreno = make_terrain(
                capa_dem,
                crs,
                banda=self.parameterAsInt(parameters, self.BANDA, context),
                factor_z=self.parameterAsDouble(parameters, self.FACTOR_Z, context),
                offset_z=self.parameterAsDouble(parameters, self.OFFSET_Z, context),
                transform_context=context.transformContext(),
            )
        except TerrainError as exc:
            raise QgsProcessingException(str(exc)) from None

        lib = self._libreria(parameters, context, feedback)
        opts = self._opciones(parameters, context, crs, lib)

        if capa_dir is None:
            raise QgsProcessingException(
                tr(
                    "this algorithm needs a real vector layer as the alignment "
                    "(not a temporary in-memory output with no layer)"
                )
            )
        try:
            res = build_corridor(capa_dir, terreno, lib.assemblies, opts, feedback)
        except (ValueError, ParamError) as exc:
            raise QgsProcessingException(str(exc)) from None

        for w in res.warnings:
            feedback.pushWarning(w)
        feedback.pushInfo(res.stats())
        if res.mesh.is_empty:
            raise QgsProcessingException(
                tr(
                    "no triangle has been generated. Check that the DEM covers "
                    "the alignments and that they are in the same reference "
                    "system."
                )
            )

        salidas = self._escribir_salidas(
            parameters, context, feedback, res, terreno, crs
        )
        self._agrupar_y_estilar(parameters, context, salidas, capa_dir)
        return salidas

    def _opciones(self, parameters, context, crs, lib) -> BuildOptions:
        """Todas las opciones de calculo leidas de los parametros del algoritmo."""
        opts = BuildOptions(
            stations=StationOptions(
                paso=self.parameterAsDouble(parameters, self.PASO_PK, context),
                incluir_vertices=self.parameterAsBool(
                    parameters, self.INCLUIR_VERTICES, context
                ),
                pk_inicio=self.parameterAsDouble(parameters, self.PK_INICIO, context),
            ),
            section=SectionOptions(
                paso=self.parameterAsDouble(parameters, self.PASO_MUESTREO, context),
                ancho_max=self.parameterAsDouble(parameters, self.ANCHO_MAX, context),
            ),
            cota_eje=MODOS_COTA[
                min(
                    len(MODOS_COTA) - 1,
                    max(0, self.parameterAsEnum(parameters, self.COTA_EJE, context)),
                )
            ],
            cota_constante=self.parameterAsDouble(
                parameters, self.COTA_CONSTANTE, context
            ),
            offset_terreno=self.parameterAsDouble(
                parameters, self.OFFSET_TERRENO, context
            ),
            campo_seccion=self.parameterAsString(
                parameters, self.CAMPO_SECCION, context
            ),
            seccion_defecto=self.parameterAsString(
                parameters, self.SECCION_DEFECTO, context
            )
            or (lib.first() or ""),
            fusionar=self.parameterAsBool(parameters, self.FUSIONAR, context),
            merge=MergeOptions(
                celda=self.parameterAsDouble(parameters, self.CELDA_FUSION, context),
                holgura=self.parameterAsDouble(parameters, self.HOLGURA, context),
            ),
            intervalo_pk=self.parameterAsDouble(
                parameters, self.INTERVALO_PK, context
            ),
        )
        ext = self.parameterAsExtent(parameters, self.EXTENT_FUSION, context, crs)
        if ext is not None and not ext.isNull() and not ext.isEmpty():
            opts.extent_fusion = (
                ext.xMinimum(),
                ext.yMinimum(),
                ext.xMaximum(),
                ext.yMaximum(),
            )
        return opts

    def _escribir_salidas(
        self, parameters, context, feedback, res, terreno, crs
    ) -> dict:
        """Vuelca cada salida pedida y devuelve ``{clave: destino}``."""
        salidas: dict = {}
        malla = res.mesh_final
        sink, dest = self.parameterAsSink(
            parameters, self.OUT_TIN, context, fields_triangulos(), WKB_POLIGONO_Z, crs
        )
        if sink is not None:
            for ft in features_triangulos(malla, terreno):
                sink.addFeature(ft)
            salidas[self.OUT_TIN] = dest

        for clave, campos, wkb, gen in (
            (self.OUT_SECCIONES, fields_secciones(), WKB_LINEA_Z, features_secciones),
            (self.OUT_LINEAS, fields_lineas(), WKB_LINEA_Z, features_lineas),
            (self.OUT_HUELLA, fields_huella(), WKB_POLIGONO_Z, features_huella),
            (self.OUT_PUNTOS, fields_puntos(), WKB_PUNTO_Z, features_puntos),
            (self.OUT_EJE, fields_eje(), WKB_LINEA_Z, features_eje),
            (self.OUT_PK, fields_pk(), WKB_PUNTO_Z, features_pk),
        ):
            sink, dest = self.parameterAsSink(
                parameters, clave, context, campos, wkb, crs
            )
            if sink is None:
                continue
            for ft in gen(res):
                sink.addFeature(ft)
            salidas[clave] = dest

        ruta_2dm = self.parameterAsFileOutput(parameters, self.OUT_2DM, context)
        if ruta_2dm:
            if not ruta_2dm.lower().endswith(".2dm"):
                ruta_2dm = os.path.splitext(ruta_2dm)[0] + ".2dm"
            write_2dm(ruta_2dm, malla)
            feedback.pushInfo(tr(f"malla escrita en {ruta_2dm}"))
            salidas[self.OUT_2DM] = ruta_2dm
        return salidas

    def _agrupar_y_estilar(self, parameters, context, salidas, capa_dir) -> None:
        """Mete las salidas en un grupo y les pone estilo al cargarlas.

        Processing carga las capas el mismo, cuando el algoritmo ya ha acabado,
        asi que aqui solo se puede dejar dicho en el contexto que grupo les toca
        y que estilo. Es cosmetico: si la version de QGIS no lo soporta, no pasa
        nada.
        """
        grupo = self.parameterAsString(parameters, self.GRUPO, context).strip()
        if not grupo:
            grupo = nombre_grupo(capa_dir)
        estilos = {
            self.OUT_PK: "pk_puntos.qml",
            self.OUT_EJE: "pk_eje.qml",
        }
        for clave, destino in salidas.items():
            if not isinstance(destino, str):
                continue
            try:
                if not context.willLoadLayerOnCompletion(destino):
                    continue
                detalles = context.layerToLoadOnCompletionDetails(destino)
                detalles.groupName = grupo
                qml = estilos.get(clave)
                if qml:
                    ruta = os.path.join(CARPETA_ESTILOS, qml)
                    if os.path.exists(ruta):
                        detalles.setPostProcessor(_Estilador(ruta))
            except (AttributeError, TypeError):
                return  # version de QGIS sin soporte: se deja como este

    # -- ayudas -----------------------------------------------------------
    def _libreria(self, parameters, context, feedback) -> AssemblyLibrary:
        texto = self.parameterAsString(parameters, self.SECCIONES_JSON, context)
        if texto and texto.strip():
            try:
                return AssemblyLibrary.from_json(texto)
            except ParamError as exc:
                raise QgsProcessingException(
                    tr(f"la libreria en JSON no se puede leer: {exc}")
                ) from None
        ruta = self.parameterAsFile(parameters, self.LIBRERIA, context)
        if ruta:
            try:
                return AssemblyLibrary.load(ruta)
            except (OSError, ParamError) as exc:
                raise QgsProcessingException(
                    tr(f"no se puede leer '{ruta}': {exc}")
                ) from None
        feedback.pushWarning(
            tr(
                "no section library given: the example templates shipped with "
                "the plugin are used"
            )
        )
        return default_library()


__all__ = ["CorridorAlgorithm"]
