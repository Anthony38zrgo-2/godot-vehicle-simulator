"""Proveedor de Processing del plugin."""

from __future__ import annotations

import os

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .alg_corridor import CorridorAlgorithm

ICONO = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icons", "corridor.svg")


class CorridorProvider(QgsProcessingProvider):
    #: El id forma parte del identificador de los algoritmos
    #: (``aqgis:corredor``), asi que cambiarlo rompe los modelos y scripts que
    #: ya lo usen. Se mantiene corto y sin guiones a proposito.
    def id(self) -> str:
        return "aqgis"

    def name(self) -> str:
        return "AQGIS-Sivil3D"

    def longName(self) -> str:
        return "AQGIS-Sivil3D (corredores: secciones tipo sobre terreno)"

    def icon(self) -> QIcon:
        return QIcon(ICONO) if os.path.exists(ICONO) else QgsProcessingProvider.icon(self)

    def loadAlgorithms(self) -> None:
        self.addAlgorithm(CorridorAlgorithm())


__all__ = ["CorridorProvider"]
