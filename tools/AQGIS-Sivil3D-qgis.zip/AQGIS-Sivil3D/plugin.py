"""Punto de entrada del plugin: menu, barra de herramientas y proveedor."""

from __future__ import annotations

import os

from qgis.core import QgsApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu, QToolButton

from .i18n import idioma, t
from .ui.qtcompat import AREA_DOCK_ABAJO, POPUP_INSTANTANEO

from .processing.provider import CorridorProvider

CARPETA = os.path.dirname(__file__)

#: Nombre del submenu y de la barra de herramientas. Tiene que coincidir con el
#: ``name`` de metadata.txt para que QGIS agrupe las entradas del plugin. Es el
#: nombre del producto, asi que no se traduce.
MENU = "&AQGIS-Sivil3D"

#: Salto de linea para los mensajes de varias lineas.
SALTO = chr(10)


def _crs_de(capas):
    """Primer sistema de referencia valido de las capas, para guardarlo aparte.

    Las capas de espacio papel no tienen ninguno, asi que no basta con mirar la
    primera.
    """
    for capa in capas:
        if capa.crs().isValid():
            return capa.crs()
    return capas[0].crs()


def icono(nombre: str) -> QIcon:
    ruta = os.path.join(CARPETA, "icons", nombre)
    return QIcon(ruta) if os.path.exists(ruta) else QIcon()


def carpeta_perfil() -> str:
    """Carpeta del plugin dentro del perfil del usuario."""
    return os.path.join(QgsApplication.qgisSettingsDirPath(), "aqgis_sivil3d")


def _migrar_libreria_antigua(carpeta: str) -> None:
    """Rescata el ``secciones.json`` de las versiones anteriores a la 1.4.

    Hasta la 1.4 habia un unico archivo y estaba en castellano, porque era el
    unico idioma. Se convierte en la libreria castellana para que nadie pierda
    sus secciones al actualizar. No se borra el original: si el usuario vuelve a
    una version anterior, lo sigue encontrando.
    """
    viejo = os.path.join(carpeta, "secciones.json")
    nuevo = os.path.join(carpeta, "secciones_es.json")
    if not os.path.exists(viejo) or os.path.exists(nuevo):
        return
    try:
        os.makedirs(carpeta, exist_ok=True)
        with open(viejo, "r", encoding="utf-8") as fh:
            contenido = fh.read()
        with open(nuevo, "w", encoding="utf-8", newline=SALTO) as fh:
            fh.write(contenido)
    except OSError as exc:
        from .gis.registro import avisar

        avisar("no se ha podido migrar la libreria de secciones antigua", exc)


def library_path(lang: str = "") -> str:
    """Archivo de la libreria de secciones, dentro del perfil del usuario.

    Hay uno por idioma: el nombre de cada seccion es su clave y viaja al campo de
    la capa de directrices, asi que el catalogo ingles y el castellano son dos
    catalogos distintos y no se pisan.

    Vive en el perfil y no en la carpeta del plugin para que no se pierda al
    actualizar o reinstalar.
    """
    carpeta = carpeta_perfil()
    _migrar_libreria_antigua(carpeta)
    return os.path.join(carpeta, f"secciones_{lang or idioma()}.json")


class CorridorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.acciones: list = []
        #: Botones con desplegable de la barra. Hay que guardarlos: si se pierde
        #: la referencia, Qt se lleva por delante el menu que cuelga de ellos.
        self.botones: list = []
        #: Acciones que devuelve ``addToolBarWidget``, para poder quitarlas.
        self.acciones_barra: list = []
        self.provider = None
        self.dock = None
        #: Panel del editor de rasantes, si esta abierto.
        self.rasante = None
        #: Ultimo resultado calculado, para que el panel de perfiles lo use sin
        #: tener que volver a calcular.
        self.ultimo_resultado = None
        #: Esponjamiento del ultimo calculo, para el diagrama de masas.
        self.ultimo_esponjamiento = 1.0
        #: Todos los corredores de la sesion, ``{nombre: resultado}``, en el orden
        #: en que se han calculado o importado. El visor de perfiles y el
        #: generador de planos eligen de aqui.
        self.corredores: dict = {}

    # -- ciclo de vida -----------------------------------------------------
    def initGui(self) -> None:
        self.provider = CorridorProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)
        self._conectar_proyecto()

        self._accion(
            "corridor.svg",
            t("Extrude typical cross section (corridor)..."),
            self.abrir_corredor,
            t(
                "Computes the corridor: typical cross sections along the "
                "alignment clipped against the terrain, and builds the TIN."
            ),
        )
        self._accion(
            "section.svg",
            t("Typical cross section editor..."),
            self.abrir_editor,
            t("Defines and saves the library of typical cross sections."),
        )
        self._accion(
            "planos.svg",
            t("Generate drawings..."),
            self.abrir_planos,
            t(
                "Plan sheets, longitudinal profile and cross section sheets of "
                "the last corridor computed."
            ),
        )
        # Exportar e importar comparten un solo boton con desplegable: son las
        # dos caras de lo mismo y se usan de tarde en tarde, asi que no merecen
        # dos huecos en la barra. En el menu si van sueltas, que es una lista.
        self._boton_menu(
            "paquete.svg",
            t("Corridor file"),
            t("Export or import the whole corridor as a GeoPackage."),
            (
                self._accion(
                    "paquete.svg",
                    t("Export corridor to file..."),
                    self.exportar_corredor,
                    t(
                        "Saves the layer group in a GeoPackage and the sections "
                        "in a sibling JSON, so the whole corridor can be "
                        "reopened later."
                    ),
                    en_barra=False,
                ),
                self._accion(
                    "paquete.svg",
                    t("Import corridor from file..."),
                    self.importar_corredor,
                    t(
                        "Loads an exported corridor: its layers and, if the "
                        "JSON is there, its sections too, so the viewer and the "
                        "drawings work."
                    ),
                    en_barra=False,
                ),
            ),
        )
        self._accion(
            "profile.svg",
            t("Corridor profiles"),
            self.abrir_perfiles,
            t(
                "Longitudinal profile, cross section at each station and mass "
                "haul diagram of the chosen corridor."
            ),
        )
        self._accion(
            "rasante.svg",
            t("Vertical alignment editor..."),
            self.abrir_rasante,
            t(
                "Editable longitudinal profile: draw the grade line with "
                "straight, arc, Bezier and NURBS segments, with vertical "
                "curves, and write it into the alignment Z."
            ),
        )
        self._accion(
            "embalse.svg",
            t("Reservoir capacity curve (elevation-volume)..."),
            self.abrir_embalse,
            t(
                "Characteristic curve of a reservoir or pond from the DEM of "
                "its basin, with optional clipping by a polygon, CSV and PNG."
            ),
        )
        self._accion(
            "ayuda.svg",
            t("AQGIS-Sivil3D help"),
            self.abrir_ayuda,
            t(
                "Full documentation: every feature explained, with the warnings "
                "and the common problems."
            ),
        )
        # Etiqueta bilingue a proposito: quien tenga el plugin en el idioma que
        # no entiende tiene que poder encontrar esta entrada igualmente.
        self._accion(
            "idioma.svg",
            "Language / Idioma...",
            self.abrir_idioma,
            t("Choose the language of the plugin: English or Spanish."),
        )

    def unload(self) -> None:
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        if self.rasante is not None:
            # Deja el mapa limpio: el editor pinta bandas y marcas sobre el.
            self.rasante.limpiar_mapa()
            self.iface.removeDockWidget(self.rasante)
            self.rasante.deleteLater()
            self.rasante = None
        for accion in self.acciones:
            self.iface.removePluginVectorMenu(MENU, accion)
            self.iface.removeToolBarIcon(accion)
        self.acciones = []
        # Los botones con desplegable van a la barra como widget, asi que se
        # quitan por la accion que devolvio addToolBarWidget.
        for accion in self.acciones_barra:
            self.iface.removeToolBarIcon(accion)
        self.acciones_barra = []
        for boton in self.botones:
            boton.deleteLater()
        self.botones = []
        if self.provider is not None:
            try:
                QgsApplication.processingRegistry().removeProvider(self.provider)
            except RuntimeError as exc:  # Qt ya se lo habia llevado
                from .gis.registro import avisar

                avisar("el proveedor de Processing ya no estaba", exc)
            self.provider = None
        self._desconectar_proyecto()

    # -- la sesion: corredores que sobreviven al cierre de QGIS -------------
    def _conectar_proyecto(self) -> None:
        """Escucha el proyecto para guardar y recuperar los corredores.

        Sin esto, al reabrir un proyecto con el grupo de capas del corredor
        delante las herramientas no encontraban nada: las secciones resueltas
        viven en memoria, no en las capas.
        """
        from qgis.core import QgsProject

        proyecto = QgsProject.instance()
        try:
            proyecto.projectSaved.connect(self._guardar_sesion)
            proyecto.readProject.connect(self._proyecto_leido)
            proyecto.cleared.connect(self._proyecto_limpiado)
        except Exception as exc:  # noqa: BLE001 - sin senales, queda el camino manual
            from .gis.registro import avisar

            avisar("no se han podido conectar las senales del proyecto", exc)
        # Si el plugin se activa con un proyecto ya abierto, hay que mirar ahora.
        self.recuperar_corredores()

    def _desconectar_proyecto(self) -> None:
        from qgis.core import QgsProject

        proyecto = QgsProject.instance()
        for senal, slot in (
            ("projectSaved", self._guardar_sesion),
            ("readProject", self._proyecto_leido),
            ("cleared", self._proyecto_limpiado),
        ):
            try:
                getattr(proyecto, senal).disconnect(slot)
            except (TypeError, RuntimeError, AttributeError):
                # No estaba conectada: no hay nada que soltar.
                continue

    def _guardar_sesion(self) -> None:
        from .gis import sesion_proyecto

        ruta = sesion_proyecto.guardar(self.corredores)
        if ruta:
            from .gis.registro import avisar

            avisar(f"corredores de la sesion guardados en {ruta}")

    def _proyecto_leido(self, *_a) -> None:
        self.corredores = {}
        self.ultimo_resultado = None
        self.recuperar_corredores()

    def _proyecto_limpiado(self) -> None:
        self.corredores = {}
        self.ultimo_resultado = None
        if self.dock is not None:
            self.dock.set_corredores({}, self.ultimo_esponjamiento)

    def recuperar_corredores(self) -> list:
        """Rescata los corredores del proyecto abierto. Devuelve los mensajes.

        Se llama al abrir un proyecto y tambien al abrir el visor o los planos: si
        el usuario acaba de cargar un GeoPackage exportado a mano, tambien vale.

        Al final se repasa **todo** lo registrado contra el arbol de capas, no
        solo lo que se acaba de recuperar: entre medias el usuario puede haber
        quitado la capa de directrices de un corredor que ya estaba en la sesion,
        y esa alineacion ya no sirve para nada.
        """
        from .gis import sesion_proyecto

        encontrados, mensajes = sesion_proyecto.recuperar(
            ya_registrados=self.corredores
        )
        for nombre, corredor in encontrados.items():
            self.corredores[nombre] = corredor
            if self.ultimo_resultado is None:
                self.ultimo_resultado = corredor
        vivos, msgs = sesion_proyecto.filtrar_por_capas(self.corredores)
        cayeron = len(self.corredores) != len(vivos)
        self.corredores = vivos
        mensajes += msgs
        if self.ultimo_resultado not in self.corredores.values():
            self.ultimo_resultado = next(iter(self.corredores.values()), None)
        if (encontrados or cayeron) and self.dock is not None:
            self.dock.set_corredores(self.corredores, self.ultimo_esponjamiento)
        for m in mensajes:
            from .gis.registro import avisar

            avisar(m)
        return mensajes

    def _accion(self, ico: str, texto: str, slot, tip: str, en_barra: bool = True):
        """Entrada del menu del plugin y, si se pide, icono en la barra.

        Devuelve la accion para poder colgarla ademas de un boton con
        desplegable.
        """
        accion = QAction(icono(ico), texto, self.iface.mainWindow())
        accion.setStatusTip(tip)
        accion.setToolTip(tip)
        accion.triggered.connect(slot)
        self.iface.addPluginToVectorMenu(MENU, accion)
        if en_barra:
            self.iface.addToolBarIcon(accion)
        self.acciones.append(accion)
        return accion

    def _boton_menu(self, ico: str, texto: str, tip: str, acciones) -> None:
        """Un solo icono en la barra que despliega varias acciones.

        El boton se queda guardado en ``self.botones`` porque Qt no se hace
        cargo de el: si se pierde la referencia, el desplegable se queda vacio.

        Si la interfaz no sabe colocar un widget en la barra, las acciones van
        sueltas: un detalle de presentacion no puede dejar el plugin sin cargar.
        """
        anadir = getattr(self.iface, "addToolBarWidget", None)
        if anadir is None:
            from .gis.registro import avisar

            avisar("sin addToolBarWidget: el boton desplegable va como iconos")
            for accion in acciones:
                self.iface.addToolBarIcon(accion)
            return

        boton = QToolButton(self.iface.mainWindow())
        boton.setIcon(icono(ico))
        boton.setText(texto)
        boton.setToolTip(tip)
        boton.setStatusTip(tip)
        # InstantPopup: el clic despliega el menu. Sin accion por defecto, para
        # que no haya un lado del boton que exporte y otro que despliegue.
        boton.setPopupMode(POPUP_INSTANTANEO)
        menu = QMenu(boton)
        for accion in acciones:
            menu.addAction(accion)
        boton.setMenu(menu)
        self.botones.append(boton)
        self.acciones_barra.append(anadir(boton))

    # -- acciones ----------------------------------------------------------
    def abrir_idioma(self):
        """Elige el idioma del plugin y avisa de que hay que reiniciar."""
        from .ui.idioma_dialog import elegir_idioma

        return elegir_idioma(self.iface.mainWindow())

    def abrir_corredor(self) -> None:
        from .ui.corridor_dialog import CorridorDialog
        from .ui.qtcompat import ejecutar_modal

        dlg = CorridorDialog(
            self.iface, library_path(), self.iface.mainWindow(), plugin=self
        )
        ejecutar_modal(dlg)

    def abrir_planos(self) -> None:
        from .ui.planos_dialog import PlanosDialog
        from .ui.qtcompat import ejecutar_modal

        # Puede haber corredores de una sesion anterior sin registrar todavia.
        self.recuperar_corredores()

        dlg = PlanosDialog(
            self.iface,
            self.ultimo_resultado,
            self.iface.mainWindow(),
            corredores=self.corredores,
        )
        ejecutar_modal(dlg)

    def abrir_rasante(self):
        """Abre (o trae al frente) el editor de rasantes."""
        from .ui.rasante_editor import RasanteEditor

        if self.rasante is None:
            self.rasante = RasanteEditor(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(AREA_DOCK_ABAJO, self.rasante)
        self.rasante.show()
        self.rasante.raise_()
        return self.rasante

    def abrir_embalse(self):
        """Curva caracteristica de un embalse o balsa."""
        from .ui.embalse_dialog import EmbalseDialog
        from .ui.qtcompat import ejecutar_modal

        dlg = EmbalseDialog(self.iface, self.iface.mainWindow())
        ejecutar_modal(dlg)
        return dlg

    # -- exportar / importar -----------------------------------------------
    def _grupo_activo(self):
        """Grupo seleccionado en el panel de capas, o el que contenga la capa activa."""
        from qgis.core import QgsLayerTreeGroup, QgsProject

        vista = getattr(self.iface, "layerTreeView", None)
        if vista is not None:
            nodo = vista().currentNode()
            while nodo is not None:
                if isinstance(nodo, QgsLayerTreeGroup) and nodo.parent() is not None:
                    return nodo
                nodo = nodo.parent()
        capa = self.iface.activeLayer()
        if capa is not None:
            raiz = QgsProject.instance().layerTreeRoot()
            nodo = raiz.findLayer(capa.id())
            if nodo is not None and isinstance(nodo.parent(), QgsLayerTreeGroup):
                padre = nodo.parent()
                if padre.parent() is not None:
                    return padre
        return None

    def _corredor_del_grupo(self, nombre: str):
        """Corredor calculado que corresponde a ese grupo de capas, si esta.

        Hace falta para guardar tambien las secciones: sin ellas el paquete se
        reabre con las capas pero sin visor de perfiles.
        """
        result = self.corredores.get(nombre)
        if result is not None:
            return result
        for base, res in self.corredores.items():
            if nombre.startswith(base):
                return res
        return None

    def exportar_corredor(self) -> None:
        from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox

        from .gis.paquete import capas_de_grupo, exportar

        titulo = t("Export corridor")
        grupo = self._grupo_activo()
        if grupo is None:
            QMessageBox.information(
                self.iface.mainWindow(),
                titulo,
                t(
                    "Select in the layers panel the group of the corridor you "
                    "want to export (for example 'my_axis-corridor')."
                ),
            )
            return
        capas = capas_de_grupo(grupo)
        if not capas:
            QMessageBox.warning(
                self.iface.mainWindow(),
                titulo,
                t("The group '{grupo}' has no vector layers.", grupo=grupo.name()),
            )
            return
        ruta, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            titulo,
            grupo.name() + ".gpkg",
            "GeoPackage (*.gpkg)",
        )
        if not ruta:
            return
        result = self._corredor_del_grupo(grupo.name())
        ok, mensajes = exportar(
            capas, ruta, result, grupo.name(), _crs_de(capas)
        )
        texto = SALTO.join(mensajes)
        if ok:
            if result is None:
                texto += SALTO * 2 + t(
                    "Warning: the computed corridor for this group was not "
                    "found, so only the layers have been saved. On import, the "
                    "profile viewer will have no data."
                )
            QMessageBox.information(self.iface.mainWindow(), titulo, texto)
        else:
            QMessageBox.critical(self.iface.mainWindow(), titulo, texto)

    def importar_corredor(self) -> None:
        from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox

        from .gis.paquete import importar

        titulo = t("Import corridor")
        ruta, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            titulo,
            "",
            "GeoPackage (*.gpkg)",
        )
        if not ruta:
            return
        grupo, corredor, mensajes = importar(ruta)
        if grupo is None:
            QMessageBox.critical(
                self.iface.mainWindow(), titulo, SALTO.join(mensajes)
            )
            return
        if corredor is not None:
            self.guardar_resultado(corredor, 1.0, nombre=corredor.nombre or grupo.name())
        QMessageBox.information(
            self.iface.mainWindow(), titulo, SALTO.join(mensajes)
        )

    def abrir_perfiles(self):
        """Abre (o trae al frente) el panel de perfiles."""
        from .ui.profile_dock import ProfileDock

        self.recuperar_corredores()
        if self.dock is None:
            self.dock = ProfileDock(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(AREA_DOCK_ABAJO, self.dock)
        self.dock.set_corredores(self.corredores, self.ultimo_esponjamiento)
        self.dock.show()
        self.dock.raise_()
        return self.dock

    def guardar_resultado(
        self, result, esponjamiento: float = 1.0, nombre: str = ""
    ) -> str:
        """Registra un corredor. Lo llaman el dialogo de calculo y la importacion.

        Devuelve el nombre con el que ha quedado registrado, que puede llevar un
        sufijo si ya habia otro igual: cada calculo es una alternativa y no se
        machacan entre ellas.
        """
        base = (nombre or getattr(result, "nombre", "") or t("Corridor")).strip()
        final, n = base, 2
        while final in self.corredores:
            final = f"{base} ({n})"
            n += 1
        if not getattr(result, "creado", ""):
            # Sella la fecha de creacion: es con lo que el selector ordena por
            # antiguedad. Un corredor importado ya la trae de su archivo.
            from datetime import datetime

            try:
                result.creado = datetime.now().isoformat(timespec="seconds")
            except (AttributeError, TypeError):
                pass  # objeto sin ese hueco: se ordenara por nombre
        self.corredores[final] = result
        self.ultimo_resultado = result
        self.ultimo_esponjamiento = esponjamiento
        if self.dock is not None:
            self.dock.set_corredores(self.corredores, esponjamiento, final)
        # Si el proyecto ya tiene archivo, el corredor queda guardado al momento;
        # si no, se guardara cuando el usuario guarde el proyecto.
        self._guardar_sesion()
        return final

    def abrir_ayuda(self, ancla: str = ""):
        """Abre la documentacion del plugin, opcionalmente en una seccion."""
        from .ui.ayuda_dialog import AyudaDialog
        from .ui.qtcompat import ejecutar_modal

        dlg = AyudaDialog(self.iface.mainWindow(), ancla)
        ejecutar_modal(dlg)
        return dlg

    def abrir_editor(self) -> None:
        from .core.library import AssemblyLibrary, default_library
        from .ui.assembly_editor import AssemblyEditor
        from .ui.qtcompat import ejecutar_modal

        ruta = library_path()
        lib = None
        if os.path.exists(ruta):
            try:
                lib = AssemblyLibrary.load(ruta)
            except Exception:  # noqa: BLE001 - se cae a las plantillas
                lib = None
        dlg = AssemblyEditor(
            lib or default_library(), ruta, self.iface.mainWindow()
        )
        ejecutar_modal(dlg)


__all__ = ["CorridorPlugin", "library_path", "carpeta_perfil"]
