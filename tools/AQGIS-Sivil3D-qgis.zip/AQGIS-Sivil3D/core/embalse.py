"""Curva caracteristica de un embalse: cota - volumen - superficie.

Dado el raster del vaso, para cada cota ``e`` se cuenta lo que quedaria bajo el
agua:

* ``area(e)``  = numero de celdas con cota menor que ``e``, por el area de celda.
* ``vol(e)``   = suma de ``(e - cota)`` en esas celdas, por el area de celda.

Es el calculo de siempre, pero resuelto **por acumulacion en un histograma** en
vez de recorriendo el raster una vez por cota: cada celda se clasifica una sola
vez segun a partir de que cota empieza a contar, y al final dos sumas acumuladas
dan la curva completa. El resultado es el mismo, exacto, y el coste no depende
del numero de cotas, asi que un vaso de varios GB con paso de 10 cm sale de una
pasada.

El modulo es Python puro: usa ``numpy`` si lo encuentra, porque es lo que hace
que esto vaya rapido de verdad, y si no tira de bucles. Asi la aritmetica se
puede probar sin abrir QGIS.
"""

from __future__ import annotations

import bisect
import math
from dataclasses import dataclass, field
from typing import Iterable, List, Optional, Sequence

try:  # numpy esta en cualquier QGIS, pero el nucleo no lo exige
    import numpy as _np
except ImportError:  # pragma: no cover
    _np = None


def cotas(cota_ini: float, cota_fin: float, paso: float) -> List[float]:
    """Vector de cotas a cubicar, de ``cota_ini`` a ``cota_fin`` incluida.

    La ultima cota es siempre la de coronacion aunque el paso no cuadre: es el
    dato que se va a leer en la tabla, y que salga 164.9 en vez de 165 no vale.
    """
    if paso <= 0.0:
        raise ValueError("El paso de cubicacion debe ser mayor que cero.")
    if cota_fin <= cota_ini:
        raise ValueError("La cota final debe ser mayor que la inicial.")
    n = int(math.floor(round((cota_fin - cota_ini) / paso, 9)))
    salida = [round(cota_ini + paso * i, 6) for i in range(n + 1)]
    if salida[-1] < cota_fin - 1e-9:
        salida.append(round(cota_fin, 6))
    return salida


@dataclass
class CurvaEmbalse:
    """Resultado del cubicaje: una fila por cota."""

    cotas: List[float] = field(default_factory=list)
    vol_m3: List[float] = field(default_factory=list)
    area_m2: List[float] = field(default_factory=list)
    #: Extremos reales del raster, que no tienen que coincidir con los pedidos.
    cota_min: float = 0.0
    cota_max: float = 0.0
    n_celdas: int = 0
    area_celda: float = 0.0

    @property
    def vacia(self) -> bool:
        return not self.cotas

    @property
    def vol_hm3(self) -> List[float]:
        return [v / 1e6 for v in self.vol_m3]

    @property
    def area_ha(self) -> List[float]:
        return [a / 1e4 for a in self.area_m2]

    def fila(self, i: int) -> tuple:
        """``(cota, volumen m3, area m2)`` de la fila ``i``."""
        return (self.cotas[i], self.vol_m3[i], self.area_m2[i])

    # -- consulta ----------------------------------------------------------
    def _interpolar(self, valores: Sequence[float], cota: float) -> Optional[float]:
        if self.vacia:
            return None
        if cota <= self.cotas[0]:
            return valores[0]
        if cota >= self.cotas[-1]:
            return valores[-1]
        i = bisect.bisect_left(self.cotas, cota)
        c0, c1 = self.cotas[i - 1], self.cotas[i]
        v0, v1 = valores[i - 1], valores[i]
        if c1 - c0 < 1e-12:
            return v0
        return v0 + (v1 - v0) * (cota - c0) / (c1 - c0)

    def volumen_en(self, cota: float) -> Optional[float]:
        """Volumen embalsado a esa cota, en m3."""
        return self._interpolar(self.vol_m3, cota)

    def area_en(self, cota: float) -> Optional[float]:
        """Superficie inundada a esa cota, en m2."""
        return self._interpolar(self.area_m2, cota)

    def cota_para_volumen(self, volumen_m3: float) -> Optional[float]:
        """La pregunta al reves: a que cota se llega con ese volumen.

        Es la consulta util para explotacion: cuanto sube la lamina con la
        aportacion que sea.
        """
        if self.vacia:
            return None
        if volumen_m3 <= self.vol_m3[0]:
            return self.cotas[0]
        if volumen_m3 >= self.vol_m3[-1]:
            return self.cotas[-1]
        i = bisect.bisect_left(self.vol_m3, volumen_m3)
        v0, v1 = self.vol_m3[i - 1], self.vol_m3[i]
        c0, c1 = self.cotas[i - 1], self.cotas[i]
        if v1 - v0 < 1e-12:
            return c0
        return c0 + (c1 - c0) * (volumen_m3 - v0) / (v1 - v0)

    # -- salidas -----------------------------------------------------------
    def csv(self, separador: str = ";", decimal: str = ",") -> str:
        """Tabla en texto, por defecto en el formato que abre Excel en espanol."""
        lineas = [
            separador.join(
                [
                    "Cota (msnm)",
                    "Volumen (hm3)",
                    "Area (ha)",
                    "Volumen (m3)",
                    "Area (m2)",
                ]
            )
        ]
        for i, cota in enumerate(self.cotas):
            campos = [
                f"{cota:.3f}",
                f"{self.vol_m3[i] / 1e6:.6f}",
                f"{self.area_m2[i] / 1e4:.4f}",
                f"{self.vol_m3[i]:.2f}",
                f"{self.area_m2[i]:.2f}",
            ]
            if decimal != ".":
                campos = [c.replace(".", decimal) for c in campos]
            lineas.append(separador.join(campos))
        return "\n".join(lineas) + "\n"

    def resumen(self) -> str:
        if self.vacia:
            return "sin curva"
        return (
            f"{len(self.cotas)} cotas de {self.cotas[0]:.2f} a {self.cotas[-1]:.2f} m, "
            f"{self.n_celdas:,} celdas de {self.area_celda:.4g} m2. "
            f"A coronacion: {self.vol_m3[-1] / 1e6:.3f} hm3 y "
            f"{self.area_m2[-1] / 1e4:.2f} ha".replace(",", ".")
        )

    def a_dict(self) -> dict:
        return {
            "cotas": list(self.cotas),
            "vol_m3": list(self.vol_m3),
            "area_m2": list(self.area_m2),
            "cota_min": self.cota_min,
            "cota_max": self.cota_max,
            "n_celdas": self.n_celdas,
            "area_celda": self.area_celda,
        }


class Acumulador:
    """Va comiendo bloques de celdas y al final entrega la curva.

    Se separa del acceso al raster a proposito: quien lea el DEM (GDAL, el
    proveedor de QGIS o un test) solo tiene que ir pasando listas de cotas
    validas. Aqui no se sabe de donde vienen.
    """

    def __init__(self, vector_cotas: Sequence[float]):
        if len(vector_cotas) < 1:
            raise ValueError("Hace falta al menos una cota.")
        self.cotas = list(vector_cotas)
        m = len(self.cotas)
        #: ``hist[t]`` = celdas que empiezan a contar en la cota de indice ``t``.
        self._hist = [0] * (m + 1)
        self._suma = [0.0] * (m + 1)
        self._np_hist = None
        self._np_suma = None
        self.n_celdas = 0
        self.cota_min = math.inf
        self.cota_max = -math.inf

    # -- entrada -----------------------------------------------------------
    def anadir(self, valores: Iterable[float]) -> int:
        """Mete un bloque de cotas validas. Devuelve cuantas ha contado.

        Las celdas por encima de la ultima cota tambien se cuentan: caen en el
        cajon ``m``, que no entra en ningun acumulado, pero sirven para saber la
        cota maxima real del raster.
        """
        if _np is not None and not isinstance(valores, (list, tuple)):
            return self._anadir_numpy(valores)
        return self._anadir_python(valores)

    def _anadir_numpy(self, valores) -> int:
        v = _np.asarray(valores, dtype="float64").ravel()
        v = v[_np.isfinite(v)]
        if v.size == 0:
            return 0
        m = len(self.cotas)
        if self._np_hist is None:
            self._np_hist = _np.zeros(m + 1, dtype="int64")
            self._np_suma = _np.zeros(m + 1, dtype="float64")
        t = _np.searchsorted(_np.asarray(self.cotas, dtype="float64"), v, side="right")
        self._np_hist += _np.bincount(t, minlength=m + 1)
        self._np_suma += _np.bincount(t, weights=v, minlength=m + 1)
        self.n_celdas += int(v.size)
        self.cota_min = min(self.cota_min, float(v.min()))
        self.cota_max = max(self.cota_max, float(v.max()))
        return int(v.size)

    def _anadir_python(self, valores) -> int:
        n = 0
        for valor in valores:
            if valor is None:
                continue
            v = float(valor)
            if not math.isfinite(v):
                continue
            t = bisect.bisect_right(self.cotas, v)
            self._hist[t] += 1
            self._suma[t] += v
            n += 1
            if v < self.cota_min:
                self.cota_min = v
            if v > self.cota_max:
                self.cota_max = v
        self.n_celdas += n
        return n

    # -- salida ------------------------------------------------------------
    def curva(self, area_celda: float) -> CurvaEmbalse:
        """Integra el histograma y devuelve la curva.

        ``count[i]`` son las celdas inundadas a la cota ``i`` y ``suma[i]`` la
        suma de sus cotas; el volumen es ``(count * cota - suma) * area``, que es
        exactamente sumar ``(cota_agua - cota_fondo)`` celda a celda.
        """
        if self.n_celdas == 0:
            return CurvaEmbalse(area_celda=area_celda)
        m = len(self.cotas)
        if self._np_hist is not None:
            hist = self._np_hist + _np.asarray(self._hist, dtype="int64")
            suma = self._np_suma + _np.asarray(self._suma, dtype="float64")
            count = _np.cumsum(hist)[:m].astype("float64")
            ssum = _np.cumsum(suma)[:m]
            area = count * area_celda
            vol = _np.maximum((count * _np.asarray(self.cotas) - ssum) * area_celda, 0.0)
            areas = [float(a) for a in area]
            vols = [float(v) for v in vol]
        else:
            areas, vols = [], []
            count = 0.0
            ssum = 0.0
            for i, cota in enumerate(self.cotas):
                count += self._hist[i]
                ssum += self._suma[i]
                areas.append(count * area_celda)
                vols.append(max((count * cota - ssum) * area_celda, 0.0))
        return CurvaEmbalse(
            cotas=list(self.cotas),
            vol_m3=vols,
            area_m2=areas,
            cota_min=self.cota_min if math.isfinite(self.cota_min) else 0.0,
            cota_max=self.cota_max if math.isfinite(self.cota_max) else 0.0,
            n_celdas=self.n_celdas,
            area_celda=area_celda,
        )


def curva_de_bloques(
    bloques: Iterable, vector_cotas: Sequence[float], area_celda: float
) -> CurvaEmbalse:
    """Atajo: acumula todos los bloques y devuelve la curva."""
    acc = Acumulador(vector_cotas)
    for bloque in bloques:
        acc.anadir(bloque)
    return acc.curva(area_celda)


__all__ = ["Acumulador", "CurvaEmbalse", "cotas", "curva_de_bloques"]
