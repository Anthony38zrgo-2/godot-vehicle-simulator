"""Comparacion de dos polilineas de cota: proyecto contra terreno. Modulo puro.

Es la base tanto del dibujo (sombrear desmonte y terraplen) como de la medicion
(areas y volumenes). Estaba duplicado en la previsualizacion y hacia falta otra
vez para las mediciones, asi que vive aqui una sola vez.

Un "perfil" es una lista de ``(x, z)`` con ``x`` no decreciente. Sirve igual para
una seccion transversal (``x`` = distancia al eje, con signo) que para un perfil
longitudinal (``x`` = PK): la geometria del problema es la misma.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

#: Por debajo de esta diferencia de cota se considera que las dos lineas van
#: juntas y no se cuenta ni como desmonte ni como terraplen.
TOL_Z = 1.0e-6

SIGNO_TERRAPLEN = 1  #: proyecto por encima del terreno -> hay que rellenar
SIGNO_DESMONTE = -1  #: proyecto por debajo -> hay que excavar
SIGNO_NULO = 0


def valores_en(perfil: Sequence, x: float) -> list:
    """Todas las cotas del perfil en ``x``.

    Devuelve mas de una cuando ahi hay un **tramo vertical** (un bordillo, un
    muro): el perfil tiene dos vertices con la misma abscisa y dos cotas. Hay que
    conservar las dos o la integracion se equivoca, porque al salir del escalon
    seguiria con la cota de entrada.
    """
    if not perfil:
        return []
    coincidentes = [z for (xx, z) in perfil if abs(xx - x) <= 1e-9]
    if coincidentes:
        out = [coincidentes[0]]
        for z in coincidentes[1:]:
            if abs(z - out[-1]) > 1e-12:
                out.append(z)
        return out
    z = _interpolar(perfil, x)
    return [] if z is None else [z]


def _interpolar(perfil: Sequence, x: float) -> Optional[float]:
    if x < perfil[0][0] - TOL_Z or x > perfil[-1][0] + TOL_Z:
        return None
    if x <= perfil[0][0]:
        return perfil[0][1]
    for (x1, z1), (x2, z2) in zip(perfil, perfil[1:]):
        if x <= x2:
            if x2 - x1 <= 1e-12:
                return z2
            return z1 + (z2 - z1) * (x - x1) / (x2 - x1)
    return perfil[-1][1]


def z_en(perfil: Sequence, x: float) -> Optional[float]:
    """Cota del perfil en ``x``, interpolando. ``None`` si queda fuera.

    En un tramo vertical devuelve la cota de **salida** (la ultima), que es la
    que continua la cadena. Para integrar areas no se usa esta funcion sino
    :func:`valores_en`, que devuelve las dos.
    """
    vs = valores_en(perfil, x)
    return vs[-1] if vs else None


@dataclass
class Tramo:
    """Un trozo de perfil en el que el signo proyecto-terreno no cambia."""

    signo: int
    #: Muestras ``(x, z_proyecto, z_terreno)``, con los cruces en los extremos.
    muestras: list = field(default_factory=list)

    @property
    def x_ini(self) -> float:
        return self.muestras[0][0]

    @property
    def x_fin(self) -> float:
        return self.muestras[-1][0]

    @property
    def longitud(self) -> float:
        return self.x_fin - self.x_ini

    def area(self) -> float:
        """Area encerrada entre las dos lineas, siempre positiva (m2)."""
        total = 0.0
        for (x1, p1, t1), (x2, p2, t2) in zip(self.muestras, self.muestras[1:]):
            dx = x2 - x1
            if dx <= 0.0:
                continue
            total += 0.5 * (abs(p1 - t1) + abs(p2 - t2)) * dx
        return total


def _signo(zp: float, zt: float) -> int:
    d = zp - zt
    if d > TOL_Z:
        return SIGNO_TERRAPLEN
    if d < -TOL_Z:
        return SIGNO_DESMONTE
    return SIGNO_NULO


def _cruce(a: tuple, b: tuple) -> tuple:
    """Punto donde las dos lineas se cortan entre dos muestras."""
    da, db = a[1] - a[2], b[1] - b[2]
    if abs(db - da) < 1e-15:
        return b
    t = max(0.0, min(1.0, da / (da - db)))
    x = a[0] + (b[0] - a[0]) * t
    z = a[1] + (b[1] - a[1]) * t
    return (x, z, z)


def _abscisas(
    proyecto: Sequence,
    terreno: Sequence,
    x0: float,
    x1: float,
    n: int,
    paso: float,
) -> set:
    """Abscisas en las que se muestrea: los quiebros de los dos perfiles y, si se
    pide, un paso fijo o un numero de muestras."""
    xs = {x0, x1}
    for perfil in (proyecto, terreno):
        for x, _z in perfil:
            if x0 < x < x1:
                xs.add(x)
    if paso > 0.0:
        k = 1
        while x0 + k * paso < x1:
            xs.add(x0 + k * paso)
            k += 1
    elif n > 2:
        for i in range(1, n):
            xs.add(x0 + (x1 - x0) * i / n)
    return xs


def muestrear(
    proyecto: Sequence,
    terreno: Sequence,
    n: int = 0,
    paso: float = 0.0,
) -> list:
    """Muestras ``(x, z_proyecto, z_terreno)`` en el solape de los dos perfiles.

    Se muestrea en la union de las abscisas de los dos perfiles (asi no se pierde
    ningun quiebro: ni un vertice de la seccion ni un pixel del terreno) y,
    opcionalmente, se densifica a ``n`` muestras o a un ``paso`` fijo.
    """
    if len(proyecto) < 2 or len(terreno) < 2:
        return []
    x0 = max(proyecto[0][0], terreno[0][0])
    x1 = min(proyecto[-1][0], terreno[-1][0])
    if x1 - x0 <= TOL_Z:
        return []

    xs = _abscisas(proyecto, terreno, x0, x1, n, paso)
    out = []
    for x in sorted(xs):
        zps = valores_en(proyecto, x)
        zts = valores_en(terreno, x)
        if not zps or not zts:
            continue
        # En un tramo vertical salen dos muestras con la misma abscisa: el
        # intervalo entre ellas tiene anchura cero y no aporta area, pero el
        # siguiente ya arranca con la cota correcta.
        n_ = max(len(zps), len(zts))
        for i in range(n_):
            out.append((x, zps[min(i, len(zps) - 1)], zts[min(i, len(zts) - 1)]))
    return out


def tramos(
    proyecto: Sequence,
    terreno: Sequence,
    n: int = 0,
    paso: float = 0.0,
) -> list:
    """Parte el solape en :class:`Tramo` de signo constante, cortando en los cruces."""
    muestras = muestrear(proyecto, terreno, n, paso)
    if len(muestras) < 2:
        return []
    salida: list = []
    actual: list = [muestras[0]]
    signo = _signo(muestras[0][1], muestras[0][2])
    for m in muestras[1:]:
        s = _signo(m[1], m[2])
        if s != signo and s != SIGNO_NULO and signo != SIGNO_NULO:
            corte = _cruce(actual[-1], m)
            actual.append(corte)
            salida.append(Tramo(signo, actual))
            actual = [corte, m]
            signo = s
            continue
        if signo == SIGNO_NULO and s != SIGNO_NULO:
            # Arrancabamos pegados al terreno: el signo real es el que aparece.
            signo = s
        actual.append(m)
    if len(actual) >= 2:
        salida.append(Tramo(signo, actual))
    return [t for t in salida if t.longitud > TOL_Z]


def areas(proyecto: Sequence, terreno: Sequence, paso: float = 0.0) -> tuple:
    """``(area_desmonte, area_terraplen)`` en m2, las dos positivas."""
    des = ter = 0.0
    for t in tramos(proyecto, terreno, paso=paso):
        if t.signo == SIGNO_DESMONTE:
            des += t.area()
        elif t.signo == SIGNO_TERRAPLEN:
            ter += t.area()
    return des, ter


__all__ = [
    "TOL_Z",
    "SIGNO_DESMONTE",
    "SIGNO_TERRAPLEN",
    "SIGNO_NULO",
    "Tramo",
    "z_en",
    "muestrear",
    "tramos",
    "areas",
]
