"""Dibujo de perfiles en espacio papel. Modulo puro.

El problema
-----------
Para sacar un plano de transversales hay que dibujar decenas de secciones
distribuidas en hojas. QGIS no tiene ningun elemento de composicion que dibuje
perfiles, y montar cientos de ``QgsLayoutItemPolyline`` a mano es inviable.

La solucion
-----------
Se convierte "dibujar en el plano" en "generar geometria", que es lo que este
plugin ya sabe hacer. Se genera una **capa de dibujo** en un sistema de
coordenadas ficticio donde ``X`` e ``Y`` son milimetros de papel, con cada
seccion trasladada a su celda de una reticula. Despues el plano no es mas que un
mapa encuadrado sobre esa capa.

Ventajas: se simboliza con QGIS como cualquier capa, se exporta a DXF gratis, el
atlas pagina solo y las escalas quedan explicitas.

Unidades
--------
Todo lo que sale de aqui esta en **milimetros de papel**. La conversion la hace
:class:`Escala`::

    x_papel = x_terreno * 1000 / denominador_horizontal

de forma que una escala 1:100 convierte 1 m de terreno en 10 mm de papel.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional, Sequence

from ..i18n import numero, t
from .perfil import SIGNO_DESMONTE, SIGNO_TERRAPLEN, tramos, z_en

#: Clases de entidad que genera este modulo. Sirven para simbolizar la capa.
CLASE_PROYECTO = "proyecto"
CLASE_TERRENO = "terreno"
CLASE_DESMONTE = "desmonte"
CLASE_TERRAPLEN = "terraplen"
CLASE_EJE = "eje"
CLASE_MARCO = "marco"
CLASE_REJILLA = "rejilla"
CLASE_REJILLA_FINA = "rejilla_fina"
CLASE_ACOTACION = "acotacion"
CLASE_TEXTO = "texto"
CLASE_GUITARRA = "guitarra"
#: Traza de OTRO corredor superpuesta en el dibujo de este.
CLASE_OTRO = "otro_corredor"


@dataclass
class Escala:
    """Escala del dibujo: 1:``horizontal`` en planta, 1:``vertical`` en cotas."""

    horizontal: float = 200.0
    vertical: float = 200.0

    @property
    def exageracion(self) -> float:
        return self.horizontal / self.vertical

    def mm_x(self, metros: float) -> float:
        return metros * 1000.0 / self.horizontal

    def mm_z(self, metros: float) -> float:
        return metros * 1000.0 / self.vertical

    def etiqueta(self) -> str:
        if abs(self.horizontal - self.vertical) < 1e-9:
            return t("S 1:{h:.0f}", h=self.horizontal)
        return t(
            "S H 1:{h:.0f}  V 1:{v:.0f}", h=self.horizontal, v=self.vertical
        )


@dataclass
class Entidad:
    """Una entidad de dibujo en milimetros de papel."""

    clase: str
    #: Puntos ``(x, y)`` en mm. Con dos o mas es linea; con uno y ``texto``, un
    #: rotulo; cerrada si ``poligono``.
    puntos: list = field(default_factory=list)
    texto: str = ""
    poligono: bool = False
    #: Angulo del texto en grados, antihorario.
    angulo: float = 0.0
    #: Altura del texto en mm de papel. 0 = la que toque por su clase.
    altura: float = 0.0
    #: Donde se ancla el texto respecto a su punto: ``centro``, ``izquierda``,
    #: ``derecha``, y en vertical ``arriba`` / ``abajo``. Es lo que evita que los
    #: rotulos se metan dentro del marco o pisen la rejilla.
    anclaje: str = "centro"
    #: Datos para la tabla de atributos y para etiquetar.
    atributos: dict = field(default_factory=dict)


@dataclass
class Celda:
    """Hueco rectangular del papel donde se dibuja un perfil."""

    x: float
    y: float
    ancho: float
    alto: float

    @property
    def x_fin(self) -> float:
        return self.x + self.ancho

    @property
    def y_fin(self) -> float:
        return self.y + self.alto


@dataclass
class Reticula:
    """Como se reparten las celdas en la hoja."""

    columnas: int = 3
    filas: int = 4
    ancho_celda: float = 90.0  #: mm
    alto_celda: float = 65.0  #: mm
    separacion_x: float = 16.0
    separacion_y: float = 18.0
    margen_x: float = 16.0
    margen_y: float = 14.0

    @classmethod
    def ajustada(
        cls,
        ancho_papel: float,
        alto_papel: float,
        columnas: int = 3,
        filas: int = 4,
        margen_x: float = 16.0,
        margen_y: float = 14.0,
        separacion_x: float = 16.0,
        separacion_y: float = 18.0,
        reserva_titulo: float = 10.0,
    ) -> "Reticula":
        """Reticula que **llena** el papel dado con esa cuadricula de celdas.

        Es al reves de lo natural pero es como se hace un plano: el formato lo
        eliges tu y las celdas salen lo mas grandes posible. Dimensionar la celda
        primero y buscar despues el papel deja el dibujo pequeno y perdido en
        medio de la hoja.
        """
        columnas = max(1, int(columnas))
        filas = max(1, int(filas))
        ancho_celda = (
            ancho_papel - 2 * margen_x - (columnas - 1) * separacion_x
        ) / columnas
        alto_celda = (
            alto_papel - 2 * margen_y - reserva_titulo - (filas - 1) * separacion_y
        ) / filas
        return cls(
            columnas=columnas,
            filas=filas,
            ancho_celda=max(20.0, ancho_celda),
            alto_celda=max(20.0, alto_celda),
            separacion_x=separacion_x,
            separacion_y=separacion_y,
            margen_x=margen_x,
            margen_y=margen_y,
        )

    @property
    def por_hoja(self) -> int:
        return max(1, self.columnas * self.filas)

    def celda(self, indice: int) -> tuple:
        """``(hoja, Celda)`` del hueco ``indice``, contando desde arriba-izquierda."""
        hoja, resto = divmod(indice, self.por_hoja)
        fila, columna = divmod(resto, self.columnas)
        x = self.margen_x + columna * (self.ancho_celda + self.separacion_x)
        # Las filas se llenan de arriba a abajo, que es como se leen los planos.
        y_arriba = self.margen_y + self.filas * (self.alto_celda + self.separacion_y)
        y = y_arriba - (fila + 1) * (self.alto_celda + self.separacion_y)
        return hoja, Celda(x, y, self.ancho_celda, self.alto_celda)

    def ancho_hoja(self) -> float:
        return (
            2 * self.margen_x
            + self.columnas * self.ancho_celda
            + (self.columnas - 1) * self.separacion_x
        )

    def alto_hoja(self) -> float:
        return (
            2 * self.margen_y
            + self.filas * self.alto_celda
            + (self.filas - 1) * self.separacion_y
        )


@dataclass
class OpcionesDibujo:
    """Ajustes del dibujo de perfiles en papel."""

    escala: Escala = field(default_factory=Escala)
    #: Paso de la rejilla de cotas, en metros de terreno. 0 = automatico.
    paso_cotas: float = 0.0
    #: Paso de la rejilla horizontal, en metros. 0 = automatico.
    paso_abscisas: float = 0.0
    con_marco: bool = True
    con_rejilla: bool = True
    con_relleno: bool = True
    con_acotacion: bool = True
    #: Desplazamiento de las hojas en X, para que no se solapen en la capa.
    paso_hoja: float = 1000.0
    #: Altura de cada tipo de texto, en mm de papel. Son las alturas de
    #: delineacion habituales: 2 mm para cifras acotadas, algo mas para titulos.
    alturas: dict = field(
        default_factory=lambda: {
            "titulo": 3.2,
            "subtitulo": 2.4,
            "acotacion": 2.0,
            "guitarra": 2.0,
            "tabla": 2.4,
            "cabecera": 2.6,
        }
    )
    #: Separacion entre el marco y los rotulos que van por fuera, en mm.
    holgura_rotulos: float = 1.8

    def altura(self, clave: str) -> float:
        return float(self.alturas.get(clave, 2.2))


# --------------------------------------------------------------------------


def _paso_bonito(bruto: float) -> float:
    if bruto <= 0.0:
        return 1.0
    exp = math.floor(math.log10(bruto))
    base = bruto / (10.0**exp)
    for cand in (1.0, 2.0, 5.0, 10.0):
        if base <= cand:
            return cand * (10.0**exp)
    return 10.0 ** (exp + 1)


@dataclass
class _Encaje:
    """Transformacion de coordenadas de perfil a milimetros de papel."""

    x0: float
    z0: float
    ox: float
    oy: float
    escala: Escala

    def punto(self, x: float, z: float) -> tuple:
        return (
            self.ox + self.escala.mm_x(x - self.x0),
            self.oy + self.escala.mm_z(z - self.z0),
        )


def _encajar(
    proyecto: Sequence,
    terreno: Sequence,
    celda: Celda,
    opts: OpcionesDibujo,
    z_base: Optional[float] = None,
) -> Optional[_Encaje]:
    """Centra el perfil en la celda respetando la escala pedida.

    La escala manda: si el perfil no cabe, se sale de la celda (y se avisa desde
    fuera). Un plano con escala variable de una seccion a otra no es acotable.
    """
    puntos = list(proyecto) + list(terreno)
    if not puntos:
        return None
    x_min = min(p[0] for p in puntos)
    x_max = max(p[0] for p in puntos)
    z_min = min(p[1] for p in puntos)
    z_max = max(p[1] for p in puntos)
    ancho_mm = opts.escala.mm_x(x_max - x_min)
    alto_mm = opts.escala.mm_z(z_max - z_min)
    ox = celda.x + max(0.0, (celda.ancho - ancho_mm) / 2.0)
    oy = celda.y + max(0.0, (celda.alto - alto_mm) / 2.0)
    return _Encaje(
        x0=x_min, z0=z_min if z_base is None else z_base, ox=ox, oy=oy,
        escala=opts.escala,
    )


def cabe(proyecto, terreno, celda: Celda, opts: OpcionesDibujo) -> bool:
    """True si el perfil cabe en la celda a la escala pedida."""
    puntos = list(proyecto) + list(terreno)
    if not puntos:
        return True
    ancho = opts.escala.mm_x(
        max(p[0] for p in puntos) - min(p[0] for p in puntos)
    )
    alto = opts.escala.mm_z(
        max(p[1] for p in puntos) - min(p[1] for p in puntos)
    )
    return ancho <= celda.ancho + 1e-9 and alto <= celda.alto + 1e-9


#: Escalas de uso normal en planos de obra civil. Un plano solo es acotable si la
#: escala es una de estas, asi que la eleccion automatica escoge de aqui y no un
#: valor cualquiera que "encaje justo".
ESCALAS_NORMALIZADAS = (50.0, 100.0, 125.0, 200.0, 250.0, 500.0, 1000.0, 2000.0)


def elegir_escala(
    perfiles: Sequence,
    celda: Celda,
    escalas: Sequence = ESCALAS_NORMALIZADAS,
) -> Optional[Escala]:
    """Escala normalizada mas grande en la que **todos** los perfiles caben.

    ``perfiles`` es una lista de parejas ``(proyecto, terreno)``. Devuelve
    ``None`` si ni la escala mas pequena de la lista da para tanto, y entonces
    quien llama decide: agrandar la celda o partir el dibujo.
    """
    ancho_m = alto_m = 0.0
    for proyecto, terreno in perfiles:
        puntos = list(proyecto) + list(terreno)
        if not puntos:
            continue
        ancho_m = max(ancho_m, max(p[0] for p in puntos) - min(p[0] for p in puntos))
        alto_m = max(alto_m, max(p[1] for p in puntos) - min(p[1] for p in puntos))
    if ancho_m <= 0.0 and alto_m <= 0.0:
        return Escala(escalas[0], escalas[0])
    for den in sorted(escalas):
        e = Escala(den, den)
        if e.mm_x(ancho_m) <= celda.ancho and e.mm_z(alto_m) <= celda.alto:
            return e
    return None


# --------------------------------------------------------------------------


def _trazas_ajenas(otros, celda: Celda, enc, opts: OpcionesDibujo,
                   atributos: dict) -> list:
    """Trazas de otros corredores, recortadas al marco de la celda.

    Un corredor que pasa a 40 m de un dibujo que abarca 15 no puede salir pintado
    por encima del cajetin: lo que no cabe se corta en el borde.
    """
    if not otros:
        return []
    limites = _limites_de_celda(celda, enc, opts)
    ents = []
    for etiqueta, puntos in otros:
        for trozo in _recortar(puntos, limites):
            a = dict(atributos)
            a["fila"] = etiqueta
            ents.append(
                Entidad(
                    CLASE_OTRO,
                    [enc.punto(x, z) for x, z in trozo],
                    atributos=a,
                )
            )
    return ents


def _limites_de_celda(celda: Celda, enc, opts: OpcionesDibujo) -> tuple:
    """``(x_min, x_max, z_min, z_max)`` de la celda, en unidades de terreno."""
    ancho = celda.ancho * opts.escala.horizontal / 1000.0
    alto = celda.alto * opts.escala.vertical / 1000.0
    x0 = enc.x0 - (enc.ox - celda.x) * opts.escala.horizontal / 1000.0
    z0 = enc.z0 - (enc.oy - celda.y) * opts.escala.vertical / 1000.0
    return (x0, x0 + ancho, z0, z0 + alto)


def _dentro(punto, limites) -> bool:
    x, z = punto
    return limites[0] <= x <= limites[1] and limites[2] <= z <= limites[3]


def _recortar(puntos: Sequence, limites: tuple) -> list:
    """Trozos de la polilinea que caen dentro del marco.

    Lo que entra y sale del marco da varios trozos, y cada uno se dibuja por
    separado: unirlos daria una linea falsa cruzando el dibujo.
    """
    utiles = [tuple(q) for q in puntos if q is not None and len(q) >= 2]
    if len(utiles) < 2:
        return []
    trozos: list = []
    actual: list = []
    for a, b in zip(utiles, utiles[1:]):
        actual = _tramo(a, b, limites, actual, trozos)
    if len(actual) >= 2:
        trozos.append(actual)
    return trozos


def _tramo(a, b, limites: tuple, actual: list, trozos: list) -> list:
    """Añade el segmento ``ab`` al trozo en curso. Devuelve el trozo resultante."""
    a_dentro, b_dentro = _dentro(a, limites), _dentro(b, limites)
    if a_dentro and b_dentro:
        if not actual:
            actual = [a]
        actual.append(b)
        return actual
    if a_dentro:
        # Sale del marco: se cierra el trozo en el borde.
        if not actual:
            actual = [a]
        actual.append(_corte_con_marco(a, b, limites))
        if len(actual) >= 2:
            trozos.append(actual)
        return []
    if b_dentro:
        # Entra en el marco: empieza un trozo en el borde.
        return [_corte_con_marco(a, b, limites), b]
    # Los dos fuera: lo que hubiera se cierra aqui.
    if len(actual) >= 2:
        trozos.append(actual)
    return []


def _corte_con_marco(a, b, limites):
    """Punto donde el segmento ``ab`` cruza el borde del marco, por biseccion.

    La biseccion basta y sobra: en el papel, 20 pasos dejan el corte por debajo
    de la milesima de milimetro, y evita el enredo de recortar contra cuatro
    lados con casos degenerados.
    """
    dentro, fuera = (a, b) if _dentro(a, limites) else (b, a)
    for _ in range(20):
        medio = ((dentro[0] + fuera[0]) / 2.0, (dentro[1] + fuera[1]) / 2.0)
        if _dentro(medio, limites):
            dentro = medio
        else:
            fuera = medio
    return dentro


def dibujar_perfil(
    proyecto: Sequence,
    terreno: Sequence,
    celda: Celda,
    opts: OpcionesDibujo,
    titulo: str = "",
    subtitulo: str = "",
    atributos: Optional[dict] = None,
    x_eje: Optional[float] = 0.0,
    otros: Optional[Sequence] = None,
) -> list:
    """Entidades de dibujo de un perfil dentro de una celda.

    ``x_eje`` marca con una vertical la abscisa del eje (0 en una transversal);
    con ``None`` no se dibuja.

    ``otros`` son trazas de otros corredores que cruzan este dibujo, cada una
    ``(etiqueta, [(x, z)])``. Se dibujan con su propia clase para que salgan a
    trazos y en otro color: en una obra con dos trazados juntos, el plano de uno
    tiene que enseñar el otro.
    """
    atributos = dict(atributos or {})
    enc = _encajar(proyecto, terreno, celda, opts)
    if enc is None:
        return []
    ents: list = []

    if opts.con_marco:
        ents.append(
            Entidad(
                CLASE_MARCO,
                [
                    (celda.x, celda.y),
                    (celda.x_fin, celda.y),
                    (celda.x_fin, celda.y_fin),
                    (celda.x, celda.y_fin),
                ],
                poligono=True,
                atributos=atributos,
            )
        )

    if opts.con_rejilla:
        ents.extend(_rejilla(proyecto, terreno, celda, enc, opts, atributos))

    if opts.con_relleno and len(proyecto) >= 2 and len(terreno) >= 2:
        ents.extend(_relleno_de_zonas(proyecto, terreno, enc, atributos))

    if len(terreno) >= 2:
        ents.append(
            Entidad(
                CLASE_TERRENO,
                [enc.punto(x, z) for x, z in terreno],
                atributos=atributos,
            )
        )
    if len(proyecto) >= 2:
        ents.append(
            Entidad(
                CLASE_PROYECTO,
                [enc.punto(x, z) for x, z in proyecto],
                atributos=atributos,
            )
        )

    if x_eje is not None:
        z_ini = min(p[1] for p in list(proyecto) + list(terreno))
        z_fin = max(p[1] for p in list(proyecto) + list(terreno))
        ents.append(
            Entidad(
                CLASE_EJE,
                [enc.punto(x_eje, z_ini), enc.punto(x_eje, z_fin)],
                atributos=atributos,
            )
        )

    ents.extend(_trazas_ajenas(otros, celda, enc, opts, atributos))
    ents.extend(_rotulos_de_celda(celda, opts, titulo, subtitulo, atributos))
    return ents


def _relleno_de_zonas(proyecto, terreno, enc, atributos: dict) -> list:
    """Poligonos de desmonte y de terraplen, cada uno con su area medida."""
    ents: list = []
    for tramo in tramos(proyecto, terreno):
        clase = (
            CLASE_DESMONTE
            if tramo.signo == SIGNO_DESMONTE
            else (CLASE_TERRAPLEN if tramo.signo == SIGNO_TERRAPLEN else None)
        )
        if clase is None:
            continue
        contorno = [enc.punto(x, zp) for x, zp, _zt in tramo.muestras]
        contorno += [enc.punto(x, zt) for x, _zp, zt in reversed(tramo.muestras)]
        a = dict(atributos)
        a["area"] = round(tramo.area(), 4)
        ents.append(Entidad(clase, contorno, poligono=True, atributos=a))
    return ents


def _rotulos_de_celda(
    celda: Celda,
    opts: OpcionesDibujo,
    titulo: str,
    subtitulo: str,
    atributos: dict,
) -> list:
    """Titulo encima del marco y subtitulo debajo de los rotulos de abscisas."""
    ents: list = []
    if titulo:
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(celda.x + celda.ancho / 2.0, celda.y_fin + opts.holgura_rotulos)],
                texto=titulo,
                altura=opts.altura("titulo"),
                anclaje="abajo",
                atributos=atributos,
            )
        )
    if subtitulo:
        # Por debajo de los rotulos de abscisas, no encima de ellos.
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(
                    celda.x + celda.ancho / 2.0,
                    celda.y - opts.holgura_rotulos - opts.altura("acotacion") - 1.2,
                )],
                texto=subtitulo,
                altura=opts.altura("subtitulo"),
                anclaje="arriba",
                atributos=atributos,
            )
        )
    return ents


def _rejilla(proyecto, terreno, celda, enc, opts, atributos) -> list:
    """Rejilla de cotas y abscisas, con sus rotulos."""
    puntos = list(proyecto) + list(terreno)
    x_min = min(p[0] for p in puntos)
    x_max = max(p[0] for p in puntos)
    z_min = min(p[1] for p in puntos)
    z_max = max(p[1] for p in puntos)
    ents = []

    paso_z = opts.paso_cotas or _paso_bonito((z_max - z_min) / 4.0)
    z = math.ceil(z_min / paso_z) * paso_z
    while z <= z_max + 1e-9:
        a = enc.punto(x_min, z)
        b = enc.punto(x_max, z)
        ents.append(Entidad(CLASE_REJILLA_FINA, [a, b], atributos=atributos))
        if opts.con_acotacion:
            ents.append(
                Entidad(
                    CLASE_ACOTACION,
                    [(celda.x - opts.holgura_rotulos, a[1])],
                    texto=f"{z:.2f}",
                    altura=opts.altura("acotacion"),
                    anclaje="derecha",
                    atributos=atributos,
                )
            )
        z += paso_z

    paso_x = opts.paso_abscisas or _paso_bonito((x_max - x_min) / 4.0)
    x = math.ceil(x_min / paso_x) * paso_x
    while x <= x_max + 1e-9:
        a = enc.punto(x, z_min)
        b = enc.punto(x, z_max)
        ents.append(Entidad(CLASE_REJILLA, [a, b], atributos=atributos))
        if opts.con_acotacion:
            ents.append(
                Entidad(
                    CLASE_ACOTACION,
                    [(a[0], celda.y - opts.holgura_rotulos)],
                    texto=f"{x:.0f}",
                    altura=opts.altura("acotacion"),
                    anclaje="arriba",
                    atributos=atributos,
                )
            )
        x += paso_x
    return ents


# --------------------------------------------------------------------------


@dataclass
class Hoja:
    """Una hoja de dibujo con sus entidades."""

    numero: int
    entidades: list = field(default_factory=list)
    #: Rango de PK que contiene, para rotular el cajetin.
    pk_ini: float = 0.0
    pk_fin: float = 0.0
    #: Encuadre de la hoja en la capa de dibujo, en mm.
    extent: tuple = (0.0, 0.0, 0.0, 0.0)


def laminas_de_transversales(
    sections: Sequence,
    reticula: Optional[Reticula] = None,
    opts: Optional[OpcionesDibujo] = None,
    escala_automatica: bool = False,
    cruces=None,
) -> list:
    """Reparte las secciones en hojas y devuelve la lista de :class:`Hoja`.

    Con ``escala_automatica`` se elige la escala normalizada mas grande en la que
    caben todas las secciones, que es lo que se hace en un plano de verdad: una
    sola escala para toda la lamina, y de las de siempre.

    ``cruces`` es ``{id(seccion): [(etiqueta, [(offset, z)])]}`` con las trazas de
    otros corredores que cortan cada seccion. Lo calcula ``core.cruces``.
    """
    reticula = reticula or Reticula()
    opts = opts or OpcionesDibujo()
    utiles = [s for s in sections if len(s.vertices) >= 2]
    # Con secciones de varias alineaciones hay que decir de cual es cada celda:
    # dos PK 0+000 en la misma lamina, uno de cada eje, serian indistinguibles.
    tramos = {(s.station.fid, s.station.part) for s in utiles}
    varias = len(tramos) > 1
    if escala_automatica and utiles:
        _h, celda_muestra = reticula.celda(0)
        elegida = elegir_escala(
            [(s.perfil, s.terreno) for s in utiles], celda_muestra
        )
        if elegida is not None:
            opts = OpcionesDibujo(
                escala=elegida,
                paso_cotas=opts.paso_cotas,
                paso_abscisas=opts.paso_abscisas,
                con_marco=opts.con_marco,
                con_rejilla=opts.con_rejilla,
                con_relleno=opts.con_relleno,
                con_acotacion=opts.con_acotacion,
                paso_hoja=opts.paso_hoja,
            )
    hojas: dict = {}
    for i, sec in enumerate(utiles):
        n_hoja, celda = reticula.celda(i)
        # Cada hoja se desplaza en X para que las hojas no se pisen en la capa.
        celda = Celda(
            celda.x + n_hoja * opts.paso_hoja, celda.y, celda.ancho, celda.alto
        )
        des, ter = sec.areas()
        atributos = {
            "hoja": n_hoja + 1,
            "pk": round(sec.station.s, 3),
            "fid_dir": sec.station.fid,
            "parte": sec.station.part,
            "area_des": round(des, 3),
            "area_ter": round(ter, 3),
        }
        subtitulo = t("C {des:.2f} m2   F {ter:.2f} m2", des=des, ter=ter)
        if varias:
            etiqueta = f"fid {sec.station.fid}"
            if sec.station.part:
                etiqueta += f"/{sec.station.part}"
            titulo = etiqueta + "   " + t("Sta {s:.2f}", s=sec.station.s)
        else:
            titulo = t("Sta {s:.2f}", s=sec.station.s)
        ents = dibujar_perfil(
            sec.perfil,
            sec.terreno,
            celda,
            opts,
            titulo=titulo,
            subtitulo=subtitulo,
            atributos=atributos,
            x_eje=0.0,
            otros=(cruces or {}).get(id(sec)),
        )
        h = hojas.setdefault(
            n_hoja,
            Hoja(numero=n_hoja + 1, pk_ini=sec.station.s, pk_fin=sec.station.s),
        )
        h.entidades.extend(ents)
        h.pk_ini = min(h.pk_ini, sec.station.s)
        h.pk_fin = max(h.pk_fin, sec.station.s)
    for n_hoja, h in hojas.items():
        x0 = n_hoja * opts.paso_hoja
        h.extent = (x0, 0.0, x0 + reticula.ancho_hoja(), reticula.alto_hoja())
    return [hojas[k] for k in sorted(hojas)]


# --------------------------------------------------------------------------
# Guitarra del perfil longitudinal
# --------------------------------------------------------------------------

#: Filas de la guitarra, en orden de arriba abajo: (clave, rotulo, alto en
#: mm). El rotulo va en ingles y se traduce al dibujar la hoja.
FILAS_GUITARRA = (
    ("pk", "STATION", 9.0),
    ("terreno", "GROUND LEVEL", 9.0),
    ("rasante", "DESIGN LEVEL", 9.0),
    ("roja", "CUT / FILL", 9.0),
)


def guitarra(
    sections: Sequence,
    celda: Celda,
    opts: OpcionesDibujo,
    cada: int = 1,
    filas=FILAS_GUITARRA,
) -> list:
    """Tabla de datos bajo el perfil longitudinal.

    Se dibuja pegada al borde inferior de ``celda`` y hacia abajo, con una
    columna por seccion (o cada ``cada`` secciones, para que no se apelotone).
    Los valores van girados 90 grados, como en un plano de verdad.
    """
    utiles = [s for s in sections if s.z_terreno is not None]
    if not utiles:
        return []
    x_min = utiles[0].station.s
    x_max = utiles[-1].station.s
    ents: list = []

    alto_total = sum(f[2] for f in filas)
    y_arriba = celda.y
    # Marco y separadores de filas.
    ents.append(
        Entidad(
            CLASE_GUITARRA,
            [
                (celda.x, y_arriba - alto_total),
                (celda.x_fin, y_arriba - alto_total),
                (celda.x_fin, y_arriba),
                (celda.x, y_arriba),
            ],
            poligono=True,
            atributos={"fila": "marco"},
        )
    )
    y = y_arriba
    for clave, rotulo, alto in filas:
        y -= alto
        ents.append(
            Entidad(
                CLASE_GUITARRA,
                [(celda.x, y), (celda.x_fin, y)],
                atributos={"fila": clave},
            )
        )
        ents.append(
            Entidad(
                CLASE_ACOTACION,
                [(celda.x - opts.holgura_rotulos, y + alto / 2.0)],
                texto=t(rotulo),
                altura=opts.altura("guitarra"),
                anclaje="derecha",
                atributos={"fila": clave},
            )
        )

    def x_mm(s: float) -> float:
        return celda.x + opts.escala.mm_x(s - x_min)

    for i, sec in enumerate(utiles):
        if i % max(1, cada) and i != len(utiles) - 1:
            continue
        xm = x_mm(sec.station.s)
        # Linea de referencia vertical de la columna.
        ents.append(
            Entidad(
                CLASE_GUITARRA,
                [(xm, y_arriba - alto_total), (xm, y_arriba)],
                atributos={"fila": "columna", "pk": round(sec.station.s, 3)},
            )
        )
        roja = sec.cota_roja
        valores = {
            "pk": f"{sec.station.s:.2f}",
            "terreno": f"{sec.z_terreno:.2f}",
            "rasante": f"{sec.z_eje:.2f}" if math.isfinite(sec.z_eje) else "",
            "roja": f"{roja:+.2f}" if roja is not None else "",
        }
        yy = y_arriba
        for clave, _rotulo, alto in filas:
            yy -= alto
            ents.append(
                Entidad(
                    CLASE_TEXTO,
                    [(xm + 0.5 + opts.altura("guitarra") / 2.0, yy + 0.8)],
                    texto=valores.get(clave, ""),
                    angulo=90.0,
                    altura=opts.altura("guitarra"),
                    anclaje="izquierda",
                    atributos={"fila": clave, "pk": round(sec.station.s, 3)},
                )
            )
    return ents


#: Columnas de la hoja de cubicaciones: (clave, rotulo, ancho en mm,
#: decimales). El rotulo va en ingles y se traduce al dibujar la hoja.
COLUMNAS_CUBICACION = (
    ("pk_ini", "Start Sta", 24.0, 2),
    ("pk_fin", "End Sta", 24.0, 2),
    ("longitud", "Length (m)", 20.0, 2),
    ("area_des", "Cut area (m2)", 26.0, 2),
    ("area_ter", "Fill area (m2)", 26.0, 2),
    ("vol_des", "Cut vol. (m3)", 32.0, 1),
    ("vol_ter", "Fill vol. (m3)", 32.0, 1),
    ("neto", "Net (m3)", 26.0, 1),
    ("acumulado", "Cumulative (m3)", 30.0, 1),
)


def laminas_de_cubicaciones(
    medicion,
    origen: Optional[Celda] = None,
    opts: Optional[OpcionesDibujo] = None,
    filas_por_hoja: int = 34,
    x_hoja: float = 0.0,
    paso_hoja: float = 1000.0,
    numero_inicial: int = 1,
    titulo: str = "CUBICACIONES",
    columnas=COLUMNAS_CUBICACION,
) -> list:
    """Hojas con la tabla de cubicaciones y el resumen de totales.

    Es la hoja de cierre de las transversales: una fila por tramo entre secciones
    consecutivas y, al final, la suma. Se dibuja como entidades de papel igual
    que el resto, asi que sale tambien en el DXF.
    """
    opts = opts or OpcionesDibujo()
    if not medicion.volumenes:
        return []
    alto_fila = opts.altura("tabla") + 2.6
    ancho_total = sum(c[2] for c in columnas)
    if origen is None:
        origen = Celda(16.0, 40.0, ancho_total, filas_por_hoja * alto_fila)

    acumulados = dict(medicion.masas)
    areas = {round(a.pk, 6): a for a in medicion.areas}
    filas = []
    for v in medicion.volumenes:
        a1 = areas.get(round(v.pk_ini, 6))
        a2 = areas.get(round(v.pk_fin, 6))
        filas.append(
            {
                "pk_ini": v.pk_ini,
                "pk_fin": v.pk_fin,
                "longitud": v.longitud,
                # Se rotula el area media del tramo, que es la que multiplica a
                # la longitud en el metodo de areas medias.
                "area_des": 0.5
                * ((a1.desmonte if a1 else 0.0) + (a2.desmonte if a2 else 0.0)),
                "area_ter": 0.5
                * ((a1.terraplen if a1 else 0.0) + (a2.terraplen if a2 else 0.0)),
                "vol_des": v.desmonte,
                "vol_ter": v.terraplen,
                "neto": v.neto,
                "acumulado": acumulados.get(v.pk_fin, 0.0),
            }
        )

    hojas: list = []
    for n, inicio in enumerate(range(0, len(filas), filas_por_hoja)):
        trozo = filas[inicio : inicio + filas_por_hoja]
        ultima = inicio + filas_por_hoja >= len(filas)
        dx = x_hoja + n * paso_hoja
        celda = Celda(origen.x + dx, origen.y, ancho_total, len(trozo) * alto_fila)
        ents = _tabla(
            trozo,
            celda,
            opts,
            columnas,
            alto_fila,
            titulo=(
                titulo + t("  (sheet {n})", n=n + 1)
                if len(filas) > filas_por_hoja
                else titulo
            ),
            totales=medicion if ultima else None,
        )
        hojas.append(
            Hoja(
                numero=numero_inicial + n,
                entidades=ents,
                pk_ini=trozo[0]["pk_ini"],
                pk_fin=trozo[-1]["pk_fin"],
                extent=(
                    celda.x - 6.0,
                    celda.y - (30.0 if ultima else 8.0),
                    celda.x_fin + 6.0,
                    celda.y_fin + 16.0,
                ),
            )
        )
    return hojas


def _tabla(filas, celda, opts, columnas, alto_fila, titulo="", totales=None) -> list:
    """Rejilla, cabecera, filas y, si se dan, el bloque de totales."""
    ents: list = []
    alto_cab = opts.altura("cabecera") + 3.4
    y_cab = celda.y_fin
    ents.append(
        Entidad(
            CLASE_GUITARRA,
            [
                (celda.x, celda.y),
                (celda.x_fin, celda.y),
                (celda.x_fin, y_cab + alto_cab),
                (celda.x, y_cab + alto_cab),
            ],
            poligono=True,
            atributos={"fila": "marco"},
        )
    )
    x = celda.x
    for clave, rotulo, ancho, _dec in columnas:
        ents.append(
            Entidad(
                CLASE_GUITARRA,
                [(x, celda.y), (x, y_cab + alto_cab)],
                atributos={"fila": "columna", "columna": clave},
            )
        )
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(x + ancho / 2.0, y_cab + alto_cab / 2.0)],
                texto=t(rotulo),
                altura=opts.altura("cabecera"),
                anclaje="centro",
                atributos={"fila": "cabecera", "columna": clave},
            )
        )
        x += ancho
    ents.append(
        Entidad(
            CLASE_GUITARRA,
            [(celda.x_fin, celda.y), (celda.x_fin, y_cab + alto_cab)],
            atributos={"fila": "columna"},
        )
    )
    ents.append(
        Entidad(
            CLASE_GUITARRA,
            [(celda.x, y_cab), (celda.x_fin, y_cab)],
            atributos={"fila": "cabecera"},
        )
    )
    if titulo:
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(celda.x, y_cab + alto_cab + opts.holgura_rotulos)],
                texto=titulo,
                altura=opts.altura("titulo"),
                anclaje="abajo_izquierda",
                atributos={"fila": "titulo"},
            )
        )

    y = y_cab
    for fila in filas:
        y -= alto_fila
        ents.append(
            Entidad(
                CLASE_GUITARRA,
                [(celda.x, y), (celda.x_fin, y)],
                atributos={"fila": "dato"},
            )
        )
        x = celda.x
        for clave, _rotulo, ancho, dec in columnas:
            ents.append(
                Entidad(
                    CLASE_TEXTO,
                    [(x + ancho - 2.2, y + alto_fila / 2.0)],
                    texto=f"{fila[clave]:.{dec}f}",
                    altura=opts.altura("tabla"),
                    anclaje="derecha",
                    atributos={"fila": "dato", "columna": clave},
                )
            )
            x += ancho

    if totales is not None:
        ents.extend(_totales(totales, celda, opts))
    return ents


def _totales(medicion, celda: Celda, opts: OpcionesDibujo) -> list:
    """Bloque de totales bajo la tabla."""
    lineas = [
        (t("Measured length"), f"{medicion.longitud:.2f} m"),
        (t("Cut volume"), numero(medicion.total_desmonte, 1) + " m3"),
        (t("Fill volume"), numero(medicion.total_terraplen, 1) + " m3"),
        (
            t("Balance (fill - cut)"),
            numero(medicion.total_neto, 1, signo=True) + " m3",
        ),
    ]
    ents: list = []
    y = celda.y - 4.0
    for rotulo, valor in lineas:
        y -= opts.altura("tabla") + 1.8
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(celda.x, y)],
                texto=rotulo,
                altura=opts.altura("tabla"),
                anclaje="izquierda",
                atributos={"fila": "total"},
            )
        )
        ents.append(
            Entidad(
                CLASE_TEXTO,
                [(celda.x + 75.0, y)],
                texto=valor,
                altura=opts.altura("tabla"),
                anclaje="izquierda",
                atributos={"fila": "total"},
            )
        )
    return ents


def laminas_longitudinal(
    sections: Sequence,
    ancho_util: float = 380.0,
    alto_util: float = 240.0,
    opts: Optional[OpcionesDibujo] = None,
    cada_guitarra: int = 1,
    x_hoja: float = 0.0,
    paso_hoja: float = 1000.0,
    numero_inicial: int = 1,
    etiqueta: str = "",
    otros=None,
) -> list:
    """Perfil longitudinal **paginado** en hojas del ancho util dado.

    Un perfil de 1 km a 1:1000 mide un metro de papel: no cabe en ninguna hoja
    normal. Los planos de verdad lo parten en tiras, una por hoja, y eso es lo
    que hace esta funcion: reparte los PK de modo que el dibujo de cada hoja no
    pase de ``ancho_util`` milimetros, y le pone a cada una su guitarra.

    Cada hoja repite el PK final de la anterior, para que las tiras empalmen.

    Con varias alineaciones en el mismo plano, ``etiqueta`` dice de cual es esta
    tira: dos perfiles distintos que empiezan en el PK 0 no se pueden distinguir
    por el rango de PK.

    ``otros`` son las rasantes de los demas corredores referidas a estas mismas
    abscisas, ``[(etiqueta, [(s, z)])]``: se superponen a trazos para ver como van
    unas respecto a otras.
    """
    opts = opts or OpcionesDibujo(escala=Escala(horizontal=1000.0, vertical=100.0))
    utiles = [
        s for s in sections if s.z_terreno is not None and math.isfinite(s.z_eje)
    ]
    if len(utiles) < 2:
        return []

    alto_guitarra = sum(f[2] for f in FILAS_GUITARRA)
    alto_dibujo = max(30.0, alto_util - alto_guitarra - 12.0)
    # Longitud de eje que cabe en una hoja, en metros de terreno.
    largo_hoja = ancho_util * opts.escala.horizontal / 1000.0

    def rango_mm(grupo) -> float:
        """Altura en mm que ocuparia ese grupo de secciones."""
        zs = [s.z_eje for s in grupo] + [s.z_terreno for s in grupo]
        return opts.escala.mm_z(max(zs) - min(zs))

    # Reparto de secciones por hoja, repitiendo la ultima de cada una para que
    # las tiras empalmen. Se corta por dos motivos: porque se agota el ancho o
    # porque el desnivel acumulado ya no cabe en el alto. Lo segundo es lo que se
    # nos escapaba: a 1:100 en vertical, 400 m de eje al 12 % son 480 mm de alto,
    # y el dibujo se salia del marco.
    grupos: list = []
    actual = [utiles[0]]
    for sec in utiles[1:]:
        tentativa = actual + [sec]
        desborda_ancho = sec.station.s - actual[0].station.s > largo_hoja
        desborda_alto = rango_mm(tentativa) > alto_dibujo
        if (desborda_ancho or desborda_alto) and len(actual) >= 2:
            grupos.append(actual)
            actual = [actual[-1], sec]
        else:
            actual.append(sec)
    if len(actual) >= 2:
        grupos.append(actual)

    hojas: list = []
    for n, grupo in enumerate(grupos):
        proyecto = [(s.station.s, s.z_eje) for s in grupo]
        terreno = [(s.station.s, s.z_terreno) for s in grupo]
        puntos = proyecto + terreno
        ancho_mm = opts.escala.mm_x(grupo[-1].station.s - grupo[0].station.s)
        alto_mm = opts.escala.mm_z(
            max(p[1] for p in puntos) - min(p[1] for p in puntos)
        )
        dx = x_hoja + n * paso_hoja
        celda = Celda(
            30.0 + dx,
            20.0 + alto_guitarra,
            max(ancho_mm, 40.0),
            max(alto_mm, alto_dibujo * 0.4),
        )
        ents = dibujar_perfil(
            proyecto,
            terreno,
            celda,
            opts,
            titulo=(
                f"PERFIL LONGITUDINAL{'  ' + etiqueta if etiqueta else ''}"
                f"   PK {grupo[0].station.s:.0f} a "
                f"{grupo[-1].station.s:.0f}   {opts.escala.etiqueta()}"
            ),
            # Sin subtitulo: debajo del marco va la guitarra, no hay sitio.
            subtitulo="",
            atributos={
                "hoja": numero_inicial + n,
                "pk_ini": round(grupo[0].station.s, 3),
                "pk_fin": round(grupo[-1].station.s, 3),
            },
            x_eje=None,
            # Solo el trozo de cada rasante ajena que cae en esta hoja.
            otros=[
                (
                    nombre,
                    [
                        (s, z)
                        for s, z in puntos
                        if grupo[0].station.s - 1e-6 <= s <= grupo[-1].station.s + 1e-6
                    ],
                )
                for nombre, puntos in (otros or ())
            ],
        )
        ents.extend(guitarra(grupo, celda, opts, cada_guitarra))
        hojas.append(
            Hoja(
                numero=numero_inicial + n,
                entidades=ents,
                pk_ini=grupo[0].station.s,
                pk_fin=grupo[-1].station.s,
                extent=(
                    celda.x - 26.0,
                    celda.y - alto_guitarra - 10.0,
                    celda.x_fin + 10.0,
                    celda.y_fin + 14.0,
                ),
            )
        )
    return hojas


def lamina_longitudinal(
    sections: Sequence,
    celda: Optional[Celda] = None,
    opts: Optional[OpcionesDibujo] = None,
    cada_guitarra: int = 1,
) -> Hoja:
    """Perfil longitudinal con su guitarra, en una sola lamina."""
    opts = opts or OpcionesDibujo(escala=Escala(horizontal=1000.0, vertical=100.0))
    utiles = [
        s for s in sections if s.z_terreno is not None and math.isfinite(s.z_eje)
    ]
    if not utiles:
        return Hoja(numero=1)
    proyecto = [(s.station.s, s.z_eje) for s in utiles]
    terreno = [(s.station.s, s.z_terreno) for s in utiles]
    if celda is None:
        ancho = opts.escala.mm_x(utiles[-1].station.s - utiles[0].station.s)
        puntos = proyecto + terreno
        alto = opts.escala.mm_z(
            max(p[1] for p in puntos) - min(p[1] for p in puntos)
        )
        celda = Celda(30.0, 45.0, max(ancho, 50.0), max(alto, 40.0))
    ents = dibujar_perfil(
        proyecto,
        terreno,
        celda,
        opts,
        titulo=t("LONGITUDINAL PROFILE"),
        subtitulo=opts.escala.etiqueta(),
        atributos={"pk_ini": round(utiles[0].station.s, 3),
                   "pk_fin": round(utiles[-1].station.s, 3)},
        x_eje=None,
    )
    ents.extend(guitarra(utiles, celda, opts, cada_guitarra))
    alto_guitarra = sum(f[2] for f in FILAS_GUITARRA)
    return Hoja(
        numero=1,
        entidades=ents,
        pk_ini=utiles[0].station.s,
        pk_fin=utiles[-1].station.s,
        extent=(
            celda.x - 25.0,
            celda.y - alto_guitarra - 10.0,
            celda.x_fin + 10.0,
            celda.y_fin + 12.0,
        ),
    )


__all__ = [
    "CLASE_PROYECTO",
    "CLASE_TERRENO",
    "CLASE_DESMONTE",
    "CLASE_TERRAPLEN",
    "CLASE_EJE",
    "CLASE_MARCO",
    "CLASE_REJILLA",
    "CLASE_REJILLA_FINA",
    "CLASE_ACOTACION",
    "CLASE_TEXTO",
    "CLASE_GUITARRA",
    "Escala",
    "Entidad",
    "Celda",
    "Reticula",
    "OpcionesDibujo",
    "Hoja",
    "cabe",
    "elegir_escala",
    "ESCALAS_NORMALIZADAS",
    "dibujar_perfil",
    "guitarra",
    "laminas_de_transversales",
    "laminas_de_cubicaciones",
    "COLUMNAS_CUBICACION",
    "lamina_longitudinal",
    "laminas_longitudinal",
    "FILAS_GUITARRA",
]
