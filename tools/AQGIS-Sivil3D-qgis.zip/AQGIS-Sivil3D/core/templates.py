"""Plantillas de seccion tipo listas para usar. Modulo puro.

Son solo :class:`~aqgis_sivil3d.core.schema.Assembly` construidas desde
codigo. Sirven de punto de partida en el editor y de material para los tests.
Cualquiera de ellas se puede guardar a JSON y volver a cargar sin perdida.

El catalogo se construye en el idioma que se le pida: el nombre de la seccion es
su clave -- es lo que se escribe en el campo de la capa de directrices -- y los
codigos de punto viajan a los atributos de las capas de salida, asi que el
catalogo de arranque en ingles y el de castellano son dos catalogos distintos, no
el mismo con etiquetas encima. Cada uno es coherente consigo mismo, que es lo que
necesita el cosido del TIN por codigo de punto.
"""

from __future__ import annotations

from ..i18n import en_idioma
from .schema import Assembly, branch, el


def _c(codigo: str, lang: str) -> str:
    """Codigo de punto en el idioma del catalogo."""
    return en_idioma(codigo, lang)


def _ramas_carretera(
    lang: str,
    carril: float,
    pend_carril: float,
    arcen: float,
    pend_arcen: float,
    berma: float,
    talud_desmonte: str,
    talud_terraplen: str,
    con_cuneta: bool,
):
    fijos = [
        el("offset_pendiente", _c("CARRIAGEWAY", lang), ancho=carril, pendiente=pend_carril),
        el("offset_pendiente", _c("SHOULDER", lang), ancho=arcen, pendiente=pend_arcen),
    ]
    if berma > 0:
        fijos.append(
            el("offset_pendiente", _c("VERGE", lang), ancho=berma, pendiente=pend_arcen)
        )
    desmonte = []
    if con_cuneta:
        desmonte.append(
            el(
                "cuneta",
                _c("DITCH", lang),
                profundidad=0.4,
                ancho_fondo=0.0,
                talud_interior="1:1",
                talud_exterior="1:1",
            )
        )
    desmonte.append(el("talud_daylight", _c("SLOPE", lang), talud=talud_desmonte))
    terraplen = [el("talud_daylight", _c("SLOPE", lang), talud=talud_terraplen)]
    return fijos, desmonte, terraplen


def carretera_1x1(lang: str = "en") -> Assembly:
    """Carretera convencional de un carril por sentido, arcen y cuneta."""
    fijos, desmonte, terraplen = _ramas_carretera(
        lang,
        carril=3.5,
        pend_carril=-2.0,
        arcen=1.5,
        pend_arcen=-4.0,
        berma=0.75,
        talud_desmonte="1:1",
        talud_terraplen="1:1.5",
        con_cuneta=True,
    )
    return Assembly(
        nombre=en_idioma("Road 1+1", lang),
        descripcion=en_idioma(
            "Carriageway 2x3.50 at -2%, shoulder 1.50 at -4%, verge 0.75. Cut "
            "1:1 with a triangular ditch, fill 1:1.5.",
            lang,
        ),
        izquierda=branch(fijos, desmonte, terraplen),
        derecha=branch(
            [e.copy() for e in fijos],
            [e.copy() for e in desmonte],
            [e.copy() for e in terraplen],
        ),
    )


def camino(lang: str = "en") -> Assembly:
    """Camino rural de 5 m sin arcenes."""
    fijos = [el("offset_pendiente", _c("EDGE", lang), ancho=2.5, pendiente=-3.0)]
    desmonte = [
        el(
            "cuneta",
            _c("DITCH", lang),
            profundidad=0.3,
            talud_interior="1:1",
            talud_exterior="1:1",
        ),
        el("talud_daylight", _c("SLOPE", lang), talud="1:1"),
    ]
    terraplen = [el("talud_daylight", _c("SLOPE", lang), talud="1:1.5")]
    return Assembly(
        nombre=en_idioma("Track 5 m", lang),
        descripcion=en_idioma(
            "5.00 m platform at -3% crowned both ways, ditch in cut.", lang
        ),
        izquierda=branch(fijos, desmonte, terraplen),
        derecha=branch(
            [e.copy() for e in fijos],
            [e.copy() for e in desmonte],
            [e.copy() for e in terraplen],
        ),
    )


def desmonte_banqueado(lang: str = "en") -> Assembly:
    """Plataforma en ladera con desmonte banqueado y terraplen banqueado.

    Es el caso que mas se nota: taludes distintos por lado y banquetas cada
    8 m en desmonte / cada 10 m en terraplen.
    """
    fijos_izq = [
        el("offset_pendiente", _c("PLATFORM", lang), ancho=7.0, pendiente=-2.0)
    ]
    fijos_der = [
        el("offset_pendiente", _c("PLATFORM", lang), ancho=7.0, pendiente=-2.0)
    ]
    desmonte = [
        el(
            "cuneta",
            _c("DITCH", lang),
            profundidad=0.5,
            ancho_fondo=0.5,
            talud_interior="1:1",
            talud_exterior="1:1",
        ),
        el(
            "talud_banqueta",
            _c("SLOPE", lang),
            talud="1:1",
            altura_banqueta=8.0,
            ancho_banqueta=3.0,
            pendiente_banqueta=2.0,
            max_banquetas=6,
        ),
    ]
    terraplen = [
        el(
            "talud_banqueta",
            _c("SLOPE", lang),
            talud="1:1.5",
            altura_banqueta=10.0,
            ancho_banqueta=4.0,
            pendiente_banqueta=-2.0,
            max_banquetas=5,
            talud_siguientes="1:2",
        )
    ]
    return Assembly(
        nombre=en_idioma("Hillside platform (benched)", lang),
        descripcion=en_idioma(
            "14 m platform. Cut 1:1 with 3 m benches every 8 m of height; fill "
            "1:1.5 (and 1:2 from the second bench on) with 4 m benches every "
            "10 m.",
            lang,
        ),
        izquierda=branch(fijos_izq, desmonte, terraplen),
        derecha=branch(
            fijos_der,
            [e.copy() for e in desmonte],
            [e.copy() for e in terraplen],
        ),
    )


def plataforma_por_campos(lang: str = "en") -> Assembly:
    """Ejemplo de seccion parametrizada por campos de la capa de directrices.

    Cada feature de la alineacion lleva su propio ancho y sus propios taludes.
    Es la forma de aplicar "una seccion distinta" a cada tramo sin definir tres
    secciones a mano.
    """
    fijos = [
        el(
            "offset_pendiente",
            _c("PLATFORM", lang),
            ancho="@" + en_idioma("width", lang),
            pendiente="@" + en_idioma("camber", lang),
        )
    ]
    desmonte = [
        el(
            "talud_daylight",
            _c("SLOPE", lang),
            talud="@" + en_idioma("cut_slope", lang),
        )
    ]
    terraplen = [
        el(
            "talud_daylight",
            _c("SLOPE", lang),
            talud="@" + en_idioma("fill_slope", lang),
        )
    ]
    return Assembly(
        nombre=en_idioma("Platform from fields", lang),
        descripcion=en_idioma(
            "The parameters are read from the alignment fields: width, camber, "
            "cut_slope, fill_slope. QGIS expressions starting with '=' also "
            "work.",
            lang,
        ),
        izquierda=branch(fijos, desmonte, terraplen),
        derecha=branch(
            [e.copy() for e in fijos],
            [e.copy() for e in desmonte],
            [e.copy() for e in terraplen],
        ),
    )


def zanja(lang: str = "en") -> Assembly:
    """Zanja / canal de cota fija, para ver el uso de eje con cota impuesta."""
    fijos = [
        el("offset_cota", _c("BOTTOM", lang), ancho=1.0, modo="desnivel", valor=0.0),
        el("offset_cota", _c("CREST", lang), ancho=1.5, modo="desnivel", valor=1.5),
    ]
    return Assembly(
        nombre=en_idioma("Trench 2 m", lang),
        descripcion=en_idioma(
            "2 m wide bottom and 1:1 sides up to 1.5 m high.", lang
        ),
        eje={"cota": "terreno", "desnivel": -1.5, "desplazamiento": 0.0},
        # El cajero busca el terreno tanto si queda por encima de la corona
        # (desmonte) como si queda por debajo (terraplen): mismo codigo en los
        # dos grupos, asi la linea de coronacion no se parte.
        izquierda=branch(
            fijos,
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1.5")],
        ),
        derecha=branch(
            [e.copy() for e in fijos],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1.5")],
        ),
    )


def presa_gravedad(lang: str = "en") -> Assembly:
    """Presa de hormigon de gravedad: el perfil triangular de siempre.

    El paramento de aguas arriba va practicamente vertical y el de aguas abajo
    con el talud que le da la estabilidad al vuelco. Los dos bajan hasta
    encontrar el terreno, que es lo que hace un cuerpo de presa apoyado en el
    valle.
    """
    return Assembly(
        nombre=en_idioma("Concrete gravity dam", lang),
        descripcion=en_idioma(
            "10 m crest, upstream face 0.15H:1V and downstream face 0.75H:1V. "
            "Compute it with a constant axis elevation: the crest is level.",
            lang,
        ),
        eje={"cota": "terreno", "desnivel": 0.0, "desplazamiento": 0.0},
        izquierda=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="5", pendiente="-2")],
            [el("talud_daylight", _c("SLOPE", lang), talud="2:1", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:0.15", altura_max=0.0)],
        ),
        derecha=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="5", pendiente="-1")],
            [el("talud_daylight", _c("SLOPE", lang), talud="2:1", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:0.75", altura_max=0.0)],
        ),
    )


def presa_escollera(lang: str = "en") -> Assembly:
    """Presa de escollera con pantalla de hormigon aguas arriba.

    La pantalla va sobre el paramento de aguas arriba, mas tendido que en una de
    gravedad, y el espaldon de aguas abajo lleva bermas.
    """
    return Assembly(
        nombre=en_idioma("Rockfill dam with face slab", lang),
        descripcion=en_idioma(
            "10 m crest, upstream slope 1.25H:1V (the face slab) and downstream "
            "shoulder 1.4H:1V with 5 m berms every 15 m of height.",
            lang,
        ),
        eje={"cota": "terreno", "desnivel": 0.0, "desplazamiento": 0.0},
        izquierda=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="5", pendiente="-2")],
            [el("talud_daylight", _c("SLOPE", lang), talud="2:1", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1.25", altura_max=0.0)],
        ),
        derecha=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="5", pendiente="-1")],
            [el("talud_daylight", _c("SLOPE", lang), talud="2:1", altura_max=0.0)],
            [
                el(
                    "talud_banqueta",
                    _c("SLOPE", lang),
                    talud="1:1.4",
                    altura_banqueta="15",
                    ancho_banqueta="5",
                    pendiente_banqueta="-2",
                    max_banquetas=6,
                    talud_siguientes=0.0,
                )
            ],
        ),
    )


def presa_materiales_sueltos(lang: str = "en") -> Assembly:
    """Presa de materiales sueltos: taludes tendidos a los dos lados."""
    return Assembly(
        nombre=en_idioma("Embankment dam", lang),
        descripcion=en_idioma(
            "12 m crest and 2.5H:1V slopes, with 5 m berms every 15 m of height "
            "on the downstream shoulder.",
            lang,
        ),
        eje={"cota": "terreno", "desnivel": 0.0, "desplazamiento": 0.0},
        izquierda=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="6", pendiente="-2")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:2.5", altura_max=0.0)],
        ),
        derecha=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="6", pendiente="-2")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1", altura_max=0.0)],
            [
                el(
                    "talud_banqueta",
                    _c("SLOPE", lang),
                    talud="1:2.5",
                    altura_banqueta="15",
                    ancho_banqueta="5",
                    pendiente_banqueta="-2",
                    max_banquetas=6,
                    talud_siguientes=0.0,
                )
            ],
        ),
    )


def pantalla_hormigon(lang: str = "en") -> Assembly:
    """Pantalla o muro de hormigon: casi sin coronacion y paramentos verticales."""
    return Assembly(
        nombre=en_idioma("Concrete wall", lang),
        descripcion=en_idioma(
            "Half a metre of crest on each side and vertical faces in cut; in "
            "fill, 1H:1V. A starting point for a wall or a face slab.",
            lang,
        ),
        eje={"cota": "terreno", "desnivel": 0.0, "desplazamiento": 0.0},
        izquierda=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="0.5", pendiente="0")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:0.001", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1", altura_max=0.0)],
        ),
        derecha=branch(
            [el("offset_pendiente", _c("EDGE", lang), ancho="0.5", pendiente="0")],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:0.001", altura_max=0.0)],
            [el("talud_daylight", _c("SLOPE", lang), talud="1:1", altura_max=0.0)],
        ),
    )


#: Plantillas disponibles, en el orden en que se ofrecen en el editor.
TEMPLATES = {
    "carretera_1x1": carretera_1x1,
    "camino": camino,
    "desmonte_banqueado": desmonte_banqueado,
    "plataforma_por_campos": plataforma_por_campos,
    "zanja": zanja,
    # Obra hidraulica: el cuerpo va siempre en el grupo de terraplen, porque
    # una presa se levanta desde el terreno hasta la coronacion.
    "presa_gravedad": presa_gravedad,
    "presa_escollera": presa_escollera,
    "presa_materiales_sueltos": presa_materiales_sueltos,
    "pantalla_hormigon": pantalla_hormigon,
}

#: Codigos de punto que usan las plantillas. Se listan aqui para que la
#: interfaz pueda ofrecerlos y para que los tests comprueben que los dos
#: catalogos estan completos.
CODIGOS_PUNTO = (
    "CARRIAGEWAY",
    "SHOULDER",
    "VERGE",
    "DITCH",
    "SLOPE",
    "PLATFORM",
    "EDGE",
    "BOTTOM",
    "CREST",
)


def template_names() -> list:
    return list(TEMPLATES)


def load_template(nombre: str, lang: str = "") -> Assembly:
    """Plantilla por su clave interna, en el idioma pedido o en el que este puesto."""
    if not lang:
        from ..i18n import idioma

        lang = idioma()
    try:
        return TEMPLATES[nombre](lang)
    except KeyError:
        raise KeyError(f"plantilla desconocida: {nombre!r}") from None


__all__ = ["TEMPLATES", "CODIGOS_PUNTO", "template_names", "load_template"]
