"""Preparacion de una seccion para previsualizarla sin capas. Modulo puro.

En el editor no hay ningun feature de la directriz, asi que los parametros
dinamicos (``@campo``, ``=expresion``) no se pueden evaluar. Para poder dibujar
la seccion igualmente se sustituyen por un valor de prueba: el que el usuario
haya escrito en la tabla de valores de prueba, y si no lo hay, el valor por
defecto del propio parametro.
"""

from __future__ import annotations

from typing import Any, Optional

from .schema import Assembly

PREFIJOS_DINAMICOS = ("@", "=")


def es_dinamico(valor: Any) -> bool:
    return isinstance(valor, str) and valor.strip()[:1] in PREFIJOS_DINAMICOS


def nombre_campo(valor: Any) -> Optional[str]:
    """``'@ancho'`` -> ``'ancho'``; cualquier otra cosa -> ``None``."""
    if isinstance(valor, str):
        txt = valor.strip()
        if txt.startswith("@"):
            return txt[1:].strip() or None
    return None


def campos_referenciados(asm: Assembly) -> list:
    """Campos que la seccion necesita, para pedir valores de prueba."""
    nombres = set()
    for clave in ("desnivel", "desplazamiento"):
        n = nombre_campo(asm.eje.get(clave))
        if n:
            nombres.add(n)
    for _side, _grupo, el in asm.elementos():
        for spec in el.definicion().params:
            n = nombre_campo(el.raw(spec.name))
            if n:
                nombres.add(n)
    return sorted(nombres)


def sanitize_for_preview(
    asm: Assembly, valores: Optional[dict] = None
) -> Assembly:
    """Copia de la seccion con los parametros dinamicos ya sustituidos.

    ``valores`` es ``{nombre_de_campo: valor_de_prueba}``. Lo que no se puede
    resolver cae al valor por defecto del parametro, que siempre es valido, de
    modo que la previsualizacion nunca se queda en blanco por una expresion.
    """
    valores = valores or {}
    out = asm.copy()
    for _side, _grupo, el in out.elementos():
        d = el.definicion()
        for spec in d.params:
            crudo = el.raw(spec.name)
            if not es_dinamico(crudo):
                el.params[spec.name] = crudo
                continue
            campo = nombre_campo(crudo)
            if campo is not None and campo in valores and valores[campo] not in (
                None,
                "",
            ):
                el.params[spec.name] = valores[campo]
            else:
                el.params[spec.name] = spec.default
    for clave, defecto in (("desnivel", 0.0), ("desplazamiento", 0.0)):
        crudo = out.eje.get(clave, defecto)
        if es_dinamico(crudo):
            campo = nombre_campo(crudo)
            if campo is not None and campo in valores and valores[campo] not in (
                None,
                "",
            ):
                out.eje[clave] = valores[campo]
            else:
                out.eje[clave] = defecto
    return out


__all__ = [
    "es_dinamico",
    "nombre_campo",
    "campos_referenciados",
    "sanitize_for_preview",
]
