"""Como se ve un corredor en el dibujo de **otro**.

En una obra con dos trazados cerca —una carretera y su reposición, un ramal, dos
calzadas— los planos de uno tienen que enseñar el otro. Si no, no hay forma de
ver si se tocan.

Aqui esta la geometria de eso, sin QGIS:

``traza_en_seccion``
    corta el plano transversal de una seccion con las **lineas caracteristicas**
    de otro corredor y devuelve la traza que deja, en coordenadas de la seccion
    (offset respecto al eje, cota). Es literalmente la seccion del otro corredor
    vista en ese plano.
``rasante_en_abscisas``
    la rasante de otro corredor referida a las abscisas del principal, para
    superponerla en el perfil longitudinal.

Se corta con **las dos familias de polilineas** de la superficie:

* las **lineas caracteristicas**, que la recorren a lo largo (borde de calzada,
  arcen, pie de talud...), y
* las propias **secciones transversales**.

Hacen falta las dos. Con dos trazados casi paralelos, el plano de corte cruza las
longitudinales y no las transversales; con dos que se cruzan en angulo recto pasa
justo lo contrario: las longitudinales del otro corredor son paralelas al plano y
no lo cortan nunca. Usando ambas, la traza sale en cualquier angulo.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

Punto3 = Tuple[float, float, float]

#: Cuanto se sale del ancho de la seccion al buscar cruces, en metros. Un poco de
#: margen evita perder un corredor que pasa justo por el borde.
MARGEN = 5.0
#: Dos cortes mas juntos que esto son el mismo punto, en metros.
TOL_DUPLICADO = 0.02


@dataclass
class TrazaCruce:
    """Traza de otro corredor en el plano de una seccion."""

    #: Nombre para la leyenda.
    etiqueta: str = ""
    #: ``[(offset, z)]`` en coordenadas de la seccion, de izquierda a derecha.
    puntos: List[Tuple[float, float]] = field(default_factory=list)
    #: Codigo de punto de cada vertice, en el mismo orden.
    codigos: List[str] = field(default_factory=list)

    @property
    def vacia(self) -> bool:
        return len(self.puntos) < 2


def _corte_segmento(a: Punto3, b: Punto3, ox: float, oy: float,
                    ax: float, ay: float, nx: float, ny: float
                    ) -> Optional[Tuple[float, float]]:
    """Corte del segmento ``ab`` con el plano vertical de una seccion.

    ``(ox, oy)`` es el eje, ``(ax, ay)`` la direccion de avance y ``(nx, ny)`` la
    normal de la seccion. Devuelve ``(offset, z)`` en coordenadas de la seccion,
    o ``None`` si el segmento no cruza el plano.

    El offset se mide **sobre la normal**, que es la misma convencion que usa
    ``Section.world``: ``mundo = eje + normal * offset``. Derivarla girando el
    avance es pedir un error de signo.
    """
    # Distancia con signo de cada extremo al plano, medida en la direccion de
    # avance del eje.
    da = (a[0] - ox) * ax + (a[1] - oy) * ay
    db = (b[0] - ox) * ax + (b[1] - oy) * ay
    if da == 0.0 and db == 0.0:
        return None  # el segmento vive dentro del plano: no hay un corte unico
    if (da > 0.0) == (db > 0.0) and da != 0.0 and db != 0.0:
        return None  # los dos al mismo lado
    denominador = da - db
    if abs(denominador) < 1e-12:
        return None
    t = da / denominador
    if t < 0.0 or t > 1.0:
        return None
    x = a[0] + (b[0] - a[0]) * t
    y = a[1] + (b[1] - a[1]) * t
    z = a[2] + (b[2] - a[2]) * t
    return ((x - ox) * nx + (y - oy) * ny, z)


def traza_en_seccion(
    seccion,
    lineas: Dict[str, Sequence[Punto3]],
    etiqueta: str = "",
    orden: Optional[Sequence[str]] = None,
    ancho_max: float = 0.0,
) -> TrazaCruce:
    """Corta las lineas caracteristicas de otro corredor con el plano de ``seccion``.

    ``lineas`` es ``{codigo: [(x, y, z)]}``. ``orden`` fija el orden de los codigos
    de izquierda a derecha; sin el, se ordena por el offset que salga, que es lo
    correcto salvo en una seccion que se pliegue sobre si misma.
    """
    st = seccion.station
    ox, oy = st.x, st.y
    nx, ny = st.nx, st.ny
    # La direccion de avance es la perpendicular a la normal.
    ax, ay = -ny, nx
    limite = ancho_max if ancho_max > 0.0 else 0.0

    encontrados: List[Tuple[float, float, str]] = []
    for codigo, puntos in lineas.items():
        pts = [p for p in puntos if p is not None and len(p) >= 3]
        for a, b in zip(pts, pts[1:]):
            corte = _corte_segmento(a, b, ox, oy, ax, ay, nx, ny)
            if corte is None:
                continue
            offset, z = corte
            if limite and abs(offset) > limite + MARGEN:
                continue
            encontrados.append((offset, z, codigo))
            break  # una linea caracteristica cruza el plano una vez
    if not encontrados:
        return TrazaCruce(etiqueta=etiqueta)

    if orden:
        posicion = {c: i for i, c in enumerate(orden)}
        encontrados.sort(key=lambda t: (posicion.get(t[2], len(posicion)), t[0]))
    else:
        encontrados.sort(key=lambda t: t[0])
    # Las dos familias de polilineas pueden dar el mismo punto dos veces: donde
    # una longitudinal se cruza con una transversal, que es en cada vertice.
    limpios: List[Tuple[float, float, str]] = []
    for offset, z, codigo in encontrados:
        if limpios and abs(offset - limpios[-1][0]) < TOL_DUPLICADO:
            if abs(z - limpios[-1][1]) < TOL_DUPLICADO:
                continue
        limpios.append((offset, z, codigo))
    return TrazaCruce(
        etiqueta=etiqueta,
        puntos=[(o, z) for o, z, _c in limpios],
        codigos=[c for _o, _z, c in limpios],
    )


def lineas_de_run(run) -> Dict[str, List[Punto3]]:
    """Polilineas 3D de la superficie de un tramo, ``{clave: [(x, y, z)]}``.

    Van las **longitudinales** (las lineas caracteristicas, una por codigo de
    punto) y las **transversales** (cada seccion resuelta). Con las dos familias,
    el plano de corte encuentra la superficie venga en el angulo que venga: si los
    ejes van paralelos cruza las longitudinales, y si se cruzan en angulo recto,
    las transversales.
    """
    from .tin import feature_lines

    validas = [s for s in run.sections if len(s.vertices) >= 2]
    lineas: Dict[str, List[Punto3]] = {}

    def guardar(clave: str, puntos) -> None:
        # Un codigo que desaparece y reaparece da varias polilineas: se quedan
        # todas, con sufijo, porque cada trozo cruza el plano por su cuenta.
        final, n = clave, 2
        while final in lineas:
            final = f"{clave}#{n}"
            n += 1
        lineas[final] = [tuple(p) for p in puntos]

    for codigo, puntos in feature_lines(validas):
        if len(puntos) >= 2:
            guardar(codigo, puntos)
    for i, sec in enumerate(validas):
        puntos = sec.world_points()
        if len(puntos) >= 2:
            guardar(f"@seccion{i}", puntos)
    return lineas


def cruces_de_seccion(
    seccion,
    otros,
    ancho_max: float = 0.0,
) -> List[TrazaCruce]:
    """Trazas de ``otros`` tramos en el plano de ``seccion``.

    ``otros`` es ``[(etiqueta, run)]``. Solo devuelve las que de verdad cruzan:
    un corredor que pasa lejos no aporta nada al dibujo.
    """
    salida = []
    for etiqueta, run in otros:
        traza = traza_en_seccion(
            seccion, lineas_de_run(run), etiqueta=etiqueta, ancho_max=ancho_max
        )
        if not traza.vacia:
            salida.append(traza)
    return salida


def _corte_planta(a, b, c, d):
    """Corte en planta de los segmentos ``ab`` y ``cd``.

    Devuelve ``(t, u)`` con las fracciones a lo largo de cada uno, o ``None`` si
    no se cruzan dentro de sus extremos.
    """
    r_x, r_y = b[0] - a[0], b[1] - a[1]
    s_x, s_y = d[0] - c[0], d[1] - c[1]
    denominador = r_x * s_y - r_y * s_x
    if abs(denominador) < 1e-12:
        return None  # paralelos o degenerados
    q_x, q_y = c[0] - a[0], c[1] - a[1]
    t = (q_x * s_y - q_y * s_x) / denominador
    u = (q_x * r_y - q_y * r_x) / denominador
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return (t, u)
    return None


def interseccion_con_recorrido(run, pts, acum=None) -> List[Tuple[float, float]]:
    """Donde la superficie de ``run`` corta el plano vertical de un recorrido.

    ``pts`` es la polilinea en planta del eje principal —el plano vertical del
    perfil longitudinal es el que la sigue— y ``acum`` sus abscisas acumuladas.

    Devuelve ``[(s, z)]``: la abscisa sobre el eje principal y la cota a la que
    el otro corredor cruza. Es lo que de verdad se ve en un longitudinal: si el
    otro trazado pasa por encima o por debajo, aparece **solo donde lo cruza**,
    no a lo largo de todo el dibujo.
    """
    if len(pts) < 2:
        return []
    if acum is None:
        acum = [0.0]
        for (x0, y0, *_a), (x1, y1, *_b) in zip(pts, pts[1:]):
            acum.append(acum[-1] + math.hypot(x1 - x0, y1 - y0))

    salida: List[Tuple[float, float]] = []
    for puntos in lineas_de_run(run).values():
        salida += _cortes_de_polilinea(puntos, pts, acum)
    if not salida:
        return []
    salida.sort(key=lambda p: p[0])
    return _sin_repetidos(salida)


def _cortes_de_polilinea(puntos, pts, acum) -> List[Tuple[float, float]]:
    """Cortes en planta de una polilinea con el recorrido, en ``(s, z)``."""
    salida = []
    for c, d in zip(puntos, puntos[1:]):
        for i in range(len(pts) - 1):
            corte = _corte_planta(pts[i], pts[i + 1], c, d)
            if corte is None:
                continue
            t, u = corte
            salida.append(
                (
                    acum[i] + (acum[i + 1] - acum[i]) * t,
                    c[2] + (d[2] - c[2]) * u,
                )
            )
    return salida


def _sin_repetidos(puntos) -> List[Tuple[float, float]]:
    """Quita los puntos pegados: el mismo cruce visto por dos polilineas."""
    limpio: List[Tuple[float, float]] = []
    for s, z in puntos:
        if limpio and abs(s - limpio[-1][0]) < TOL_DUPLICADO:
            if abs(z - limpio[-1][1]) < TOL_DUPLICADO:
                continue
        limpio.append((s, z))
    return limpio


def rasante_en_abscisas(run, principal) -> List[Tuple[float, float]]:
    """Rasante de ``run`` referida a las abscisas del tramo ``principal``.

    Para superponerla en el perfil longitudinal hace falta que las dos hablen del
    mismo eje de abscisas. Se usa la **distancia en planta** desde el origen del
    principal a la proyeccion de cada punto del otro: no es exacto si los dos ejes
    divergen mucho, pero para dos trazados que van juntos —que es cuando esto se
    superpone— es justo lo que se quiere ver.
    """
    utiles = [s for s in run.sections if s.vertices and math.isfinite(s.z_eje)]
    if len(utiles) < 2:
        return []
    base = [s for s in principal.sections if s.vertices]
    if len(base) < 2:
        return [(s.station.s, s.z_eje) for s in utiles]

    puntos = []
    for sec in utiles:
        x, y = sec.station.x, sec.station.y
        # Estacion del principal mas cercana en planta.
        mejor, dist = None, float("inf")
        for otra in base:
            d = (otra.station.x - x) ** 2 + (otra.station.y - y) ** 2
            if d < dist:
                mejor, dist = otra, d
        if mejor is None:
            continue
        puntos.append((mejor.station.s, sec.z_eje))
    puntos.sort(key=lambda p: p[0])
    # Una sola cota por abscisa: si dos secciones caen en la misma, se promedian.
    salida: List[Tuple[float, float]] = []
    for s, z in puntos:
        if salida and abs(s - salida[-1][0]) < 1e-6:
            salida[-1] = (s, (salida[-1][1] + z) / 2.0)
        else:
            salida.append((s, z))
    return salida


__all__ = [
    "MARGEN",
    "TOL_DUPLICADO",
    "TrazaCruce",
    "cruces_de_seccion",
    "interseccion_con_recorrido",
    "lineas_de_run",
    "rasante_en_abscisas",
    "traza_en_seccion",
]
