"""Guardado y recuperacion de un corredor calculado. Modulo puro.

Las capas de salida se pueden exportar a un GeoPackage y volver a abrirlas, pero
con eso solo se recupera el dibujo: el visor de perfiles, las mediciones y los
planos necesitan los objetos :class:`Section`, que llevan la linea de terreno, la
cota del eje y los codigos de cada vertice.

Aqui se serializa exactamente eso a JSON, de modo que un corredor guardado se
puede reabrir y seguir trabajando **sin el DEM y sin recalcular**.

El JSON es deliberadamente plano y legible: es un formato de intercambio, no un
volcado binario, y tiene que poder inspeccionarse y versionarse.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional

from .elements import Vertex
from .resolver import Section, Station

SESION_VERSION = 1


# --------------------------------------------------------------------------
# Serializacion de las piezas
# --------------------------------------------------------------------------


def station_a_dict(st: Station) -> dict:
    d = {
        "s": st.s,
        "x": st.x,
        "y": st.y,
        "nx": st.nx,
        "ny": st.ny,
        "fid": st.fid,
        "part": st.part,
    }
    if st.es_vertice:
        d["v"] = 1
    if st.z is not None:
        d["z"] = st.z
    return d


def station_de_dict(d: dict) -> Station:
    return Station(
        s=float(d["s"]),
        x=float(d["x"]),
        y=float(d["y"]),
        nx=float(d["nx"]),
        ny=float(d["ny"]),
        fid=int(d.get("fid", -1)),
        part=int(d.get("part", 0)),
        es_vertice=bool(d.get("v", 0)),
        z=None if d.get("z") is None else float(d["z"]),
    )


def section_a_dict(sec: Section) -> dict:
    return {
        "station": station_a_dict(sec.station),
        "z_eje": sec.z_eje,
        "z_terreno": sec.z_terreno,
        "modo_izq": sec.modo_izq,
        "modo_der": sec.modo_der,
        "ok": bool(sec.ok),
        "avisos": list(sec.warnings),
        # Los vertices van como listas y no como diccionarios: son muchos y el
        # archivo se dispararia de tamano.
        "vertices": [[v.offset, v.z, v.code, v.kind] for v in sec.vertices],
        "terreno": [[o, z] for o, z in sec.terreno],
    }


def section_de_dict(d: dict) -> Section:
    return Section(
        station=station_de_dict(d["station"]),
        z_eje=float(d["z_eje"]),
        vertices=[
            Vertex(float(v[0]), float(v[1]), str(v[2]), str(v[3]))
            for v in d.get("vertices") or []
        ],
        modo_izq=str(d.get("modo_izq", "")),
        modo_der=str(d.get("modo_der", "")),
        ok=bool(d.get("ok", True)),
        warnings=list(d.get("avisos") or []),
        terreno=[(float(t[0]), float(t[1])) for t in d.get("terreno") or []],
        z_terreno=None if d.get("z_terreno") is None else float(d["z_terreno"]),
    )


# --------------------------------------------------------------------------
# Objetos ligeros que imitan a los del calculo
# --------------------------------------------------------------------------


@dataclass
class AlineacionGuardada:
    """Lo que del ``Alignment`` hace falta para el visor y para los planos."""

    fid: int = -1
    part: int = 0
    stations: list = field(default_factory=list)
    longitud: float = 0.0
    tiene_z: bool = False
    pts: list = field(default_factory=list)
    #: Capa de directrices de la que salio. Sin esto no se puede saber si la
    #: alineacion sigue cargada en el proyecto, y un corredor recuperado de una
    #: sesion vieja ofreceria alineaciones muertas. Vacio en los archivos
    #: escritos antes de que esto existiera.
    capa_id: str = ""
    capa_nombre: str = ""

    #: Los PK de rotulacion ya vienen guardados en el tramo, asi que aqui no hay
    #: que volver a repartirlos: ``pk_stations`` no existe a proposito.

    @property
    def etiqueta(self) -> str:
        return f"fid {self.fid}" if self.part == 0 else f"fid {self.fid}/{self.part}"


@dataclass
class TramoGuardado:
    """Equivalente de ``CorridorRun`` para un corredor recuperado."""

    alignment: AlineacionGuardada = field(default_factory=AlineacionGuardada)
    asm_nombre: str = ""
    sections: list = field(default_factory=list)
    pks: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    ring: list = field(default_factory=list)

    @property
    def etiqueta(self) -> str:
        return self.alignment.etiqueta

    @property
    def n_ok(self) -> int:
        return sum(1 for s in self.sections if s.ok)


@dataclass
class CorredorGuardado:
    """Equivalente de ``BuildResult`` para un corredor recuperado.

    No lleva la malla: el TIN se recupera de la capa de triangulos del
    GeoPackage. Lo que lleva son las secciones, que es lo que no se puede
    reconstruir de las capas.
    """

    nombre: str = ""
    runs: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    crs: str = ""
    #: Momento en que se calculo o importo, en ISO 8601. Para poder ordenar las
    #: alineaciones por fecha de creacion.
    creado: str = ""

    @property
    def sections(self) -> list:
        return [s for r in self.runs for s in r.sections]

    def stats(self) -> str:
        return (
            f"{len(self.runs)} tramos, {len(self.sections)} secciones "
            f"(corredor recuperado, sin malla)"
        )


# --------------------------------------------------------------------------
# JSON
# --------------------------------------------------------------------------


def a_dict(result, nombre: str = "", crs: str = "") -> dict:
    """Serializa un ``BuildResult`` (o un :class:`CorredorGuardado`)."""
    runs = []
    for run in result.runs:
        al = run.alignment
        runs.append(
            {
                "asm_nombre": getattr(run, "asm_nombre", ""),
                "avisos": list(getattr(run, "warnings", []) or []),
                "alineacion": {
                    "fid": getattr(al, "fid", -1),
                    "part": getattr(al, "part", 0),
                    "longitud": getattr(al, "longitud", 0.0),
                    "tiene_z": bool(getattr(al, "tiene_z", False)),
                    "capa_id": str(getattr(al, "capa_id", "") or ""),
                    "capa_nombre": str(getattr(al, "capa_nombre", "") or ""),
                    "pts": [
                        [p[0], p[1], p[2]] for p in (getattr(al, "pts", []) or [])
                    ],
                },
                "pks": [station_a_dict(st) for st in (getattr(run, "pks", []) or [])],
                "secciones": [section_a_dict(s) for s in run.sections],
            }
        )
    return {
        "version": SESION_VERSION,
        "nombre": nombre or getattr(result, "nombre", ""),
        "crs": crs or getattr(result, "crs", ""),
        "creado": str(getattr(result, "creado", "") or ""),
        "avisos": list(getattr(result, "warnings", []) or []),
        "tramos": runs,
    }


def de_dict(data: dict) -> CorredorGuardado:
    runs = []
    for d in data.get("tramos") or []:
        a = d.get("alineacion") or {}
        pts = [
            (float(p[0]), float(p[1]), None if p[2] is None else float(p[2]))
            for p in (a.get("pts") or [])
        ]
        secciones = [section_de_dict(s) for s in d.get("secciones") or []]
        al = AlineacionGuardada(
            fid=int(a.get("fid", -1)),
            part=int(a.get("part", 0)),
            stations=[s.station for s in secciones],
            longitud=float(a.get("longitud", 0.0)),
            tiene_z=bool(a.get("tiene_z", False)),
            pts=pts,
            capa_id=str(a.get("capa_id", "") or ""),
            capa_nombre=str(a.get("capa_nombre", "") or ""),
        )
        runs.append(
            TramoGuardado(
                alignment=al,
                asm_nombre=str(d.get("asm_nombre", "")),
                sections=secciones,
                pks=[station_de_dict(x) for x in d.get("pks") or []],
                warnings=list(d.get("avisos") or []),
            )
        )
    return CorredorGuardado(
        nombre=str(data.get("nombre", "")),
        runs=runs,
        warnings=list(data.get("avisos") or []),
        crs=str(data.get("crs", "")),
        creado=str(data.get("creado", "") or ""),
    )


def guardar(result, ruta: str, nombre: str = "", crs: str = "") -> None:
    with open(ruta, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(a_dict(result, nombre, crs), fh, ensure_ascii=False, separators=(",", ":"))


def cargar(ruta: str) -> CorredorGuardado:
    with open(ruta, "r", encoding="utf-8") as fh:
        return de_dict(json.load(fh))


__all__ = [
    "SESION_VERSION",
    "AlineacionGuardada",
    "TramoGuardado",
    "CorredorGuardado",
    "station_a_dict",
    "station_de_dict",
    "section_a_dict",
    "section_de_dict",
    "a_dict",
    "de_dict",
    "guardar",
    "cargar",
]
