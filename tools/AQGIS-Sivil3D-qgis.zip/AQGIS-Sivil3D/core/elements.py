"""Catalogo de elementos de seccion y su resolucion geometrica.

Una seccion tipo no es una geometria, es una *cadena de reglas*: cada elemento
arranca donde acabo el anterior y produce uno o mas vertices. Solo dos
elementos son "inteligentes" (buscan el terreno) y el ultimo de la cadena tiene
que ser uno de ellos para que la superficie cierre.

Un ``talud_daylight`` intermedio si vale: con un limite de tramo, busca el
terreno dentro de ese tramo y, si no lo encuentra, cierra en un quiebro y le
pasa el relevo al elemento siguiente. Asi se define un talud con dos o mas
pendientes (1:1 hasta 2 m de desnivel y 1:1.5 a partir de ahi, por ejemplo) sin
tener que elegir a mano cual aplica en cada PK.

Modulo puro: no importa nada de QGIS.

Sistema de coordenadas local de la seccion
------------------------------------------
* ``offset``: distancia con signo al eje, negativa a la izquierda y positiva a
  la derecha del sentido de avance de la directriz.
* ``z``: cota absoluta.
* ``ctx.side``: -1 para la rama izquierda, +1 para la derecha. Los elementos
  usan ``ctx.side * ancho`` para avanzar, de modo que la misma definicion sirve
  para los dos lados.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ..i18n import t
from .params import ParamError, format_slope

GRUPO_FIJOS = "fijos"
GRUPO_DESMONTE = "desmonte"
GRUPO_TERRAPLEN = "terraplen"
GRUPOS = (GRUPO_FIJOS, GRUPO_DESMONTE, GRUPO_TERRAPLEN)

#: Nombre visible de cada grupo, en ingles. La interfaz lo pasa por ``t()``.
GRUPO_LABEL = {
    GRUPO_FIJOS: "Fixed",
    GRUPO_DESMONTE: "Cut",
    GRUPO_TERRAPLEN: "Fill",
}

#: Clase de vertice.
KIND_PUNTO = "punto"
KIND_DAYLIGHT = "daylight"
KIND_TRUNCADO = "truncado"
#: Fin normal de un tramo de talud que no busca ya el terreno porque detras
#: viene otro talud con distinta pendiente. No corta la cadena (a diferencia de
#: ``KIND_DAYLIGHT`` y ``KIND_TRUNCADO``) y no forma parte de la linea de
#: daylight, pero si es un vertice con codigo propio: ancla el cosido del TIN y
#: sale como linea caracteristica (la linea de cambio de talud).
KIND_QUIEBRO = "quiebro"

#: Sufijo del vertice donde el talud corta el terreno. Es deliberadamente el
#: mismo para todos los elementos que buscan terreno: asi la linea de daylight
#: es continua entre secciones aunque una tenga 2 banquetas y la siguiente 3.
SUF_DAY = "_DAY"


def code_quiebro(code: str, n: int) -> str:
    """Codigo del quiebro del ``n``-esimo talud de una cadena.

    Se numera solo, como los vertices de banqueta, para que los taludes de una
    cadena puedan compartir codigo sin que sus quiebros se pisen.
    """
    return code + t("_Q{n}", n=n) if n > 0 else code


@dataclass(frozen=True)
class Vertex:
    """Un punto de la seccion resuelta."""

    offset: float
    z: float
    code: str
    kind: str = KIND_PUNTO

    def with_code(self, code: str) -> "Vertex":
        return Vertex(self.offset, self.z, code, self.kind)


#: Que hacer con un parametro cuando su elemento es el ultimo de su grupo, o
#: sea, cuando no hay ningun elemento detras al que traspasar el trazado.
ULTIMO_NORMAL = ""  # se edita siempre
ULTIMO_GRIS = "gris"  # se ve, pero inhabilitado
ULTIMO_OCULTO = "oculto"  # no se muestra


@dataclass(frozen=True)
class ParamSpec:
    """Descripcion de un parametro. La interfaz genera el formulario con esto."""

    name: str
    label: str
    kind: str  # float | percent | slope | int | bool | choice
    default: Any
    unit: str = ""
    choices: tuple = ()
    tooltip: str = ""
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    #: Trato en la interfaz cuando el elemento es el ultimo de su grupo.
    si_ultimo: str = ULTIMO_NORMAL
    #: Nombre de otro parametro que tiene que valer algo distinto de 0 para que
    #: este pinte algo. Solo afecta a como se resume el elemento en la lista.
    depende_de: str = ""


@dataclass
class ResolveContext:
    """Estado compartido durante la resolucion de una rama."""

    side: int
    mode: str
    tz: Callable[[float], Optional[float]]
    step: float = 0.5
    max_width: float = 200.0
    tol: float = 1.0e-4
    warnings: list = field(default_factory=list)
    failed: bool = False
    #: ``True`` si el elemento que se esta resolviendo es el ultimo de su grupo.
    #: Un talud intermedio puede cerrar su tramo y traspasar al siguiente; el
    #: ultimo no tiene a quien traspasar, asi que o corta el terreno o falla.
    ultimo: bool = True
    #: Codigo del vertice de daylight del grupo. Es uno solo para todo el grupo
    #: (el del ultimo elemento que busca terreno), de modo que la linea de
    #: daylight sea continua aunque en un PK corte el primer talud y en el
    #: siguiente corte el segundo. Vacio = cada elemento usa el suyo.
    code_day: str = ""
    #: Orden del elemento entre los que buscan terreno de su grupo, empezando en
    #: 1. Numera el vertice de quiebro (``TALUD_Q1``, ``TALUD_Q2``...) para que
    #: los taludes de una cadena puedan llamarse todos igual: eso es lo deseable
    #: -mantiene una sola linea de daylight- y no puede costar que sus quiebros
    #: se confundan entre si.
    buscador_n: int = 0

    def fail(self, msg: str) -> None:
        self.failed = True
        self.warn(msg)

    def warn(self, msg: str) -> None:
        lado = t("left") if self.side < 0 else t("right")
        self.warnings.append(f"[{lado}] {msg}")


# --------------------------------------------------------------------------
# Busqueda del corte con el terreno
# --------------------------------------------------------------------------

STATUS_CUT = "cut"  # se ha encontrado el corte
STATUS_END = "end"  # se ha agotado el segmento sin cortar
STATUS_NODATA = "nodata"  # el terreno no tiene datos


def _gap(offset: float, z: float, ctx: ResolveContext) -> Optional[float]:
    """Desnivel proyecto - terreno en un offset dado. ``None`` si NoData."""
    tz = ctx.tz(offset)
    if tz is None:
        return None
    return z - tz


def _clip_to_max_width(cur: Vertex, dx: float, ctx: ResolveContext) -> float:
    """Factor <= 1 que recorta el avance para no salir del ancho maximo."""
    if dx == 0.0:
        return 1.0
    target = abs(cur.offset + dx)
    if target <= ctx.max_width:
        return 1.0
    disponible = ctx.max_width - abs(cur.offset)
    if disponible <= 0.0:
        return 0.0
    return max(0.0, min(1.0, disponible / abs(dx)))


def seek_terrain(
    cur: Vertex,
    dx: float,
    dz: float,
    ctx: ResolveContext,
    code: str,
) -> tuple[Optional[Vertex], str]:
    """Busca el corte con el terreno dentro del segmento ``(dx, dz)``.

    Marcha muestreando cada ``ctx.step`` metros horizontales; cuando el signo de
    ``proyecto - terreno`` cambia, afina por biseccion. Devuelve el vertice del
    corte (``STATUS_CUT``), o el extremo alcanzado con ``STATUS_END`` /
    ``STATUS_NODATA``.
    """
    g0 = _gap(cur.offset, cur.z, ctx)
    if g0 is None:
        return None, STATUS_NODATA
    if abs(g0) <= ctx.tol:
        # El terreno ya pasa por el punto de arranque: daylight inmediato.
        return Vertex(cur.offset, cur.z, code, KIND_DAYLIGHT), STATUS_CUT

    factor = _clip_to_max_width(cur, dx, ctx)
    if factor <= 0.0:
        return None, STATUS_END
    dx, dz = dx * factor, dz * factor

    n = max(1, int(math.ceil(abs(dx) / max(ctx.step, 1e-6))))
    ta, ga = 0.0, g0
    for i in range(1, n + 1):
        tb = i / n
        gb = _gap(cur.offset + dx * tb, cur.z + dz * tb, ctx)
        if gb is None:
            return None, STATUS_NODATA
        if abs(gb) <= ctx.tol or (ga > 0.0) != (gb > 0.0):
            t = _bisect(cur, dx, dz, ta, ga, tb, gb, ctx)
            return (
                Vertex(cur.offset + dx * t, cur.z + dz * t, code, KIND_DAYLIGHT),
                STATUS_CUT,
            )
        ta, ga = tb, gb
    return None, STATUS_END


def _bisect(
    cur: Vertex,
    dx: float,
    dz: float,
    ta: float,
    ga: float,
    tb: float,
    gb: float,
    ctx: ResolveContext,
    iters: int = 40,
) -> float:
    """Biseccion sobre el parametro ``t`` del segmento hasta ``ctx.tol``."""
    if abs(gb) <= ctx.tol:
        return tb
    for _ in range(iters):
        tm = 0.5 * (ta + tb)
        gm = _gap(cur.offset + dx * tm, cur.z + dz * tm, ctx)
        if gm is None:  # NoData justo en el intervalo: nos quedamos con el borde
            return ta
        if abs(gm) <= ctx.tol:
            return tm
        if (ga > 0.0) != (gm > 0.0):
            tb, gb = tm, gm
        else:
            ta, ga = tm, gm
        if abs(tb - ta) * abs(dx) < 1e-6:
            break
    return 0.5 * (ta + tb)


def _z_dir(ctx: ResolveContext) -> int:
    """+1 si el talud sube al alejarse (desmonte), -1 si baja (terraplen)."""
    return 1 if ctx.mode == GRUPO_DESMONTE else -1


# --------------------------------------------------------------------------
# Resolvedores de cada tipo de elemento
# --------------------------------------------------------------------------


def _res_offset_pendiente(cur, p, code, ctx):
    ancho = p["ancho"]
    if ancho < 0:
        raise ParamError("ancho: debe ser >= 0")
    dz = p["pendiente"] / 100.0 * ancho
    return [Vertex(cur.offset + ctx.side * ancho, cur.z + dz, code)]


def _res_offset_cota(cur, p, code, ctx):
    ancho = p["ancho"]
    if ancho < 0:
        raise ParamError("ancho: debe ser >= 0")
    z = cur.z + p["valor"] if p["modo"] == "desnivel" else p["valor"]
    return [Vertex(cur.offset + ctx.side * ancho, z, code)]


def _res_vertical(cur, p, code, ctx):
    return [Vertex(cur.offset, cur.z + p["desnivel"], code)]


def _res_cuneta(cur, p, code, ctx):
    prof = p["profundidad"]
    if prof <= 0:
        raise ParamError("profundidad: debe ser > 0")
    out = []
    dx_baja = prof / p["talud_interior"]
    v = Vertex(cur.offset + ctx.side * dx_baja, cur.z - prof, code + t("_BOTTOM_START"))
    out.append(v)
    if p["ancho_fondo"] > 0:
        v = Vertex(v.offset + ctx.side * p["ancho_fondo"], v.z, code + t("_BOTTOM_END"))
        out.append(v)
    subida = prof + p["desnivel_salida"]
    if subida <= 0:
        raise ParamError("desnivel_salida: la salida queda por debajo del fondo")
    dx_sube = subida / p["talud_exterior"]
    out.append(Vertex(v.offset + ctx.side * dx_sube, v.z + subida, code + t("_END")))
    return out


#: Tope que ata la longitud de un tramo de talud. Decide el desenlace cuando el
#: tramo se agota sin haber cortado el terreno.
TOPE_TRAMO = "tramo"  # fin normal: la cadena sigue con el talud siguiente
TOPE_ALTURA = "altura"  # altura maxima del elemento: truncado + aviso
TOPE_ANCHO = "ancho"  # semiancho maximo de la seccion: truncado + aviso


def _largo_talud(cur, p, s, ctx) -> tuple[float, str]:
    """Longitud horizontal del tramo de talud y el tope que la ata.

    Los tres topes se comparan en longitud horizontal y gana el menor. En caso
    de empate manda el mas benigno, por el orden en que se apilan aqui.
    """
    topes = []
    limite = p.get("limite_tramo", 0.0) or 0.0
    if limite > 0 and not ctx.ultimo:
        # El traspaso solo existe si hay un elemento detras que lo recoja.
        if p.get("limite_modo") == "horizontal":
            topes.append((limite, TOPE_TRAMO))
        else:
            topes.append((limite / s, TOPE_TRAMO))
    altura_max = p.get("altura_max", 0.0) or 0.0
    if altura_max > 0:
        topes.append((altura_max / s, TOPE_ALTURA))
    topes.append((ctx.max_width - abs(cur.offset), TOPE_ANCHO))
    return min(topes, key=lambda t: t[0])


def _res_talud_daylight(cur, p, code, ctx):
    s = p["talud"]
    zdir = _z_dir(ctx)
    largo, tope = _largo_talud(cur, p, s, ctx)
    if largo <= 0:
        ctx.fail(t("no room for the slope at offset {offset:.2f}", offset=cur.offset))
        return []
    dx = ctx.side * largo
    dz = zdir * s * largo
    code_day = ctx.code_day or (code + SUF_DAY)
    v, status = seek_terrain(cur, dx, dz, ctx, code_day)
    if status == STATUS_CUT:
        return [v]
    if status == STATUS_NODATA:
        ctx.fail(t("the terrain has no data under the slope (NoData)"))
    elif tope == TOPE_TRAMO:
        # Fin normal del tramo: no se ha llegado al terreno pero detras viene
        # otro talud que sigue buscandolo desde aqui con su propia pendiente.
        return [
            Vertex(
                cur.offset + dx,
                cur.z + dz,
                code_quiebro(code, ctx.buscador_n),
                KIND_QUIEBRO,
            )
        ]
    else:
        ctx.fail(
            t(
                "slope {talud} does not cut the terrain within {largo:.1f} m",
                talud=format_slope(s),
                largo=largo,
            )
        )
    return [Vertex(cur.offset + dx, cur.z + dz, code_day, KIND_TRUNCADO)]


def _res_talud_banqueta(cur, p, code, ctx):
    s1 = p["talud"]
    s2 = p["talud_siguientes"] if p["talud_siguientes"] > 0 else s1
    h = p["altura_banqueta"]
    ancho_b = p["ancho_banqueta"]
    pend_b = p["pendiente_banqueta"]
    nmax = p["max_banquetas"]
    if h <= 0:
        raise ParamError("altura_banqueta: debe ser > 0")
    if ancho_b <= 0:
        raise ParamError("ancho_banqueta: debe ser > 0")

    zdir = _z_dir(ctx)
    code_day = ctx.code_day or (code + SUF_DAY)
    out: list[Vertex] = []
    v = cur
    i = 0
    ilimitado = nmax <= 0
    while ilimitado or i < nmax:
        i += 1
        s = s1 if i == 1 else s2
        # --- tramo de talud hasta la banqueta i ---
        dx = ctx.side * (h / s)
        dz = zdir * h
        hit, status = seek_terrain(v, dx, dz, ctx, code_day)
        if status == STATUS_NODATA:
            ctx.fail(t("the terrain has no data under the slope (NoData)"))
            return out
        if status == STATUS_CUT:
            out.append(hit)
            return out
        if _clip_to_max_width(v, dx, ctx) < 1.0:
            break  # nos hemos comido el ancho maximo: cerramos con el tramo final
        v = Vertex(v.offset + dx, v.z + dz, code + t("_B{i}_START", i=i))
        out.append(v)
        # --- banqueta i ---
        dx = ctx.side * ancho_b
        dz = pend_b / 100.0 * ancho_b
        hit, status = seek_terrain(v, dx, dz, ctx, code_day)
        if status == STATUS_NODATA:
            ctx.fail(t("the terrain has no data under the bench (NoData)"))
            return out
        if status == STATUS_CUT:
            out.append(hit)
            return out
        if _clip_to_max_width(v, dx, ctx) < 1.0:
            break
        v = Vertex(v.offset + dx, v.z + dz, code + t("_B{i}_END", i=i))
        out.append(v)

    # Agotadas las banquetas: tramo final de talud continuo hasta el terreno.
    # Sin limite de tramo: este elemento cierra siempre, no traspasa a nadie.
    final = _res_talud_daylight(
        v, {"talud": s2, "altura_max": 0.0, "limite_tramo": 0.0}, code, ctx
    )
    out.extend(final)
    return out


# --------------------------------------------------------------------------
# Registro
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class ElementDef:
    tipo: str
    label: str
    descripcion: str
    params: tuple
    resolver: Callable
    grupos: tuple = GRUPOS
    busca_terreno: bool = False
    codigo_default: str = "POINT"

    def spec(self, name: str) -> ParamSpec:
        for p in self.params:
            if p.name == name:
                return p
        raise KeyError(name)

    def defaults(self) -> dict:
        return {p.name: p.default for p in self.params}


#: Las etiquetas y las descripciones van en ingles, el idioma original del
#: plugin, y la interfaz las pasa por ``t()`` antes de pintarlas. Los ``choices``
#: **no**: son el valor que se guarda en la libreria de secciones, asi que se
#: traducen solo al mostrarse (``etiquetas.OPCIONES``).
_DEFS: list[ElementDef] = [
    ElementDef(
        tipo="offset_pendiente",
        label="Offset with slope",
        descripcion=(
            "Advances a horizontal width at a given cross slope. It is the "
            "element for carriageway, shoulder, verge, widening..."
        ),
        codigo_default="EDGE",
        params=(
            ParamSpec("ancho", "Width", "float", 3.5, "m", minimum=0.0),
            ParamSpec(
                "pendiente",
                "Slope",
                "percent",
                -2.0,
                "%",
                tooltip="Positive = rises away from the axis",
            ),
        ),
        resolver=_res_offset_pendiente,
    ),
    ElementDef(
        tipo="offset_cota",
        label="Offset to elevation / height difference",
        descripcion=(
            "Advances a horizontal width up to a relative height difference or "
            "up to an absolute elevation."
        ),
        codigo_default="EDGE",
        params=(
            ParamSpec("ancho", "Width", "float", 1.0, "m", minimum=0.0),
            ParamSpec(
                "modo",
                "Mode",
                "choice",
                "desnivel",
                choices=("desnivel", "cota"),
                tooltip=(
                    "height difference = relative to the previous point; "
                    "elevation = absolute"
                ),
            ),
            ParamSpec("valor", "Value", "float", -0.05, "m"),
        ),
        resolver=_res_offset_cota,
    ),
    ElementDef(
        tipo="vertical",
        label="Vertical segment",
        descripcion="Goes up or down vertically without advancing (kerb, wall, step).",
        codigo_default="WALL",
        params=(
            ParamSpec(
                "desnivel",
                "Height difference",
                "float",
                0.15,
                "m",
                tooltip="Positive upwards",
            ),
        ),
        resolver=_res_vertical,
    ),
    ElementDef(
        tipo="cuneta",
        label="Ditch",
        descripcion=(
            "Triangular or trapezoidal ditch. With a bottom width of 0 it comes "
            "out triangular. Generates 2 or 3 vertices."
        ),
        codigo_default="DITCH",
        params=(
            ParamSpec("profundidad", "Depth", "float", 0.4, "m", minimum=0.0),
            ParamSpec("ancho_fondo", "Bottom width", "float", 0.0, "m", minimum=0.0),
            ParamSpec("talud_interior", "Inner slope", "slope", "1:1"),
            ParamSpec("talud_exterior", "Outer slope", "slope", "1:1"),
            ParamSpec(
                "desnivel_salida",
                "Exit height difference",
                "float",
                0.0,
                "m",
                tooltip=(
                    "Exit elevation relative to the entry one (0 = same "
                    "elevation)"
                ),
            ),
        ),
        resolver=_res_cuneta,
    ),
    ElementDef(
        tipo="talud_daylight",
        label="Slope to daylight",
        descripcion=(
            "Projects a continuous slope until it cuts the terrain. It goes up "
            "in cut and down in fill automatically. If there is another slope "
            "behind, the segment limit says where it hands over."
        ),
        codigo_default="SLOPE",
        grupos=(GRUPO_DESMONTE, GRUPO_TERRAPLEN),
        busca_terreno=True,
        params=(
            ParamSpec("talud", "Slope (V:H)", "slope", "1:1.5"),
            ParamSpec(
                "altura_max",
                "Maximum height",
                "float",
                0.0,
                "m",
                minimum=0.0,
                tooltip=(
                    "Hard stop: if it is reached without meeting the terrain, "
                    "the section is left open and a warning is issued. 0 = no "
                    "limit"
                ),
            ),
            ParamSpec(
                "limite_tramo",
                "Segment limit",
                "float",
                0.0,
                "m",
                minimum=0.0,
                si_ultimo=ULTIMO_GRIS,
                tooltip=(
                    "Only if there is another slope behind: how far this one "
                    "looks for the terrain before handing over to the next. "
                    "0 = no limit (it would eat the rest of the chain)"
                ),
            ),
            ParamSpec(
                "limite_modo",
                "Measured as",
                "choice",
                "cota",
                choices=("cota", "horizontal"),
                si_ultimo=ULTIMO_OCULTO,
                depende_de="limite_tramo",
                tooltip=(
                    "elevation = vertical height of the segment; horizontal = "
                    "horizontal distance covered"
                ),
            ),
        ),
        resolver=_res_talud_daylight,
    ),
    ElementDef(
        tipo="talud_banqueta",
        label="Benched slope",
        descripcion=(
            "Repeats [slope of height H + bench] until it cuts the terrain. If "
            "the cut falls inside a segment, it is truncated there: the number "
            "of vertices varies from one section to the next."
        ),
        codigo_default="SLOPE",
        grupos=(GRUPO_DESMONTE, GRUPO_TERRAPLEN),
        busca_terreno=True,
        params=(
            ParamSpec("talud", "Slope (V:H)", "slope", "1:1"),
            ParamSpec("altura_banqueta", "Height between benches", "float", 8.0, "m"),
            ParamSpec("ancho_banqueta", "Bench width", "float", 3.0, "m"),
            ParamSpec(
                "pendiente_banqueta",
                "Bench slope",
                "percent",
                2.0,
                "%",
                tooltip="Positive = adverse slope (rises outwards)",
            ),
            ParamSpec(
                "max_banquetas",
                "Maximum number of benches",
                "int",
                6,
                tooltip="0 = no limit",
                minimum=0,
            ),
            ParamSpec(
                "talud_siguientes",
                "Slope of the 2nd and following",
                "slope_opt",
                0.0,
                tooltip="Empty or 0 = same as the first",
            ),
        ),
        resolver=_res_talud_banqueta,
    ),
]

ELEMENTS: dict[str, ElementDef] = {d.tipo: d for d in _DEFS}


def element_def(tipo: str) -> ElementDef:
    try:
        return ELEMENTS[tipo]
    except KeyError:
        raise ParamError(f"tipo de elemento desconocido: {tipo!r}") from None


def elements_for(grupo: str) -> list[ElementDef]:
    return [d for d in _DEFS if grupo in d.grupos]
