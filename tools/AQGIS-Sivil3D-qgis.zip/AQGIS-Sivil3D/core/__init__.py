"""Nucleo de calculo del plugin: Python puro, sin dependencias de QGIS.

Todo lo que hay aqui se puede importar y testear con un interprete normal, lo
que hace posible probar la geometria de las secciones y el mallado sin abrir
QGIS. La capa que habla con QGIS vive en ``aqgis_sivil3d.qgis``.
"""

from .elements import (
    ELEMENTS,
    GRUPO_DESMONTE,
    GRUPO_FIJOS,
    GRUPO_TERRAPLEN,
    GRUPO_LABEL,
    GRUPOS,
    KIND_DAYLIGHT,
    KIND_PUNTO,
    KIND_QUIEBRO,
    KIND_TRUNCADO,
    SUF_DAY,
    ElementDef,
    ParamSpec,
    Vertex,
    element_def,
    elements_for,
)
from .params import ParamError, format_slope, parse_percent, parse_slope
from .resolver import (
    MODO_DESMONTE,
    MODO_NINGUNO,
    MODO_TERRAPLEN,
    Section,
    SectionOptions,
    Station,
    plane_terrain,
    resolve_section,
)
from .schema import CODE_EJE, SCHEMA_VERSION, Assembly, Branch, Element
from .tin import (
    Mesh,
    boundary_ring,
    build_mesh,
    daylight_lines,
    feature_lines,
    mesh_stats,
    write_2dm,
)

__all__ = [
    "ELEMENTS",
    "GRUPOS",
    "GRUPO_FIJOS",
    "GRUPO_DESMONTE",
    "GRUPO_TERRAPLEN",
    "GRUPO_LABEL",
    "KIND_PUNTO",
    "KIND_DAYLIGHT",
    "KIND_QUIEBRO",
    "KIND_TRUNCADO",
    "SUF_DAY",
    "ElementDef",
    "ParamSpec",
    "Vertex",
    "element_def",
    "elements_for",
    "ParamError",
    "format_slope",
    "parse_slope",
    "parse_percent",
    "Assembly",
    "Branch",
    "Element",
    "CODE_EJE",
    "SCHEMA_VERSION",
    "Station",
    "Section",
    "SectionOptions",
    "resolve_section",
    "plane_terrain",
    "MODO_DESMONTE",
    "MODO_TERRAPLEN",
    "MODO_NINGUNO",
    "Mesh",
    "build_mesh",
    "feature_lines",
    "boundary_ring",
    "daylight_lines",
    "write_2dm",
    "mesh_stats",
]
