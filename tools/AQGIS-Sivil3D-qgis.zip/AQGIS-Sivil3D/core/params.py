"""Parseo y formateo de valores de parametros.

Modulo puro: no importa nada de QGIS, se puede testear con python a secas.

Convenciones de unidades del plugin
-----------------------------------
* ``pendiente``  -> se expresa en % y el signo indica el sentido: positivo
  significa que la rasante *sube* al alejarse del eje. Un firme al -2% baja
  hacia el exterior en los dos lados.
* ``talud``      -> se expresa como ``V:H`` (1 vertical : H horizontal), que es
  la notacion habitual: ``1:1.5`` es un talud tendido, ``1:0.5`` es escarpado.
  Internamente se guarda como ``dz/dx`` (magnitud positiva), o sea ``V/H``.
  Tambien se aceptan porcentajes (``"66%"``) y numeros desnudos, que se
  interpretan como H por cada 1 de V (``1.5`` == ``"1:1.5"``).
"""

from __future__ import annotations

import math
import re
from typing import Any


class ParamError(ValueError):
    """Valor de parametro no interpretable."""


_RATIO_RE = re.compile(r"^\s*([0-9]*\.?[0-9]+)\s*[:/]\s*([0-9]*\.?[0-9]+)\s*$")
_PCT_RE = re.compile(r"^\s*([+-]?[0-9]*\.?[0-9]+)\s*%\s*$")
_NUM_RE = re.compile(r"^\s*([+-]?[0-9]*\.?[0-9]+([eE][+-]?[0-9]+)?)\s*$")

#: Talud practicamente vertical: se usa como tope para no dividir por cero.
MAX_DZ_DX = 1.0e4


def parse_number(value: Any, what: str = "numero") -> float:
    """Convierte a float aceptando coma decimal y espacios."""
    if isinstance(value, bool):
        raise ParamError(f"{what}: se esperaba un numero, no un booleano")
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)):
            raise ParamError(f"{what}: valor no finito")
        return float(value)
    if isinstance(value, str):
        txt = value.strip().replace(",", ".")
        m = _NUM_RE.match(txt)
        if m:
            return float(m.group(1))
    raise ParamError(f"{what}: no se puede interpretar {value!r} como numero")


def parse_int(value: Any, what: str = "entero") -> int:
    n = parse_number(value, what)
    if abs(n - round(n)) > 1e-9:
        raise ParamError(f"{what}: se esperaba un entero, no {value!r}")
    return int(round(n))


def parse_bool(value: Any, what: str = "booleano") -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        txt = value.strip().lower()
        if txt in ("1", "true", "si", "sí", "yes", "y", "verdadero", "on"):
            return True
        if txt in ("0", "false", "no", "n", "falso", "off", ""):
            return False
    raise ParamError(f"{what}: no se puede interpretar {value!r} como booleano")


def parse_percent(value: Any, what: str = "pendiente") -> float:
    """Devuelve la pendiente en % (con signo). Acepta ``-2``, ``"-2%"``, ``"-2,0"``."""
    if isinstance(value, str):
        m = _PCT_RE.match(value.strip().replace(",", "."))
        if m:
            return float(m.group(1))
    return parse_number(value, what)


def parse_slope(value: Any, what: str = "talud") -> float:
    """Devuelve el talud como ``dz/dx`` positivo (desnivel por unidad horizontal)."""
    if isinstance(value, str):
        txt = value.strip().replace(",", ".")
        m = _RATIO_RE.match(txt)
        if m:
            v, h = float(m.group(1)), float(m.group(2))
            if v <= 0.0:
                raise ParamError(
                    f"{what}: la parte vertical de {value!r} debe ser mayor que 0"
                )
            if h <= 0.0:
                raise ParamError(
                    f"{what}: talud vertical ({value!r}); usa el elemento 'vertical'"
                )
            return min(v / h, MAX_DZ_DX)
        m = _PCT_RE.match(txt)
        if m:
            pct = float(m.group(1))
            if pct < 0.0:
                # Antes se tomaba el valor absoluto en silencio, o sea que el
                # plugin hacia lo contrario de lo escrito sin avisar. Un talud
                # es una magnitud: el sentido lo decide el grupo (sube en
                # desmonte, baja en terraplen).
                raise ParamError(
                    f"{what}: {value!r} no puede ser negativo; el talud es una "
                    f"magnitud y el sentido lo decide el grupo (sube en desmonte, "
                    f"baja en terraplen). Para bajar en desmonte, o subir en "
                    f"terraplen, usa 'Offset con pendiente' con la pendiente "
                    f"del signo que quieras"
                )
            if pct == 0.0:
                raise ParamError(f"{what}: el talud no puede ser 0%")
            return min(pct / 100.0, MAX_DZ_DX)
    h = parse_number(value, what)
    if h <= 0.0:
        raise ParamError(
            f"{what}: {value!r} no es valido; usa 'V:H' (p.ej. 1:1.5) con H > 0"
        )
    return min(1.0 / h, MAX_DZ_DX)


#: Valores que en un parametro de talud opcional significan "no lo impongas,
#: hereda el del elemento anterior".
AUTO_SLOPE = ("", "0", "0.0", "auto", "igual", "-")


def parse_slope_opt(value: Any, what: str = "talud") -> float:
    """Como :func:`parse_slope` pero admitiendo el sentinela "automatico" -> 0.

    Lo usan los parametros de talud que pueden dejarse en blanco para heredar
    otro valor (p.ej. "talud de la 2.a banqueta y siguientes").
    """
    if value is None:
        return 0.0
    if isinstance(value, str) and value.strip().lower() in AUTO_SLOPE:
        return 0.0
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if float(value) == 0.0:
            return 0.0
    return parse_slope(value, what)


def format_slope(dz_dx: float) -> str:
    """Inverso de :func:`parse_slope`, para mostrar en la interfaz."""
    if dz_dx <= 0.0:
        return "1:0"
    h = 1.0 / dz_dx
    if abs(h - round(h)) < 1e-9:
        return f"1:{int(round(h))}"
    return f"1:{h:.4g}"


def format_slope_opt(dz_dx: float) -> str:
    return "auto" if dz_dx <= 0.0 else format_slope(dz_dx)


#: Conversores por ``kind`` de :class:`~aqgis_sivil3d.core.elements.ParamSpec`.
COERCERS = {
    "float": parse_number,
    "percent": parse_percent,
    "slope": parse_slope,
    "slope_opt": parse_slope_opt,
    "int": parse_int,
    "bool": parse_bool,
}


def coerce(value: Any, kind: str, what: str = "parametro") -> Any:
    """Convierte ``value`` al tipo interno que corresponde a ``kind``."""
    if kind == "choice":
        return str(value).strip()
    fn = COERCERS.get(kind)
    if fn is None:
        return value
    return fn(value, what)
