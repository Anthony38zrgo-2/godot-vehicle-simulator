"""Modelo de datos de la seccion tipo y su serializacion JSON.

Modulo puro: no importa nada de QGIS.

Estructura
----------
::

    Assembly
      eje         -> {cota, desnivel, desplazamiento}
      izquierda   -> Branch(fijos[], desmonte[], terraplen[])
      derecha     -> Branch(fijos[], desmonte[], terraplen[])

Cada ``Element`` guarda los parametros *en crudo*: pueden ser numeros,
literales tipo ``"1:1.5"``, referencias a campo (``"@talud_izq"``) o
expresiones QGIS (``"=if(\\"roca\\", '1:0.5', '1:1.5')"``). El paso de crudo a
numero se hace una sola vez por feature con :meth:`Assembly.materialize`.
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator, Optional

from ..i18n import t
from .elements import (
    GRUPO_DESMONTE,
    GRUPO_FIJOS,
    GRUPO_TERRAPLEN,
    GRUPOS,
    ElementDef,
    element_def,
)
from .params import ParamError, coerce, parse_slope

SCHEMA_VERSION = 1

#: Prefijos de codigo que se anaden automaticamente segun el lado, en ingles
#: (el idioma original). Se traducen al resolver, con :func:`prefijo_de_lado`:
#: el codigo de punto viaja a los atributos de las capas y se lee, asi que va en
#: el idioma en que se calculo el corredor.
PREFIJO = {-1: "L_", 1: "R_"}

#: Codigo del punto del eje. Tambien se traduce al resolver.
CODE_EJE = "AXIS"


def prefijo_de_lado(side: int) -> str:
    """Prefijo del lado en el idioma que este puesto: ``L_``/``R_``, ``I_``/``D_``."""
    from ..i18n import t

    return t(PREFIJO[side])


def codigo_del_eje() -> str:
    """Codigo del punto del eje en el idioma que este puesto."""
    from ..i18n import t

    return t(CODE_EJE)


def codigos_del_eje() -> tuple:
    """El codigo del eje en todos los idiomas.

    Quien **busca** el vertice del eje en una seccion ya resuelta tiene que
    probarlos todos: un corredor calculado en castellano guarda 'EJE' y se puede
    reabrir en una sesion en ingles.
    """
    from ..i18n import todas_las_formas

    return todas_las_formas(CODE_EJE)


@dataclass
class Element:
    """Un elemento de la cadena, con sus parametros en crudo."""

    tipo: str
    codigo: str = ""
    params: dict = field(default_factory=dict)

    def __post_init__(self):
        d = self.definicion()
        if not self.codigo:
            self.codigo = d.codigo_default

    def definicion(self) -> ElementDef:
        return element_def(self.tipo)

    @property
    def label(self) -> str:
        return self.definicion().label

    def raw(self, name: str) -> Any:
        """Valor en crudo, cayendo al default del ParamSpec si no esta puesto."""
        spec = self.definicion().spec(name)
        v = self.params.get(name, None)
        return spec.default if v is None or v == "" else v

    def to_dict(self) -> dict:
        d = {"tipo": self.tipo, "codigo": self.codigo}
        d.update(self.params)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "Element":
        data = dict(data)
        tipo = data.pop("tipo", None)
        if not tipo:
            raise ParamError("elemento sin 'tipo'")
        codigo = str(data.pop("codigo", "") or "")
        return cls(tipo=tipo, codigo=codigo, params=data)

    def copy(self) -> "Element":
        return Element(self.tipo, self.codigo, copy.deepcopy(self.params))

    def describe(self) -> str:
        """Resumen de una linea para la interfaz."""
        d = self.definicion()
        trozos = []
        for spec in d.params:
            v = self.raw(spec.name)
            if spec.kind in ("float", "slope_opt") and float_or_none(v) == 0.0:
                continue  # un 0 aqui significa "sin limite" / "heredado"
            if spec.depende_de and float_or_none(self.raw(spec.depende_de)) == 0.0:
                continue  # lo que gobierna este parametro esta desactivado
            trozos.append(f"{t(spec.label).lower()}={v}{spec.unit}")
        return ", ".join(trozos)


def float_or_none(v: Any) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _revisar_traspaso(donde: str, el: "Element") -> list:
    """Revisa que un buscador intermedio pueda pasarle el relevo al siguiente.

    Las comprobaciones numericas se saltan si el valor es dinamico (``@campo`` o
    ``=expresion``): eso no se conoce hasta resolver cada feature.
    """
    try:
        el.definicion().spec("limite_tramo")
    except KeyError:
        return [
            f"{donde}: '{el.codigo}' busca el terreno, no es el ultimo y no "
            f"admite limite de tramo; lo que va detras se ignorara."
        ]
    limite = float_or_none(el.raw("limite_tramo"))
    if limite is None:
        return []
    if limite <= 0:
        return [
            f"{donde}: '{el.codigo}' no es el ultimo pero no tiene limite de "
            f"tramo; buscara el terreno hasta el ancho maximo y lo que va detras "
            f"se ignorara."
        ]
    altura = float_or_none(el.raw("altura_max"))
    if not altura or altura <= 0:
        return []
    try:
        s = parse_slope(el.raw("talud"))
    except ParamError:
        return []
    # Los dos topes se comparan en longitud horizontal, como en el resolvedor.
    horizontal = limite if el.raw("limite_modo") == "horizontal" else limite / s
    if altura / s < horizontal:
        return [
            f"{donde}: '{el.codigo}' tiene la altura maxima ({altura:g} m) por "
            f"debajo de su limite de tramo; nunca llegara a traspasar y lo que va "
            f"detras se ignorara."
        ]
    return []


@dataclass
class Branch:
    """Una rama (un lado) de la seccion."""

    fijos: list = field(default_factory=list)
    desmonte: list = field(default_factory=list)
    terraplen: list = field(default_factory=list)

    def grupo(self, nombre: str) -> list:
        if nombre not in GRUPOS:
            raise ParamError(f"grupo desconocido: {nombre!r}")
        return getattr(self, nombre)

    def to_dict(self) -> dict:
        return {g: [e.to_dict() for e in self.grupo(g)] for g in GRUPOS}

    @classmethod
    def from_dict(cls, data: dict) -> "Branch":
        data = data or {}
        return cls(
            **{
                g: [Element.from_dict(e) for e in (data.get(g) or [])]
                for g in GRUPOS
            }
        )

    def copy(self) -> "Branch":
        return Branch(**{g: [e.copy() for e in self.grupo(g)] for g in GRUPOS})

    def __iter__(self) -> Iterator[tuple]:
        for g in GRUPOS:
            for e in self.grupo(g):
                yield g, e


DEFAULT_EJE = {"cota": "terreno", "desnivel": 0.0, "desplazamiento": 0.0}


@dataclass
class Assembly:
    """Una seccion tipo completa."""

    nombre: str = "Nueva seccion"
    descripcion: str = ""
    eje: dict = field(default_factory=lambda: dict(DEFAULT_EJE))
    izquierda: Branch = field(default_factory=Branch)
    derecha: Branch = field(default_factory=Branch)
    version: int = SCHEMA_VERSION

    # -- serializacion ----------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "nombre": self.nombre,
            "descripcion": self.descripcion,
            "eje": dict(self.eje),
            "izquierda": self.izquierda.to_dict(),
            "derecha": self.derecha.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Assembly":
        eje = dict(DEFAULT_EJE)
        eje.update(data.get("eje") or {})
        return cls(
            nombre=str(data.get("nombre") or "Sin nombre"),
            descripcion=str(data.get("descripcion") or ""),
            eje=eje,
            izquierda=Branch.from_dict(data.get("izquierda")),
            derecha=Branch.from_dict(data.get("derecha")),
            version=int(data.get("version") or SCHEMA_VERSION),
        )

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "Assembly":
        return cls.from_dict(json.loads(text))

    def copy(self) -> "Assembly":
        return Assembly(
            nombre=self.nombre,
            descripcion=self.descripcion,
            eje=dict(self.eje),
            izquierda=self.izquierda.copy(),
            derecha=self.derecha.copy(),
            version=self.version,
        )

    def branch(self, side: int) -> Branch:
        return self.izquierda if side < 0 else self.derecha

    def elementos(self) -> Iterator[tuple]:
        """Itera ``(side, grupo, element)`` sobre toda la seccion."""
        for side in (-1, 1):
            for grupo, el in self.branch(side):
                yield side, grupo, el

    # -- validacion -------------------------------------------------------
    def validate(self) -> list[str]:
        """Lista de problemas detectables sin terreno. Vacia = todo bien."""
        errores = []
        if not self.nombre.strip():
            errores.append("La seccion no tiene nombre.")
        for side, grupo, el in self.elementos():
            errores += self._revisar_elemento(side, grupo, el)
        for side in (-1, 1):
            errores += self._revisar_rama(side)
        return errores

    def _revisar_elemento(self, side: int, grupo: str, el) -> list:
        """Que el elemento exista, sirva para ese grupo y tenga codigo."""
        lado = "izquierda" if side < 0 else "derecha"
        donde = f"{lado}/{grupo}/{el.codigo}"
        try:
            d = el.definicion()
        except ParamError as exc:
            return [f"{donde}: {exc}"]
        errores = []
        if grupo not in d.grupos:
            errores.append(
                f"{donde}: el elemento '{d.label}' no se puede usar en '{grupo}'."
            )
        conocidos = {p.name for p in d.params}
        for clave in el.params:
            if clave not in conocidos:
                errores.append(f"{donde}: parametro desconocido '{clave}'.")
        if not el.codigo.strip():
            errores.append(f"{donde}: falta el codigo del elemento.")
        return errores

    def _revisar_rama(self, side: int) -> list:
        """Revisa un lado completo: grupos vacios, cierre y codigos repetidos."""
        lado = "izquierda" if side < 0 else "derecha"
        rama = self.branch(side)
        errores = []
        vacios = [g for g in (GRUPO_DESMONTE, GRUPO_TERRAPLEN) if not rama.grupo(g)]
        if len(vacios) == 1:
            errores.append(
                f"{lado}/{vacios[0]}: grupo vacio. En los PK donde este lado "
                f"caiga en {vacios[0]} la seccion se cortara en el ultimo "
                f"elemento fijo y la superficie quedara abierta."
            )
        for grupo in (GRUPO_DESMONTE, GRUPO_TERRAPLEN):
            errores += self._revisar_cierre(lado, rama, grupo)
        errores += self._revisar_codigos(lado, rama)
        return errores

    @staticmethod
    def _revisar_cierre(lado: str, rama, grupo: str) -> list:
        """El grupo condicional tiene que acabar en un elemento que busque el terreno.

        Un buscador intermedio si vale, pero solo si puede traspasar el trazado
        al siguiente: un talud con limite de tramo cierra en un quiebro y la
        cadena sigue, mientras que uno sin limite (o unas banquetas, que no
        tienen tope de altura) se queda con el trazado y deja muerto lo de atras.
        """
        elems = rama.grupo(grupo)
        if not elems:
            return []
        busca = [
            (i, e) for i, e in enumerate(elems) if e.definicion().busca_terreno
        ]
        if not busca:
            return [
                f"{lado}/{grupo}: no hay ningun elemento que busque el terreno; "
                f"la superficie quedara abierta."
            ]
        ultimo = len(elems) - 1
        errores = []
        for i, e in busca:
            if i != ultimo:
                errores += _revisar_traspaso(f"{lado}/{grupo}", e)
        if busca[-1][0] != ultimo:
            errores.append(
                f"{lado}/{grupo}: '{elems[-1].codigo}' es el ultimo elemento y no "
                f"busca el terreno; la superficie quedara abierta."
            )
        return errores

    @staticmethod
    def _revisar_codigos(lado: str, rama) -> list:
        """Codigos repetidos, por escenario.

        Solo tienen que ser unicos entre elementos que puedan coincidir en una
        misma seccion resuelta: 'desmonte' y 'terraplen' son excluyentes, asi que
        repetir 'TALUD' en los dos no solo vale, es lo deseable (mantiene la linea
        de daylight continua al pasar de desmonte a terraplen).

        Por lo mismo, los taludes **encadenados de un mismo grupo** tampoco
        cuentan: comparten a proposito el codigo del vertice de daylight, y sus
        quiebros se numeran solos (``TALUD_Q1``, ``TALUD_Q2``...), asi que
        llamarlos todos 'TALUD' es lo correcto y no crea ninguna ambiguedad.
        """
        errores = []
        vistos = set()
        for grupo in (GRUPO_DESMONTE, GRUPO_TERRAPLEN):
            condicional = rama.grupo(grupo)
            buscadores = [e for e in condicional if e.definicion().busca_terreno]
            # De los que buscan terreno se cuenta solo el primero: los demas
            # repiten su codigo a proposito.
            omitir = {id(e) for e in buscadores[1:]}
            codigos = [e.codigo for e in rama.fijos] + [
                e.codigo for e in condicional if id(e) not in omitir
            ]
            dup = tuple(sorted({c for c in codigos if codigos.count(c) > 1}))
            if dup and dup not in vistos:
                vistos.add(dup)
                errores.append(
                    f"{lado} ({grupo}): codigos repetidos {list(dup)}; deben ser "
                    f"unicos entre 'fijos' y el grupo condicional."
                )
        return errores

    # -- materializacion --------------------------------------------------
    def materialize(self, evaluate: Optional[Callable[[Any], Any]] = None) -> "Assembly":
        """Devuelve una copia con todos los parametros convertidos a numeros.

        ``evaluate`` recibe el valor en crudo y resuelve referencias a campo
        (``@campo``) o expresiones (``=...``); si es ``None`` solo se aplica el
        parseo de literales. Se llama una vez por feature de la directriz.
        """
        ev = evaluate or (lambda v: v)
        out = self.copy()
        for side in (-1, 1):
            rama = out.branch(side)
            for grupo in GRUPOS:
                for el in rama.grupo(grupo):
                    d = el.definicion()
                    nuevos = {}
                    for spec in d.params:
                        crudo = el.raw(spec.name)
                        try:
                            valor = coerce(ev(crudo), spec.kind, spec.label)
                        except ParamError as exc:
                            lado = "izq" if side < 0 else "der"
                            raise ParamError(
                                f"{lado}/{grupo}/{el.codigo}: {exc}"
                            ) from None
                        if spec.minimum is not None and valor < spec.minimum:
                            lado = "izq" if side < 0 else "der"
                            raise ParamError(
                                f"{lado}/{grupo}/{el.codigo}/{spec.label}: "
                                f"{valor} < minimo {spec.minimum}"
                            )
                        if spec.kind == "choice" and valor not in spec.choices:
                            raise ParamError(
                                f"{spec.label}: '{valor}' no esta en "
                                f"{list(spec.choices)}"
                            )
                        nuevos[spec.name] = valor
                    el.params = nuevos
        out.eje = dict(self.eje)
        for clave in ("desnivel", "desplazamiento"):
            out.eje[clave] = coerce(
                ev(self.eje.get(clave, DEFAULT_EJE[clave])), "float", clave
            )
        return out


# --------------------------------------------------------------------------
# Ayudas para construir secciones desde codigo (util en tests y plantillas)
# --------------------------------------------------------------------------


def el(tipo: str, codigo: str = "", **params) -> Element:
    return Element(tipo=tipo, codigo=codigo, params=params)


def branch(fijos=(), desmonte=(), terraplen=()) -> Branch:
    return Branch(list(fijos), list(desmonte), list(terraplen))


__all__ = [
    "SCHEMA_VERSION",
    "CODE_EJE",
    "PREFIJO",
    "prefijo_de_lado",
    "codigo_del_eje",
    "codigos_del_eje",
    "Assembly",
    "Branch",
    "Element",
    "el",
    "branch",
    "GRUPO_FIJOS",
    "GRUPO_DESMONTE",
    "GRUPO_TERRAPLEN",
]
