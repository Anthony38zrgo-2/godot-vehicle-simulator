"""Utilidades de geometria 2D en planta. Modulo puro.

Se usa para la fusion con el terreno: hay que decidir, para muchisimos puntos
de rejilla, si caen dentro de la huella del corredor. :class:`RingIndex` indexa
las aristas del anillo por bandas de ``y`` para que cada consulta toque solo
unas pocas aristas en vez de las miles del anillo completo.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Optional, Sequence

Point2 = tuple  # (x, y) o (x, y, z): siempre se usan las dos primeras


def signed_area(ring: Sequence) -> float:
    """Area con signo del anillo (positiva si es antihorario)."""
    n = len(ring)
    if n < 3:
        return 0.0
    acc = 0.0
    for i in range(n):
        x1, y1 = ring[i][0], ring[i][1]
        x2, y2 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        acc += x1 * y2 - x2 * y1
    return 0.5 * acc


def bbox(points: Iterable) -> Optional[tuple]:
    xs, ys = [], []
    for p in points:
        xs.append(p[0])
        ys.append(p[1])
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def densify(points: Sequence, max_len: float, closed: bool = False) -> list:
    """Inserta vertices intermedios para que ningun tramo pase de ``max_len``.

    Interpola tambien la ``z`` si los puntos la traen. Se usa para que el
    anillo del corredor entre en la triangulacion del terreno con una densidad
    parecida a la de la rejilla; si no, salen triangulos larguisimos pegados al
    borde.
    """
    if max_len <= 0.0 or len(points) < 2:
        return list(points)
    pares = list(zip(points, points[1:]))
    if closed:
        pares.append((points[-1], points[0]))
    out = [points[0]]
    tiene_z = len(points[0]) > 2
    for a, b in pares:
        d = math.hypot(b[0] - a[0], b[1] - a[1])
        n = max(1, int(math.ceil(d / max_len)))
        for i in range(1, n + 1):
            t = i / n
            x = a[0] + (b[0] - a[0]) * t
            y = a[1] + (b[1] - a[1]) * t
            if tiene_z:
                z = a[2] + (b[2] - a[2]) * t
                out.append((x, y, z))
            else:
                out.append((x, y))
    if closed and out:
        out.pop()  # el ultimo coincide con el primero
    return out


@dataclass
class RingIndex:
    """Test punto-en-anillo acelerado por bandas horizontales.

    El anillo se supone cerrado implicitamente (el ultimo vertice conecta con
    el primero). El criterio es el numero de cruces (par/impar), que funciona
    igual con anillos convexos, concavos o incluso autointersecantes, que es
    justo lo que puede pasar con un corredor en una curva muy cerrada.
    """

    ring: list
    nbands: int = 0
    y0: float = 0.0
    y1: float = 0.0
    _bands: list = None  # type: ignore[assignment]
    _xmin: float = 0.0
    _xmax: float = 0.0

    def __post_init__(self):
        self.ring = [(p[0], p[1]) for p in self.ring]
        n = len(self.ring)
        if n < 3:
            self._bands = []
            return
        b = bbox(self.ring)
        self._xmin, self._xmax = b[0], b[2]
        self.y0, self.y1 = b[1], b[3]
        if not self.nbands:
            self.nbands = max(1, min(1024, int(math.sqrt(n)) * 4))
        self._bands = [[] for _ in range(self.nbands)]
        alto = max(self.y1 - self.y0, 1e-12)
        for i in range(n):
            ax, ay = self.ring[i]
            bx, by = self.ring[(i + 1) % n]
            if ay == by:
                continue  # las aristas horizontales no cuentan cruces
            lo, hi = (ay, by) if ay < by else (by, ay)
            i0 = int((lo - self.y0) / alto * self.nbands)
            i1 = int((hi - self.y0) / alto * self.nbands)
            i0 = max(0, min(self.nbands - 1, i0))
            i1 = max(0, min(self.nbands - 1, i1))
            arista = (ax, ay, bx, by)
            for k in range(i0, i1 + 1):
                self._bands[k].append(arista)

    @property
    def is_empty(self) -> bool:
        return not self._bands

    def contains(self, x: float, y: float) -> bool:
        if self.is_empty:
            return False
        if y < self.y0 or y > self.y1 or x < self._xmin or x > self._xmax:
            return False
        alto = max(self.y1 - self.y0, 1e-12)
        k = int((y - self.y0) / alto * self.nbands)
        k = max(0, min(self.nbands - 1, k))
        dentro = False
        for ax, ay, bx, by in self._bands[k]:
            if (ay > y) == (by > y):
                continue
            xc = ax + (y - ay) * (bx - ax) / (by - ay)
            if x < xc:
                dentro = not dentro
        return dentro

    def contains_centroid(self, a, b, c) -> bool:
        return self.contains((a[0] + b[0] + c[0]) / 3.0, (a[1] + b[1] + c[1]) / 3.0)


def tri_area2(a, b, c) -> float:
    """Doble del area en planta con signo."""
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def max_edge(a, b, c) -> float:
    return max(
        math.hypot(b[0] - a[0], b[1] - a[1]),
        math.hypot(c[0] - b[0], c[1] - b[1]),
        math.hypot(a[0] - c[0], a[1] - c[1]),
    )


__all__ = [
    "signed_area",
    "bbox",
    "densify",
    "RingIndex",
    "tri_area2",
    "max_edge",
]
