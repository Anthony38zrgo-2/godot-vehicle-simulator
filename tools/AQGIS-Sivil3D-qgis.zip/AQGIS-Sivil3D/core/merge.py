"""Fusion del TIN del corredor con el terreno base. Modulo puro.

Problema
--------
El corredor es una malla estructurada con su propia huella en planta (el
anillo de daylight). Para entregar "el terreno con la obra metida dentro" hay
que rellenar todo lo que queda *fuera* de esa huella con el terreno original y
que las dos mallas se peguen sin huecos ni solapes.

Estrategia
----------
1. Se muestrea el terreno en una rejilla regular sobre la zona de interes y se
   descartan los nodos que caen dentro de la huella del corredor (o demasiado
   cerca del borde, que solo darian triangulos aguja).
2. Al conjunto de nodos supervivientes se le suma el **anillo del corredor
   densificado**, con las cotas del propio corredor. Estos son los nodos que
   comparten las dos mallas: la costura.
3. Se triangula todo eso en planta (Delaunay) y se tiran los triangulos cuyo
   centroide cae dentro de la huella. Como el anillo es parte de la nube, la
   frontera de la triangulacion coincide exactamente con el anillo.
4. Se pegan los triangulos del corredor, reutilizando los nodos de la costura.

Delaunay se toma de ``scipy.spatial`` si esta disponible (lo esta en las
instalaciones estandar de QGIS); si no, se avisa y se devuelve solo el
corredor.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Optional, Sequence

from .geom2d import RingIndex, densify, max_edge, tri_area2
from .tin import MIN_AREA, ORIGEN_TERRENO, Mesh

#: Tope de nodos de la rejilla de terreno. Por encima se agranda la celda.
MAX_NODOS_REJILLA = 1_500_000


@dataclass
class MergeOptions:
    """Ajustes de la fusion."""

    #: Lado de la celda de muestreo del terreno (m). Lo natural es el tamano de
    #: pixel del DEM, o algo mayor si el DEM es muy fino y la zona muy grande.
    celda: float = 5.0
    #: Margen de terreno alrededor de la huella del corredor (m).
    holgura: float = 50.0
    #: Arista maxima en planta de un triangulo de terreno (m). 0 = 3 * celda.
    #: Sirve para que Delaunay no cierre el hueco de un corredor concavo ni
    #: cosa a traves de zonas NoData.
    max_arista: float = 0.0
    #: Distancia minima entre un nodo de rejilla y el anillo (m). 0 = 0.6 * celda.
    despeje: float = 0.0

    def resueltas(self) -> "MergeOptions":
        celda = max(self.celda, 1e-6)
        return MergeOptions(
            celda=celda,
            holgura=max(self.holgura, 0.0),
            max_arista=self.max_arista if self.max_arista > 0 else 3.0 * celda,
            despeje=self.despeje if self.despeje > 0 else 0.6 * celda,
        )


# --------------------------------------------------------------------------


class _PointHash:
    """Rejilla hash para preguntar "hay algun punto a menos de r de aqui?"."""

    def __init__(self, points: Sequence, radio: float):
        self.r = max(radio, 1e-9)
        self.cells: dict = {}
        for p in points:
            self.cells.setdefault(self._key(p[0], p[1]), []).append((p[0], p[1]))

    def _key(self, x: float, y: float) -> tuple:
        return (int(math.floor(x / self.r)), int(math.floor(y / self.r)))

    def near(self, x: float, y: float) -> bool:
        i0, j0 = self._key(x, y)
        r2 = self.r * self.r
        for i in range(i0 - 1, i0 + 2):
            for j in range(j0 - 1, j0 + 2):
                for px, py in self.cells.get((i, j), ()):  # type: ignore[arg-type]
                    if (px - x) ** 2 + (py - y) ** 2 <= r2:
                        return True
        return False


class DelaunayNoDisponible(RuntimeError):
    """No hay scipy: la fusion no se puede hacer."""


def _delaunay(xy: list):
    """Indices de triangulos de la triangulacion de Delaunay en planta.

    Se resta el centroide antes de triangular: las coordenadas UTM son del orden
    de 1e6 y Qhull decide precision en terminos relativos, asi que trabajar
    centrado evita que puntos separados metros se consideren coincidentes.
    """
    try:
        import numpy as np
        from scipy.spatial import Delaunay  # type: ignore
    except ImportError as exc:
        raise DelaunayNoDisponible(str(exc)) from None
    if len(xy) < 3:
        return []
    pts = np.asarray(xy, dtype=float)
    pts = pts - pts.mean(axis=0)
    try:
        tri = Delaunay(pts)
    except Exception as exc:
        raise RuntimeError(f"Qhull no ha podido triangular: {exc}") from None
    return [tuple(int(v) for v in t) for t in tri.simplices]


class _NodeStore:
    """Acumula nodos deduplicando por coordenada exacta redondeada.

    La ``z`` entra en la clave a proposito: un elemento vertical (bordillo,
    muro) tiene dos vertices con la misma ``x, y`` y distinta cota, y son nodos
    distintos.
    """

    def __init__(self, mesh: Mesh, decimales: int = 4):
        self.mesh = mesh
        self.q = decimales
        self.index: dict = {}

    def add(self, x: float, y: float, z: float) -> int:
        clave = (round(x, self.q), round(y, self.q), round(z, self.q))
        idx = self.index.get(clave)
        if idx is None:
            idx = self.mesh.add_node(x, y, z)
            self.index[clave] = idx
        return idx


# --------------------------------------------------------------------------


def _envolvente(puntos: Sequence, holgura: float) -> tuple:
    """``(xmin, ymin, xmax, ymax)`` de los puntos, con holgura alrededor."""
    xs = [p[0] for p in puntos]
    ys = [p[1] for p in puntos]
    return (
        min(xs) - holgura,
        min(ys) - holgura,
        max(xs) + holgura,
        max(ys) + holgura,
    )


def _rejilla(extent: tuple, opts: "MergeOptions") -> tuple:
    """``(opts, celda, nx, ny, aviso)`` de la rejilla de terreno.

    Si la celda pedida daria una rejilla desproporcionada, se agranda la celda y
    se avisa: mas vale menos detalle que diez minutos de calculo o quedarse sin
    memoria.
    """
    xmin, ymin, xmax, ymax = extent
    celda = opts.celda
    nx = max(2, int(math.floor((xmax - xmin) / celda)) + 1)
    ny = max(2, int(math.floor((ymax - ymin) / celda)) + 1)
    if nx * ny <= MAX_NODOS_REJILLA:
        return opts, celda, nx, ny, ""
    area = max((xmax - xmin) * (ymax - ymin), 1.0)
    celda = math.sqrt(area / MAX_NODOS_REJILLA)
    nx = max(2, int(math.floor((xmax - xmin) / celda)) + 1)
    ny = max(2, int(math.floor((ymax - ymin) / celda)) + 1)
    aviso = (
        f"la celda de {opts.celda:.2f} m daria una rejilla inmanejable en esta "
        f"extension; se usa {celda:.2f} m ({nx}x{ny} nodos). Reduce la holgura o "
        f"acota la extension si quieres mas detalle."
    )
    nuevas = MergeOptions(
        celda=celda,
        holgura=opts.holgura,
        max_arista=max(opts.max_arista, 3.0 * celda),
        despeje=max(opts.despeje, 0.6 * celda),
    )
    return nuevas, celda, nx, ny, aviso


def _nodos_de_terreno(
    extent: tuple,
    celda: float,
    nx: int,
    ny: int,
    sample,
    dentro,
    costura: Sequence,
    despeje: float,
) -> tuple:
    """``(puntos, n NoData)`` de la rejilla, fuera de la huella y de la costura."""
    xmin, ymin = extent[0], extent[1]
    cerca = _PointHash(costura, despeje) if costura else None
    puntos: list = []
    nodata = 0
    for j in range(ny):
        y = ymin + j * celda
        for i in range(nx):
            x = xmin + i * celda
            if dentro(x, y):
                continue
            if cerca is not None and cerca.near(x, y):
                continue
            z = sample(x, y)
            if z is None:
                nodata += 1
                continue
            puntos.append((x, y, z))
    return puntos, nodata


def _anadir_terreno(out, store, tris, nube, dentro, max_arista: float) -> int:
    """Mete en la malla los triangulos de terreno que valen. Devuelve descartados.

    Se descarta lo degenerado, lo que cae dentro de la huella del corredor (ahi
    manda el corredor) y lo que tiene una arista demasiado larga, que es como se
    recorta el relleno del casco convexo que devuelve Delaunay.
    """
    idx_nube: dict = {}
    descartados = 0
    for a, b, c in tris:
        pa, pb, pc = nube[a], nube[b], nube[c]
        if abs(0.5 * tri_area2(pa, pb, pc)) < MIN_AREA:
            continue
        cx = (pa[0] + pb[0] + pc[0]) / 3.0
        cy = (pa[1] + pb[1] + pc[1]) / 3.0
        if dentro(cx, cy):
            continue
        if max_edge(pa, pb, pc) > max_arista:
            descartados += 1
            continue
        ids = []
        for t in (a, b, c):
            n = idx_nube.get(t)
            if n is None:
                pt = nube[t]
                n = store.add(pt[0], pt[1], pt[2])
                idx_nube[t] = n
            ids.append(n)
        out.add_tri(*ids, origen=ORIGEN_TERRENO)
    return descartados


def _costura(anillos: Sequence, celda: float) -> tuple:
    """``(puntos de costura, dentro(x, y))`` de los anillos de la huella.

    La costura es el propio contorno del corredor densificado a la escala de la
    rejilla: al triangular, esos puntos son comunes a las dos superficies y es lo
    que hace que casen sin solapes ni huecos.
    """
    costura: list = []
    indices: list = []
    for r in anillos:
        d = densify(r, celda, closed=True)
        costura.extend(d)
        indices.append(RingIndex(d))

    def dentro(x: float, y: float) -> bool:
        return any(ix.contains(x, y) for ix in indices)

    return costura, dentro


def _anadir_corredor(out: Mesh, store: "_NodeStore", corridor: Mesh) -> int:
    """Copia el corredor en la malla de salida. Devuelve cuantos triangulos tiene."""
    remap = [store.add(*n) for n in corridor.nodes]
    for i, j, k in corridor.tris:
        out.add_tri(remap[i], remap[j], remap[k])
    return len(out.tris)


def _triangular(nube: Sequence) -> tuple:
    """``(triangulos, aviso)`` de la nube. ``triangulos`` es ``None`` si no se puede.

    Los tres motivos por los que puede no haber triangulacion son distintos y hay
    que distinguirlos en el aviso: pocos puntos, scipy ausente o un fallo de qhull.
    """
    if len(nube) < 3:
        return None, "no hay suficientes puntos de terreno para triangular"
    try:
        return _delaunay([(p[0], p[1]) for p in nube]), ""
    except DelaunayNoDisponible as exc:
        return None, (
            f"la fusion con el terreno necesita scipy.spatial.Delaunay y no se ha "
            f"podido importar ({exc}). Se devuelve solo el corredor."
        )
    except RuntimeError as exc:
        return None, f"{exc}. Se devuelve solo el corredor."


def merge_with_terrain(
    corridor: Mesh,
    rings: Sequence,
    sample: Callable[[float, float], Optional[float]],
    extent: Optional[tuple] = None,
    opts: Optional[MergeOptions] = None,
) -> tuple:
    """Devuelve ``(malla_fusionada, avisos)``.

    ``rings`` es la lista de anillos (uno por feature de la directriz), cada uno
    una lista de ``(x, y, z)`` sin cerrar. ``sample`` da la cota del terreno o
    ``None`` en NoData. ``extent`` limita la zona de terreno a incluir; si es
    ``None`` se toma la envolvente de los anillos mas ``opts.holgura``.
    """
    opts = (opts or MergeOptions()).resueltas()
    avisos: list = []

    anillos = [list(r) for r in rings if r and len(r) >= 3]
    if not anillos:
        avisos.append("no hay huella de corredor; se devuelve solo el terreno")

    # --- costura: anillos densificados a la escala de la rejilla ---
    costura, dentro = _costura(anillos, opts.celda)

    # --- extent de trabajo ---
    if extent is None:
        if not costura:
            return corridor, avisos + ["nada que fusionar"]
        extent = _envolvente(costura, opts.holgura)

    opts, celda, nx, ny, aviso = _rejilla(extent, opts)
    if aviso:
        avisos.append(aviso)
    puntos, nodata = _nodos_de_terreno(
        extent, celda, nx, ny, sample, dentro, costura, opts.despeje
    )
    if nodata:
        avisos.append(f"{nodata} nodos de rejilla descartados por NoData")

    nube = puntos + costura
    tris, aviso = _triangular(nube)
    if aviso:
        avisos.append(aviso)
    if tris is None:
        return corridor, avisos
    avisos.append(
        f"terreno: {len(puntos)} nodos de rejilla + {len(costura)} de costura -> "
        f"{len(tris)} triangulos brutos"
    )

    # --- montaje: primero el corredor entero, tal cual ---
    out = Mesh()
    store = _NodeStore(out)
    n_corredor = _anadir_corredor(out, store, corridor)

    # 2) el terreno, filtrando lo que pisa el corredor
    descartados = _anadir_terreno(out, store, tris, nube, dentro, opts.max_arista)
    if descartados:
        avisos.append(
            f"{descartados} triangulos de terreno descartados por arista > "
            f"{opts.max_arista:.1f} m"
        )
    avisos.append(
        f"fusion: {n_corredor} triangulos de corredor + "
        f"{len(out.tris) - n_corredor} de terreno"
    )
    return out, avisos


__all__ = ["MergeOptions", "merge_with_terrain"]
