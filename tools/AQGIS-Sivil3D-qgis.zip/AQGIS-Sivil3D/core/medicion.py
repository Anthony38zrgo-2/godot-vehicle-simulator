"""Mediciones de tierras: areas por seccion, volumenes y diagrama de masas.

Modulo puro.

Metodo
------
Las areas de desmonte y terraplen de cada seccion se obtienen integrando entre
la linea de proyecto y la del terreno, partiendo por los cruces (``core.perfil``).
No es una estimacion: es el area exacta de los poligonos que se ven sombreados
en la previsualizacion.

Los volumenes se calculan por **areas medias** entre secciones consecutivas, que
es el metodo clasico de proyecto::

    V = (A1 + A2) / 2 * L

Es la convencion habitual y la que hay que usar si los numeros tienen que cuadrar
con una medicion hecha a mano. Tiene un sesgo conocido cuando una de las dos
areas es cero (el paso de desmonte a terraplen), donde el prismatoide daria algo
menos; para eso esta ``metodo="prismatoide"``, que aplica la formula de Simpson
con el area interpolada en el centro.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from .perfil import areas as areas_perfil
from ..i18n import numero, t

METODO_AREAS_MEDIAS = "areas_medias"
METODO_PRISMATOIDE = "prismatoide"


@dataclass
class AreaSeccion:
    """Areas de una seccion, en m2."""

    pk: float
    desmonte: float = 0.0
    terraplen: float = 0.0
    cota_roja: Optional[float] = None
    ok: bool = True

    @property
    def neta(self) -> float:
        """Terraplen menos desmonte: positiva si falta tierra."""
        return self.terraplen - self.desmonte


@dataclass
class VolumenTramo:
    """Volumen entre dos secciones consecutivas, en m3."""

    pk_ini: float
    pk_fin: float
    desmonte: float = 0.0
    terraplen: float = 0.0

    @property
    def longitud(self) -> float:
        return self.pk_fin - self.pk_ini

    @property
    def neto(self) -> float:
        return self.terraplen - self.desmonte


@dataclass
class Medicion:
    """Resultado completo de la medicion de un tramo."""

    areas: list = field(default_factory=list)
    volumenes: list = field(default_factory=list)
    #: ``[(pk, volumen_neto_acumulado)]``: el diagrama de masas.
    masas: list = field(default_factory=list)

    @property
    def total_desmonte(self) -> float:
        return sum(v.desmonte for v in self.volumenes)

    @property
    def total_terraplen(self) -> float:
        return sum(v.terraplen for v in self.volumenes)

    @property
    def total_neto(self) -> float:
        return self.total_terraplen - self.total_desmonte

    @property
    def longitud(self) -> float:
        if not self.areas:
            return 0.0
        return self.areas[-1].pk - self.areas[0].pk

    def resumen(self) -> str:
        return t(
            "{largo:.1f} m: cut {des} m3, fill {ter} m3, net {neto} m3",
            largo=self.longitud,
            des=numero(self.total_desmonte),
            ter=numero(self.total_terraplen),
            neto=numero(self.total_neto, signo=True),
        )


# --------------------------------------------------------------------------


def areas_de_secciones(sections: Sequence) -> list:
    """Una :class:`AreaSeccion` por seccion resuelta."""
    salida = []
    for sec in sections:
        des, ter = 0.0, 0.0
        if sec.terreno and len(sec.vertices) >= 2:
            des, ter = areas_perfil(sec.perfil, sec.terreno)
        salida.append(
            AreaSeccion(
                pk=sec.station.s,
                desmonte=des,
                terraplen=ter,
                cota_roja=sec.cota_roja,
                ok=sec.ok,
            )
        )
    return salida


def volumenes_entre(areas: Sequence, metodo: str = METODO_AREAS_MEDIAS) -> list:
    """Volumenes entre areas consecutivas."""
    salida = []
    for a, b in zip(areas, areas[1:]):
        L = b.pk - a.pk
        if L <= 0.0:
            continue
        if metodo == METODO_PRISMATOIDE:
            # Simpson con el area central interpolada linealmente: para areas
            # que varian de forma lineal da lo mismo que las areas medias, y
            # amortigua el salto cuando una de las dos es cero.
            des = L / 6.0 * (a.desmonte + 4.0 * _medio(a.desmonte, b.desmonte) + b.desmonte)
            ter = L / 6.0 * (
                a.terraplen + 4.0 * _medio(a.terraplen, b.terraplen) + b.terraplen
            )
        else:
            des = 0.5 * (a.desmonte + b.desmonte) * L
            ter = 0.5 * (a.terraplen + b.terraplen) * L
        salida.append(
            VolumenTramo(pk_ini=a.pk, pk_fin=b.pk, desmonte=des, terraplen=ter)
        )
    return salida


def _medio(a: float, b: float) -> float:
    """Area en el centro del tramo.

    Si una de las dos es cero, la superficie pasa por ahi y el area central es
    la mitad de la que no lo es (no la media aritmetica).
    """
    if a <= 0.0 or b <= 0.0:
        return 0.25 * (a + b)
    return 0.5 * (a + b)


def diagrama_masas(
    volumenes: Sequence, esponjamiento: float = 1.0, pk_inicial: float = 0.0
) -> list:
    """``[(pk, acumulado)]`` del volumen neto.

    ``esponjamiento`` es el coeficiente de paso de desmonte a terraplen: con 1.0
    un metro cubico excavado rellena un metro cubico. Con 0.9, el desmonte
    aprovechable es el 90 %.
    """
    salida = [(pk_inicial, 0.0)]
    acumulado = 0.0
    for v in volumenes:
        acumulado += v.terraplen - v.desmonte * esponjamiento
        salida.append((v.pk_fin, acumulado))
    return salida


def medir(
    sections: Sequence,
    metodo: str = METODO_AREAS_MEDIAS,
    esponjamiento: float = 1.0,
) -> Medicion:
    """Medicion completa de una lista de secciones resueltas."""
    areas = areas_de_secciones(sections)
    vols = volumenes_entre(areas, metodo)
    pk0 = areas[0].pk if areas else 0.0
    return Medicion(
        areas=areas,
        volumenes=vols,
        masas=diagrama_masas(vols, esponjamiento, pk0),
    )


def medir_resultado(result, metodo: str = METODO_AREAS_MEDIAS, esponjamiento: float = 1.0):
    """``{etiqueta_de_tramo: Medicion}`` para un ``BuildResult``.

    Se mide tramo a tramo y no todo junto: los volumenes entre el final de un
    tramo y el principio del siguiente no significan nada.
    """
    return {
        run.etiqueta: medir(run.sections, metodo, esponjamiento)
        for run in result.runs
    }


__all__ = [
    "METODO_AREAS_MEDIAS",
    "METODO_PRISMATOIDE",
    "AreaSeccion",
    "VolumenTramo",
    "Medicion",
    "areas_de_secciones",
    "volumenes_entre",
    "diagrama_masas",
    "medir",
    "medir_resultado",
]
