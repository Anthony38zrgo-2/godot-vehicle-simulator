"""Libreria de secciones tipo: varias :class:`Assembly` en un solo archivo.

Modulo puro. El formato es un JSON legible y editable a mano::

    {
      "version": 1,
      "secciones": [ {<assembly>}, {<assembly>}, ... ]
    }

El nombre de cada seccion es su clave: es lo que se pone en el campo de la capa
de directrices para decidir que seccion se aplica a cada tramo.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Iterator, Optional

from .params import ParamError
from .schema import Assembly

LIBRARY_VERSION = 1


@dataclass
class AssemblyLibrary:
    """Coleccion ordenada de secciones tipo indexada por nombre."""

    assemblies: dict = field(default_factory=dict)

    # -- acceso -----------------------------------------------------------
    def __len__(self) -> int:
        return len(self.assemblies)

    def __contains__(self, nombre: str) -> bool:
        return nombre in self.assemblies

    def __iter__(self) -> Iterator[str]:
        return iter(self.assemblies)

    def __getitem__(self, nombre: str) -> Assembly:
        try:
            return self.assemblies[nombre]
        except KeyError:
            raise ParamError(
                f"la libreria no tiene la seccion '{nombre}'. "
                f"Hay: {self.names()}"
            ) from None

    def get(self, nombre: str) -> Optional[Assembly]:
        return self.assemblies.get(nombre)

    def names(self) -> list:
        return list(self.assemblies)

    def first(self) -> Optional[str]:
        return next(iter(self.assemblies), None)

    # -- edicion ----------------------------------------------------------
    def add(self, asm: Assembly, sobrescribir: bool = False) -> str:
        """Anade la seccion. Si el nombre ya existe le pone un sufijo."""
        nombre = (asm.nombre or "Sin nombre").strip()
        if not sobrescribir and nombre in self.assemblies:
            base, n = nombre, 2
            while nombre in self.assemblies:
                nombre = f"{base} ({n})"
                n += 1
        asm.nombre = nombre
        self.assemblies[nombre] = asm
        return nombre

    def remove(self, nombre: str) -> None:
        self.assemblies.pop(nombre, None)

    def rename(self, viejo: str, nuevo: str) -> str:
        nuevo = (nuevo or "").strip()
        if not nuevo:
            raise ParamError("el nombre de la seccion no puede estar vacio")
        if viejo not in self.assemblies:
            raise ParamError(f"no existe la seccion '{viejo}'")
        if nuevo != viejo and nuevo in self.assemblies:
            raise ParamError(f"ya hay una seccion llamada '{nuevo}'")
        # Se reconstruye el diccionario para no perder el orden.
        salida = {}
        for k, v in self.assemblies.items():
            if k == viejo:
                v.nombre = nuevo
                salida[nuevo] = v
            else:
                salida[k] = v
        self.assemblies = salida
        return nuevo

    def duplicate(self, nombre: str) -> str:
        asm = self[nombre].copy()
        asm.nombre = f"{nombre} copia"
        return self.add(asm)

    def move(self, nombre: str, delta: int) -> None:
        claves = self.names()
        if nombre not in claves:
            return
        i = claves.index(nombre)
        j = max(0, min(len(claves) - 1, i + delta))
        if i == j:
            return
        claves.insert(j, claves.pop(i))
        self.assemblies = {k: self.assemblies[k] for k in claves}

    # -- validacion -------------------------------------------------------
    def validate(self) -> dict:
        """``{nombre: [problemas]}`` solo con las que tienen algo que decir."""
        salida = {}
        for nombre, asm in self.assemblies.items():
            problemas = asm.validate()
            if problemas:
                salida[nombre] = problemas
        return salida

    # -- serializacion ----------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "version": LIBRARY_VERSION,
            "secciones": [a.to_dict() for a in self.assemblies.values()],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AssemblyLibrary":
        if not isinstance(data, dict):
            raise ParamError("el archivo de secciones no tiene el formato esperado")
        # Se acepta tambien un archivo con una sola seccion suelta.
        if "secciones" not in data and ("izquierda" in data or "derecha" in data):
            data = {"version": LIBRARY_VERSION, "secciones": [data]}
        lib = cls()
        for d in data.get("secciones") or []:
            lib.add(Assembly.from_dict(d))
        return lib

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_json(cls, texto: str) -> "AssemblyLibrary":
        try:
            data = json.loads(texto)
        except json.JSONDecodeError as exc:
            raise ParamError(f"JSON invalido: {exc}") from None
        return cls.from_dict(data)

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(self.to_json())

    @classmethod
    def load(cls, path: str) -> "AssemblyLibrary":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_json(fh.read())

    def copy(self) -> "AssemblyLibrary":
        return AssemblyLibrary({k: v.copy() for k, v in self.assemblies.items()})


def default_library(lang: str = "") -> AssemblyLibrary:
    """Libreria de arranque con las plantillas incluidas, en un idioma.

    Sin ``lang`` se usa el idioma que tenga puesto el plugin: al elegir ingles se
    arranca con el catalogo en ingles y al elegir castellano, con el castellano.
    """
    from ..i18n import idioma
    from .templates import TEMPLATES

    lang = lang or idioma()
    lib = AssemblyLibrary()
    for fabrica in TEMPLATES.values():
        lib.add(fabrica(lang))
    return lib


def load_or_default(path: Optional[str], lang: str = "") -> AssemblyLibrary:
    """Carga la libreria del disco; si no se puede, devuelve la de plantillas."""
    if path:
        try:
            return AssemblyLibrary.load(path)
        except (OSError, ParamError):
            pass
    return default_library(lang)


__all__ = [
    "LIBRARY_VERSION",
    "AssemblyLibrary",
    "default_library",
    "load_or_default",
]
