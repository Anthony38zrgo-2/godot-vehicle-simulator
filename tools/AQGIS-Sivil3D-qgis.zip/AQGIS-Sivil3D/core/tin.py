"""Construccion del TIN del corredor a partir de las secciones resueltas.

Modulo puro: no importa nada de QGIS.

Idea
----
Entre dos secciones consecutivas se teje una banda de triangulos. El
emparejado se hace **por codigo de punto**, no por indice, porque el numero de
vertices cambia de una seccion a otra (una tiene 2 banquetas, la siguiente 3).
Se calcula la subsecuencia comun mas larga (LCS) de los codigos: esos son los
"raíles" ancla. Entre anclas consecutivas se cose la subcadena con una tira de
triangulos avanzando por la cadena que va mas retrasada en longitud
normalizada. Asi la malla es estructurada, determinista y no necesita Delaunay.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Optional

from .elements import KIND_DAYLIGHT, KIND_TRUNCADO
from ..i18n import t

#: Area minima en planta para aceptar un triangulo (m2).
MIN_AREA = 1.0e-9


#: Procedencia de un triangulo, para poder simbolizar el resultado.
ORIGEN_CORREDOR = "corredor"
ORIGEN_TERRENO = "terreno"


@dataclass
class Mesh:
    """Malla triangular: nodos ``(x, y, z)`` y triangulos ``(i, j, k)`` 0-based.

    ``origenes`` es una lista paralela a ``tris`` con la procedencia de cada
    triangulo. Hace falta para distinguir en la malla fusionada la obra del
    terreno natural, que no se puede deducir de la geometria: un triangulo de
    corredor junto a la linea de daylight tambien esta pegado al terreno.
    """

    nodes: list = field(default_factory=list)
    tris: list = field(default_factory=list)
    origenes: list = field(default_factory=list)

    def add_node(self, x: float, y: float, z: float) -> int:
        self.nodes.append((x, y, z))
        return len(self.nodes) - 1

    def add_tri(self, i: int, j: int, k: int, origen: str = ORIGEN_CORREDOR) -> bool:
        """Anade el triangulo normalizando el sentido a antihorario en planta."""
        if i == j or j == k or i == k:
            return False
        a, b, c = self.nodes[i], self.nodes[j], self.nodes[k]
        area2 = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        if abs(0.5 * area2) < MIN_AREA:
            return False
        if area2 < 0.0:
            i, j, k = i, k, j
        self.tris.append((i, j, k))
        self.origenes.append(origen)
        return True

    def origen(self, n: int) -> str:
        """Origen del triangulo ``n``."""
        return self.origenes[n] if n < len(self.origenes) else ORIGEN_CORREDOR

    def extend(self, other: "Mesh") -> None:
        """Anade otra malla desplazando sus indices. No deduplica nodos."""
        base = len(self.nodes)
        self.nodes.extend(other.nodes)
        self.tris.extend((i + base, j + base, k + base) for i, j, k in other.tris)
        self.origenes.extend(other.origen(n) for n in range(len(other.tris)))

    def triangle_coords(self) -> Iterable[list]:
        for i, j, k in self.tris:
            yield [self.nodes[i], self.nodes[j], self.nodes[k]]

    def __len__(self) -> int:
        return len(self.tris)

    @property
    def is_empty(self) -> bool:
        return not self.tris

    def bbox(self) -> Optional[tuple]:
        if not self.nodes:
            return None
        xs = [n[0] for n in self.nodes]
        ys = [n[1] for n in self.nodes]
        return (min(xs), min(ys), max(xs), max(ys))

    def z_range(self) -> Optional[tuple]:
        if not self.nodes:
            return None
        zs = [n[2] for n in self.nodes]
        return (min(zs), max(zs))


# --------------------------------------------------------------------------
# Emparejado por codigo
# --------------------------------------------------------------------------


def lcs_pairs(a: list, b: list) -> list:
    """Subsecuencia comun mas larga de dos listas de codigos.

    Devuelve la lista de parejas de indices ``(ia, ib)``.
    """
    n, m = len(a), len(b)
    if n == 0 or m == 0:
        return []
    tabla = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        fila, sig = tabla[i], tabla[i + 1]
        for j in range(m - 1, -1, -1):
            fila[j] = sig[j + 1] + 1 if a[i] == b[j] else max(sig[j], fila[j + 1])
    out = []
    i = j = 0
    while i < n and j < m:
        if a[i] == b[j]:
            out.append((i, j))
            i += 1
            j += 1
        elif tabla[i + 1][j] >= tabla[i][j + 1]:
            i += 1
        else:
            j += 1
    return out


def _anchors(codes_a: list, codes_b: list) -> list:
    """Anclas de cosido.

    Los extremos de las dos cadenas (el punto mas a la izquierda y el mas a la
    derecha de cada seccion) son siempre ancla: son los bordes del corredor
    aunque su codigo no coincida. Las anclas intermedias salen del LCS de los
    codigos, descartando las que caen en los extremos para no romper la
    monotonia.
    """
    na, nb = len(codes_a), len(codes_b)
    if na == 0 or nb == 0:
        return []
    out: list = [(0, 0)]
    for ia, ib in lcs_pairs(codes_a, codes_b):
        if ia <= 0 or ib <= 0 or ia >= na - 1 or ib >= nb - 1:
            continue
        pa, pb = out[-1]
        if ia > pa and ib > pb:
            out.append((ia, ib))
    ultimo = (na - 1, nb - 1)
    if ultimo != out[-1]:
        out.append(ultimo)
    return out


def _params(pts: list) -> list:
    """Longitud de arco normalizada [0, 1] de una polilinea 3D."""
    if len(pts) < 2:
        return [0.0] * len(pts)
    acum = [0.0]
    for p, q in zip(pts, pts[1:]):
        acum.append(acum[-1] + math.dist(p, q))
    total = acum[-1]
    if total <= 0.0:
        n = len(pts) - 1
        return [i / n for i in range(len(pts))]
    return [v / total for v in acum]


def _strip(mesh: Mesh, ia: list, pa: list, ib: list, pb: list) -> None:
    """Tira de triangulos entre dos subcadenas ya ancladas en sus extremos."""
    ta, tb = _params(pa), _params(pb)
    i = j = 0
    na, nb = len(ia), len(ib)
    guard = na + nb + 2
    while (i < na - 1 or j < nb - 1) and guard > 0:
        guard -= 1
        if i >= na - 1:
            j += 1
            mesh.add_tri(ia[i], ib[j - 1], ib[j])
        elif j >= nb - 1:
            i += 1
            mesh.add_tri(ia[i - 1], ib[j], ia[i])
        elif ta[i + 1] <= tb[j + 1]:
            i += 1
            mesh.add_tri(ia[i - 1], ib[j], ia[i])
        else:
            j += 1
            mesh.add_tri(ia[i], ib[j - 1], ib[j])


def build_mesh(sections: list) -> Mesh:
    """Teje el TIN del corredor a partir de secciones consecutivas."""
    mesh = Mesh()
    if len(sections) < 2:
        return mesh
    indices: list = []
    puntos: list = []
    for sec in sections:
        pts = sec.world_points()
        puntos.append(pts)
        indices.append([mesh.add_node(*p) for p in pts])
    for k in range(len(sections) - 1):
        ca, cb = sections[k].codes(), sections[k + 1].codes()
        ia_all, ib_all = indices[k], indices[k + 1]
        pa_all, pb_all = puntos[k], puntos[k + 1]
        if not ia_all or not ib_all:
            continue
        anclas = _anchors(ca, cb)
        for (a0, b0), (a1, b1) in zip(anclas, anclas[1:]):
            _strip(
                mesh,
                ia_all[a0 : a1 + 1],
                pa_all[a0 : a1 + 1],
                ib_all[b0 : b1 + 1],
                pb_all[b0 : b1 + 1],
            )
    return mesh


# --------------------------------------------------------------------------
# Lineas caracteristicas y borde
# --------------------------------------------------------------------------


def feature_lines(sections: list) -> list:
    """Lineas longitudinales por codigo (las *breaklines* del corredor).

    Devuelve ``[(codigo, [(x, y, z), ...]), ...]``. Un codigo que desaparece y
    reaparece genera varias polilineas.
    """
    activos: dict = {}
    salida: list = []
    for sec in sections:
        presentes = set()
        for v in sec.vertices:
            presentes.add(v.code)
            activos.setdefault(v.code, []).append(sec.world(v))
        for code in [c for c in activos if c not in presentes]:
            linea = activos.pop(code)
            if len(linea) > 1:
                salida.append((code, linea))
    for code, linea in activos.items():
        if len(linea) > 1:
            salida.append((code, linea))
    salida.sort(key=lambda t: t[0])
    return salida


def boundary_ring(sections: list) -> list:
    """Anillo exterior del corredor (borde de daylight + secciones extremas)."""
    if len(sections) < 2:
        return []
    filas = [s.world_points() for s in sections]
    anillo: list = []
    anillo.extend(filas[0])  # seccion inicial, izq -> der
    anillo.extend(f[-1] for f in filas[1:])  # borde derecho
    anillo.extend(list(reversed(filas[-1]))[1:])  # seccion final, der -> izq
    anillo.extend(f[0] for f in reversed(filas[1:-1]))  # borde izquierdo
    return _clean_ring(anillo)


def _clean_ring(pts: list, tol: float = 1e-9) -> list:
    out: list = []
    for p in pts:
        if out and abs(out[-1][0] - p[0]) < tol and abs(out[-1][1] - p[1]) < tol:
            continue
        out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) < tol and abs(
        out[0][1] - out[-1][1]
    ) < tol:
        out.pop()
    return out


def daylight_lines(sections: list) -> list:
    """Las dos lineas de daylight (izquierda y derecha) como polilineas 3D."""
    izq, der = [], []
    for sec in sections:
        if not sec.vertices:
            continue
        v0, v1 = sec.vertices[0], sec.vertices[-1]
        if v0.kind in (KIND_DAYLIGHT, KIND_TRUNCADO):
            izq.append(sec.world(v0))
        if v1.kind in (KIND_DAYLIGHT, KIND_TRUNCADO):
            der.append(sec.world(v1))
    salida = []
    if len(izq) > 1:
        salida.append(("DAYLIGHT_IZQ", izq))
    if len(der) > 1:
        salida.append(("DAYLIGHT_DER", der))
    return salida


# --------------------------------------------------------------------------
# Escritura de malla en formato 2DM (SMS 2D mesh), que QGIS abre nativamente
# --------------------------------------------------------------------------


def write_2dm(path: str, mesh: Mesh) -> None:
    """Escribe la malla en ``.2dm``; QGIS la carga como capa de malla."""
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("MESH2D\n")
        fh.write("NUM_MATERIALS_PER_ELEM 1\n")
        for idx, (i, j, k) in enumerate(mesh.tris, start=1):
            fh.write(f"E3T {idx} {i + 1} {j + 1} {k + 1} 1\n")
        for idx, (x, y, z) in enumerate(mesh.nodes, start=1):
            fh.write(f"ND {idx} {x:.6f} {y:.6f} {z:.6f}\n")


def mesh_stats(mesh: Mesh) -> str:
    zr = mesh.z_range()
    if zr is None:
        return t("empty mesh")
    return t(
        "{n} nodes, {tr} triangles, elevations {a:.2f} to {b:.2f}",
        n=len(mesh.nodes),
        tr=len(mesh.tris),
        a=zr[0],
        b=zr[1],
    )
