"""Geometria de una rasante: la linea (s, z) que define la cota del eje.

Una rasante se edita como se edita cualquier linea en QGIS, y por eso aqui hay
los mismos tipos de segmento que ofrece la digitalizacion en planta:

``recta``
    tramo de pendiente constante, el pan de cada dia de un proyecto.
``arco``
    arco de circunferencia que pasa por un punto intermedio, como la herramienta
    de curva por tres puntos.
``bezier``
    cubica de Bezier con dos tiradores.
``nurbs``
    B-spline racional de grado 3 sobre los puntos de control que haya, con peso
    por punto. Es la unica que permite subir el grado de libertad sin llenar la
    rasante de vertices.

Ademas de los tipos de segmento, cada vertice interior admite un **acuerdo
vertical** de longitud ``L``: la parabola simetrica de toda la vida, que redondea
la esquina entre dos rectas. Es la herramienta que de verdad se usa en un
proyecto de carretera, y no tiene equivalente en la digitalizacion en planta, asi
que conviven las dos cosas: los tipos de segmento para dibujar cualquier forma y
el acuerdo para proyectar como se proyecta.

El modulo es Python puro a proposito: la geometria delicada se prueba sin abrir
QGIS. La vista y las herramientas de raton estan en :mod:`ui.rasante_view`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Sequence, Tuple

from ..i18n import t

Punto = Tuple[float, float]

#: Tipos de segmento admitidos, en el orden en que salen en la barra.
RECTA = "recta"
ARCO = "arco"
BEZIER = "bezier"
NURBS = "nurbs"
TIPOS = (RECTA, ARCO, BEZIER, NURBS)

#: Cuantos puntos de control necesita cada tipo. ``None`` = los que sea (>= 1).
CONTROLES = {RECTA: 0, ARCO: 1, BEZIER: 2, NURBS: None}

#: Nombre visible de cada tipo de segmento, en ingles. Quien lo pinta lo
#: pasa por ``t()``; la clave es lo que se guarda.
NOMBRES = {
    RECTA: "Straight",
    ARCO: "Arc",
    BEZIER: "Bezier",
    NURBS: "NURBS",
}


def _interp(a: Punto, b: Punto, t: float) -> Punto:
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


# ---------------------------------------------------------------- vertices
def simplificar(puntos: Sequence[Punto], tolerancia: float) -> List[Punto]:
    """Quita los puntos que no hacen falta para describir la linea (Douglas-Peucker).

    Se aplica en el plano ``(s, z)``, y la tolerancia es **en metros de cota**: un
    punto sobra si esta a menos de ``tolerancia`` de la recta que une los que le
    rodean. Es lo que convierte los 300 vertices que hereda una rasante leida de
    la planta en los 6 u 8 que de verdad la definen.
    """
    pts = [p for p in puntos if p[1] is not None]
    if len(pts) < 3 or tolerancia <= 0.0:
        return list(pts)

    def desvio(p: Punto, a: Punto, b: Punto) -> float:
        """Distancia vertical de ``p`` a la recta ``ab``, en cota."""
        if abs(b[0] - a[0]) < 1e-12:
            return abs(p[1] - a[1])
        t = (p[0] - a[0]) / (b[0] - a[0])
        return abs(p[1] - (a[1] + (b[1] - a[1]) * t))

    guardar = [False] * len(pts)
    guardar[0] = guardar[-1] = True
    pila = [(0, len(pts) - 1)]
    while pila:
        ini, fin = pila.pop()
        if fin - ini < 2:
            continue
        peor, cual = 0.0, -1
        for i in range(ini + 1, fin):
            d = desvio(pts[i], pts[ini], pts[fin])
            if d > peor:
                peor, cual = d, i
        if peor > tolerancia and cual > 0:
            guardar[cual] = True
            pila.append((ini, cual))
            pila.append((cual, fin))
    return [p for p, vale in zip(pts, guardar) if vale]


@dataclass
class Vertice:
    """Un vertice de la rasante, con lo que sale de el."""

    #: Abscisa sobre el eje, en metros.
    s: float
    #: Cota.
    z: float
    #: Longitud del acuerdo vertical en este vertice, en metros. 0 = esquina viva.
    acuerdo: float = 0.0
    #: Tipo del segmento que sale de este vertice hacia el siguiente.
    tipo: str = RECTA
    #: Puntos de control ``(s, z)`` del segmento que sale de aqui.
    control: List[Punto] = field(default_factory=list)
    #: Pesos del NURBS, uno por punto de control incluyendo los extremos. Vacio
    #: es lo mismo que todos a 1, es decir, una B-spline sin racionalizar.
    pesos: List[float] = field(default_factory=list)

    def copia(self) -> "Vertice":
        return Vertice(
            self.s,
            self.z,
            self.acuerdo,
            self.tipo,
            [tuple(c) for c in self.control],
            list(self.pesos),
        )

    def a_dict(self) -> dict:
        d = {"s": self.s, "z": self.z}
        if self.acuerdo:
            d["acuerdo"] = self.acuerdo
        if self.tipo != RECTA:
            d["tipo"] = self.tipo
            d["control"] = [list(c) for c in self.control]
            if self.pesos:
                d["pesos"] = list(self.pesos)
        return d

    @staticmethod
    def de_dict(d: dict) -> "Vertice":
        return Vertice(
            float(d["s"]),
            float(d["z"]),
            float(d.get("acuerdo", 0.0) or 0.0),
            str(d.get("tipo", RECTA)),
            [(float(c[0]), float(c[1])) for c in d.get("control", [])],
            [float(w) for w in d.get("pesos", [])],
        )


# ---------------------------------------------------------------- piezas
@dataclass
class Pieza:
    """Un trozo de rasante con su propia ley, entre dos abscisas."""

    s_ini: float
    s_fin: float
    clase: str
    #: ``z = evaluar(s)``.
    evaluar: Callable[[float], float]
    #: Vertice del que sale, para poder rotular.
    indice: int = 0

    @property
    def longitud(self) -> float:
        return self.s_fin - self.s_ini

    def muestrear(self, paso: float) -> List[Punto]:
        """Puntos de la pieza incluyendo sus dos extremos."""
        n = max(1, int(math.ceil(self.longitud / max(paso, 1e-6))))
        if self.clase == RECTA:
            n = 1  # una recta no necesita puntos intermedios
        return [
            (
                self.s_ini + self.longitud * i / n,
                self.evaluar(self.s_ini + self.longitud * i / n),
            )
            for i in range(n + 1)
        ]


# ------------------------------------------------------- curvas parametricas
def _muestras_arco(p0: Punto, c: Punto, p1: Punto, n: int = 24) -> List[Punto]:
    """Arco de circunferencia por tres puntos, en el plano (s, z).

    Si los tres puntos son casi colineales no hay circunferencia que valga: se
    devuelve la cuerda, que es el limite correcto.
    """
    ax, ay = p0
    bx, by = c
    cx, cy = p1
    d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-12:
        return [p0, p1]
    ux = (
        (ax * ax + ay * ay) * (by - cy)
        + (bx * bx + by * by) * (cy - ay)
        + (cx * cx + cy * cy) * (ay - by)
    ) / d
    uy = (
        (ax * ax + ay * ay) * (cx - bx)
        + (bx * bx + by * by) * (ax - cx)
        + (cx * cx + cy * cy) * (bx - ax)
    ) / d
    r = math.hypot(ax - ux, ay - uy)
    a0 = math.atan2(ay - uy, ax - ux)
    a1 = math.atan2(by - uy, bx - ux)
    a2 = math.atan2(cy - uy, cx - ux)

    def normaliza(desde: float, hasta: float, sentido: float) -> float:
        d = hasta - desde
        while d * sentido < 0:
            d += 2.0 * math.pi * sentido
        while abs(d) > 2.0 * math.pi:
            d -= 2.0 * math.pi * sentido
        return d

    # El sentido lo decide el punto intermedio: hay que pasar por el.
    sentido = 1.0
    if normaliza(a0, a1, 1.0) > normaliza(a0, a2, 1.0):
        sentido = -1.0
    barrido = normaliza(a0, a2, sentido)
    return [
        (ux + r * math.cos(a0 + barrido * i / n), uy + r * math.sin(a0 + barrido * i / n))
        for i in range(n + 1)
    ]


def _muestras_bezier(p0: Punto, c1: Punto, c2: Punto, p1: Punto, n: int = 24) -> List[Punto]:
    salida = []
    for i in range(n + 1):
        t = i / n
        u = 1.0 - t
        salida.append(
            (
                u**3 * p0[0] + 3 * u * u * t * c1[0] + 3 * u * t * t * c2[0] + t**3 * p1[0],
                u**3 * p0[1] + 3 * u * u * t * c1[1] + 3 * u * t * t * c2[1] + t**3 * p1[1],
            )
        )
    return salida


def _nudos(n_control: int, grado: int) -> List[float]:
    """Vector de nudos uniforme sujeto: la curva pasa por los extremos."""
    m = n_control + grado + 1
    interiores = n_control - grado - 1
    nudos = [0.0] * (grado + 1)
    for i in range(1, interiores + 1):
        nudos.append(i / (interiores + 1.0))
    nudos += [1.0] * (grado + 1)
    del m
    return nudos


def _de_boor(t: float, control: Sequence[Punto], pesos: Sequence[float], grado: int) -> Punto:
    """Punto de una B-spline racional en el parametro ``t``."""
    nudos = _nudos(len(control), grado)
    n = len(control) - 1
    # Intervalo que contiene t.
    k = grado
    while k < n and t >= nudos[k + 1]:
        k += 1
    d = [
        (
            control[j][0] * pesos[j],
            control[j][1] * pesos[j],
            pesos[j],
        )
        for j in range(k - grado, k + 1)
    ]
    for r in range(1, grado + 1):
        for j in range(grado, r - 1, -1):
            i = j + k - grado
            den = nudos[i + grado - r + 1] - nudos[i]
            alfa = 0.0 if abs(den) < 1e-12 else (t - nudos[i]) / den
            a, b = d[j - 1], d[j]
            d[j] = (
                a[0] + alfa * (b[0] - a[0]),
                a[1] + alfa * (b[1] - a[1]),
                a[2] + alfa * (b[2] - a[2]),
            )
    x, y, w = d[grado]
    if abs(w) < 1e-12:
        return (control[-1][0], control[-1][1])
    return (x / w, y / w)


def _muestras_nurbs(
    puntos: Sequence[Punto], pesos: Sequence[float], n: int = 32, grado: int = 3
) -> List[Punto]:
    """B-spline racional sujeta por los extremos.

    Con menos puntos de control que grado+1 se baja el grado: con dos puntos sale
    la recta, con tres la cuadratica. Es lo que espera cualquiera que arrastre
    tiradores sin pensar en el grado.
    """
    if len(puntos) < 2:
        return list(puntos)
    grado = min(grado, len(puntos) - 1)
    pesos = list(pesos) if pesos else [1.0] * len(puntos)
    if len(pesos) != len(puntos):
        pesos = (pesos + [1.0] * len(puntos))[: len(puntos)]
    pesos = [w if w > 1e-6 else 1e-6 for w in pesos]
    salida = [tuple(puntos[0])]
    for i in range(1, n + 1):
        t = i / n
        salida.append(_de_boor(min(t, 1.0 - 1e-9), puntos, pesos, grado))
    salida[-1] = tuple(puntos[-1])
    return salida


def _como_funcion(muestras: Sequence[Punto]) -> Callable[[float], float]:
    """Convierte una polilinea muestreada en ``z(s)``.

    Una Bezier o un NURBS pueden volver atras en ``s``; una rasante no puede. Se
    resuelve quedandose con la envolvente de ``s`` creciente, que es lo que se
    dibuja y lo que se aplica. El aviso de que eso ha pasado lo da
    :meth:`Rasante.avisos`.
    """
    limpio: List[Punto] = []
    for s, z in muestras:
        if limpio and s <= limpio[-1][0] + 1e-9:
            continue
        limpio.append((s, z))
    if not limpio:
        limpio = [tuple(muestras[0])] if muestras else [(0.0, 0.0)]

    def z_en(s: float) -> float:
        if s <= limpio[0][0]:
            return limpio[0][1]
        if s >= limpio[-1][0]:
            return limpio[-1][1]
        lo, hi = 0, len(limpio) - 1
        while hi - lo > 1:
            medio = (lo + hi) // 2
            if limpio[medio][0] <= s:
                lo = medio
            else:
                hi = medio
        (s0, z0), (s1, z1) = limpio[lo], limpio[hi]
        if s1 - s0 < 1e-12:
            return z0
        return z0 + (z1 - z0) * (s - s0) / (s1 - s0)

    return z_en


# ---------------------------------------------------------------- rasante
class Rasante:
    """Linea (s, z) editable, con acuerdos verticales y segmentos de varios tipos."""

    def __init__(self, vertices: Optional[Sequence[Vertice]] = None):
        self.vertices: List[Vertice] = [v.copia() for v in (vertices or [])]

    # -- construccion ------------------------------------------------------
    @staticmethod
    def de_puntos(puntos: Sequence[Punto], tolerancia: float = 0.0) -> "Rasante":
        """Rasante a partir de ``[(s, z)]``.

        Con ``tolerancia`` mayor que cero se simplifica primero: la rasante es una
        ley de cotas, no una copia de los vertices de la planta, y heredar los
        trescientos vertices de una directriz la hace inmanejable.
        """
        utiles = simplificar(puntos, tolerancia) if tolerancia > 0.0 else puntos
        return Rasante([Vertice(float(s), float(z)) for s, z in utiles])

    @staticmethod
    def del_terreno(
        terreno: Sequence[Punto], n_vertices: int = 5, offset: float = 0.0
    ) -> "Rasante":
        """Rasante inicial pegada al terreno, con pocos vertices.

        Es el punto de partida habitual: se arranca del terreno y se va subiendo
        y bajando lo que haga falta.
        """
        puntos = [p for p in terreno if p[1] is not None]
        if len(puntos) < 2:
            return Rasante()
        n = max(2, min(n_vertices, len(puntos)))
        z_en = _como_funcion(puntos)
        s0, s1 = puntos[0][0], puntos[-1][0]
        return Rasante.de_puntos(
            [
                (s0 + (s1 - s0) * i / (n - 1), z_en(s0 + (s1 - s0) * i / (n - 1)) + offset)
                for i in range(n)
            ]
        )

    def copia(self) -> "Rasante":
        return Rasante(self.vertices)

    def __len__(self) -> int:
        return len(self.vertices)

    def __getitem__(self, i: int) -> Vertice:
        return self.vertices[i]

    @property
    def vacia(self) -> bool:
        return len(self.vertices) < 2

    @property
    def s_ini(self) -> float:
        return self.vertices[0].s if self.vertices else 0.0

    @property
    def s_fin(self) -> float:
        return self.vertices[-1].s if self.vertices else 0.0

    # -- edicion -----------------------------------------------------------
    def ordenar(self) -> None:
        """Deja los vertices por abscisa creciente. Los edita el raton, y el raton
        arrastra un vertice por delante del siguiente sin avisar."""
        orden = sorted(range(len(self.vertices)), key=lambda i: self.vertices[i].s)
        if orden != list(range(len(self.vertices))):
            # Los datos del segmento pertenecen al hueco, no al vertice, asi que
            # al reordenar hay que dejar los segmentos como estaban de posicion.
            tipos = [(v.tipo, v.control, v.pesos) for v in self.vertices]
            self.vertices = [self.vertices[i] for i in orden]
            for v, (tipo, control, pesos) in zip(self.vertices, tipos):
                v.tipo, v.control, v.pesos = tipo, control, pesos

    def insertar(self, s: float, z: float) -> int:
        """Mete un vertice en su sitio por abscisa y devuelve su indice.

        Si cae dentro de un segmento curvo, el segmento se parte en dos rectas:
        conservar la curva partida significaria inventarse los controles.
        """
        v = Vertice(float(s), float(z))
        i = 0
        while i < len(self.vertices) and self.vertices[i].s < s:
            i += 1
        if 0 < i < len(self.vertices) and self.vertices[i - 1].tipo != RECTA:
            self.vertices[i - 1].tipo = RECTA
            self.vertices[i - 1].control = []
            self.vertices[i - 1].pesos = []
        self.vertices.insert(i, v)
        return i

    def anadir(self, s: float, z: float) -> int:
        self.vertices.append(Vertice(float(s), float(z)))
        return len(self.vertices) - 1

    def borrar(self, i: int) -> bool:
        if not (0 <= i < len(self.vertices)) or len(self.vertices) <= 2:
            return False
        # El segmento que moria en el desaparece: el anterior se queda recto.
        if i > 0:
            self.vertices[i - 1].tipo = RECTA
            self.vertices[i - 1].control = []
            self.vertices[i - 1].pesos = []
        self.vertices.pop(i)
        return True

    def mover(self, i: int, s: float, z: float) -> None:
        if 0 <= i < len(self.vertices):
            v = self.vertices[i]
            ds, dz = s - v.s, z - v.z
            v.s, v.z = float(s), float(z)
            # Los controles del segmento que sale de aqui lo siguen, para que la
            # curva no se deforme al mover el vertice.
            v.control = [(c[0] + ds, c[1] + dz) for c in v.control]

    def mover_varios(self, indices, ds: float, dz: float) -> None:
        """Desplaza varios vertices a la vez el mismo incremento.

        Es lo que permite subir o bajar un tramo entero sin deformarlo: mover uno
        a uno cambiaria las pendientes intermedias por el camino.
        """
        for i in sorted(set(indices)):
            if 0 <= i < len(self.vertices):
                v = self.vertices[i]
                v.s += float(ds)
                v.z += float(dz)
                v.control = [(c[0] + ds, c[1] + dz) for c in v.control]

    def borrar_varios(self, indices) -> int:
        """Borra varios vertices. Devuelve cuantos se han quitado de verdad.

        Nunca deja menos de dos: una rasante de un solo vertice no es nada.
        """
        candidatos = sorted({i for i in indices if 0 <= i < len(self.vertices)})
        sobran = len(self.vertices) - 2
        if sobran <= 0:
            return 0
        quitados = 0
        # De atras adelante, para que los indices no se desplacen por el camino.
        for i in reversed(candidatos[:sobran] if len(candidatos) > sobran else candidatos):
            if self.borrar(i):
                quitados += 1
        return quitados

    def simplificar_a(self, tolerancia: float) -> int:
        """Simplifica la rasante en el sitio. Devuelve cuantos vertices se quitan.

        Los segmentos vuelven a ser rectas: los tiradores de una curva no
        sobreviven a que desaparezca uno de sus extremos.
        """
        if tolerancia <= 0.0 or len(self.vertices) < 3:
            return 0
        antes = len(self.vertices)
        puntos = simplificar([(v.s, v.z) for v in self.vertices], tolerancia)
        if len(puntos) < 2 or len(puntos) == antes:
            return 0
        acuerdos = {round(v.s, 6): v.acuerdo for v in self.vertices if v.acuerdo}
        self.vertices = [Vertice(s, z) for s, z in puntos]
        # Los acuerdos de los vertices que sobreviven se conservan.
        for v in self.vertices:
            v.acuerdo = acuerdos.get(round(v.s, 6), 0.0)
        return antes - len(self.vertices)

    def set_tipo(self, i: int, tipo: str, forzar: bool = False) -> bool:
        """Cambia el tipo del segmento ``i`` y le pone controles razonables.

        Los controles por defecto van sobre la cuerda, asi que al cambiar de tipo
        la rasante **no salta**: sigue siendo la misma recta hasta que se
        arrastra un tirador.

        Si el segmento **ya es de ese tipo** no se toca nada y se devuelve
        ``False``: volver a aplicarlo devolveria los tiradores a la cuerda y se
        perderia la forma que se acabase de dar. Con ``forzar`` se recolocan a
        proposito, que es como se «reinicia» una curva que se ha ido de las manos.
        """
        if tipo not in TIPOS or not (0 <= i < len(self.vertices) - 1):
            return False
        if not forzar and self.vertices[i].tipo == tipo:
            if tipo == RECTA or self.vertices[i].control:
                return False
        v, w = self.vertices[i], self.vertices[i + 1]
        a, b = (v.s, v.z), (w.s, w.z)
        v.tipo = tipo
        v.pesos = []
        if tipo == RECTA:
            v.control = []
        elif tipo == ARCO:
            v.control = [_interp(a, b, 0.5)]
        elif tipo == BEZIER:
            v.control = [_interp(a, b, 1 / 3), _interp(a, b, 2 / 3)]
        else:
            v.control = [_interp(a, b, 1 / 3), _interp(a, b, 2 / 3)]
        return True

    def anadir_control(self, i: int) -> bool:
        """Un punto de control mas en un NURBS: mas libertad sin mas vertices."""
        if not (0 <= i < len(self.vertices) - 1):
            return False
        v = self.vertices[i]
        if v.tipo != NURBS:
            return False
        puntos = self._control_completo(i)
        # Se parte el tramo mas largo de la poligonal de control.
        j = max(
            range(len(puntos) - 1),
            key=lambda k: math.hypot(
                puntos[k + 1][0] - puntos[k][0], puntos[k + 1][1] - puntos[k][1]
            ),
        )
        nuevo = _interp(puntos[j], puntos[j + 1], 0.5)
        v.control.insert(max(0, j), nuevo)
        if v.pesos:
            v.pesos.insert(max(1, j + 1), 1.0)
        return True

    def set_acuerdo(self, i: int, longitud: float) -> bool:
        if 0 < i < len(self.vertices) - 1:
            self.vertices[i].acuerdo = max(0.0, float(longitud))
            return True
        return False

    def set_peso(self, i: int, j: int, peso: float) -> bool:
        """Peso del punto de control ``j`` (contando los extremos) del NURBS ``i``."""
        if not (0 <= i < len(self.vertices) - 1):
            return False
        v = self.vertices[i]
        if v.tipo != NURBS:
            return False
        n = len(v.control) + 2
        if not (0 <= j < n):
            return False
        if not v.pesos:
            v.pesos = [1.0] * n
        v.pesos[j] = max(1e-3, float(peso))
        return True

    # -- geometria ---------------------------------------------------------
    def _control_completo(self, i: int) -> List[Punto]:
        v, w = self.vertices[i], self.vertices[i + 1]
        return [(v.s, v.z)] + [tuple(c) for c in v.control] + [(w.s, w.z)]

    def pendiente(self, i: int) -> float:
        """Pendiente de la cuerda del segmento ``i`` en tanto por uno."""
        if not (0 <= i < len(self.vertices) - 1):
            return 0.0
        v, w = self.vertices[i], self.vertices[i + 1]
        if abs(w.s - v.s) < 1e-9:
            return 0.0
        return (w.z - v.z) / (w.s - v.s)

    def parametro_k(self, i: int) -> Optional[float]:
        """K del acuerdo del vertice ``i``: metros por cada 1 % de cambio."""
        if not (0 < i < len(self.vertices) - 1):
            return None
        v = self.vertices[i]
        if v.acuerdo <= 0.0:
            return None
        a = (self.pendiente(i) - self.pendiente(i - 1)) * 100.0
        if abs(a) < 1e-9:
            return None
        return v.acuerdo / abs(a)

    def set_k(self, i: int, k: float) -> bool:
        """Fija el acuerdo por su K, que es como se proyecta de verdad."""
        if not (0 < i < len(self.vertices) - 1):
            return False
        a = (self.pendiente(i) - self.pendiente(i - 1)) * 100.0
        if abs(a) < 1e-9:
            return False
        return self.set_acuerdo(i, abs(k) * abs(a))

    def _acuerdo_util(self, i: int) -> float:
        """Longitud de acuerdo que cabe de verdad en el vertice ``i``.

        Un acuerdo no puede pasar de la mitad de la tangente que tiene a cada
        lado, porque se comeria el vertice de al lado. Y solo tiene sentido entre
        dos rectas: sobre una Bezier o un NURBS lo que manda son los tiradores.
        """
        if not (0 < i < len(self.vertices) - 1):
            return 0.0
        v = self.vertices[i]
        if v.acuerdo <= 0.0:
            return 0.0
        if self.vertices[i - 1].tipo != RECTA or v.tipo != RECTA:
            return 0.0
        izq = v.s - self.vertices[i - 1].s
        der = self.vertices[i + 1].s - v.s
        if abs(self.pendiente(i) - self.pendiente(i - 1)) < 1e-12:
            return 0.0
        return min(v.acuerdo, 2.0 * izq * 0.98, 2.0 * der * 0.98)

    def piezas(self) -> List[Pieza]:
        """Descompone la rasante en piezas con ley propia, en orden de abscisa."""
        if self.vacia:
            return []
        piezas: List[Pieza] = []
        n = len(self.vertices)
        acuerdos = [self._acuerdo_util(i) for i in range(n)]
        for i in range(n - 1):
            v, w = self.vertices[i], self.vertices[i + 1]
            s_a = v.s + acuerdos[i] / 2.0
            s_b = w.s - acuerdos[i + 1] / 2.0
            if v.tipo == RECTA:
                m = self.pendiente(i)
                z_a = v.z + m * (s_a - v.s)
                if s_b > s_a + 1e-9:
                    piezas.append(
                        Pieza(
                            s_a,
                            s_b,
                            RECTA,
                            (lambda s0, zz0, mm: lambda s: zz0 + mm * (s - s0))(
                                s_a, z_a, m
                            ),
                            i,
                        )
                    )
            else:
                muestras = self.muestras_segmento(i)
                z_en = _como_funcion(muestras)
                piezas.append(
                    Pieza(min(v.s, w.s), max(v.s, w.s), v.tipo, z_en, i)
                )
            # Acuerdo del vertice que cierra este segmento.
            if i + 1 < n - 1 and acuerdos[i + 1] > 0.0:
                piezas.append(self._pieza_acuerdo(i + 1, acuerdos[i + 1]))
        return piezas

    def _pieza_acuerdo(self, i: int, longitud: float) -> Pieza:
        """Parabola simetrica de longitud ``longitud`` centrada en el vertice."""
        v = self.vertices[i]
        g1, g2 = self.pendiente(i - 1), self.pendiente(i)
        s_bvc = v.s - longitud / 2.0
        z_bvc = v.z - g1 * longitud / 2.0
        a = (g2 - g1) / (2.0 * longitud)

        def z_en(s: float) -> float:
            x = s - s_bvc
            return z_bvc + g1 * x + a * x * x

        return Pieza(s_bvc, v.s + longitud / 2.0, "acuerdo", z_en, i)

    def muestras_segmento(self, i: int, n: int = 32) -> List[Punto]:
        """Puntos del segmento ``i`` segun su tipo, sin tocar los acuerdos."""
        if not (0 <= i < len(self.vertices) - 1):
            return []
        v, w = self.vertices[i], self.vertices[i + 1]
        a, b = (v.s, v.z), (w.s, w.z)
        if v.tipo == RECTA or not v.control:
            return [a, b]
        if v.tipo == ARCO:
            return _muestras_arco(a, tuple(v.control[0]), b, n)
        if v.tipo == BEZIER:
            c = list(v.control) + [b, b]
            return _muestras_bezier(a, tuple(c[0]), tuple(c[1]), b, n)
        return _muestras_nurbs(self._control_completo(i), v.pesos, n)

    def muestrear(self, paso: float = 5.0) -> List[Punto]:
        """Polilinea de la rasante con el paso pedido, extremos incluidos."""
        salida: List[Punto] = []
        for pieza in self.piezas():
            for p in pieza.muestrear(paso):
                if salida and abs(p[0] - salida[-1][0]) < 1e-9:
                    salida[-1] = p
                else:
                    salida.append(p)
        return salida

    def z_en(self, s: float) -> Optional[float]:
        """Cota de la rasante en esa abscisa, o ``None`` fuera de ella."""
        if self.vacia:
            return None
        if s < self.s_ini - 1e-6 or s > self.s_fin + 1e-6:
            return None
        piezas = self.piezas()
        for pieza in piezas:
            if pieza.s_ini - 1e-9 <= s <= pieza.s_fin + 1e-9:
                return pieza.evaluar(s)
        # Entre piezas por redondeo: se coge la mas cercana.
        pieza = min(piezas, key=lambda pz: min(abs(s - pz.s_ini), abs(s - pz.s_fin)))
        return pieza.evaluar(min(max(s, pieza.s_ini), pieza.s_fin))

    def cotas_en(self, abscisas: Sequence[float]) -> List[Optional[float]]:
        """Cota en cada abscisa, reutilizando la descomposicion una sola vez."""
        if self.vacia:
            return [None] * len(abscisas)
        piezas = self.piezas()
        salida: List[Optional[float]] = []
        for s in abscisas:
            if s < self.s_ini - 1e-6 or s > self.s_fin + 1e-6:
                salida.append(None)
                continue
            for pieza in piezas:
                if pieza.s_ini - 1e-9 <= s <= pieza.s_fin + 1e-9:
                    salida.append(pieza.evaluar(s))
                    break
            else:
                pieza = min(
                    piezas, key=lambda pz: min(abs(s - pz.s_ini), abs(s - pz.s_fin))
                )
                salida.append(pieza.evaluar(min(max(s, pieza.s_ini), pieza.s_fin)))
        return salida

    # -- revision ----------------------------------------------------------
    def avisos(self, pendiente_max: float = 0.12) -> List[str]:
        """Lo que un proyectista querria que le dijesen antes de aplicarla."""
        if self.vacia:
            return [t("The grade line needs at least two vertices.")]
        avisos: List[str] = []
        for i in range(len(self.vertices) - 1):
            avisos += self._avisos_segmento(i, pendiente_max)
        for i in range(1, len(self.vertices) - 1):
            aviso = self._aviso_acuerdo(i)
            if aviso:
                avisos.append(aviso)
        return avisos

    def _avisos_segmento(self, i: int, pendiente_max: float) -> List[str]:
        """Revisa el segmento ``i``: abscisa, pendiente y forma de la curva."""
        v, w = self.vertices[i], self.vertices[i + 1]
        if w.s <= v.s + 1e-9:
            return [
                t(
                    "vertex {n}: abscissa {a:.2f} is not greater than the "
                    "previous one ({b:.2f})",
                    n=i + 2,
                    a=w.s,
                    b=v.s,
                )
            ]
        avisos: List[str] = []
        m = abs(self.pendiente(i))
        if m > pendiente_max:
            avisos.append(
                t(
                    "segment {n}: grade {m:.1f} %, above the maximum of "
                    "{max:.0f} %",
                    n=i + 1,
                    m=m * 100,
                    max=pendiente_max * 100,
                )
            )
        if v.tipo != RECTA and self._vuelve_sobre_si_misma(i):
            avisos.append(
                t(
                    "segment {n} ({tipo}): the curve folds back on itself; "
                    "only the increasing-abscissa part is drawn",
                    n=i + 1,
                    tipo=t(NOMBRES.get(v.tipo, v.tipo)),
                )
            )
        return avisos

    def _vuelve_sobre_si_misma(self, i: int) -> bool:
        """True si el segmento curvo deja de ser funcion de la abscisa."""
        muestras = self.muestras_segmento(i)
        return any(
            b[0] <= a[0] - 1e-9 for a, b in zip(muestras, muestras[1:])
        )

    def _aviso_acuerdo(self, i: int) -> str:
        """Aviso del acuerdo del vertice ``i``, o cadena vacia si no hay nada."""
        v = self.vertices[i]
        if v.acuerdo <= 0.0:
            return ""
        util = self._acuerdo_util(i)
        if util <= 0.0:
            if self.vertices[i - 1].tipo != RECTA or v.tipo != RECTA:
                return (
                    f"vertice {i + 1}: el acuerdo se ignora porque alguno de sus "
                    "lados no es una recta"
                )
            return (
                f"vertice {i + 1}: el acuerdo se ignora porque no hay cambio de "
                "pendiente"
            )
        if util < v.acuerdo - 1e-6:
            return (
                f"vertice {i + 1}: el acuerdo de {v.acuerdo:.0f} m no cabe entre "
                f"sus vertices; se usa {util:.0f} m"
            )
        return ""

    def resumen(self) -> str:
        if self.vacia:
            return t("grade line not defined")
        pendientes = [abs(self.pendiente(i)) for i in range(len(self.vertices) - 1)]
        acuerdos = sum(1 for v in self.vertices if v.acuerdo > 0.0)
        curvos = sum(
            1 for v in self.vertices[:-1] if v.tipo != RECTA
        )
        trozos = [
            t("{n} vertices", n=len(self.vertices)),
            f"{self.s_fin - self.s_ini:.0f} m",
            t("max grade {m:.1f} %", m=max(pendientes) * 100),
        ]
        if acuerdos:
            trozos.append(t("{n} vertical curve(s)", n=acuerdos))
        if curvos:
            trozos.append(t("{n} curved segment(s)", n=curvos))
        return ", ".join(trozos)

    # -- serializacion -----------------------------------------------------
    def a_dict(self) -> dict:
        return {"vertices": [v.a_dict() for v in self.vertices]}

    @staticmethod
    def de_dict(d: dict) -> "Rasante":
        return Rasante([Vertice.de_dict(v) for v in (d or {}).get("vertices", [])])


__all__ = [
    "ARCO",
    "simplificar",
    "BEZIER",
    "CONTROLES",
    "NOMBRES",
    "NURBS",
    "RECTA",
    "TIPOS",
    "Pieza",
    "Rasante",
    "Vertice",
]
