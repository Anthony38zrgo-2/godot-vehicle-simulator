"""Resolucion de una seccion tipo contra el terreno.

Modulo puro: solo necesita una funcion ``tz(x, y) -> cota | None``. Por eso se
puede testear sin QGIS y sin ningun raster.

El algoritmo por rama es:

1. Resolver el bloque ``fijos`` (aritmetica pura, sin tocar el terreno).
2. En el ultimo punto (el *punto de enganche*) comparar la cota del terreno:
   si el terreno esta por encima -> ``desmonte``; si esta por debajo ->
   ``terraplen``. Cada lado decide por separado, asi que una seccion a media
   ladera sale bien sin configurar nada.
3. Resolver el bloque condicional elegido. En cuanto un elemento alcanza el
   terreno se para: lo que venga detras se ignora.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Optional

from .elements import (
    GRUPO_DESMONTE,
    GRUPO_FIJOS,
    GRUPO_TERRAPLEN,
    KIND_DAYLIGHT,
    KIND_TRUNCADO,
    STATUS_CUT,
    STATUS_NODATA,
    SUF_DAY,
    ResolveContext,
    Vertex,
    seek_terrain,
)
from .params import ParamError
from .schema import Assembly, codigo_del_eje, prefijo_de_lado

MODO_DESMONTE = GRUPO_DESMONTE
MODO_TERRAPLEN = GRUPO_TERRAPLEN
MODO_NINGUNO = "sin_rama"


@dataclass
class SectionOptions:
    """Ajustes numericos de la resolucion."""

    paso: float = 0.5  #: paso de muestreo del DEM al buscar el corte (m)
    ancho_max: float = 200.0  #: semiancho maximo de busqueda desde el eje (m)
    tol: float = 1.0e-4  #: tolerancia de cierre en cota (m)
    #: Muestras de la linea de terreno que se guardan con la seccion. Con ellas
    #: la seccion es autosuficiente: se puede dibujar y medir sin volver a tocar
    #: el DEM. Con 0 no se guarda nada.
    muestras_terreno: int = 60
    #: Margen a cada lado al muestrear el terreno, como fraccion del ancho de la
    #: seccion, para que el dibujo no acabe justo en el ultimo vertice.
    margen_terreno: float = 0.08


@dataclass
class Station:
    """Un PK de la directriz con su normal a la derecha (unitaria).

    ``z`` es la cota de la propia directriz, si la geometria es 3D. Sirve para
    usar la directriz como rasante en vez de apoyar el eje en el terreno.
    ``offset_critico`` es la distancia al eje a la que esta seccion se cruza con
    la contigua por el interior de la curva (``inf`` si no se cruzan).
    """

    s: float
    x: float
    y: float
    nx: float
    ny: float
    fid: int = -1
    part: int = 0
    es_vertice: bool = False
    z: Optional[float] = None
    offset_critico: float = float("inf")

    def point_at(self, offset: float) -> tuple:
        return (self.x + self.nx * offset, self.y + self.ny * offset)


@dataclass
class Section:
    """Seccion resuelta: vertices ordenados de izquierda a derecha."""

    station: Station
    z_eje: float
    vertices: list = field(default_factory=list)
    modo_izq: str = MODO_NINGUNO
    modo_der: str = MODO_NINGUNO
    ok: bool = True
    warnings: list = field(default_factory=list)
    #: Linea de terreno de esta seccion, ``[(offset, z)]``. Con ella la seccion
    #: se puede dibujar y medir sin tener el DEM abierto.
    terreno: list = field(default_factory=list)
    #: Cota del terreno en el eje. Es la que se enfrenta a la rasante en el
    #: perfil longitudinal.
    z_terreno: Optional[float] = None

    # -- geometria --------------------------------------------------------
    @property
    def x0(self) -> float:
        return self.station.x

    @property
    def y0(self) -> float:
        return self.station.y

    @property
    def perfil(self) -> list:
        """La linea de proyecto como perfil ``[(offset, z)]``."""
        return [(v.offset, v.z) for v in self.vertices]

    @property
    def cota_roja(self) -> Optional[float]:
        """Rasante menos terreno en el eje. Negativa en desmonte."""
        if self.z_terreno is None or not math.isfinite(self.z_eje):
            return None
        return self.z_eje - self.z_terreno

    def areas(self) -> tuple:
        """``(area_desmonte, area_terraplen)`` de esta seccion, en m2."""
        from .perfil import areas as _areas

        if not self.terreno or len(self.vertices) < 2:
            return 0.0, 0.0
        return _areas(self.perfil, self.terreno)

    def world(self, v: Vertex) -> tuple:
        """Pasa un vertice de coordenadas de seccion a coordenadas del mundo."""
        st = self.station
        return (st.x + st.nx * v.offset, st.y + st.ny * v.offset, v.z)

    def world_points(self) -> list:
        return [self.world(v) for v in self.vertices]

    def codes(self) -> list:
        return [v.code for v in self.vertices]

    def vertex_by_code(self, code: str) -> Optional[Vertex]:
        for v in self.vertices:
            if v.code == code:
                return v
        return None

    @property
    def ancho_izq(self) -> float:
        return -min((v.offset for v in self.vertices), default=0.0)

    @property
    def ancho_der(self) -> float:
        return max((v.offset for v in self.vertices), default=0.0)


# --------------------------------------------------------------------------


def _code_day(elementos: list, prefijo: str) -> str:
    """Codigo del vertice de daylight del grupo: el del ultimo buscador.

    Con varios taludes en cadena, el terreno lo puede cortar cualquiera de
    ellos segun el PK. Si cada uno pusiera su propio codigo, la linea de
    daylight saldria partida en trozos y el cosido del TIN perderia el ancla.
    Con un codigo unico por grupo la linea es una sola, continua.
    """
    for el in reversed(elementos):
        if el.definicion().busca_terreno:
            return prefijo + el.codigo + SUF_DAY
    return ""


def _recortar_en_terreno(cur: Vertex, nuevos: list, ctx: ResolveContext) -> list:
    """Corta la cadena de vertices en el primer cruce con el terreno.

    Los elementos que no buscan terreno son ciegos: dibujan su forma desde donde
    acabo el anterior sin mirar el suelo. Eso esta bien delante del primer talud
    -ahi son continuacion de la plataforma-, pero dentro de la cadena que va a
    buscar el terreno no: una banqueta de 15 m entre dos taludes puede atravesar
    el terreno y nadie se enteraria. Aqui se recorre lo que ha producido el
    elemento y se corta en el primer cruce.

    Si no hay cruce se devuelven sus vertices **intactos**: en particular no se
    recorta por el ancho maximo, que es solo el limite de busqueda.
    """
    salida: list = []
    v0 = cur
    for v in nuevos:
        hit, status = seek_terrain(
            v0, v.offset - v0.offset, v.z - v0.z, ctx, ctx.code_day
        )
        if status == STATUS_CUT:
            salida.append(hit)
            return salida
        if status == STATUS_NODATA:
            # Sin datos del terreno no se decide nada. Cerrar la superficie no
            # es cosa de este elemento, asi que se deja como estaba y sera el
            # talud de detras el que avise.
            return nuevos
        salida.append(v)
        v0 = v
    return salida


def _resolve_grupo(
    elementos: list,
    cur: Vertex,
    ctx: ResolveContext,
    prefijo: str,
    out: list,
) -> Vertex:
    """Encadena los elementos de un grupo. Devuelve el ultimo vertice."""
    ctx.code_day = _code_day(elementos, prefijo)
    ultimo = len(elementos) - 1
    buscadores = 0
    for i, el in enumerate(elementos):
        d = el.definicion()
        code = prefijo + el.codigo
        ctx.ultimo = i == ultimo
        if d.busca_terreno:
            buscadores += 1
        ctx.buscador_n = buscadores
        try:
            nuevos = d.resolver(cur, el.params, code, ctx)
        except ParamError as exc:
            ctx.fail(f"{el.codigo}: {exc}")
            return cur
        if nuevos and not d.busca_terreno and buscadores:
            # Va dentro de la cadena que busca el terreno: tambien se para en el.
            nuevos = _recortar_en_terreno(cur, nuevos, ctx)
        for v in nuevos:
            out.append(v)
            cur = v
        if nuevos and nuevos[-1].kind in (KIND_DAYLIGHT, KIND_TRUNCADO):
            break  # alcanzado el terreno: el resto del grupo no aplica
    return cur


def _resolve_branch(
    asm: Assembly,
    side: int,
    z_eje: float,
    tz_offset: Callable[[float], Optional[float]],
    opts: SectionOptions,
) -> tuple:
    """Resuelve una rama. Devuelve ``(vertices, modo, warnings, ok)``."""
    rama = asm.branch(side)
    prefijo = prefijo_de_lado(side)
    ctx = ResolveContext(
        side=side,
        mode=GRUPO_FIJOS,
        tz=tz_offset,
        step=opts.paso,
        max_width=opts.ancho_max,
        tol=opts.tol,
    )
    vertices: list = []
    cur = Vertex(0.0, z_eje, codigo_del_eje())
    cur = _resolve_grupo(rama.fijos, cur, ctx, prefijo, vertices)

    modo = MODO_NINGUNO
    if vertices and vertices[-1].kind in (KIND_DAYLIGHT, KIND_TRUNCADO):
        return vertices, modo, ctx.warnings, not ctx.failed

    # --- eleccion de rama condicional en el punto de enganche ---
    z_terreno = tz_offset(cur.offset)
    if z_terreno is None:
        ctx.fail(
            f"el terreno no tiene datos en el punto de enganche "
            f"(offset {cur.offset:.2f})"
        )
        return vertices, modo, ctx.warnings, False
    modo = MODO_DESMONTE if (cur.z - z_terreno) < 0.0 else MODO_TERRAPLEN
    ctx.mode = modo
    condicional = rama.grupo(modo)
    if condicional:
        _resolve_grupo(condicional, cur, ctx, prefijo, vertices)
    return vertices, modo, ctx.warnings, not ctx.failed


def resolve_section(
    asm: Assembly,
    station: Station,
    tz: Callable[[float, float], Optional[float]],
    opts: Optional[SectionOptions] = None,
    z_eje: Optional[float] = None,
    offset_terreno: float = 0.0,
) -> Section:
    """Resuelve la seccion ``asm`` en el PK ``station``.

    ``asm`` debe venir ya materializada (parametros numericos). ``tz`` devuelve
    la cota del terreno en coordenadas del mundo.

    ``z_eje`` permite imponer la cota del eje. Si es ``None`` se toma del terreno,
    y entonces ``offset_terreno`` se suma a esa cota: es lo que permite una
    rasante paralela al terreno a una distancia dada, por encima o por debajo. El
    ``desnivel`` de la seccion se suma en los dos casos.
    """
    opts = opts or SectionOptions()
    desplazamiento = float(asm.eje.get("desplazamiento", 0.0) or 0.0)
    desnivel = float(asm.eje.get("desnivel", 0.0) or 0.0)

    # El desplazamiento mueve el origen de offsets a lo largo de la normal.
    if desplazamiento:
        ox, oy = station.point_at(desplazamiento)
        station = Station(
            station.s, ox, oy, station.nx, station.ny,
            station.fid, station.part, station.es_vertice,
            station.z, station.offset_critico,
        )

    def tz_offset(offset: float) -> Optional[float]:
        x, y = station.point_at(offset)
        return tz(x, y)

    warnings: list = []
    # La cota del terreno en el eje se necesita siempre: es la que se enfrenta a
    # la rasante en el perfil longitudinal, tambien cuando la rasante viene dada.
    z_terreno = tz_offset(0.0)
    if z_eje is None:
        if z_terreno is None:
            return Section(
                station=station,
                z_eje=float("nan"),
                vertices=[],
                ok=False,
                warnings=["el terreno no tiene datos en el eje (NoData)"],
            )
        z_eje = z_terreno + desnivel + offset_terreno
    else:
        z_eje = z_eje + desnivel

    izq, modo_izq, w_izq, ok_izq = _resolve_branch(asm, -1, z_eje, tz_offset, opts)
    der, modo_der, w_der, ok_der = _resolve_branch(asm, 1, z_eje, tz_offset, opts)
    warnings.extend(w_izq)
    warnings.extend(w_der)

    vertices = list(reversed(izq)) + [Vertex(0.0, z_eje, codigo_del_eje())] + der
    vertices = _dedupe(vertices, opts.tol)

    return Section(
        station=station,
        z_eje=z_eje,
        vertices=vertices,
        modo_izq=modo_izq,
        modo_der=modo_der,
        ok=bool(ok_izq and ok_der),
        warnings=warnings,
        terreno=_muestrear_terreno(vertices, tz_offset, opts),
        z_terreno=z_terreno,
    )


def _muestrear_terreno(vertices: list, tz_offset, opts: SectionOptions) -> list:
    """Linea de terreno de la seccion, ``[(offset, z)]``.

    Se muestrea a paso constante en el ancho de la seccion mas un margen. Los
    puntos en NoData se saltan, asi que la linea puede tener huecos; el resto de
    la maquinaria (dibujo y medicion) trabaja con lo que haya.
    """
    if opts.muestras_terreno <= 1 or len(vertices) < 2:
        return []
    o0 = min(v.offset for v in vertices)
    o1 = max(v.offset for v in vertices)
    if o1 - o0 < 1e-9:
        return []
    margen = max(0.5, opts.margen_terreno * (o1 - o0))
    o0 -= margen
    o1 += margen
    n = int(opts.muestras_terreno)
    salida = []
    for i in range(n + 1):
        o = o0 + (o1 - o0) * i / n
        z = tz_offset(o)
        if z is not None:
            salida.append((o, z))
    return salida


def _dedupe(vertices: list, tol: float) -> list:
    """Quita vertices consecutivos coincidentes (elementos de ancho/altura 0)."""
    out: list = []
    for v in vertices:
        if out:
            p = out[-1]
            if abs(p.offset - v.offset) < 1e-9 and abs(p.z - v.z) < tol:
                # Nos quedamos con el que aporta informacion (daylight manda).
                if v.kind != "punto" and p.kind == "punto":
                    out[-1] = v
                continue
        out.append(v)
    return out


# --------------------------------------------------------------------------
# Terreno sintetico: usado por la previsualizacion del editor y por los tests
# --------------------------------------------------------------------------


def plane_terrain(
    z_ref: float,
    pendiente_pct: float,
    nx: float = 0.0,
    ny: float = 1.0,
    x0: float = 0.0,
    y0: float = 0.0,
) -> Callable[[float, float], float]:
    """Terreno plano inclinado, para previsualizar sin DEM.

    ``pendiente_pct`` es la pendiente transversal en % en la direccion
    ``(nx, ny)`` medida desde ``(x0, y0)``, donde la cota vale ``z_ref``.
    """
    m = pendiente_pct / 100.0

    def tz(x: float, y: float) -> float:
        d = (x - x0) * nx + (y - y0) * ny
        return z_ref + m * d

    return tz


def cone_terrain(z_ref: float, pendiente_pct: float, x0=0.0, y0=0.0):
    """Terreno conico (utilidad para tests)."""
    m = pendiente_pct / 100.0

    def tz(x: float, y: float) -> float:
        return z_ref + m * math.hypot(x - x0, y - y0)

    return tz
