"""Nombre visible de las claves internas del modelo.

Hay valores que viajan al JSON de la sesion, a los atributos de las capas y a la
libreria de secciones: ``desmonte``, ``terraplen``, ``recta``, ``arco``... Esos
**no** se traducen nunca, porque son la clave con la que se vuelve a leer lo
guardado. Lo que se traduce es como se escriben en pantalla, y eso es lo que hay
aqui: un diccionario de clave interna a texto en ingles, que luego pasa por
``t()`` como cualquier otra cadena.

Asi el archivo guardado en una sesion en castellano se abre igual en una sesion
en ingles, que es lo que se espera de un proyecto que se pasa entre equipos.
"""

from __future__ import annotations

from .i18n import t

#: Modo de una rama de la seccion (``resolver.MODO_*``).
MODOS = {
    "desmonte": "cut",
    "terraplen": "fill",
    "sin_rama": "no branch",
}

#: Grupo al que pertenece un elemento dentro de una rama.
GRUPOS = {
    "fijo": "fixed",
    "desmonte": "cut",
    "terraplen": "fill",
}

#: Lado de la seccion.
LADOS = {
    "izquierda": "left",
    "derecha": "right",
}

#: Zona de un triangulo del TIN (``outputs.ZONA_*``).
ZONAS = {
    "desmonte": "cut",
    "terraplen": "fill",
    "cota": "at grade",
    "terreno": "natural ground",
}

#: Tipo de segmento de la rasante (``rasante_geom.RECTA`` y companeros) y
#: herramientas del editor que se llaman igual.
SEGMENTOS = {
    "recta": "straight",
    "arco": "arc",
    "bezier": "Bezier",
    "nurbs": "NURBS",
    "mover": "move",
    "insertar": "insert",
    "borrar": "delete",
    "control": "control point",
}

#: Valores de los parametros de tipo ``choice`` de los elementos. Se guardan en
#: la libreria de secciones tal cual, asi que solo se traduce como se leen.
OPCIONES = {
    "desnivel": "height difference",
    "cota": "elevation",
    "horizontal": "horizontal",
}

#: De donde sale la cota del eje (``build.COTA_*``).
ORIGENES_COTA = {
    "terreno": "terrain",
    "directriz": "alignment Z",
    "constante": "constant",
    "offset_terreno": "offset from terrain",
}


def _de(tabla: dict, clave: str) -> str:
    """Texto visible de la clave, o la clave misma si no esta en la tabla."""
    return t(tabla.get(clave, clave))


def modo(clave: str) -> str:
    return _de(MODOS, clave)


def grupo(clave: str) -> str:
    return _de(GRUPOS, clave)


def lado(clave: str) -> str:
    return _de(LADOS, clave)


def zona(clave: str) -> str:
    return _de(ZONAS, clave)


def origen_cota(clave: str) -> str:
    return _de(ORIGENES_COTA, clave)


def opcion(clave: str) -> str:
    return _de(OPCIONES, clave)


def segmento(clave: str) -> str:
    return _de(SEGMENTOS, clave)


__all__ = [
    "MODOS",
    "GRUPOS",
    "LADOS",
    "ZONAS",
    "SEGMENTOS",
    "OPCIONES",
    "ORIGENES_COTA",
    "modo",
    "grupo",
    "lado",
    "zona",
    "segmento",
    "opcion",
    "origen_cota",
]
