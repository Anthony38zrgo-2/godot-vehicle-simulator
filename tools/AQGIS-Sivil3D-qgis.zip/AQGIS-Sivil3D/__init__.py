"""Plugin de QGIS: extrusion de secciones tipo sobre terreno (corredor).

AQGIS-Sivil3D
Copyright (C) 2026 Rafael Vazquez. Escrito con Claude (Anthropic).

Este programa es software libre: se puede redistribuir y/o modificar bajo los
terminos de la Licencia Publica General GNU publicada por la Free Software
Foundation, en su version 3 o cualquier posterior. Se distribuye SIN NINGUNA
GARANTIA. Vease el archivo LICENSE que acompana al plugin, o
<https://www.gnu.org/licenses/>.

Organizacion del codigo
-----------------------
``core``       calculo puro, sin QGIS: seccion tipo, resolucion contra terreno,
               mallado y fusion. Se puede testear con python a secas.
``gis``        integracion con QGIS: muestreo del DEM, PKs de la directriz,
               evaluacion de expresiones y capas de salida.
``processing`` proveedor y algoritmo de Processing.
``ui``         editor de secciones y dialogo del corredor.
"""


def classFactory(iface):  # noqa: N802  (nombre impuesto por QGIS)
    from .plugin import CorridorPlugin

    return CorridorPlugin(iface)


__all__ = ["classFactory"]
