"""Editor de rasantes: el perfil longitudinal en modo digitalizacion.

Es el panel que faltaba para proyectar en alzado. Se elige la directriz y el DEM,
se arranca la rasante del terreno (o de la Z que ya tenga la capa), y a partir de
ahi se dibuja con las mismas herramientas que se usan en planta: **recta, arco,
Bezier y NURBS** por segmento, mas el **acuerdo vertical** de cada vertice, que es
lo propio del alzado y no tiene equivalente en planta.

Mientras se edita:

* la vista muestra terreno, rasante, desmonte y terraplen, pendientes, cotas y
  los K de los acuerdos;
* el mapa marca en **planta** el punto de la directriz donde esta el raton y el
  vertice seleccionado, para no perder de vista de que parte del trazado se esta
  hablando;
* la tabla permite meter los numeros a mano, que es como se ajusta una rasante de
  verdad cuando ya esta casi.

Al terminar, «Aplicar a la Z de la capa» escribe la rasante en la geometria de la
directriz, densificando lo que haga falta para que los acuerdos y las curvas no se
pierdan. Desde ahi el corredor ya se puede calcular con *cota del eje = Z de la
directriz*.
"""

from __future__ import annotations

from typing import List

from qgis.core import (
    QgsMapLayerProxyModel,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox, QgsRubberBand, QgsVertexMarker
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDockWidget,
    QDoubleSpinBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..core.rasante_geom import NOMBRES, RECTA, TIPOS, Rasante
from ..etiquetas import segmento as etiqueta_segmento
from ..gis.outputs import ORDEN_CAPAS, clave_de_etiqueta
from ..i18n import t
from ..gis.alignment import StationOptions, alignments_from_feature
from ..gis.rasante import (
    aplicar_rasante,
    perfil_del_terreno,
    punto_en,
    rasante_de_geometria,
)
from ..gis.terrain import make_terrain
from .ayuda_dialog import abrir_ayuda_en
from .qtcompat import (
    BOTON_SI,
    SIN_MARCO,
    FORMA_LINEA_VERTICAL,
    ITEM_EDITABLE,
    ROL_USUARIO,
    SEL_SIMPLE,
)
from .rasante_view import (
    ACCIONES,
    H_ARCO,
    H_BEZIER,
    H_BORRAR,
    H_CONTROL,
    H_INSERTAR,
    H_MOVER,
    H_NURBS,
    H_RECTA,
    MODOS,
    PISTAS,
    pista,
    RasanteView,
)

#: Herramientas de la barra: ``(clave, rotulo, tooltip)``.
#:
#: Las tres primeras son **modos** (se quedan activas). Las demas son **acciones
#: de un solo uso**: se aplican al segmento seleccionado, o al que se pinche, y
#: el mando vuelve a Mover para poder arrastrar los tiradores enseguida.
#: ``(clave, rotulo, ayuda)``. Los textos van en ingles y se traducen al
#: construir los botones.
BOTONES = (
    (H_MOVER, "Move", "Select and drag vertices and handles"),
    (H_INSERTAR, "Insert", "Click to put in a new vertex"),
    (H_BORRAR, "Delete", "Click a vertex to remove it (or the Del key)"),
    (
        H_RECTA,
        "Straight",
        "Leaves the selected segment straight (or the next one clicked)",
    ),
    (
        H_ARCO,
        "Arc",
        "Turns the segment into a circular arc passing through its handle",
    ),
    (
        H_BEZIER,
        "Bezier",
        "Turns the segment into a cubic Bezier (2 handles)",
    ),
    (
        H_NURBS,
        "NURBS",
        "Turns the segment into a rational B-spline over its control points",
    ),
    (H_CONTROL, "+ control", "Adds a control point to the NURBS"),
)

#: Nombres, en los dos idiomas, de las capas de dibujo de los planos: no
#: son directrices aunque sean lineas.
HOJAS_DE_PLANTA = ("hojas de planta", "plan sheets")

COL_MAPA = QColor(20, 90, 190)
#: Cabeceras de la tabla de vertices, en ingles. Se traducen al pintarlas.
COLUMNAS = ("Sta", "Elevation", "Segment", "Curve L", "K", "Slope %")


def _r() -> str:
    """Titulo de los avisos del editor."""
    return t("Grade line")


class RasanteEditor(QDockWidget):
    """Panel acoplable para proyectar la rasante de una directriz."""

    def __init__(self, iface, parent=None):
        super().__init__(t("Vertical alignment editor"), parent)
        self.iface = iface
        self.setObjectName("AqgisSivil3DRasante")
        self._terreno = None
        self._alineaciones: List = []
        self._pts: List = []
        self._banda = None
        self._marca = None
        self._actualizando = False

        # La vista se crea antes que los controles: la cabecera y la barra se
        # conectan a ella.
        self.vista = RasanteView()
        self.vista.cambiada.connect(self._rasante_cambiada)
        self.vista.seleccion_cambiada.connect(self._seleccion_cambiada)
        self.vista.posicion.connect(self._raton_en)
        self.vista.herramienta_cambiada.connect(self._herramienta_cambiada)

        raiz = QWidget()
        lay = QVBoxLayout(raiz)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)
        lay.addLayout(self._cabecera())
        lay.addLayout(self._barra())
        self.lbl_pista = QLabel()
        self.lbl_pista.setWordWrap(True)
        self.lbl_pista.setStyleSheet("color:#666; padding:1px 2px;")
        lay.addWidget(self.lbl_pista)

        cuerpo = QHBoxLayout()
        cuerpo.addWidget(self.vista, 3)
        cuerpo.addWidget(self._panel_tabla(), 1)
        lay.addLayout(cuerpo, 1)

        lay.addLayout(self._pie())
        self.lbl_estado = QLabel(t("Choose the alignment and the DEM."))
        self.lbl_estado.setWordWrap(True)
        lay.addWidget(self.lbl_estado)
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(SIN_MARCO)
        area.setWidget(raiz)
        area.setMinimumWidth(240)
        self.setWidget(area)

        self.cmb_capa.layerChanged.connect(self._capa_cambiada)
        self.cmb_dem.layerChanged.connect(self._dem_cambiado)
        # Los combos llegan con una capa ya elegida (la primera que encaje), y en
        # ese caso no hay senal que esperar: hay que arrancar del estado actual.
        # La capa de partida se elige a mano: el combo se queda con la primera
        # que encaja, y esa puede ser una salida del propio corredor.
        de_partida = self._capa_de_partida()
        if de_partida is not None:
            self.cmb_capa.setLayer(de_partida)
        self._dem_cambiado()
        self._capa_cambiada()
        self._pista(pista(H_MOVER))

    # -- construccion ------------------------------------------------------
    def _cabecera(self) -> QHBoxLayout:
        fila = QHBoxLayout()
        fila.setSpacing(4)
        self.cmb_capa = QgsMapLayerComboBox()
        self.cmb_capa.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.cmb_capa.setMinimumWidth(140)
        self.cmb_capa.setToolTip(
            t(
                "Line layer the grade line is designed on. On opening, the "
                "active layer is chosen, or the first one that is not an "
                "output of the corridor itself."
            )
        )
        self.cmb_tramo = QComboBox()
        self.cmb_tramo.setMinimumWidth(90)
        self.cmb_tramo.currentIndexChanged.connect(self._tramo_cambiado)
        self.cmb_dem = QgsMapLayerComboBox()
        self.cmb_dem.setFilters(
            QgsMapLayerProxyModel.RasterLayer | QgsMapLayerProxyModel.MeshLayer
        )
        self.cmb_dem.setAllowEmptyLayer(True)
        self.cmb_dem.setMinimumWidth(120)
        for rotulo, widget in (
            (t("Alignment"), self.cmb_capa),
            (t("Run"), self.cmb_tramo),
            (t("DEM"), self.cmb_dem),
        ):
            fila.addWidget(QLabel(rotulo))
            fila.addWidget(widget)
        self.sp_exag = QDoubleSpinBox()
        self.sp_exag.setRange(1.0, 50.0)
        self.sp_exag.setValue(5.0)
        self.sp_exag.setPrefix("x")
        self.sp_exag.setToolTip(t("Vertical exaggeration of the view"))
        self.sp_exag.valueChanged.connect(self._exageracion)
        fila.addWidget(QLabel(t("exag.")))
        fila.addWidget(self.sp_exag)
        btn = QToolButton()
        btn.setText(t("Fit"))
        btn.setToolTip(t("Fit the view again"))
        btn.clicked.connect(self.vista.encajar)
        fila.addWidget(btn)
        ayuda = QToolButton()
        ayuda.setText("?")
        ayuda.setToolTip(t("Help for the vertical alignment editor"))
        ayuda.clicked.connect(lambda: abrir_ayuda_en("rasante", self))
        fila.addWidget(ayuda)
        fila.addStretch(1)
        return fila

    def _barra(self) -> QHBoxLayout:
        fila = QHBoxLayout()
        fila.setSpacing(2)
        self.botones = {}
        for clave, rotulo, tip in BOTONES:
            if clave == BOTONES[3][0]:
                # Separador: a la izquierda los modos, a la derecha las acciones.
                raya = QFrame()
                raya.setFrameShape(FORMA_LINEA_VERTICAL)
                fila.addSpacing(6)
                fila.addWidget(raya)
                fila.addSpacing(6)
                fila.addWidget(QLabel("segmento:"))
            b = QToolButton()
            b.setText(rotulo)
            b.setToolTip(tip)
            # Solo los modos se quedan pulsados; las acciones son de un solo uso.
            b.setCheckable(clave in MODOS)
            b.clicked.connect(lambda _c=False, k=clave: self.set_herramienta(k))
            self.botones[clave] = b
            fila.addWidget(b)
        self.botones[H_MOVER].setChecked(True)
        fila.addSpacing(10)

        raya2 = QFrame()
        raya2.setFrameShape(FORMA_LINEA_VERTICAL)
        fila.addWidget(raya2)
        fila.addSpacing(6)
        fila.addWidget(QLabel(t("vertices:")))
        for rotulo, tip, slot in (
            (t("All"), t("Select every vertex (Ctrl+A)"),
             lambda: self.vista.seleccionar_todos()),
            (t("None"), t("Clear the selection (Esc)"),
             lambda: self.vista.limpiar_seleccion()),
            (t("Simplify") + "…", t("Remove the vertices that are not needed"),
             self.simplificar),
        ):
            b = QToolButton()
            b.setText(rotulo)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            fila.addWidget(b)
        fila.addSpacing(10)

        self.chk_terreno = QCheckBox(t("snap to the terrain"))
        self.chk_terreno.setToolTip(
            t("Vertices stick to the terrain when moved: handy to start.")
        )
        self.chk_terreno.toggled.connect(self._ajustes)
        fila.addWidget(self.chk_terreno)
        self.sp_paso_s = QDoubleSpinBox()
        self.sp_paso_s.setRange(0.0, 500.0)
        self.sp_paso_s.setValue(0.0)
        self.sp_paso_s.setSuffix(" m " + t("Sta"))
        self.sp_paso_s.setToolTip(
            t("Snap the abscissa to multiples of this value")
        )
        self.sp_paso_s.valueChanged.connect(self._ajustes)
        fila.addWidget(self.sp_paso_s)
        self.sp_paso_z = QDoubleSpinBox()
        self.sp_paso_z.setRange(0.0, 100.0)
        self.sp_paso_z.setDecimals(2)
        self.sp_paso_z.setValue(0.0)
        self.sp_paso_z.setSuffix(" m " + t("elevation"))
        self.sp_paso_z.setToolTip(
            t("Snap the elevation to multiples of this value")
        )
        self.sp_paso_z.valueChanged.connect(self._ajustes)
        fila.addWidget(self.sp_paso_z)
        fila.addStretch(1)
        return fila

    def _panel_tabla(self) -> QWidget:
        caja = QWidget()
        lay = QVBoxLayout(caja)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        self.tabla = QTableWidget(0, len(COLUMNAS))
        self.tabla.setHorizontalHeaderLabels([t(c) for c in COLUMNAS])
        self.tabla.setSelectionMode(SEL_SIMPLE)
        self.tabla.verticalHeader().setVisible(False)
        self.tabla.setMinimumWidth(300)
        self.tabla.itemChanged.connect(self._celda_editada)
        self.tabla.currentCellChanged.connect(self._fila_elegida)
        lay.addWidget(self.tabla, 1)

        fila = QHBoxLayout()
        fila.setSpacing(3)
        self.cmb_tipo = QComboBox()
        for tipo in TIPOS:
            self.cmb_tipo.addItem(t(NOMBRES[tipo]), tipo)
        self.cmb_tipo.setToolTip(
            t("Type of the segment leaving the selected vertex")
        )
        self.cmb_tipo.currentIndexChanged.connect(self._tipo_elegido)
        fila.addWidget(QLabel(t("Segment")))
        fila.addWidget(self.cmb_tipo, 1)
        lay.addLayout(fila)

        fila = QHBoxLayout()
        fila.setSpacing(3)
        self.sp_k = QDoubleSpinBox()
        self.sp_k.setRange(0.0, 100000.0)
        self.sp_k.setDecimals(1)
        self.sp_k.setToolTip(
            t(
                "K of the vertical curve at the selected vertex: metres of "
                "curve per 1 % of grade change"
            )
        )
        boton_k = QPushButton(t("Apply K"))
        boton_k.clicked.connect(self._aplicar_k)
        fila.addWidget(QLabel("K"))
        fila.addWidget(self.sp_k, 1)
        fila.addWidget(boton_k)
        lay.addLayout(fila)
        return caja

    def _pie(self) -> QHBoxLayout:
        fila = QHBoxLayout()
        fila.setSpacing(4)
        for rotulo, tip, slot in (
            (
                t("From the terrain"),
                t("Starts a grade line hugging the terrain, with few vertices"),
                self.desde_terreno,
            ),
            (
                t("From the layer Z"),
                t("Reads the grade line the alignment geometry already has"),
                self.desde_z,
            ),
            (
                t("Apply to the layer Z"),
                t(
                    "Writes the grade line into the alignment Z, densifying "
                    "the vertical curves and the curved segments"
                ),
                self.aplicar,
            ),
        ):
            b = QPushButton(rotulo)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            fila.addWidget(b)
        self.sp_paso_aplicar = QDoubleSpinBox()
        self.sp_paso_aplicar.setRange(0.0, 200.0)
        self.sp_paso_aplicar.setValue(5.0)
        self.sp_paso_aplicar.setSuffix(" m")
        self.sp_paso_aplicar.setToolTip(
            t(
                "Densification step when applying. With 0 only the vertices "
                "the alignment already has are written, and the vertical "
                "curves are lost."
            )
        )
        fila.addWidget(QLabel(t("step")))
        fila.addWidget(self.sp_paso_aplicar)
        self.sp_n_vertices = QDoubleSpinBox()
        self.sp_n_vertices.setRange(2, 60)
        self.sp_n_vertices.setDecimals(0)
        self.sp_n_vertices.setValue(5)
        self.sp_n_vertices.setToolTip(
            t("Vertices of the initial grade line from the terrain")
        )
        fila.addWidget(QLabel(t("vertices")))
        fila.addWidget(self.sp_n_vertices)
        self.sp_tolerancia = QDoubleSpinBox()
        self.sp_tolerancia.setRange(0.0, 10.0)
        self.sp_tolerancia.setDecimals(2)
        self.sp_tolerancia.setSingleStep(0.05)
        self.sp_tolerancia.setValue(0.05)
        self.sp_tolerancia.setSuffix(" m")
        self.sp_tolerancia.setToolTip(
            t(
                "Tolerance when reading the layer Z and when simplifying. An "
                "alignment can have hundreds of vertices, and the grade line "
                "need not inherit them: it keeps the ones that really define "
                "it. With 0 they are all read."
            )
        )
        fila.addWidget(QLabel(t("tol.")))
        fila.addWidget(self.sp_tolerancia)
        fila.addStretch(1)
        return fila

    # -- estado ------------------------------------------------------------
    @property
    def rasante(self) -> Rasante:
        return self.vista.rasante

    def set_herramienta(self, clave: str) -> None:
        """Activa un modo o ejecuta una accion.

        Si es una accion y hay un segmento a la vista (el seleccionado), se aplica
        ya: no hace falta pinchar otra vez. Si no hay ninguno, la accion queda
        armada para el siguiente clic.
        """
        if clave in ACCIONES:
            indice = self._segmento_actual()
            if indice is not None and self.vista.aplicar_a(indice, clave):
                self.vista.set_herramienta(H_MOVER)
                self._pista(
                    t(
                        "{tipo} applied to segment {n}. Drag its handles to "
                        "shape it.",
                        tipo=etiqueta_segmento(clave),
                        n=indice + 1,
                    )
                )
                return
        self.vista.set_herramienta(clave)

    def _segmento_actual(self):
        """Segmento sobre el que actuan las acciones de la barra, si hay alguno."""
        sel = self.vista.seleccion
        if sel and sel[0] == "segmento":
            return sel[1]
        if sel and sel[0] in ("vertice", "control"):
            return min(sel[1], len(self.rasante) - 2) if len(self.rasante) > 1 else None
        return None

    def _herramienta_cambiada(self, clave: str) -> None:
        """La vista manda: los botones y la pista siguen su estado."""
        for k, b in self.botones.items():
            if b.isCheckable():
                b.setChecked(k == clave)
        self._pista(pista(clave))

    def _pista(self, texto: str) -> None:
        self.lbl_pista.setText(texto)

    def _exageracion(self, valor: float) -> None:
        self.vista.exageracion = valor
        self.vista.update()

    def _ajustes(self, *_a) -> None:
        self.vista.ajustar_terreno = self.chk_terreno.isChecked()
        self.vista.paso_s = self.sp_paso_s.value()
        self.vista.paso_cota = self.sp_paso_z.value()

    # -- capas -------------------------------------------------------------
    def _releer_tramos(self, indice: int = -1) -> None:
        """Rehace la lista de tramos de la capa sin tocar la rasante en curso."""
        capa = self.cmb_capa.currentLayer()
        if indice < 0:
            indice = max(0, self.cmb_tramo.currentIndex())
        self.cmb_tramo.blockSignals(True)
        self.cmb_tramo.clear()
        self._alineaciones = []
        if capa is not None and capa.geometryType() == QgsWkbTypes.LineGeometry:
            opciones = StationOptions(paso=20.0)
            for f in capa.getFeatures():
                for al in alignments_from_feature(f, opciones):
                    self._alineaciones.append(al)
                    self.cmb_tramo.addItem(
                        f"{al.etiqueta} · {al.longitud:.0f} m",
                        len(self._alineaciones) - 1,
                    )
        if self._alineaciones:
            self.cmb_tramo.setCurrentIndex(min(indice, len(self._alineaciones) - 1))
        self.cmb_tramo.blockSignals(False)
        al = self._alineacion()
        self._pts = list(al.pts) if al is not None else []

    def _capa_de_partida(self):
        """Capa de lineas con la que arrancar: la activa, o una que no sea salida.

        El corredor genera capas de linea propias (``eje``, ``secciones``,
        ``lineas caracteristicas``), y si el combo se queda con la primera que
        encuentra puede coger una de esas en vez de la directriz del usuario. Eso
        hacia parecer que «no encuentra las alineaciones».
        """
        from qgis.core import QgsProject, QgsWkbTypes

        def es_directriz(capa) -> bool:
            if capa is None or not isinstance(capa, QgsVectorLayer):
                return False
            if not capa.isValid() or capa.geometryType() != QgsWkbTypes.LineGeometry:
                return False
            etiqueta = capa.name().split(" - ")[-1].strip()
            # Se reconoce por clave interna: el nombre de la capa esta en
            # el idioma en que se calculo el corredor.
            clave = clave_de_etiqueta(etiqueta)
            if clave in ORDEN_CAPAS or clave == "tin_fusionado":
                return False
            if etiqueta.lower() in HOJAS_DE_PLANTA:
                return False
            # Las capas de dibujo de los planos tampoco son directrices.
            return " - " not in capa.name() or etiqueta.lower() not in (
                "lineas", "rotulos", "rellenos",
                "lines", "labels", "fills",
            )

        activa = None
        obtener = getattr(self.iface, "activeLayer", None)
        if callable(obtener):
            activa = obtener()
        if es_directriz(activa):
            return activa
        for capa in QgsProject.instance().mapLayers().values():
            if es_directriz(capa):
                return capa
        return None

    def _capa_cambiada(self, *_a) -> None:
        self._releer_tramos(indice=0)
        self._tramo_cambiado()

    def _dem_cambiado(self, *_a) -> None:
        capa = self.cmb_dem.currentLayer()
        self._terreno = None
        if capa is not None:
            crs = None
            directriz = self.cmb_capa.currentLayer()
            if directriz is not None:
                crs = directriz.crs()
            try:
                self._terreno = make_terrain(capa, crs)
            except Exception as exc:  # noqa: BLE001
                self.lbl_estado.setText(t("the DEM cannot be used: {error}", error=exc))
                self._terreno = None
        self._refrescar_terreno()

    def _tramo_cambiado(self, *_a) -> None:
        al = self._alineacion()
        self._pts = list(al.pts) if al is not None else []
        self.vista.pks = []
        if al is not None:
            self.vista.pks = [
                (st.s, f"{st.s:.0f}") for st in al.pk_stations(100.0)
            ]
        self._refrescar_terreno()
        if al is None:
            self.vista.set_rasante(Rasante())
            self._llenar_tabla()
            self.lbl_estado.setText(t("The chosen layer has no lines."))
            return
        # Si la directriz ya trae Z, se arranca de ella; si no, del terreno.
        actual = rasante_de_geometria(self._pts, tolerancia=self.sp_tolerancia.value())
        if not actual.vacia:
            self.vista.set_rasante(actual)
            heredados = sum(1 for p in self._pts if len(p) > 2 and p[2] is not None)
            extra = (
                t(" (from {n} plan vertices)", n=heredados)
                if heredados > len(actual) + 1
                else ""
            )
            self.lbl_estado.setText(
                t(
                    "{etiqueta}: grade line read from the layer Z{extra}, "
                    "{resumen}",
                    etiqueta=al.etiqueta,
                    extra=extra,
                    resumen=actual.resumen(),
                )
            )
        elif self.vista.terreno:
            self.desde_terreno()
        else:
            self.vista.set_rasante(Rasante())
            self.lbl_estado.setText(
                t(
                    "{etiqueta}: choose a DEM to start from the terrain, or "
                    "draw the vertices with the Insert tool.",
                    etiqueta=al.etiqueta,
                )
            )
        self._llenar_tabla()
        self._dibujar_en_mapa()

    def _alineacion(self):
        i = self.cmb_tramo.currentIndex()
        if 0 <= i < len(self._alineaciones):
            return self._alineaciones[i]
        return None

    def _refrescar_terreno(self) -> None:
        if self._terreno is None or len(self._pts) < 2:
            self.vista.set_terreno([])
            return
        perfil = perfil_del_terreno(self._pts, self._terreno.z, paso=5.0)
        self.vista.set_terreno(perfil)

    # -- acciones ----------------------------------------------------------
    def desde_terreno(self) -> None:
        if not self.vista.terreno:
            self.lbl_estado.setText(
                t("A DEM is needed to start the grade line from the terrain.")
            )
            return
        r = Rasante.del_terreno(
            self.vista.terreno, n_vertices=int(self.sp_n_vertices.value())
        )
        self.vista.set_rasante(r)
        self._llenar_tabla()
        self.lbl_estado.setText(
            t("Grade line started from the terrain: {r}", r=r.resumen())
        )
        self._dibujar_en_mapa()

    def desde_z(self) -> None:
        if len(self._pts) < 2:
            return
        r = rasante_de_geometria(self._pts, tolerancia=self.sp_tolerancia.value())
        if r.vacia:
            self.lbl_estado.setText(
                t(
                    "The alignment has no Z: use «From the terrain» or draw "
                    "the vertices."
                )
            )
            return
        self.vista.set_rasante(r)
        self._llenar_tabla()
        self.lbl_estado.setText(
            t("Grade line read from the layer: {r}", r=r.resumen())
        )

    def simplificar(self) -> None:
        """Quita los vertices que no hacen falta, con la tolerancia del pie."""
        if self.rasante.vacia:
            return
        tolerancia = self.sp_tolerancia.value()
        if tolerancia <= 0.0:
            self._pista(
                t("Raise the tolerance («tol.» field) to be able to simplify.")
            )
            return
        antes = len(self.rasante)
        quitados = self.rasante.simplificar_a(tolerancia)
        if not quitados:
            self._pista(
                t(
                    "Nothing to simplify with {tol:.2f} m: all {n} vertices "
                    "are needed.",
                    tol=tolerancia,
                    n=antes,
                )
            )
            return
        self.vista.limpiar_seleccion()
        self._rasante_cambiada(rehacer_tabla=True)
        self._pista(
            t(
                "Simplified: {antes} → {ahora} vertices (tolerance "
                "{tol:.2f} m). The segments become straight again.",
                antes=antes,
                ahora=len(self.rasante),
                tol=tolerancia,
            )
        )

    def aplicar(self) -> None:
        capa = self.cmb_capa.currentLayer()
        al = self._alineacion()
        if capa is None or al is None:
            return
        if self.rasante.vacia:
            QMessageBox.warning(
                self, _r(), t("The grade line needs at least two vertices.")
            )
            return
        avisos = self.rasante.avisos()
        if avisos:
            texto = chr(10).join(f"· {a}" for a in avisos[:8])
            respuesta = QMessageBox.question(
                self,
                _r(),
                t("The grade line has warnings:")
                + chr(10) * 2
                + texto
                + chr(10) * 2
                + t("Apply it anyway?"),
            )
            if respuesta != BOTON_SI:
                return
        ok, mensajes, nueva = aplicar_rasante(
            capa,
            self.rasante,
            fid=al.fid,
            part=al.part,
            paso=self.sp_paso_aplicar.value(),
        )
        if nueva is not None:
            QgsProject.instance().addMapLayer(nueva)
        if not ok:
            self.lbl_estado.setText(" · ".join(mensajes))
            QMessageBox.warning(self, _r(), chr(10).join(mensajes))
            return
        # La geometria ha cambiado (mas vertices), asi que hay que releerla para
        # que un segundo «Aplicar» trabaje sobre la de verdad. Pero la rasante
        # que se acaba de editar se queda: rehacerla seria perder el trabajo.
        self._releer_tramos()
        self.lbl_estado.setText(" · ".join(mensajes))

    # -- tabla -------------------------------------------------------------
    def _llenar_tabla(self) -> None:
        self._actualizando = True
        r = self.rasante
        self.tabla.setRowCount(len(r))
        for i, v in enumerate(r.vertices):
            k = r.parametro_k(i)
            pend = r.pendiente(i) * 100.0 if i < len(r) - 1 else None
            valores = (
                f"{v.s:.2f}",
                f"{v.z:.3f}",
                t(NOMBRES.get(v.tipo, v.tipo)) if i < len(r) - 1 else "",
                f"{v.acuerdo:.1f}" if v.acuerdo else "",
                f"{k:.1f}" if k else "",
                f"{pend:+.2f}" if pend is not None else "",
            )
            for j, texto in enumerate(valores):
                item = QTableWidgetItem(texto)
                if j in (2, 4, 5):
                    # Calculadas: se leen, no se escriben.
                    item.setFlags(item.flags() & ~ITEM_EDITABLE)
                item.setData(ROL_USUARIO, i)
                self.tabla.setItem(i, j, item)
        self.tabla.resizeColumnsToContents()
        self._actualizando = False

    def _celda_editada(self, item) -> None:
        if self._actualizando:
            return
        i, j = item.row(), item.column()
        if not (0 <= i < len(self.rasante)):
            return
        try:
            valor = float(item.text().replace(",", "."))
        except ValueError:
            self._llenar_tabla()
            return
        v = self.rasante[i]
        if j == 0:
            self.rasante.mover(i, valor, v.z)
            self.rasante.ordenar()
        elif j == 1:
            self.rasante.mover(i, v.s, valor)
        elif j == 3:
            self.rasante.set_acuerdo(i, valor)
        self.vista.update()
        self._rasante_cambiada(rehacer_tabla=True)

    def _fila_elegida(self, fila: int, *_a) -> None:
        if self._actualizando or not (0 <= fila < len(self.rasante)):
            return
        # Elegir en la tabla manda sobre la seleccion multiple: si no, tocar una
        # fila con un grupo marcado dejaria en duda que se va a mover.
        self.vista.seleccion_multiple = {fila}
        self.vista.seleccionar_vertice(fila)

    def _tipo_elegido(self, *_a) -> None:
        if self._actualizando:
            return
        i = self.vista.vertice_seleccionado()
        if i is None or i >= len(self.rasante) - 1:
            return
        tipo = self.cmb_tipo.currentData()
        if self.vista.aplicar_a(i, tipo):
            self._rasante_cambiada(rehacer_tabla=True)

    def _aplicar_k(self) -> None:
        i = self.vista.vertice_seleccionado()
        if i is None:
            return
        if not self.rasante.set_k(i, self.sp_k.value()):
            self.lbl_estado.setText(
                t(
                    "That vertex takes no vertical curve: it has to be an "
                    "inner one and there has to be a change of grade."
                )
            )
            return
        self._rasante_cambiada(rehacer_tabla=True)

    # -- reacciones --------------------------------------------------------
    def _rasante_cambiada(self, rehacer_tabla: bool = True) -> None:
        if rehacer_tabla:
            self._llenar_tabla()
        self.vista.update()
        avisos = self.rasante.avisos()
        texto = self.rasante.resumen()
        if avisos:
            texto += "  ·  " + avisos[0]
            if len(avisos) > 1:
                texto += t(" (and {n} more warning(s))", n=len(avisos) - 1)
        self.lbl_estado.setText(texto)
        self._dibujar_en_mapa()

    def _seleccion_cambiada(self) -> None:
        i = self.vista.vertice_seleccionado()
        grupo = len(self.vista.seleccion_multiple)
        if grupo > 1:
            self._pista(
                t(
                    "{n} vertices selected: drag one and they all move by the "
                    "same increment. Del removes them.",
                    n=grupo,
                )
            )
        self._actualizando = True
        if i is not None and i < len(self.rasante) - 1:
            tipo = self.rasante[i].tipo
            indice = TIPOS.index(tipo) if tipo in TIPOS else 0
            self.cmb_tipo.setCurrentIndex(indice)
        if i is not None:
            k = self.rasante.parametro_k(i)
            self.sp_k.setValue(k or 0.0)
            if 0 <= i < self.tabla.rowCount():
                self.tabla.selectRow(i)
        self._actualizando = False
        self._dibujar_en_mapa()

    def _raton_en(self, s: float, _z: float) -> None:
        self._marcar_en_mapa(s)

    # -- mapa --------------------------------------------------------------
    def _canvas(self):
        canvas = getattr(self.iface, "mapCanvas", None)
        return canvas() if callable(canvas) else None

    def _dibujar_en_mapa(self) -> None:
        """Resalta la directriz en planta y marca el vertice seleccionado."""
        canvas = self._canvas()
        if canvas is None or len(self._pts) < 2:
            return
        from qgis.core import QgsGeometry, QgsPointXY

        if self._banda is None:
            self._banda = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
            self._banda.setColor(QColor(20, 90, 190, 140))
            self._banda.setWidth(3)
        self._banda.setToGeometry(
            QgsGeometry.fromPolylineXY([QgsPointXY(p[0], p[1]) for p in self._pts]),
            self.cmb_capa.currentLayer(),
        )
        i = self.vista.vertice_seleccionado()
        if i is not None and 0 <= i < len(self.rasante):
            self._marcar_en_mapa(self.rasante[i].s)

    def _marcar_en_mapa(self, s: float) -> None:
        canvas = self._canvas()
        if canvas is None or len(self._pts) < 2:
            return
        from qgis.core import QgsPointXY

        if self._marca is None:
            self._marca = QgsVertexMarker(canvas)
            self._marca.setColor(COL_MAPA)
            self._marca.setIconSize(13)
            self._marca.setPenWidth(3)
        x, y = punto_en(self._pts, s)
        self._marca.setCenter(QgsPointXY(x, y))

    def limpiar_mapa(self) -> None:
        for objeto in (self._banda, self._marca):
            if objeto is not None:
                canvas = self._canvas()
                if canvas is not None:
                    canvas.scene().removeItem(objeto)
        self._banda = None
        self._marca = None

    def closeEvent(self, event) -> None:
        self.limpiar_mapa()
        super().closeEvent(event)


__all__ = ["RasanteEditor"]
