"""Interfaz de usuario del plugin: editor de secciones y dialogo del corredor."""
