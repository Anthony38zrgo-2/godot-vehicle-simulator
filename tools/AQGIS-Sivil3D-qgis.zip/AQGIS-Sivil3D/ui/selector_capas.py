"""Selector de las capas que salen en el plano de planta.

Un plano no lleva todo lo que hay abierto en QGIS. En un proyecto de verdad hay
catastro, ortofotos, capas de trabajo y a lo mejor otros corredores, y mandarlas
todas al plano da una hoja ilegible y una exportacion lentisima.

Este widget lista las capas que **pueden** ir a un plano y deja marcar las que de
verdad se quieren. La marca inicial no es caprichosa:

* **si** las capas de salida del corredor que se esta dibujando (el TIN, la
  huella, el eje, las lineas caracteristicas) y su directriz;
* **no** los rasteres, porque un DEM en gris tapa el dibujo entero, y las capas
  de dibujo en espacio papel, cuyas coordenadas son milimetros y apareceran en
  otro punto del planeta.

El orden de la lista es el del panel de capas, para que se reconozca de un
vistazo.
"""

from __future__ import annotations

from typing import List, Optional

from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer
from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QToolButton,
    QVBoxLayout,
)

from ..gis.outputs import ORDEN_CAPAS, clave_de_etiqueta
from ..i18n import t
from .qtcompat import (
    BARRA_CUANDO_HAGA_FALTA,
    ELIDIR_DERECHA,
    ITEM_HABILITADO,
    ITEM_MARCABLE,
    ITEM_SELECCIONABLE,
    MARCADO,
    ROL_USUARIO,
    SIN_MARCAR,
)

#: Claves internas de las capas que son salidas del corredor. Se marcan de
#: partida. El nombre de la capa esta en el idioma en que se calculo, asi que se
#: reconoce por clave y no por texto.
SALIDAS = set(ORDEN_CAPAS) | {"tin_fusionado"}


def es_de_plano(capa) -> bool:
    """True si la capa puede ir al mapa de un plano de planta.

    Se quedan fuera las de espacio papel: sus coordenadas son milimetros y, si se
    mandan al mapa, aparecen a cientos de kilometros del corredor.
    """
    if capa is None or not capa.isValid():
        return False
    return bool(capa.crs().isValid())


def _etiqueta_de(capa) -> str:
    """Ultimo tramo del nombre, que es el que dice de que capa se trata."""
    return capa.name().split(" - ")[-1].strip()


def es_salida_de_corredor(capa) -> bool:
    return clave_de_etiqueta(_etiqueta_de(capa)) in SALIDAS


class SelectorCapas(QGroupBox):
    """Lista con casilla de las capas que iran al plano."""

    #: Ha cambiado el conjunto de capas marcadas.
    cambiado = pyqtSignal()

    def __init__(self, titulo: str = "", parent=None):
        super().__init__(titulo or t("Drawing layers"), parent)
        #: ``[id de capa]`` en el orden de la lista.
        self._ids: List[str] = []
        self._silencio = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 4, 6, 6)
        lay.setSpacing(3)

        self.lista = QListWidget()
        self.lista.setMinimumHeight(90)
        self.lista.setMaximumHeight(170)
        self.lista.setMinimumWidth(170)
        self.lista.setHorizontalScrollBarPolicy(BARRA_CUANDO_HAGA_FALTA)
        self.lista.setTextElideMode(ELIDIR_DERECHA)
        self.lista.setToolTip(
            t(
                "Layers drawn on the plan sheet. By default the corridor "
                "outputs and the alignment are checked; the rest of the "
                "project (cadastre, orthophotos, working layers) is left out."
            )
        )
        self.lista.itemChanged.connect(self._item_cambiado)
        lay.addWidget(self.lista, 1)

        barra = QHBoxLayout()
        barra.setSpacing(3)
        for texto, tip, slot in (
            (
                t("All"),
                t("Check every layer"),
                lambda: self.marcar_todas(True),
            ),
            (t("None"), t("Uncheck every layer"), lambda: self.marcar_todas(False)),
            (
                t("Corridor only"),
                t("Only the corridor output layers and the alignment"),
                self.solo_corredor,
            ),
        ):
            b = QToolButton()
            b.setText(texto)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            barra.addWidget(b)
        barra.addStretch(1)
        self.lbl_cuenta = QLabel()
        f = QFont(self.lbl_cuenta.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1.0))
        self.lbl_cuenta.setFont(f)
        self.lbl_cuenta.setStyleSheet("color:#777;")
        barra.addWidget(self.lbl_cuenta)
        lay.addLayout(barra)

    # -- carga -------------------------------------------------------------
    def recargar(self, proyecto=None, directrices=None) -> None:
        """Relee las capas del proyecto y marca las razonables.

        ``directrices`` son las capas de las que salen los corredores que se van a
        dibujar: se marcan aunque no sean salidas del corredor.
        """
        proyecto = proyecto or QgsProject.instance()
        nombres_dir = {c.id() for c in (directrices or []) if c is not None}
        marcadas_antes = set(self.marcadas_ids()) if self._ids else None

        self._silencio = True
        self.lista.clear()
        self._ids = []
        for capa in self._capas_ordenadas(proyecto):
            if not es_de_plano(capa):
                continue
            item = QListWidgetItem(capa.name())
            item.setFlags(ITEM_HABILITADO | ITEM_MARCABLE | ITEM_SELECCIONABLE)
            if marcadas_antes is not None:
                # Al recargar se respeta lo que el usuario hubiera tocado.
                marcar = capa.id() in marcadas_antes
            else:
                marcar = es_salida_de_corredor(capa) or capa.id() in nombres_dir
            item.setCheckState(MARCADO if marcar else SIN_MARCAR)
            item.setData(ROL_USUARIO, capa.id())
            item.setToolTip(self._descripcion(capa))
            self.lista.addItem(item)
            self._ids.append(capa.id())
        self._silencio = False
        self._actualizar_cuenta()
        self.cambiado.emit()

    @staticmethod
    def _capas_ordenadas(proyecto) -> list:
        """Capas en el orden del panel de capas, y si no, en el del proyecto."""
        raiz = proyecto.layerTreeRoot()
        if raiz is not None:
            capas = [n.layer() for n in raiz.findLayers() if n.layer() is not None]
            if capas:
                return capas
        return list(proyecto.mapLayers().values())

    @staticmethod
    def _descripcion(capa) -> str:
        if isinstance(capa, QgsRasterLayer):
            tipo = t("raster")
        elif isinstance(capa, QgsVectorLayer):
            tipo = t("vector, {n} features", n=capa.featureCount())
        else:
            tipo = t("layer")
        crs = capa.crs().authid() or t("no CRS")
        return capa.name() + chr(10) + tipo + chr(10) + crs

    @property
    def vacio(self) -> bool:
        return not self._ids

    def __len__(self) -> int:
        return len(self._ids)

    # -- consulta ----------------------------------------------------------
    def marcadas_ids(self) -> List[str]:
        salida = []
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            if item.checkState() == MARCADO:
                salida.append(item.data(ROL_USUARIO))
        return salida

    def marcadas(self, proyecto=None) -> list:
        """Las capas marcadas, en el orden en que se dibujan."""
        proyecto = proyecto or QgsProject.instance()
        salida = []
        for identificador in self.marcadas_ids():
            capa = proyecto.mapLayer(identificador)
            if capa is not None:
                salida.append(capa)
        return salida

    # -- acciones ----------------------------------------------------------
    def marcar_todas(self, marcar: bool) -> None:
        self._silencio = True
        for i in range(self.lista.count()):
            self.lista.item(i).setCheckState(MARCADO if marcar else SIN_MARCAR)
        self._silencio = False
        self._actualizar_cuenta()
        self.cambiado.emit()

    def solo_corredor(self, proyecto=None) -> None:
        """Deja marcadas solo las salidas del corredor."""
        proyecto = proyecto or QgsProject.instance()
        self._silencio = True
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            capa = proyecto.mapLayer(item.data(ROL_USUARIO))
            vale = capa is not None and es_salida_de_corredor(capa)
            item.setCheckState(MARCADO if vale else SIN_MARCAR)
        self._silencio = False
        self._actualizar_cuenta()
        self.cambiado.emit()

    def marcar_id(self, identificador: str, marcar: bool = True) -> None:
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            if item.data(ROL_USUARIO) == identificador:
                item.setCheckState(MARCADO if marcar else SIN_MARCAR)
                return

    # -- interno -----------------------------------------------------------
    def _item_cambiado(self, _item) -> None:
        if self._silencio:
            return
        self._actualizar_cuenta()
        self.cambiado.emit()

    def _actualizar_cuenta(self) -> None:
        n = len(self.marcadas_ids())
        total = len(self._ids)
        self.lbl_cuenta.setText(
            t("{n} of {total}", n=n, total=total) if total else t("no layers")
        )


__all__ = ["SALIDAS", "SelectorCapas", "es_de_plano", "es_salida_de_corredor"]
