"""Panel de perfiles: longitudinal, seccion en el PK actual y diagrama de masas.

Se alimenta del resultado del ultimo calculo, que el plugin guarda en memoria. La
navegacion por PK esta sincronizada con el mapa en los dos sentidos: al moverse
por los PK se resalta la seccion sobre el mapa, y al pinchar en el mapa se salta
al PK mas cercano.
"""

from __future__ import annotations

import math
from typing import Optional

from qgis.core import QgsGeometry, QgsPointXY, QgsProject, QgsWkbTypes
from qgis.gui import QgsDockWidget, QgsMapToolEmitPoint, QgsRubberBand
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..core.cruces import lineas_de_run, traza_en_seccion
from ..core.medicion import medir
from .profile_view import (
    ProfileView,
    Serie,
    datos_de_seccion,
    datos_longitudinal,
    datos_masas,
)
from .selector_tramos import MARCAR_CAPA_ACTIVA, SelectorTramos, color_de
from .qtcompat import SIN_MARCO, VERTICAL

from ..gis.registro import avisar
from ..i18n import numero, t


COL_BANDA = QColor(255, 120, 0)

#: Hasta donde se buscan otros corredores alrededor de una seccion, en metros.
ANCHO_CRUCES = 50.0


def _con_scroll(contenido: QWidget) -> QWidget:
    """Envuelve el contenido en un area con desplazamiento.

    Sin esto, el ancho minimo del panel es el que pidan sus widgets —y con una
    barra de herramientas larga eso son miles de pixeles—. Al acoplarlo, Qt hace
    el dock mas ancho que la ventana y **recorta la barra de titulo**, con lo que
    desaparece la X de cerrar. Con el area de desplazamiento el panel puede
    encogerse todo lo que haga falta.
    """
    from qgis.PyQt.QtWidgets import QScrollArea

    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(SIN_MARCO)
    area.setWidget(contenido)
    area.setMinimumWidth(240)
    return area


class ProfileDock(QgsDockWidget):
    """Panel acoplable con los perfiles del ultimo corredor calculado."""

    cerrado = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__(t("Corridor profiles"), parent)
        self.setObjectName("AqgisSivil3DPerfiles")
        self.iface = iface
        self._corredores: dict = {}
        self._result = None
        self._run = None
        self._medicion = None
        self._banda = None
        self._herramienta_previa = None
        self._selector = None

        raiz = QWidget()
        lay = QVBoxLayout(raiz)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        self.selector = SelectorTramos(t("Alignments"))
        self.selector.cambiado.connect(self._refrescar_todo)
        self.selector.actual_cambiado.connect(self._cambiar_actual)

        cabecera = QHBoxLayout()
        # El selector se lleva un tercio del ancho: los nombres de alineacion son
        # largos ('corredor · fid 2 · Carretera 1+1') y cortados no se leen.
        cabecera.addWidget(self.selector, 1)
        cabecera.addLayout(self._barra(), 2)
        lay.addLayout(cabecera)

        self.vista_long = ProfileView()
        self.vista_long.exageracion = 10.0
        self.vista_long.mostrar_marcas = False
        self.vista_long.pinchado.connect(self._ir_a_pk)
        self.vista_sec = ProfileView()

        self.vista_masas = ProfileView()
        self.vista_masas.exageracion = 1.0
        self.vista_masas.mostrar_marcas = False
        self.vista_masas.mostrar_relleno = True

        self.pestanas = QTabWidget()
        arriba = QSplitter(VERTICAL)
        arriba.addWidget(self.vista_long)
        arriba.addWidget(self.vista_sec)
        arriba.setStretchFactor(0, 2)
        arriba.setStretchFactor(1, 3)
        self.pestanas.addTab(arriba, t("Profiles"))
        self.pestanas.addTab(self.vista_masas, t("Mass haul diagram"))
        lay.addWidget(self.pestanas, 1)

        self.lbl_estado = QLabel(t("Compute a corridor to see its profiles."))
        self.lbl_estado.setStyleSheet("color:#666;")
        lay.addWidget(self.lbl_estado)
        self.setWidget(_con_scroll(raiz))
        self._habilitar(False)

    # -- interfaz ----------------------------------------------------------
    def _barra(self) -> QHBoxLayout:
        b = QVBoxLayout()
        b.setSpacing(4)
        fila1 = QHBoxLayout()
        fila1.setSpacing(4)

        self.btn_ant = QToolButton()
        self.btn_ant.setText("◀")
        self.btn_ant.setToolTip(t("Previous station"))
        self.btn_ant.clicked.connect(lambda: self._mover(-1))
        self.cmb_pk = QComboBox()
        self.cmb_pk.setMinimumWidth(110)
        self.cmb_pk.currentIndexChanged.connect(self._cambiar_pk)
        self.btn_sig = QToolButton()
        self.btn_sig.setText("▶")
        self.btn_sig.setToolTip(t("Next station"))
        self.btn_sig.clicked.connect(lambda: self._mover(1))
        fila1.addWidget(QLabel(t("Sta")))
        fila1.addWidget(self.btn_ant)
        fila1.addWidget(self.cmb_pk)
        fila1.addWidget(self.btn_sig)

        self.sp_exa = QDoubleSpinBox()
        self.sp_exa.setRange(1.0, 50.0)
        self.sp_exa.setValue(10.0)
        self.sp_exa.setSingleStep(1.0)
        self.sp_exa.setToolTip(
            t(
                "Vertical exaggeration of the longitudinal profile. Without it "
                "the grade line would be a horizontal stroke."
            )
        )
        self.sp_exa.valueChanged.connect(self._cambiar_exageracion)
        fila1.addWidget(QLabel(t("vert. exag.")))
        fila1.addWidget(self.sp_exa)
        fila1.addStretch(1)
        b.addLayout(fila1)

        fila2 = QHBoxLayout()
        fila2.setSpacing(4)

        self.chk_codigos = QCheckBox(t("codes"))
        self.chk_codigos.setChecked(True)
        self.chk_codigos.toggled.connect(self._refrescar_seccion)
        fila2.addWidget(self.chk_codigos)

        self.chk_pinchar = QCheckBox(t("click on the map"))
        self.chk_pinchar.setToolTip(
            t("Clicking on the map jumps to the nearest station of the run.")
        )
        self.chk_pinchar.toggled.connect(self._modo_pinchar)
        fila2.addWidget(self.chk_pinchar)

        btn_ayuda = QToolButton()
        btn_ayuda.setText("?")
        btn_ayuda.setToolTip(t("Help for the profile viewer"))
        btn_ayuda.clicked.connect(self._ayuda)
        fila2.addWidget(btn_ayuda)
        btn_png = QPushButton(t("Export..."))
        btn_png.setToolTip(t("Saves the current view as a PNG image."))
        btn_png.clicked.connect(self._exportar)
        fila2.addWidget(btn_png)
        fila2.addStretch(1)
        b.addLayout(fila2)
        return b

    def _ayuda(self) -> None:
        from .ayuda_dialog import abrir_ayuda_en

        abrir_ayuda_en("visor", self)

    def _habilitar(self, activo: bool) -> None:
        for w in (
            self.cmb_pk,
            self.btn_ant,
            self.btn_sig,
            self.chk_pinchar,
        ):
            w.setEnabled(activo)

    # -- datos -------------------------------------------------------------
    def _capa_activa(self) -> str:
        """Id de la capa activa en el arbol de capas, o "" si no hay ninguna."""
        try:
            capa = self.iface.activeLayer()
        except (AttributeError, RuntimeError):
            return ""
        try:
            return capa.id() if capa is not None else ""
        except RuntimeError:  # capa borrada
            return ""

    def set_corredores(
        self, corredores: dict, esponjamiento: float = 1.0, activo: str = ""
    ) -> None:
        """Carga todas las alineaciones de todos los corredores en el selector.

        Al abrir el panel no se dibuja todo de golpe: se marca solo la
        alineacion de la capa activa en el arbol de capas, y si la capa activa no
        es una de directrices con corredor, no se marca ninguna. Con varios
        trazados cargados, dibujarlos todos a la vez no es lo que se espera y
        deja el longitudinal ilegible.
        """
        self._corredores = dict(corredores or {})
        self._esponjamiento = esponjamiento
        self.selector.set_corredores(
            self._corredores,
            marcar_todo=MARCAR_CAPA_ACTIVA,
            capa_activa=self._capa_activa(),
        )
        if activo:
            # Se deja como actual la primera alineacion del corredor pedido.
            self.selector.set_principal_de_corredor(activo)
        if self.selector.vacio:
            self._run = None
            self._medicion = None
            for vista in (self.vista_long, self.vista_sec, self.vista_masas):
                vista.limpiar(t("No result"))
            self.lbl_estado.setText(
                t(
                    "Compute a corridor, or import a saved one, to see its "
                    "profiles."
                )
            )
            self._habilitar(False)

    def set_result(self, result, esponjamiento: float = 1.0) -> None:
        """Carga un solo corredor. Atajo de :meth:`set_corredores`."""
        if result is None:
            self.set_corredores({}, esponjamiento)
            return
        nombre = getattr(result, "nombre", "") or t("Corridor")
        self.set_corredores({nombre: result}, esponjamiento)

    # -- refrescos ---------------------------------------------------------
    def _refrescar_todo(self) -> None:
        """Se ha cambiado el conjunto de alineaciones marcadas."""
        self._refrescar_longitudinal()
        self._refrescar_masas()
        # La seccion tambien: de las marcadas depende que otros trazados se
        # dibujan sobre ella.
        self._refrescar_seccion()
        self._actualizar_estado()

    def _cambiar_actual(self) -> None:
        """Ha cambiado la alineacion actual: se rehace la lista de PK."""
        actual = self.selector.actual()
        self._run = actual[2] if actual else None
        secciones = self._secciones()
        self._medicion = (
            medir(secciones, esponjamiento=self._esponjamiento) if secciones else None
        )
        self._habilitar(bool(secciones))

        self.cmb_pk.blockSignals(True)
        self.cmb_pk.clear()
        for i, s in enumerate(secciones):
            self.cmb_pk.addItem(f"{s.station.s:.2f}", i)
        self.cmb_pk.blockSignals(False)

        # El cursor y la seccion son de la alineacion actual; el longitudinal y las
        # masas llevan todas las marcadas, asi que tambien se rehacen.
        self._refrescar_longitudinal()
        self._refrescar_masas()
        self._actualizar_estado()
        if secciones:
            self.cmb_pk.setCurrentIndex(0)
            self._cambiar_pk(0)
        else:
            self.vista_sec.limpiar(t("No section"))

    def _series(self, dibujar) -> tuple:
        """``(principal, extras)`` a partir de las alineaciones marcadas.

        ``dibujar(run)`` devuelve la polilinea de ese tramo. La principal es la
        alineacion actual si esta marcada; si no, la primera marcada.
        """
        marcadas = self.selector.seleccionados()
        if not marcadas:
            return None, []
        actual = self.selector.actual()
        indice_actual = actual[0] if actual else -1
        principal = next(
            (m for m in marcadas if m[0] == indice_actual), marcadas[0]
        )
        extras = []
        for indice, nombre, run in marcadas:
            if indice == principal[0]:
                continue
            puntos = dibujar(run)
            if len(puntos) < 2:
                continue
            extras.append(
                Serie(
                    puntos=puntos,
                    color=color_de(indice),
                    etiqueta=self.selector.lista.item(indice).text(),
                    discontinua=True,
                )
            )
        del nombre
        return principal, extras

    def _refrescar_longitudinal(self) -> None:
        def rasante(run):
            return [
                (s.station.s, s.z_eje)
                for s in run.sections
                if s.vertices and math.isfinite(s.z_eje)
            ]

        principal, extras = self._series(rasante)
        if principal is None:
            self.vista_long.limpiar(t("Check some alignment"))
            return
        _i, _nombre, run = principal
        secciones = [s for s in run.sections if s.vertices]
        datos = datos_longitudinal(secciones, run.pks)
        datos.extras = extras
        if extras:
            datos.titulo_proyecto = self.selector.lista.item(principal[0]).text()
            datos.titulo = t(
                "Longitudinal profile — {n} alignments", n=len(extras) + 1
            )
        self.vista_long.set_datos(datos, t("No profile"))

    def _refrescar_masas(self) -> None:
        def masas(run):
            m = medir(
                [s for s in run.sections if s.vertices],
                esponjamiento=self._esponjamiento,
            )
            return list(m.masas)

        principal, extras = self._series(masas)
        if principal is None:
            self.vista_masas.limpiar("Marca alguna alineacion")
            return
        _i, _nombre, run = principal
        m = medir(
            [s for s in run.sections if s.vertices], esponjamiento=self._esponjamiento
        )
        datos = datos_masas(m)
        datos.extras = extras
        if extras:
            datos.titulo_proyecto = self.selector.lista.item(principal[0]).text()
        self.vista_masas.set_datos(datos, t("No earthwork data"))

    def _actualizar_estado(self) -> None:
        marcadas = self.selector.seleccionados()
        if not marcadas:
            self.lbl_estado.setText(t("No alignment is checked."))
            return
        if len(marcadas) == 1 and self._medicion is not None:
            _i, nombre, run = marcadas[0]
            n = sum(1 for s in run.sections if s.vertices)
            self.lbl_estado.setText(
                t(
                    "{nombre} · {etiqueta}: {n} sections. {resumen}",
                    nombre=nombre,
                    etiqueta=run.etiqueta,
                    n=n,
                    resumen=self._medicion.resumen(),
                )
            )
            return
        # Con varias, el resumen util es el total y el reparto por alineacion.
        total_des = total_ter = 0.0
        trozos = []
        for _i, _nombre, run in marcadas:
            m = medir(
                [s for s in run.sections if s.vertices],
                esponjamiento=self._esponjamiento,
            )
            total_des += m.total_desmonte
            total_ter += m.total_terraplen
            trozos.append(
                f"{run.etiqueta} {numero(m.total_neto, signo=True)}"
            )
        self.lbl_estado.setText(
            t(
                "{n} alignments · cut {des} m3, fill {ter} m3 · net per run: "
                "{trozos}",
                n=len(marcadas),
                des=numero(total_des),
                ter=numero(total_ter),
                trozos="  ".join(trozos),
            )
        )

    def _secciones(self) -> list:
        if self._run is None:
            return []
        return [s for s in self._run.sections if s.vertices]

    def _cambiar_pk(self, indice: int) -> None:
        self._refrescar_seccion()
        secciones = self._secciones()
        if 0 <= indice < len(secciones):
            sec = secciones[indice]
            self.vista_long.cursor = sec.station.s
            self.vista_long.update()
            self.vista_masas.cursor = sec.station.s
            self.vista_masas.update()
            self._marcar_en_mapa(sec)

    def _refrescar_seccion(self) -> None:
        secciones = self._secciones()
        i = self.cmb_pk.currentIndex()
        if not (0 <= i < len(secciones)):
            self.vista_sec.limpiar(t("No section"))
            return
        self.vista_sec.mostrar_marcas = self.chk_codigos.isChecked()
        datos = datos_de_seccion(
            secciones[i], con_codigos=self.chk_codigos.isChecked()
        )
        actual = self.selector.actual()
        if actual and len(self.selector) > 1:
            # Con varias alineaciones hay que saber de cual es esta seccion.
            datos.titulo = f"{actual[2].etiqueta} · {datos.titulo}"
        datos.extras = self._cruces_en(secciones[i])
        self.vista_sec.set_datos(datos)

    def _cruces_en(self, seccion) -> list:
        """Trazas de las demas alineaciones marcadas en el plano de esta seccion.

        Es lo mismo que se dibuja en el plano de transversales: se corta el plano
        de la seccion con las lineas caracteristicas de los otros corredores. Si
        dos trazados se cruzan, aqui se ve.
        """
        marcadas = self.selector.seleccionados()
        actual = self.selector.actual()
        if actual is None or len(marcadas) < 2:
            return []
        otros = [
            (indice, self.selector.lista.item(indice).text(), run)
            for indice, _nombre, run in marcadas
            if run is not actual[2]
        ]
        if not otros:
            return []
        # Cuanto se mira alrededor: el triple del ancho de la seccion, y nunca
        # menos de 50 m. Con menos se perderia un trazado paralelo que va a 40 m,
        # que es justo lo que se quiere ver; sin tope, un eje que cruza en angulo
        # recto dejaria una traza de cientos de metros y la seccion de verdad
        # quedaria del tamano de una raya.
        ancho = max(max(seccion.ancho_izq, seccion.ancho_der) * 3.0, ANCHO_CRUCES)
        salida = []
        for indice, etiqueta, run in otros:
            traza = traza_en_seccion(
                seccion, lineas_de_run(run), etiqueta=etiqueta, ancho_max=ancho
            )
            if traza.vacia:
                continue
            salida.append(
                Serie(
                    puntos=traza.puntos,
                    color=color_de(indice),
                    etiqueta=etiqueta,
                    discontinua=True,
                )
            )
        return salida

    def _mover(self, delta: int) -> None:
        n = self.cmb_pk.count()
        if n == 0:
            return
        self.cmb_pk.setCurrentIndex(max(0, min(n - 1, self.cmb_pk.currentIndex() + delta)))

    def _cambiar_exageracion(self, valor: float) -> None:
        self.vista_long.exageracion = float(valor)
        self.vista_long.update()

    def _ir_a_pk(self, pk: float) -> None:
        """Salta al PK mas cercano al que se ha pinchado en el perfil."""
        secciones = self._secciones()
        if not secciones:
            return
        i = min(
            range(len(secciones)), key=lambda k: abs(secciones[k].station.s - pk)
        )
        self.cmb_pk.setCurrentIndex(i)

    # -- sincronia con el mapa ---------------------------------------------
    def _banda_elastica(self):
        if self._banda is None:
            canvas = self.iface.mapCanvas()
            self._banda = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
            self._banda.setColor(COL_BANDA)
            self._banda.setWidth(3)
        return self._banda

    def _marcar_en_mapa(self, sec) -> None:
        try:
            banda = self._banda_elastica()
        except Exception:  # noqa: BLE001 - sin canvas (tests)
            return
        pts = [QgsPointXY(p[0], p[1]) for p in sec.world_points()]
        if len(pts) < 2:
            banda.reset(QgsWkbTypes.LineGeometry)
            return
        banda.setToGeometry(QgsGeometry.fromPolylineXY(pts), None)

    def _modo_pinchar(self, activo: bool) -> None:
        canvas = self.iface.mapCanvas()
        if activo:
            self._herramienta_previa = canvas.mapTool()
            self._selector = QgsMapToolEmitPoint(canvas)
            self._selector.canvasClicked.connect(self._pinchado_en_mapa)
            canvas.setMapTool(self._selector)
        else:
            if self._selector is not None:
                canvas.unsetMapTool(self._selector)
                self._selector = None
            if self._herramienta_previa is not None:
                canvas.setMapTool(self._herramienta_previa)
                self._herramienta_previa = None

    def _pinchado_en_mapa(self, punto, _boton) -> None:
        """Salta al PK cuya seccion pasa mas cerca del punto pinchado."""
        secciones = self._secciones()
        if not secciones:
            return
        mejor, mejor_d = 0, float("inf")
        for i, sec in enumerate(secciones):
            d = math.hypot(sec.station.x - punto.x(), sec.station.y - punto.y())
            if d < mejor_d:
                mejor, mejor_d = i, d
        self.cmb_pk.setCurrentIndex(mejor)

    # -- exportar ----------------------------------------------------------
    def _exportar(self) -> None:
        vista = self._vista_actual()
        if vista is None:
            return
        ruta, _ = QFileDialog.getSaveFileName(
            self, t("Save image"), "perfil.png", t("PNG image (*.png)")
        )
        if not ruta:
            return
        if not ruta.lower().endswith(".png"):
            ruta += ".png"
        imagen = vista.grab()
        if not imagen.save(ruta):
            QMessageBox.warning(
                self, t("Export"), t("Could not save {ruta}", ruta=ruta)
            )

    def _vista_actual(self) -> Optional[ProfileView]:
        if self.pestanas.currentIndex() == 1:
            return self.vista_masas
        # En la pestana de perfiles se exporta el conjunto de los dos.
        return self.pestanas.widget(0)

    # -- cierre ------------------------------------------------------------
    def closeEvent(self, evento) -> None:
        if self.chk_pinchar.isChecked():
            self.chk_pinchar.setChecked(False)
        if self._banda is not None:
            try:
                self._banda.reset(QgsWkbTypes.LineGeometry)
            except Exception as exc:  # noqa: BLE001
                avisar("banda del visor no borrada al cerrar", exc)
        self.cerrado.emit()
        super().closeEvent(evento)


__all__ = ["ProfileDock"]
