"""Eleccion del idioma del plugin: ingles o castellano.

Todo lo que se ve aqui va en los dos idiomas a la vez. Quien acaba de dejar el
plugin en el idioma que no entiende tiene que poder volver atras sin adivinar.
"""

from __future__ import annotations

import os

from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QMessageBox,
    QVBoxLayout,
)  # QDialog es la clase base de IdiomaDialog

from ..i18n import IDIOMAS, NOMBRES, en_idioma, idioma, set_idioma
from .qtcompat import (
    BOTON_CANCELAR,
    BOTON_OK,
    DIALOGO_ACEPTADO,
    ROL_USUARIO,
    ejecutar_modal,
)

#: Salto de linea, para no pelearse con el escapado.
SALTO = chr(10)


def _bilingue(texto: str) -> str:
    """El texto en ingles y en castellano, uno debajo del otro."""
    formas = []
    for codigo in IDIOMAS:
        forma = en_idioma(texto, codigo)
        if forma not in formas:
            formas.append(forma)
    return SALTO.join(formas)


class IdiomaDialog(QDialog):
    """Desplegable con los idiomas disponibles."""

    def __init__(self, padre=None):
        super().__init__(padre)
        self.setWindowTitle("Language / Idioma")

        caja = QVBoxLayout(self)
        caja.addWidget(QLabel(_bilingue("Plugin language:")))

        self.combo = QComboBox()
        for codigo in IDIOMAS:
            self.combo.addItem(NOMBRES.get(codigo, codigo), codigo)
        actual = self.combo.findData(idioma())
        self.combo.setCurrentIndex(actual if actual >= 0 else 0)
        caja.addWidget(self.combo)

        aviso = QLabel(
            _bilingue(
                "Changing the language requires restarting QGIS for the menu "
                "and the docked panels to be translated."
            )
        )
        aviso.setWordWrap(True)
        caja.addWidget(aviso)

        botones = QDialogButtonBox(BOTON_OK | BOTON_CANCELAR)
        botones.accepted.connect(self.accept)
        botones.rejected.connect(self.reject)
        caja.addWidget(botones)

    def elegido(self) -> str:
        return self.combo.itemData(self.combo.currentIndex(), ROL_USUARIO) or "en"


def _sembrar_catalogo(lang: str) -> None:
    """Crea la libreria de secciones de ese idioma si todavia no existe.

    Es lo que hace que al elegir ingles se arranque con el catalogo ingles y al
    elegir castellano, con el castellano: la primera vez que se usa un idioma se
    escriben sus plantillas en el perfil. Si el usuario ya tenia una libreria en
    ese idioma no se toca.
    """
    from ..core.library import default_library
    from ..plugin import library_path

    try:
        ruta = library_path(lang)
        if os.path.exists(ruta):
            return
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        default_library(lang).save(ruta)
    except OSError as exc:
        from ..gis.registro import avisar

        avisar("no se ha podido crear la libreria de secciones del idioma", exc)


def elegir_idioma(padre=None) -> str:
    """Abre el dialogo. Devuelve el idioma que ha quedado puesto."""
    anterior = idioma()
    dlg = IdiomaDialog(padre)
    if ejecutar_modal(dlg) != DIALOGO_ACEPTADO:
        return anterior
    nuevo = dlg.elegido()
    if nuevo == anterior:
        return anterior
    set_idioma(nuevo)
    _sembrar_catalogo(nuevo)
    QMessageBox.information(
        padre,
        en_idioma("Language changed", nuevo),
        en_idioma(
            "The plugin language is now {nombre}.", nuevo, nombre=NOMBRES.get(nuevo, nuevo)
        )
        + SALTO * 2
        + en_idioma(
            "Restart QGIS so that the menu, the toolbar and the docked panels "
            "come up translated. Dialogs are already translated the next time "
            "you open them.",
            nuevo,
        )
        + SALTO * 2
        + en_idioma(
            "The typical cross section library for this language has been "
            "selected. Each language keeps its own library, because the name "
            "of a section is the key written in the alignment field.",
            nuevo,
        ),
    )
    return nuevo


__all__ = ["IdiomaDialog", "elegir_idioma"]
