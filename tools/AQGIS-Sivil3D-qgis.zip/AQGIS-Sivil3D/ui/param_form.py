"""Formulario de parametros generado a partir de los ``ParamSpec``.

No hay ningun formulario escrito a mano por tipo de elemento: la interfaz se
construye leyendo la definicion del elemento. Anadir un elemento nuevo al
catalogo (``core/elements.py``) hace que aparezca en el editor sin tocar la UI.

Todos los campos numericos se editan como texto, porque un parametro puede ser
un numero (``3.5``), un literal (``1:1.5``, ``-2%``), una referencia a campo
(``@ancho``) o una expresion (``=...``). Debajo de cada campo se indica como se
ha interpretado, o el error si no se puede interpretar.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QVBoxLayout,
    QWidget,
)

from .qtcompat import AL_DER, AL_VCENTRO

from ..core.elements import ULTIMO_GRIS, ULTIMO_OCULTO
from ..core.params import ParamError, coerce, format_slope
from ..core.preview import es_dinamico
from ..etiquetas import opcion as etiqueta_opcion
from ..i18n import t

COL_ERROR = "#b03030"
COL_DINAMICO = "#7a5cc0"
COL_OK = "#707070"


class ParamForm(QWidget):
    """Formulario de un elemento. Escribe directamente en ``element.params``."""

    cambiado = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._element = None
        self._es_ultimo = True
        self._filas: list = []
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._form = QFormLayout()
        self._form.setLabelAlignment(AL_DER | AL_VCENTRO)
        self._cabecera = QLabel()
        self._cabecera.setWordWrap(True)
        self._cabecera.setStyleSheet("color:#555;")
        self._layout.addWidget(self._cabecera)
        self._layout.addLayout(self._form)
        self._layout.addStretch(1)
        self.set_element(None)

    # -- API ---------------------------------------------------------------
    def set_element(self, element, es_ultimo: bool = True) -> None:
        """Muestra ``element``. ``es_ultimo`` = cierra su grupo de la seccion.

        Los parametros de traspaso al elemento siguiente (el limite de tramo del
        talud y su modo de medida) solo tienen sentido si hay un elemento detras,
        asi que en el ultimo se ven inhabilitados o no se ven.
        """
        if (
            element is not None
            and element is self._element
            and es_ultimo == self._es_ultimo
        ):
            # Mismo elemento: no se reconstruye nada, para no arrancarle el foco
            # al campo que se este editando.
            self._revalidar()
            return
        self._element = element
        self._es_ultimo = es_ultimo
        self._limpiar()
        if element is None:
            self._cabecera.setText(t("Select an element of the section."))
            return
        d = element.definicion()
        self._cabecera.setText(f"<b>{t(d.label)}</b><br>{t(d.descripcion)}")

        codigo = QLineEdit(element.codigo)
        codigo.setToolTip(
            t(
                "Point code. It is what the meshing uses to stitch one section "
                "to the next, and the name of the output feature line. The "
                "L_ / R_ prefix is added automatically."
            )
        )
        codigo.textEdited.connect(self._set_codigo)
        self._form.addRow(t("Code"), codigo)
        self._filas.append(codigo)

        for spec in d.params:
            if es_ultimo and spec.si_ultimo == ULTIMO_OCULTO:
                continue
            widget, pista = self._editor(spec)
            etiqueta = self._etiqueta(spec)
            self._form.addRow(etiqueta, widget)
            if pista is not None:
                self._form.addRow("", pista)
            if es_ultimo and spec.si_ultimo == ULTIMO_GRIS:
                etiqueta.setEnabled(False)
                widget.setEnabled(False)
                if pista is not None:
                    pista.setText(
                        f"<span style='color:{COL_OK}'>"
                        + t("only if there is another element behind to hand over to")
                        + "</span>"
                    )
            self._filas.append(widget)
        self._revalidar()

    # -- construccion ------------------------------------------------------
    def _etiqueta(self, spec) -> QLabel:
        lab = QLabel(t(spec.label) + (f" ({spec.unit})" if spec.unit else ""))
        if spec.tooltip:
            lab.setToolTip(t(spec.tooltip))
        return lab

    def _editor(self, spec) -> tuple:
        crudo = self._element.raw(spec.name)
        if spec.kind == "bool":
            w = QCheckBox()
            w.setChecked(bool(crudo))
            w.toggled.connect(lambda v, s=spec: self._set(s, bool(v)))
            return w, None
        if spec.kind == "choice":
            # Se muestra traducido pero se guarda la clave interna: el valor va
            # a la libreria de secciones y tiene que leerse igual en los dos
            # idiomas.
            w = QComboBox()
            for c in spec.choices:
                w.addItem(etiqueta_opcion(str(c)), str(c))
            i = w.findData(str(crudo))
            w.setCurrentIndex(max(0, i))
            w.currentIndexChanged.connect(
                lambda i, s=spec, c=w: self._set(s, c.itemData(i))
            )
            return w, None

        w = QLineEdit(str(crudo))
        w.setToolTip(self._ayuda(spec))
        pista = QLabel()
        f = QFont(pista.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1.0))
        pista.setFont(f)
        w.setProperty("spec_name", spec.name)
        w.setProperty("pista", pista)
        w.textEdited.connect(lambda v, s=spec, ed=w: self._set_texto(s, v, ed))
        return w, pista

    def _ayuda(self, spec) -> str:
        base = t(spec.tooltip or spec.label)
        extra = {
            "slope": t("V:H slope, e.g. 1:1.5. 66% or 1.5 also work."),
            "slope_opt": t(
                "V:H slope. Empty or 0 = inherited from the previous element."
            ),
            "percent": t("Slope in %, signed."),
            "int": t("Whole number."),
            "float": t("Number in metres."),
        }.get(spec.kind, "")
        return (
            base
            + chr(10)
            + extra
            + chr(10) * 2
            + t(
                "It also accepts '@field' to read it from the alignment layer, "
                "or '=expression' of QGIS."
            )
        )

    # -- edicion -----------------------------------------------------------
    def _set_codigo(self, texto: str) -> None:
        if self._element is None:
            return
        self._element.codigo = texto.strip()
        self.cambiado.emit()

    def _set(self, spec, valor: Any) -> None:
        if self._element is None:
            return
        self._element.params[spec.name] = valor
        self.cambiado.emit()

    def _set_texto(self, spec, texto: str, editor: QLineEdit) -> None:
        if self._element is None:
            return
        self._element.params[spec.name] = texto
        self._pintar(spec, texto, editor)
        self.cambiado.emit()

    def _pintar(self, spec, texto: str, editor: QLineEdit) -> None:
        pista = editor.property("pista")
        if pista is None:
            return
        if es_dinamico(texto):
            pista.setText(
                f"<span style='color:{COL_DINAMICO}'>"
                + t("will be resolved per feature")
                + "</span>"
            )
            editor.setStyleSheet("")
            return
        try:
            valor = coerce(texto, spec.kind, spec.label)
        except ParamError as exc:
            pista.setText(f"<span style='color:{COL_ERROR}'>{exc}</span>")
            editor.setStyleSheet(f"border:1px solid {COL_ERROR};")
            return
        editor.setStyleSheet("")
        pista.setText(
            f"<span style='color:{COL_OK}'>= {self._formato(spec, valor)}</span>"
        )

    def _formato(self, spec, valor) -> str:
        if spec.kind in ("slope", "slope_opt"):
            if not valor:
                return t("inherited")
            return f"{format_slope(valor)}  ({100.0 * valor:.1f}%)"
        if spec.kind == "percent":
            return f"{valor:g} %"
        if spec.kind == "int":
            return f"{int(valor)}"
        return f"{valor:g}{(' ' + spec.unit) if spec.unit else ''}"

    def _revalidar(self) -> None:
        if self._element is None:
            return
        for w in self._filas:
            # Los campos inhabilitados llevan en su pista el motivo, no el valor.
            if isinstance(w, QLineEdit) and w.property("spec_name") and w.isEnabled():
                nombre = w.property("spec_name")
                spec = self._element.definicion().spec(nombre)
                self._pintar(spec, w.text(), w)

    def _limpiar(self) -> None:
        while self._form.count():
            item = self._form.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
        self._filas = []


__all__ = ["ParamForm"]
