"""Dialogo principal: elegir capas y opciones, calcular y cargar el resultado.

Es la via rapida (el algoritmo de Processing es la via para modelos y lotes).
Todo lo que se calcula aqui sale como capas en memoria, y el TIN se puede
guardar ademas como malla ``.2dm`` para tenerlo como capa de malla de verdad.
"""

from __future__ import annotations

import os
import traceback
from typing import Optional

from qgis.core import (
    QgsMapLayerProxyModel,
    QgsProject,
    QgsMeshLayer,
    QgsVectorLayer,
)
from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .ayuda_dialog import abrir_ayuda_en
from .dialogos import ajustar_a_pantalla, cuerpo_con_scroll
from .qtcompat import (
    BOTON_SI,
    ROL_ACCION,
    ROL_AYUDA,
    ROL_RECHAZAR,
    ejecutar_modal,
)

from ..core.library import AssemblyLibrary, default_library
from ..core.merge import MergeOptions
from ..core.params import ParamError
from ..core.resolver import SectionOptions
from ..core.tin import mesh_stats, write_2dm
from ..gis.alignment import StationOptions
from ..gis.build import (
    COTA_CONSTANTE,
    COTA_DIRECTRIZ,
    COTA_OFFSET_TERRENO,
    COTA_TERRENO,
    BuildOptions,
    build_corridor,
)
from ..gis.outputs import (
    cargar_en_grupo,
    etiqueta_capa,
    layers_from_result,
    nombre_grupo,
    tabla_medicion,
)
from ..gis.terrain import TerrainError, make_terrain
from ..i18n import t
from .assembly_editor import AssemblyEditor


#: Salto de linea para los mensajes de varias lineas.
NL = chr(10)


def _c() -> str:
    """Titulo de los avisos del dialogo."""
    return t("Corridor")


def _z() -> str:
    """Titulo de los avisos de la escritura de cota en la Z."""
    return t("Elevation into the Z")


#: Modos de cota del eje, en el mismo orden que el desplegable.
MODOS_COTA = (COTA_TERRENO, COTA_DIRECTRIZ, COTA_CONSTANTE, COTA_OFFSET_TERRENO)


def _filtro(nombre: str):
    """``QgsMapLayerProxyModel`` cambio a enums con ambito en QGIS 4."""
    scoped = getattr(QgsMapLayerProxyModel, "Filters", None)
    for fuente in (scoped, QgsMapLayerProxyModel):
        if fuente is not None and hasattr(fuente, nombre):
            return getattr(fuente, nombre)
    raise AttributeError(nombre)


class _Feedback:
    """Adaptador de feedback contra la barra de progreso del dialogo."""

    def __init__(self, dialogo):
        self.d = dialogo
        self.cancelado = False

    def setProgress(self, p: float) -> None:
        self.d.barra.setValue(int(max(0.0, min(100.0, p))))
        QApplication.processEvents()

    def pushInfo(self, texto: str) -> None:
        self.d.log(texto)

    def pushWarning(self, texto: str) -> None:
        self.d.log(texto, aviso=True)

    def reportError(self, texto: str, _fatal: bool = False) -> None:
        self.d.log(texto, aviso=True)

    def isCanceled(self) -> bool:
        return self.cancelado


class CorridorDialog(QDialog):
    def __init__(self, iface, library_path: str, parent=None, plugin=None):
        super().__init__(parent)
        self.iface = iface
        #: El plugin, para poder pasarle el resultado al panel de perfiles.
        self.plugin = plugin
        self.library_path = library_path
        self.library = self._cargar_libreria()
        self.setWindowTitle(t("Corridor: extrude typical cross section"))
        ajustar_a_pantalla(self, 660, 640)
        self._resultado = None

        #: Si el usuario escribe el nombre del grupo, deja de seguir a la capa.
        self._grupo_editado_a_mano = False

        # El cuerpo va en un area con desplazamiento y la botonera fuera:
        # asi el dialogo cabe en cualquier pantalla y los botones se ven
        # siempre.
        lay, raiz = cuerpo_con_scroll(self)
        pestanas = QTabWidget()
        # Las salidas se construyen antes que las entradas porque el combo de
        # capas dispara layerChanged al crearse y ese slot escribe en ed_grupo.
        salidas = self._tab_salidas()
        pestanas.addTab(self._tab_entradas(), t("Inputs"))
        pestanas.addTab(self._tab_opciones(), t("Options"))
        pestanas.addTab(salidas, t("Outputs"))
        lay.addWidget(pestanas)

        self.barra = QProgressBar()
        self.barra.setRange(0, 100)
        lay.addWidget(self.barra)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setMinimumHeight(120)
        lay.addWidget(self.txt_log, 1)

        botones = QDialogButtonBox()
        self.btn_calcular = botones.addButton(t("Compute"), ROL_ACCION)
        self.btn_calcular.clicked.connect(self.calcular)
        btn_ayuda = botones.addButton(t("Help"), ROL_AYUDA)
        btn_ayuda.clicked.connect(lambda: abrir_ayuda_en("calculo", self))
        botones.addButton(t("Close"), ROL_RECHAZAR)
        botones.rejected.connect(self.reject)
        raiz.addWidget(botones)
        self._sincronizar_secciones()

    # -- pestanas ----------------------------------------------------------
    def _tab_entradas(self) -> QWidget:
        w = QWidget()
        lay = QFormLayout(w)
        self.cmb_dir = QgsMapLayerComboBox()
        self.cmb_dir.setFilters(_filtro("LineLayer"))
        self.cmb_dir.layerChanged.connect(self._capa_cambiada)
        lay.addRow(t("Alignments (lines)"), self.cmb_dir)

        self.chk_seleccion = QCheckBox(t("selected features only"))
        lay.addRow("", self.chk_seleccion)

        self.cmb_dem = QgsMapLayerComboBox()
        try:
            self.cmb_dem.setFilters(
                _filtro("RasterLayer") | _filtro("MeshLayer")
            )
        except AttributeError:
            self.cmb_dem.setFilters(_filtro("RasterLayer"))
        lay.addRow(t("Terrain (DEM)"), self.cmb_dem)

        fila = QHBoxLayout()
        self.ed_lib = QLineEdit(self.library_path)
        self.ed_lib.setReadOnly(True)
        btn_editar = QPushButton(t("Edit sections..."))
        btn_editar.clicked.connect(self._editar_secciones)
        fila.addWidget(self.ed_lib, 1)
        fila.addWidget(btn_editar)
        lay.addRow(t("Section library"), fila)

        self.cmb_campo = QgsFieldComboBox()
        self.cmb_campo.setAllowEmptyFieldName(True)
        self.cmb_campo.setToolTip(
            t(
                "Field whose value says which section applies to each "
                "feature. If left empty, every feature uses the default "
                "section."
            )
        )
        lay.addRow(t("Field with the section"), self.cmb_campo)

        self.cmb_seccion = QComboBox()
        lay.addRow(t("Default section"), self.cmb_seccion)

        fila_cota = QHBoxLayout()
        self.cmb_cota = QComboBox()
        self.cmb_cota.addItems(
            [
                t("from the terrain (DEM)"),
                t("from the alignment Z"),
                t("constant value:"),
                t("offset from the terrain:"),
            ]
        )
        self.cmb_cota.setToolTip(
            t("Where the axis elevation comes from at each station.")
            + NL
            + t("- from the terrain: the axis rests on the DEM.")
            + NL
            + t(
                "- from the alignment Z: a grade line already designed in "
                "the geometry."
            )
            + NL
            + t(
                "- constant value: level platform at that elevation (a "
                "yard, the basin of a pond, or to try out a grade line)."
            )
            + NL
            + t(
                "- offset from the terrain: grade line parallel to the "
                "terrain at that distance, positive above and negative "
                "below. It gives a cut or a fill of constant thickness (a "
                "pavement box, an excavated track, a bund)."
            )
        )
        self.cmb_cota.currentIndexChanged.connect(self._cota_cambiada)
        self.sp_cota = _spin(0.0, -10000.0, 10000.0, " m", 3)
        self.btn_cota_a_z = QPushButton(t("Write into the layer Z"))
        self.btn_cota_a_z.setToolTip(
            t(
                "Puts that elevation in the Z of every alignment vertex, so "
                "you can carry on with 'axis elevation = alignment Z' and "
                "then edit the grade line vertex by vertex."
            )
            + NL * 2
            + t(
                "If the layer is 2D it cannot take Z (its provider decides "
                "that): a new layer with Z is created instead."
            )
        )
        self.btn_cota_a_z.clicked.connect(self._cota_a_z)
        fila_cota.addWidget(self.cmb_cota, 1)
        fila_cota.addWidget(self.sp_cota)
        fila_cota.addWidget(self.btn_cota_a_z)
        lay.addRow(t("Axis elevation"), fila_cota)
        self._cota_cambiada(0)
        return w

    def _cota_cambiada(self, indice: int) -> None:
        """El campo y el boton solo aplican a las dos opciones con valor."""
        con_valor = indice in (2, 3)
        self.sp_cota.setEnabled(con_valor)
        self.btn_cota_a_z.setEnabled(con_valor)
        if indice == 3:
            self.sp_cota.setToolTip(
                t(
                    "Height relative to the terrain: positive above, "
                    "negative below. The grade line stays parallel to the "
                    "terrain."
                )
            )
        else:
            self.sp_cota.setToolTip(
                t("Axis elevation, the same at every station.")
            )

    def _cota_a_z(self) -> None:
        """Escribe la cota constante en la Z de la capa de directrices."""
        from ..gis.rasante import admite_z, asignar_cota

        capa = self.cmb_dir.currentLayer()
        if capa is None:
            QMessageBox.warning(self, _z(), t("Choose the alignment layer."))
            return
        valor = self.sp_cota.value()
        drapear = self.cmb_cota.currentIndex() == 3
        solo = self.chk_seleccion.isChecked()
        cuantos = (
            capa.selectedFeatureCount() if solo else capa.featureCount()
        )
        if solo and not cuantos:
            QMessageBox.warning(
                self, _z(), t("No feature is selected.")
            )
            return

        terreno = None
        if drapear:
            terreno = self._terreno_para_drapear(capa)
            if terreno is None:
                return

        if QMessageBox.question(
            self, _z(), self._aviso_de_cota(capa, valor, drapear, cuantos)
        ) != BOTON_SI:
            return

        ok, mensajes, nueva = asignar_cota(
            capa, valor, solo, terreno=terreno, offset=valor
        )
        for m in mensajes:
            self.log(m, aviso=not ok)
        if not ok:
            QMessageBox.warning(self, _z(), NL.join(mensajes))
            return
        if nueva is not None:
            QgsProject.instance().addMapLayer(nueva)
            self.cmb_dir.setLayer(nueva)
        # Ya hay rasante en la geometria: lo natural es seguir con esa opcion.
        self.cmb_cota.setCurrentIndex(1)
        QMessageBox.information(self, _z(), NL.join(mensajes))

    def _terreno_para_drapear(self, capa):
        """Terreno con el que drapear, o ``None`` avisando de lo que falta."""
        dem = self.cmb_dem.currentLayer()
        if dem is None:
            QMessageBox.warning(
                self,
                _z(),
                t("Writing an offset over the terrain needs the DEM."),
            )
            return None
        try:
            return make_terrain(
                dem,
                capa.crs(),
                transform_context=QgsProject.instance().transformContext(),
            )
        except TerrainError as exc:
            QMessageBox.critical(self, _z(), str(exc))
            return None

    @staticmethod
    def _aviso_de_cota(capa, valor: float, drapear: bool, cuantos: int) -> str:
        """Lo que se le pregunta al usuario antes de tocarle la geometria."""
        from ..gis.rasante import admite_z

        que = (
            t("the terrain elevation {v:+.3f} m", v=valor)
            if drapear
            else t("the elevation {v:.3f} m", v=valor)
        )
        seguir = t("Continue?")
        if admite_z(capa):
            return (
                t(
                    "{que} is going to be written into the Z of {n} "
                    "features of '{capa}'.",
                    que=que,
                    n=cuantos,
                    capa=capa.name(),
                )
                + NL * 2
                + t("The Z they have now is lost.")
                + " "
                + seguir
            )
        return (
            t(
                "'{capa}' is a 2D layer and its provider cannot store Z, so "
                "it is not modified: a new layer will be created with {que}.",
                capa=capa.name(),
                que=que,
            )
            + NL * 2
            + seguir
        )

    def _tab_opciones(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)

        g1 = QGroupBox(t("Stations along the alignment"))
        f1 = QFormLayout(g1)
        self.sp_paso_pk = _spin(5.0, 0.01, 10000.0, " m", 2)
        f1.addRow(t("Station interval"), self.sp_paso_pk)
        self.chk_vertices = QCheckBox(t("add a station at every line vertex"))
        self.chk_vertices.setChecked(True)
        self.chk_vertices.setToolTip(
            t(
                "Recommended: at the vertices the section is placed on the "
                "bisector, and without a station there the mesh opens up "
                "on the outside of the curve."
            )
        )
        f1.addRow("", self.chk_vertices)
        self.sp_pk0 = _spin(0.0, -1e6, 1e6, "", 3)
        f1.addRow(t("Start station"), self.sp_pk0)
        self.sp_intervalo_pk = _spin(100.0, 0.0, 100000.0, " m", 1)
        self.sp_intervalo_pk.setToolTip(
            t(
                "Interval of the stations labelled on the axis. It is "
                "independent of the computation step: you can compute "
                "every 5 m and label every 100. 0 = do not generate the "
                "stations layer."
            )
        )
        f1.addRow(t("Labelled station interval"), self.sp_intervalo_pk)
        lay.addWidget(g1)

        g2 = QGroupBox(t("Cut with the terrain"))
        f2 = QFormLayout(g2)
        self.sp_paso_dem = _spin(0.0, 0.0, 100.0, " m", 2)
        self.sp_paso_dem.setToolTip(
            t("0 = automatic from the DEM resolution")
        )
        f2.addRow(t("Sampling step"), self.sp_paso_dem)
        self.sp_ancho_max = _spin(200.0, 1.0, 5000.0, " m", 1)
        self.sp_ancho_max.setToolTip(
            t(
                "Maximum distance from the axis at which the terrain is "
                "sought. If a slope does not cut within this width it is "
                "marked as truncated."
            )
        )
        f2.addRow(t("Maximum half-width"), self.sp_ancho_max)
        lay.addWidget(g2)

        g3 = QGroupBox(t("Merge with the base terrain"))
        f3 = QFormLayout(g3)
        self.chk_fusion = QCheckBox(
            t("return a single surface: corridor + surrounding terrain")
        )
        self.chk_fusion.toggled.connect(self._fusion_cambiada)
        f3.addRow("", self.chk_fusion)
        self.sp_celda = _spin(0.0, 0.0, 500.0, " m", 2)
        self.sp_celda.setToolTip(t("0 = DEM resolution"))
        f3.addRow(t("Terrain cell"), self.sp_celda)
        self.sp_holgura = _spin(50.0, 0.0, 100000.0, " m", 1)
        f3.addRow(t("Margin around"), self.sp_holgura)
        lay.addWidget(g3)
        lay.addStretch(1)
        self._fusion_cambiada(False)
        return w

    def _tab_salidas(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        g = QGroupBox(t("Layers to create"))
        f = QVBoxLayout(g)
        self.chk_tin = QCheckBox(t("TIN as polygons (one polygon per triangle)"))
        self.chk_tin.setChecked(True)
        self.chk_puntos = QCheckBox(t("points of every section"))
        self.chk_medicion = QCheckBox(
            t("earthwork table (areas per section and earthwork volumes)")
        )
        self.chk_medicion.setChecked(True)
        for c in (
            self.chk_tin,
            self.chk_puntos,
            self.chk_medicion,
        ):
            f.addWidget(c)
        fila_esp = QHBoxLayout()
        self.sp_esponjamiento = _spin(1.0, 0.5, 1.5, "", 2)
        self.sp_esponjamiento.setToolTip(
            t(
                "Cut-to-fill conversion factor for the mass haul diagram. "
                "1.0 = one cubic metre excavated fills one cubic metre; "
                "0.9 = only 90 % is usable."
            )
        )
        fila_esp.addWidget(QLabel(t("Bulking factor")))
        fila_esp.addWidget(self.sp_esponjamiento)
        fila_esp.addStretch(1)
        f.addLayout(fila_esp)
        f.addWidget(
            QLabel(
                "<i>"
                + t(
                    "The cross sections, the feature lines and the "
                    "footprint are always created."
                )
                + "</i>"
            )
        )
        lay.addWidget(g)

        g4 = QGroupBox(t("Layer group"))
        f4 = QVBoxLayout(g4)
        self.chk_grupo = QCheckBox(
            t("put the layers in a group of the layers panel")
        )
        self.chk_grupo.setChecked(True)
        self.chk_grupo.toggled.connect(self._grupo_cambiado)
        f4.addWidget(self.chk_grupo)
        fila = QHBoxLayout()
        self.ed_grupo = QLineEdit()
        self.ed_grupo.setToolTip(
            t(
                "Group name. By default, that of the alignment layer with "
                "the '-corridor' suffix. Each computation creates a new "
                "group, so alternatives can be compared without mixing."
            )
        )
        fila.addWidget(QLabel(t("Name")))
        fila.addWidget(self.ed_grupo, 1)
        f4.addLayout(fila)
        self.ed_grupo.textEdited.connect(self._grupo_tecleado)
        lay.addWidget(g4)

        g2 = QGroupBox(t("2DM mesh (native QGIS mesh layer)"))
        f2 = QHBoxLayout(g2)
        self.ed_2dm = QLineEdit()
        self.ed_2dm.setPlaceholderText(t("optional: path of the .2dm file"))
        btn = QPushButton("...")
        btn.setMaximumWidth(32)
        btn.clicked.connect(self._elegir_2dm)
        self.chk_cargar_2dm = QCheckBox(t("load"))
        self.chk_cargar_2dm.setChecked(True)
        f2.addWidget(self.ed_2dm, 1)
        f2.addWidget(btn)
        f2.addWidget(self.chk_cargar_2dm)
        lay.addWidget(g2)
        lay.addStretch(1)
        return w

    # -- libreria ----------------------------------------------------------
    def _cargar_libreria(self) -> AssemblyLibrary:
        if self.library_path and os.path.exists(self.library_path):
            try:
                return AssemblyLibrary.load(self.library_path)
            except (OSError, ParamError):
                pass
        lib = default_library()
        if self.library_path:
            try:
                os.makedirs(os.path.dirname(self.library_path), exist_ok=True)
                lib.save(self.library_path)
            except OSError:
                pass
        return lib

    def _editar_secciones(self) -> None:
        dlg = AssemblyEditor(self.library, self.library_path, self)
        if ejecutar_modal(dlg):
            self.library = dlg.library
            self.library_path = dlg.path
            self.ed_lib.setText(self.library_path)
            self._sincronizar_secciones()

    def _sincronizar_secciones(self) -> None:
        actual = self.cmb_seccion.currentText()
        self.cmb_seccion.clear()
        self.cmb_seccion.addItems(self.library.names())
        i = self.cmb_seccion.findText(actual)
        if i >= 0:
            self.cmb_seccion.setCurrentIndex(i)

    def _capa_cambiada(self, capa) -> None:
        self.cmb_campo.setLayer(capa if isinstance(capa, QgsVectorLayer) else None)
        # El nombre del grupo sigue a la capa mientras el usuario no lo toque a
        # mano; si lo ha escrito el, se respeta.
        if not self._grupo_editado_a_mano:
            self.ed_grupo.setText(nombre_grupo(capa))

    def _grupo_cambiado(self, activo: bool) -> None:
        self.ed_grupo.setEnabled(activo)

    def _grupo_tecleado(self, texto: str) -> None:
        self._grupo_editado_a_mano = bool(texto.strip())

    def _fusion_cambiada(self, activo: bool) -> None:
        self.sp_celda.setEnabled(activo)
        self.sp_holgura.setEnabled(activo)

    def _elegir_2dm(self) -> None:
        ruta, _ = QFileDialog.getSaveFileName(
            self, t("Save mesh"), "corredor.2dm", t("SMS 2DM mesh (*.2dm)")
        )
        if ruta:
            self.ed_2dm.setText(ruta if ruta.lower().endswith(".2dm") else ruta + ".2dm")

    # -- log ---------------------------------------------------------------
    def log(self, texto: str, aviso: bool = False) -> None:
        color = "#b06000" if aviso else "#333333"
        self.txt_log.append(f'<span style="color:{color}">{texto}</span>')
        QApplication.processEvents()

    # -- calculo -----------------------------------------------------------
    def calcular(self) -> None:
        capa = self.cmb_dir.currentLayer()
        dem = self.cmb_dem.currentLayer()
        if capa is None:
            QMessageBox.warning(self, _c(), t("Choose the alignment layer."))
            return
        if dem is None:
            QMessageBox.warning(self, _c(), t("Choose the terrain layer."))
            return
        if not self.library.names():
            QMessageBox.warning(
                self, _c(), t("The section library is empty.")
            )
            return

        self.txt_log.clear()
        self.barra.setValue(0)
        self.btn_calcular.setEnabled(False)
        fb = _Feedback(self)
        try:
            terreno = make_terrain(
                dem, capa.crs(), transform_context=QgsProject.instance().transformContext()
            )
            opts = BuildOptions(
                stations=StationOptions(
                    paso=self.sp_paso_pk.value(),
                    incluir_vertices=self.chk_vertices.isChecked(),
                    pk_inicio=self.sp_pk0.value(),
                ),
                section=SectionOptions(
                    paso=self.sp_paso_dem.value(),
                    ancho_max=self.sp_ancho_max.value(),
                ),
                cota_eje=MODOS_COTA[self.cmb_cota.currentIndex()],
                cota_constante=self.sp_cota.value(),
                offset_terreno=self.sp_cota.value(),
                campo_seccion=self.cmb_campo.currentField() or "",
                seccion_defecto=self.cmb_seccion.currentText(),
                solo_seleccionados=self.chk_seleccion.isChecked(),
                fusionar=self.chk_fusion.isChecked(),
                merge=MergeOptions(
                    celda=self.sp_celda.value(), holgura=self.sp_holgura.value()
                ),
                intervalo_pk=self.sp_intervalo_pk.value(),
            )
            self._terreno = terreno
            res = build_corridor(capa, terreno, self.library.assemblies, opts, fb)
        except (TerrainError, ValueError, ParamError) as exc:
            self.log(str(exc), aviso=True)
            QMessageBox.critical(self, _c(), str(exc))
            self.btn_calcular.setEnabled(True)
            return
        except Exception as exc:  # noqa: BLE001
            self.log(traceback.format_exc(), aviso=True)
            QMessageBox.critical(
                self,
                _c(),
                t("Unexpected error: {error}", error=exc)
                + NL * 2
                + t("Check the log."),
            )
            self.btn_calcular.setEnabled(True)
            return

        self._resultado = res
        self.log("<b>" + res.stats() + "</b>")
        if res.mesh.is_empty:
            QMessageBox.warning(
                self,
                _c(),
                t(
                    "No triangle has been generated. Check that the DEM "
                    "covers the alignments and that they are in the same "
                    "reference system."
                ),
            )
            self.btn_calcular.setEnabled(True)
            return

        titulo = self.ed_grupo.text().strip() or nombre_grupo(capa)
        self._cargar_resultado(capa, res)
        if self.plugin is not None:
            self.plugin.guardar_resultado(
                res, self.sp_esponjamiento.value(), nombre=titulo
            )
        self.btn_calcular.setEnabled(True)

    def _cargar_resultado(self, capa, res) -> None:
        proyecto = QgsProject.instance()
        agrupar = self.chk_grupo.isChecked()
        titulo = self.ed_grupo.text().strip() or nombre_grupo(capa)
        capas = [
            c
            for c in layers_from_result(
                res,
                capa.crs(),
                # Dentro de un grupo las capas van sin prefijo: el grupo ya dice
                # de que alineacion son.
                prefijo="" if agrupar else titulo,
                con_puntos=self.chk_puntos.isChecked(),
                con_triangulos=self.chk_tin.isChecked(),
                fusionada=self.chk_fusion.isChecked(),
                tz=getattr(self, "_terreno", None),
                con_pk=self.sp_intervalo_pk.value() > 0,
            )
            if c.featureCount() > 0
        ]

        if self.chk_medicion.isChecked():
            tabla = tabla_medicion(
                res,
                _nombre_capa_medicion(agrupar, titulo),
                self.sp_esponjamiento.value(),
            )
            if tabla.featureCount():
                capas.append(tabla)

        grupo = None
        if agrupar and capas:
            grupo = cargar_en_grupo(capas, titulo, proyecto)
            self.log(t("group created: {n}", n=grupo.name()))
        else:
            for c in capas:
                proyecto.addMapLayer(c)
        for c in capas:
            self.log(
                "  "
                + t(
                    "layer added: {n} ({f})", n=c.name(), f=c.featureCount()
                )
            )

        ruta = self.ed_2dm.text().strip()
        if ruta:
            self._escribir_2dm(ruta, res, proyecto, grupo)

    def _escribir_2dm(self, ruta: str, res, proyecto, grupo) -> None:
        """Escribe la malla en 2DM y, si se pide, la carga como capa de malla."""
        try:
            write_2dm(ruta, res.mesh_final)
        except OSError as exc:
            self.log(t("could not write the 2dm: {error}", error=exc), aviso=True)
            return
        self.log(
            t(
                "mesh written: {ruta} ({stats})",
                ruta=ruta,
                stats=mesh_stats(res.mesh_final),
            )
        )
        if not self.chk_cargar_2dm.isChecked():
            return
        ml = QgsMeshLayer(ruta, os.path.basename(ruta), "mdal")
        if not ml.isValid():
            self.log(
                t(
                    "the 2dm was written but QGIS could not load it (is the "
                    "MDAL provider missing?)"
                ),
                aviso=True,
            )
            return
        if grupo is not None:
            # Al final del grupo: la malla va debajo de todo.
            proyecto.addMapLayer(ml, False)
            grupo.addLayer(ml)
        else:
            proyecto.addMapLayer(ml)
        self.log("  " + t("mesh layer added"))


def _nombre_capa_medicion(agrupar: bool, titulo: str) -> str:
    etiqueta = etiqueta_capa("mediciones")
    return etiqueta if agrupar else f"{titulo} - {etiqueta}"


def _spin(valor, minimo, maximo, sufijo, decimales) -> QDoubleSpinBox:
    w = QDoubleSpinBox()
    w.setRange(minimo, maximo)
    w.setDecimals(decimales)
    w.setValue(valor)
    if sufijo:
        w.setSuffix(sufijo)
    return w


__all__ = ["CorridorDialog"]
