"""Vista de la curva de embalse: volumen y superficie contra la cota.

Dos paneles apilados sobre el mismo eje de cotas en vez de un doble eje Y: son
dos magnitudes distintas, hm3 y ha, y superponerlas en un solo grafico obliga a
mirar dos escalas a la vez para leer un solo punto.

Se dibuja con ``QPainter``, como el resto de vistas del plugin, para no depender
de matplotlib: asi el mismo codigo sirve para la pantalla y para el PNG que se
exporta, y el PNG sale igual en cualquier instalacion de QGIS.
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

from qgis.PyQt.QtCore import QPointF, QRectF, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from qgis.PyQt.QtWidgets import QWidget

from .qtcompat import (
    AL_CENTRO,
    AL_DER,
    AL_IZQ,
    AL_VCENTRO,
    ANTIALIAS,
    POL_EXPANDIR,
    SIN_PINCEL,
    SIN_PLUMA,
)
from ..i18n import t

COL_FONDO = QColor(252, 252, 251)
COL_PANEL = QColor(255, 255, 255)
COL_REJILLA = QColor(225, 224, 217)
COL_EJE = QColor(160, 158, 148)
COL_TEXTO = QColor(30, 30, 30)
COL_SUAVE = QColor(120, 118, 112)
COL_VOLUMEN = QColor(42, 120, 214)
COL_AREA = QColor(235, 104, 52)

MARGEN_IZQ = 62.0
MARGEN_DER = 14.0
MARGEN_SUP = 22.0
MARGEN_INF = 34.0
SEPARACION = 30.0


def _paso_bonito(bruto: float) -> float:
    """Paso de rejilla en 1, 2, 5 x 10^n."""
    if bruto <= 0:
        return 1.0
    exp = math.floor(math.log10(bruto))
    base = bruto / (10.0**exp)
    for corte, valor in ((1.5, 1.0), (3.5, 2.0), (7.5, 5.0)):
        if base < corte:
            return valor * (10.0**exp)
    return 10.0 ** (exp + 1)


def _formato(valor: float, decimales: int) -> str:
    """Numero con coma decimal y punto de millares, como se escribe aqui."""
    texto = f"{valor:,.{decimales}f}"
    return texto.replace(",", " ").replace(".", ",")


class Panel:
    """Un panel del grafico: su rectangulo y su transformacion."""

    def __init__(self, rect: QRectF, x0: float, x1: float, y0: float, y1: float):
        self.rect = rect
        self.x0, self.x1 = x0, x1
        self.y0, self.y1 = y0, y1

    def px(self, x: float, y: float) -> QPointF:
        ax = self.rect.width() / max(self.x1 - self.x0, 1e-9)
        ay = self.rect.height() / max(self.y1 - self.y0, 1e-9)
        return QPointF(
            self.rect.left() + (x - self.x0) * ax,
            self.rect.bottom() - (y - self.y0) * ay,
        )


class CurvaView(QWidget):
    """Vista de una :class:`core.embalse.CurvaEmbalse`."""

    #: Cota sobre la que esta el raton, para que el dialogo la muestre.
    cota_recorrida = pyqtSignal(float)
    #: Cota pinchada: el dialogo dibuja ahi la lamina de agua.
    cota_pinchada = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(260)
        self.setSizePolicy(POL_EXPANDIR, POL_EXPANDIR)
        self.setMouseTracking(True)
        self.curva = None
        self.titulo = ""
        self.mensaje = t("Choose the DEM and compute the curve.")
        #: Cota resaltada con una vertical, normalmente la del raton.
        self.cursor: Optional[float] = None
        #: Cota fijada al pinchar, que se queda dibujada.
        self.fijada: Optional[float] = None
        self._paneles: List[Panel] = []

    # -- API ---------------------------------------------------------------
    def set_curva(self, curva, titulo: str = "") -> None:
        self.curva = curva if curva is not None and not curva.vacia else None
        self.titulo = titulo
        if self.curva is None:
            self.cursor = None
            self.fijada = None
        self.update()

    def limpiar(self, mensaje: str = "") -> None:
        self.curva = None
        self.mensaje = mensaje or t("No curve")
        self.update()

    def indice_de(self, cota: float) -> int:
        """Fila mas cercana a esa cota."""
        c = self.curva.cotas
        i = min(range(len(c)), key=lambda k: abs(c[k] - cota))
        return i

    def imagen(self, ancho: int = 1800, alto: int = 1200, escala_texto: float = 2.0):
        """Render de la vista a un ``QImage``, para exportar el PNG.

        Se dibuja a tamano grande con el texto proporcionalmente mayor, no se
        escala una captura de pantalla: asi el PNG sale nitido.
        """
        from qgis.PyQt.QtGui import QImage

        formato = getattr(getattr(QImage, "Format", QImage), "Format_ARGB32")
        img = QImage(ancho, alto, formato)
        img.fill(COL_FONDO)
        p = QPainter(img)
        p.setRenderHint(ANTIALIAS, True)
        cursor, self.cursor = self.cursor, None
        self._pintar(p, QRectF(0, 0, ancho, alto), escala_texto)
        self.cursor = cursor
        p.end()
        return img

    # -- interaccion -------------------------------------------------------
    def _cota_en(self, x: float) -> Optional[float]:
        if not self._paneles:
            return None
        panel = self._paneles[0]
        t = (x - panel.rect.left()) / max(panel.rect.width(), 1e-9)
        return panel.x0 + (panel.x1 - panel.x0) * min(max(t, 0.0), 1.0)

    def _x_del_evento(self, event) -> float:
        pos = getattr(event, "position", None)
        return pos().x() if callable(pos) else float(event.x())

    def mouseMoveEvent(self, event) -> None:
        if self.curva is None:
            return
        cota = self._cota_en(self._x_del_evento(event))
        if cota is None:
            return
        self.cursor = self.curva.cotas[self.indice_de(cota)]
        self.cota_recorrida.emit(self.cursor)
        self.update()

    def leaveEvent(self, _event) -> None:
        if self.cursor is not None:
            self.cursor = None
            self.update()

    def mousePressEvent(self, event) -> None:
        if self.curva is None:
            return
        cota = self._cota_en(self._x_del_evento(event))
        if cota is None:
            return
        self.fijada = self.curva.cotas[self.indice_de(cota)]
        self.cota_pinchada.emit(self.fijada)
        self.update()

    # -- pintado -----------------------------------------------------------
    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(ANTIALIAS, True)
        self._pintar(p, QRectF(self.rect()), 1.0)
        p.end()

    def _fuente(self, p: QPainter, puntos: float, negrita: bool = False) -> None:
        f = QFont(p.font())
        f.setPointSizeF(max(5.0, puntos))
        f.setBold(negrita)
        p.setFont(f)

    def _pintar(self, p: QPainter, area: QRectF, k: float) -> None:
        p.fillRect(area, COL_FONDO)
        self._paneles = []
        if self.curva is None:
            p.setPen(QPen(COL_SUAVE))
            self._fuente(p, 9.5 * k)
            p.drawText(area, AL_CENTRO, self.mensaje)
            return

        c = self.curva
        vol = c.vol_hm3
        area_ha = c.area_ha
        x0, x1 = c.cotas[0], c.cotas[-1]
        if x1 - x0 < 1e-9:
            x0, x1 = x0 - 0.5, x1 + 0.5

        sup = MARGEN_SUP * k + (16.0 * k if self.titulo else 0.0)
        alto_util = area.height() - sup - MARGEN_INF * k - SEPARACION * k
        alto_panel = max(30.0, alto_util / 2.0)
        izq = MARGEN_IZQ * k
        ancho = max(30.0, area.width() - izq - MARGEN_DER * k)

        p_vol = Panel(
            QRectF(izq, sup, ancho, alto_panel), x0, x1, 0.0, max(vol[-1], 1e-9) * 1.05
        )
        p_area = Panel(
            QRectF(izq, sup + alto_panel + SEPARACION * k, ancho, alto_panel),
            x0,
            x1,
            0.0,
            max(area_ha[-1], 1e-9) * 1.05,
        )
        self._paneles = [p_vol, p_area]

        if self.titulo:
            p.setPen(QPen(COL_TEXTO))
            self._fuente(p, 10.5 * k, True)
            p.drawText(
                QRectF(izq, 2.0 * k, ancho, 15.0 * k),
                AL_IZQ | AL_VCENTRO,
                self.titulo,
            )

        for panel, valores, color, rotulo, decimales, unidad in (
            (p_vol, vol, COL_VOLUMEN, t("Stored volume"), 3, "hm3"),
            (p_area, area_ha, COL_AREA, t("Flooded area"), 2, "ha"),
        ):
            self._panel(p, panel, valores, color, rotulo, decimales, unidad, k)

        # Eje de cotas: solo debajo del panel de abajo, es comun a los dos.
        self._eje_x(p, p_area, k)

    def _panel(
        self,
        p: QPainter,
        panel: Panel,
        valores: List[float],
        color: QColor,
        rotulo: str,
        decimales: int,
        unidad: str,
        k: float,
    ) -> None:
        p.setPen(SIN_PLUMA)
        p.setBrush(COL_PANEL)
        p.drawRect(panel.rect)

        # Rejilla horizontal con su escala.
        paso = _paso_bonito((panel.y1 - panel.y0) / 5.0)
        p.setPen(QPen(COL_REJILLA, 0.8 * k))
        self._fuente(p, 7.5 * k)
        y = 0.0
        while y <= panel.y1 + 1e-9:
            a = panel.px(panel.x0, y)
            b = panel.px(panel.x1, y)
            p.setPen(QPen(COL_REJILLA, 0.8 * k))
            p.drawLine(a, b)
            p.setPen(QPen(COL_SUAVE))
            p.drawText(
                QRectF(0.0, a.y() - 7.0 * k, panel.rect.left() - 5.0 * k, 14.0 * k),
                AL_DER | AL_VCENTRO,
                _formato(y, decimales),
            )
            y += paso

        # Rejilla vertical, en las mismas cotas que el eje.
        paso_x = _paso_bonito((panel.x1 - panel.x0) / 6.0)
        x = math.ceil(panel.x0 / paso_x) * paso_x
        p.setPen(QPen(COL_REJILLA, 0.8 * k))
        while x <= panel.x1:
            p.drawLine(panel.px(x, panel.y0), panel.px(x, panel.y1))
            x += paso_x

        p.setPen(QPen(COL_EJE, 1.0 * k))
        p.drawLine(panel.px(panel.x0, panel.y0), panel.px(panel.x1, panel.y0))
        p.drawLine(panel.px(panel.x0, panel.y0), panel.px(panel.x0, panel.y1))

        # La curva.
        poli = QPolygonF(
            [panel.px(c, v) for c, v in zip(self.curva.cotas, valores)]
        )
        # Relleno suave bajo la curva: ayuda a ver de un golpe donde esta el
        # grueso del volumen sin tener que seguir la linea.
        p.setBrush(QColor(color.red(), color.green(), color.blue(), 38))
        relleno = QPolygonF(poli)
        relleno.append(panel.px(self.curva.cotas[-1], panel.y0))
        relleno.append(panel.px(self.curva.cotas[0], panel.y0))
        p.setPen(SIN_PLUMA)
        p.drawPolygon(relleno)
        p.setBrush(SIN_PINCEL)
        p.setPen(QPen(color, 1.8 * k))
        p.drawPolyline(poli)

        # Titulo del panel y valor a coronacion, fuera del area de trazado.
        p.setPen(QPen(COL_TEXTO))
        self._fuente(p, 9.0 * k, True)
        p.drawText(
            QRectF(panel.rect.left(), panel.rect.top() - 15.0 * k, panel.rect.width(), 14.0 * k),
            AL_IZQ | AL_VCENTRO,
            rotulo,
        )
        p.setPen(QPen(COL_SUAVE))
        self._fuente(p, 8.0 * k)
        p.drawText(
            QRectF(panel.rect.left(), panel.rect.top() - 15.0 * k, panel.rect.width(), 14.0 * k),
            AL_DER | AL_VCENTRO,
            t(
                "at crest ({cota} m.a.s.l.)  {valor} {unidad}",
                cota=_formato(self.curva.cotas[-1], 2),
                valor=_formato(valores[-1], decimales),
                unidad=unidad,
            ),
        )

        # Cursor y cota fijada.
        for cota, col, ancho_pluma in (
            (self.fijada, COL_SUAVE, 1.4 * k),
            (self.cursor, COL_TEXTO, 1.0 * k),
        ):
            if cota is None:
                continue
            i = self.indice_de(cota)
            p.setPen(QPen(col, ancho_pluma))
            p.drawLine(panel.px(cota, panel.y0), panel.px(cota, panel.y1))
            centro = panel.px(cota, valores[i])
            p.setBrush(color)
            p.setPen(QPen(COL_PANEL, 1.6 * k))
            p.drawEllipse(centro, 3.4 * k, 3.4 * k)
            p.setBrush(COL_PANEL)
            etiqueta = (
                f"{_formato(cota, 2)} msnm   {_formato(valores[i], decimales)} {unidad}"
            )
            self._fuente(p, 8.0 * k)
            ancho_txt = p.fontMetrics().horizontalAdvance(etiqueta) + 8.0 * k
            a_la_izq = centro.x() + ancho_txt > panel.rect.right()
            caja = QRectF(
                centro.x() - (ancho_txt + 6.0 * k if a_la_izq else -6.0 * k),
                max(panel.rect.top() + 2.0 * k, centro.y() - 20.0 * k),
                ancho_txt,
                14.0 * k,
            )
            p.setPen(QPen(COL_REJILLA, 0.8 * k))
            p.drawRect(caja)
            p.setPen(QPen(COL_TEXTO))
            p.drawText(caja, AL_CENTRO, etiqueta)

    def _eje_x(self, p: QPainter, panel: Panel, k: float) -> None:
        paso = _paso_bonito((panel.x1 - panel.x0) / 6.0)
        x = math.ceil(panel.x0 / paso) * paso
        self._fuente(p, 7.5 * k)
        p.setPen(QPen(COL_SUAVE))
        while x <= panel.x1:
            q = panel.px(x, panel.y0)
            p.drawLine(q, QPointF(q.x(), q.y() + 3.0 * k))
            p.drawText(
                QRectF(q.x() - 30.0 * k, q.y() + 4.0 * k, 60.0 * k, 12.0 * k),
                AL_CENTRO,
                _formato(x, 2 if paso < 1.0 else 0),
            )
            x += paso
        p.setPen(QPen(COL_TEXTO))
        self._fuente(p, 8.0 * k)
        p.drawText(
            QRectF(panel.rect.left(), panel.rect.bottom() + 16.0 * k, panel.rect.width(), 14.0 * k),
            AL_CENTRO,
            t("Elevation (m.a.s.l.)"),
        )


def datos_de_lectura(curva, cota: float) -> Tuple[str, str, str]:
    """Los tres numeros que se leen en la barra al pasar el raton."""
    i = min(range(len(curva.cotas)), key=lambda k: abs(curva.cotas[k] - cota))
    return (
        f"{_formato(curva.cotas[i], 2)} msnm",
        f"{_formato(curva.vol_hm3[i], 3)} hm3",
        f"{_formato(curva.area_ha[i], 2)} ha",
    )


__all__ = ["CurvaView", "datos_de_lectura"]
