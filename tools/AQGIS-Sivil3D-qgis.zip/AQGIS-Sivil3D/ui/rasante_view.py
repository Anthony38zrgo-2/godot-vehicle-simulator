"""Vista **editable** de la rasante: el perfil longitudinal en modo digitalizacion.

Es el equivalente en alzado de digitalizar en planta: se arrastran vertices y
tiradores con el raton, y cada segmento puede ser recta, arco, Bezier o NURBS.
Ademas cada vertice interior admite un acuerdo vertical, que es lo que se usa de
verdad al proyectar una rasante.

Lo que se dibuja:

* el **terreno** en marron y la **rasante** en azul, con desmonte y terraplen
  sombreados en los mismos colores que el resto del plugin;
* los **vertices** como cuadraditos blancos, igual que los de la digitalizacion
  de QGIS, y el seleccionado en naranja;
* los **tiradores** de los segmentos curvos, con su poligonal de control a
  trazos, porque sin verla no hay manera de saber que se esta arrastrando;
* los rotulos que se leen mientras se proyecta: pendiente de cada tramo, cota y
  PK de cada vertice, y L y K de cada acuerdo.

La geometria esta en :mod:`core.rasante_geom`; aqui solo hay pixeles y raton.
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

from qgis.PyQt.QtCore import QPointF, QRectF, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from qgis.PyQt.QtWidgets import QWidget

from ..core.rasante_geom import ARCO, BEZIER, NURBS, RECTA, Rasante
from .qtcompat import (
    AL_CENTRO,
    AL_DER,
    AL_IZQ,
    AL_VCENTRO,
    ANTIALIAS,
    BOTON_DERECHO,
    BOTON_IZQUIERDO,
    BOTON_MEDIO,
    CURSOR_CRUZ,
    CURSOR_MANO,
    FOCO_FUERTE,
    LINEA_PUNTOS,
    LINEA_TRAZOS,
    MOD_CONTROL,
    MOD_MAYUSCULAS,
    POL_EXPANDIR,
    SIN_PINCEL,
    SIN_PLUMA,
    TECLA_A,
    TECLA_ESCAPE,
    TECLA_SUPRIMIR,
)

COL_FONDO = QColor(252, 252, 250)
COL_REJILLA = QColor(228, 228, 222)
COL_REJILLA_FINA = QColor(240, 240, 235)
COL_EJE = QColor(150, 150, 150)
COL_TERRENO = QColor(150, 105, 60)
COL_RASANTE = QColor(20, 90, 190)
COL_DESMONTE = QColor(214, 170, 60, 90)
COL_TERRAPLEN = QColor(90, 170, 90, 90)
COL_TEXTO = QColor(70, 70, 70)
COL_SUAVE = QColor(140, 138, 132)
COL_SEL = QColor(235, 104, 52)
COL_CONTROL = QColor(120, 60, 170)
COL_AVISO = QColor(190, 40, 40)
COL_BLANCO = QColor(255, 255, 255)
COL_MARCA_PK = QColor(20, 90, 190, 110)

MARGEN_IZQ = 54.0
MARGEN_DER = 16.0
MARGEN_SUP = 22.0
MARGEN_INF = 30.0

#: Radio de captura del raton, en pixeles. Generoso a proposito: un tirador que
#: no se coge a la primera hace que la herramienta parezca rota.
CAPTURA = 12.0
#: Medio lado del cuadradito de vertice y radio del tirador, en pixeles.
LADO_VERTICE = 4.2
RADIO_TIRADOR = 5.0

# Herramientas. Las cuatro primeras son las de digitalizacion de un segmento.
H_MOVER = "mover"
H_INSERTAR = "insertar"
H_BORRAR = "borrar"
H_RECTA = RECTA
H_ARCO = ARCO
H_BEZIER = BEZIER
H_NURBS = NURBS
H_CONTROL = "control"
HERRAMIENTAS = (
    H_MOVER,
    H_INSERTAR,
    H_BORRAR,
    H_RECTA,
    H_ARCO,
    H_BEZIER,
    H_NURBS,
    H_CONTROL,
)

from ..etiquetas import segmento as etiqueta_segmento
from ..i18n import t

#: Herramientas que son **modos**: se quedan activas hasta que se cambia.
MODOS = (H_MOVER, H_INSERTAR, H_BORRAR)
#: Herramientas que son **acciones de un solo uso**: se aplican al segmento y se
#: vuelve solo a Mover. Si se quedasen activas, el clic siguiente sobre un tirador
#: volveria a convertir el segmento en vez de arrastrarlo, que es justo lo que
#: hacia que pareciese que los tiradores no se podian mover.
ACCIONES = (H_RECTA, H_ARCO, H_BEZIER, H_NURBS, H_CONTROL)

#: Que hace cada herramienta, para el rotulo de ayuda del panel. El texto
#: original va en ingles y se traduce al pedirlo, con :func:`pista`.
PISTAS = {
    H_MOVER: (
        "Drag the squares (vertices) and the purple circles (curve "
        "handles). Double click inserts a vertex, right button removes it, "
        "Del deletes the selected one. Wheel = zoom, middle button = pan."
    ),
    H_INSERTAR: "Click where you want to insert a new vertex.",
    H_BORRAR: "Click the vertex you want to remove.",
    H_RECTA: "Click the segment you want to leave straight.",
    H_ARCO: (
        "Click the segment you want to turn into an arc. Then drag its "
        "handle: the arc passes through it."
    ),
    H_BEZIER: (
        "Click the segment you want to turn into a Bezier. Then drag its "
        "two handles."
    ),
    H_NURBS: (
        "Click the segment you want to turn into a NURBS. Then drag its "
        "handles, and use «+ control» to get more."
    ),
    H_CONTROL: "Click the NURBS you want to add a control point to.",
}


def pista(herramienta: str) -> str:
    """Texto de ayuda de la herramienta, en el idioma que este puesto."""
    return t(PISTAS.get(herramienta, ""))


def _paso_bonito(bruto: float) -> float:
    if bruto <= 0:
        return 1.0
    exp = math.floor(math.log10(bruto))
    base = bruto / (10.0**exp)
    for corte, valor in ((1.5, 1.0), (3.5, 2.0), (7.5, 5.0)):
        if base < corte:
            return valor * (10.0**exp)
    return 10.0 ** (exp + 1)


class RasanteView(QWidget):
    """Perfil longitudinal editable con el raton."""

    #: La rasante ha cambiado de forma.
    cambiada = pyqtSignal()
    #: Ha cambiado lo seleccionado (vertice, tirador o segmento).
    seleccion_cambiada = pyqtSignal()
    #: Posicion del raton en coordenadas del perfil, ``(s, z)``.
    posicion = pyqtSignal(float, float)
    #: La herramienta activa ha cambiado (las acciones vuelven solas a Mover).
    herramienta_cambiada = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(240)
        self.setSizePolicy(POL_EXPANDIR, POL_EXPANDIR)
        self.setMouseTracking(True)
        self.setFocusPolicy(FOCO_FUERTE)
        self.setCursor(CURSOR_CRUZ)

        self.rasante = Rasante()
        #: Perfil del terreno ``[(s, z)]``, solo para dibujar y para ajustar.
        self.terreno: List[Tuple[float, float]] = []
        #: PK a rotular ``[(s, texto)]``.
        self.pks: List[Tuple[float, str]] = []
        self.exageracion = 5.0
        self.herramienta = H_MOVER
        #: ``("vertice", i)``, ``("control", i, j)`` o ``("segmento", i)``.
        self.seleccion: Optional[tuple] = None
        #: Ajustes: al terreno, a cota redonda y a abscisa redonda.
        self.ajustar_terreno = False
        self.paso_cota = 0.0
        self.paso_s = 0.0
        #: Ventana de datos visible, ``(s0, s1, z0, z1)``. ``None`` = encajar.
        self._ventana: Optional[tuple] = None
        self._arrastre: Optional[tuple] = None
        self._pan: Optional[tuple] = None
        #: Lo que hay bajo el raton, para resaltarlo: se ve que se puede coger.
        self._resaltado: Optional[tuple] = None
        #: Indices de los vertices seleccionados. La rasante es independiente de
        #: la planta, pero puede tener muchos vertices igual, y subir o bajar un
        #: tramo entero de uno en uno deformaria las pendientes por el camino.
        self.seleccion_multiple: set = set()
        #: Ventana de seleccion en curso, ``(x0, y0, x1, y1)`` en pixeles.
        self._goma: Optional[tuple] = None
        self._cursor: Optional[Tuple[float, float]] = None
        self._caja = None

    # -- datos -------------------------------------------------------------
    def set_rasante(self, rasante: Rasante, encajar: bool = True) -> None:
        self.rasante = rasante or Rasante()
        self.seleccion = None
        if encajar:
            self._ventana = None
        self.update()

    def set_terreno(self, puntos, encajar: bool = True) -> None:
        self.terreno = [(float(s), float(z)) for s, z in (puntos or [])]
        if encajar:
            self._ventana = None
        self.update()

    def encajar(self) -> None:
        self._ventana = None
        self.update()

    def set_herramienta(self, clave: str) -> None:
        """Activa una herramienta y avisa, para que el panel siga el estado."""
        if clave not in HERRAMIENTAS or clave == self.herramienta:
            if clave in HERRAMIENTAS:
                self.herramienta_cambiada.emit(clave)
            return
        self.herramienta = clave
        self.herramienta_cambiada.emit(clave)
        self.update()

    def aplicar_a(self, indice: int, herramienta: str) -> bool:
        """Aplica una accion (tipo de segmento o «+ control») a un segmento.

        Es lo mismo que hace el clic, pero llamable desde el panel: asi se puede
        seleccionar un segmento y pulsar el boton, sin tener que pinchar otra vez.
        """
        if not (0 <= indice < len(self.rasante) - 1):
            return False
        if herramienta == H_CONTROL:
            hecho = self.rasante.anadir_control(indice)
        else:
            hecho = self.rasante.set_tipo(indice, herramienta)
        if hecho:
            self.seleccion = ("segmento", indice)
            self._emitir_cambio()
        return hecho

    def seleccionar_varios(self, indices, anadir: bool = False) -> None:
        """Marca varios vertices. Sin ``anadir``, sustituye la seleccion."""
        nuevos = {
            int(i) for i in indices if 0 <= int(i) < len(self.rasante)
        }
        self.seleccion_multiple = (
            self.seleccion_multiple | nuevos if anadir else nuevos
        )
        if self.seleccion_multiple and (
            self.seleccion is None or self.seleccion[0] != "vertice"
            or self.seleccion[1] not in self.seleccion_multiple
        ):
            self.seleccion = ("vertice", min(self.seleccion_multiple))
        self.seleccion_cambiada.emit()
        self.update()

    def limpiar_seleccion(self) -> None:
        self.seleccion_multiple = set()
        self.seleccion = None
        self.seleccion_cambiada.emit()
        self.update()

    def seleccionar_todos(self) -> None:
        self.seleccionar_varios(range(len(self.rasante)))

    def vertice_seleccionado(self) -> Optional[int]:
        if self.seleccion and self.seleccion[0] in ("vertice", "control", "segmento"):
            return self.seleccion[1]
        return None

    def seleccionar_vertice(self, i: int) -> None:
        if 0 <= i < len(self.rasante):
            self.seleccion = ("vertice", i)
            self.seleccion_cambiada.emit()
            self.update()

    # -- transformacion ----------------------------------------------------
    def _limites(self) -> tuple:
        if self._ventana is not None:
            return self._ventana
        puntos = list(self.terreno)
        if not self.rasante.vacia:
            puntos += self.rasante.muestrear(max(1.0, self._paso_muestreo()))
            puntos += [(v.s, v.z) for v in self.rasante.vertices]
            for i, v in enumerate(self.rasante.vertices[:-1]):
                puntos += [tuple(c) for c in v.control]
        if not puntos:
            return (0.0, 100.0, 0.0, 10.0)
        s0 = min(p[0] for p in puntos)
        s1 = max(p[0] for p in puntos)
        z0 = min(p[1] for p in puntos)
        z1 = max(p[1] for p in puntos)
        if s1 - s0 < 1e-6:
            s0, s1 = s0 - 10.0, s1 + 10.0
        if z1 - z0 < 1e-6:
            z0, z1 = z0 - 1.0, z1 + 1.0
        margen = (z1 - z0) * 0.12
        return (s0, s1, z0 - margen, z1 + margen)

    def _paso_muestreo(self) -> float:
        s0, s1, _z0, _z1 = self._ventana or (0.0, 100.0, 0.0, 1.0)
        if self._ventana is None and not self.rasante.vacia:
            s0, s1 = self.rasante.s_ini, self.rasante.s_fin
        return max((s1 - s0) / 400.0, 0.2)

    def _geometria(self) -> tuple:
        """``(s0, s1, z0, z1, cx, cy, esc_s, esc_z)`` de la vista actual."""
        s0, s1, z0, z1 = self._limites()
        w = max(1.0, self.width() - MARGEN_IZQ - MARGEN_DER)
        h = max(1.0, self.height() - MARGEN_SUP - MARGEN_INF)
        esc_s = w / (s1 - s0)
        esc_z = h / (z1 - z0)
        # La exageracion manda: sin ella una rasante al 5 % es una raya.
        esc_s = min(esc_s, esc_z / max(self.exageracion, 1e-6))
        esc_z = esc_s * self.exageracion
        cx = MARGEN_IZQ + (w - (s1 - s0) * esc_s) / 2.0
        cy = MARGEN_SUP + (h + (z1 - z0) * esc_z) / 2.0
        return (s0, s1, z0, z1, cx, cy, esc_s, esc_z)

    def px(self, s: float, z: float) -> QPointF:
        s0, _s1, z0, _z1, cx, cy, esc_s, esc_z = self._caja or self._geometria()
        return QPointF(cx + (s - s0) * esc_s, cy - (z - z0) * esc_z)

    def datos(self, x: float, y: float) -> Tuple[float, float]:
        s0, _s1, z0, _z1, cx, cy, esc_s, esc_z = self._caja or self._geometria()
        return (s0 + (x - cx) / esc_s, z0 + (cy - y) / esc_z)

    # -- ajustes -----------------------------------------------------------
    def _z_terreno(self, s: float) -> Optional[float]:
        if len(self.terreno) < 2:
            return None
        if s <= self.terreno[0][0]:
            return self.terreno[0][1]
        if s >= self.terreno[-1][0]:
            return self.terreno[-1][1]
        for (sa, za), (sb, zb) in zip(self.terreno, self.terreno[1:]):
            if sa <= s <= sb:
                if sb - sa < 1e-12:
                    return za
                return za + (zb - za) * (s - sa) / (sb - sa)
        return None

    def _ajustar(self, s: float, z: float) -> Tuple[float, float]:
        if self.paso_s > 0.0:
            s = round(s / self.paso_s) * self.paso_s
        if self.ajustar_terreno:
            zt = self._z_terreno(s)
            if zt is not None:
                return (s, zt)
        if self.paso_cota > 0.0:
            z = round(z / self.paso_cota) * self.paso_cota
        return (s, z)

    # -- captura -----------------------------------------------------------
    def _pos(self, event) -> Tuple[float, float]:
        pos = getattr(event, "position", None)
        if callable(pos):
            p = pos()
            return (p.x(), p.y())
        return (float(event.x()), float(event.y()))

    def _que_hay_en(self, x: float, y: float) -> Optional[tuple]:
        """Que se ha pinchado: vertice, tirador o segmento. En ese orden."""
        if self.rasante.vacia:
            return None
        for i, v in enumerate(self.rasante.vertices):
            q = self.px(v.s, v.z)
            if math.hypot(q.x() - x, q.y() - y) <= CAPTURA:
                return ("vertice", i)
        for i, v in enumerate(self.rasante.vertices[:-1]):
            for j, c in enumerate(v.control):
                q = self.px(c[0], c[1])
                if math.hypot(q.x() - x, q.y() - y) <= CAPTURA:
                    return ("control", i, j)
        # Segmento: se compara con la polilinea dibujada de cada uno.
        for i in range(len(self.rasante) - 1):
            muestras = self.rasante.muestras_segmento(i, 16)
            for a, b in zip(muestras, muestras[1:]):
                pa, pb = self.px(*a), self.px(*b)
                if _distancia_a_segmento(x, y, pa, pb) <= CAPTURA:
                    return ("segmento", i)
        return None

    # -- raton -------------------------------------------------------------
    def mousePressEvent(self, event) -> None:
        x, y = self._pos(event)
        if event.button() == BOTON_MEDIO:
            self._pan = (x, y, self._limites())
            return
        self._caja = self._geometria()
        que = self._que_hay_en(x, y)
        if event.button() == BOTON_DERECHO:
            # Como en la digitalizacion de QGIS: el derecho quita el vertice.
            if que and que[0] == "vertice" and self.rasante.borrar(que[1]):
                self.seleccion = None
                self._emitir_cambio()
            return
        if event.button() != BOTON_IZQUIERDO:
            return
        if self.herramienta == H_MOVER:
            mods = event.modifiers()
            acumular = bool(mods & MOD_CONTROL) or bool(mods & MOD_MAYUSCULAS)
            self._empezar_arrastre(que, x, y, acumular)
            return
        self._aplicar_herramienta(que, *self._ajustar(*self.datos(x, y)))
        # Las acciones de un solo uso se aplican y devuelven el mando a Mover:
        # lo siguiente que se quiere hacer es arrastrar los tiradores.
        if self.herramienta in ACCIONES:
            self.set_herramienta(H_MOVER)

    def mouseDoubleClickEvent(self, event) -> None:
        """Doble clic mete un vertice, esté activa la herramienta que sea."""
        if event.button() != BOTON_IZQUIERDO:
            return
        self._caja = self._geometria()
        s, z = self._ajustar(*self.datos(*self._pos(event)))
        if self.rasante.vacia:
            return
        self.seleccion = ("vertice", self.rasante.insertar(s, z))
        self._emitir_cambio()

    def _empezar_arrastre(self, que, x: float = 0.0, y: float = 0.0,
                          acumular: bool = False) -> None:
        """Herramienta de mover: selecciona y, si hay algo, empieza a arrastrar.

        Con ``acumular`` (Ctrl o Mayus) el vertice se anade o se quita de la
        seleccion en vez de sustituirla, y arrastrar mueve **todos** los
        seleccionados a la vez. Pinchando en vacio se abre una ventana de
        seleccion.
        """
        if que is None:
            if not acumular:
                self.seleccion_multiple = set()
                self.seleccion = None
            self._goma = (x, y, x, y)
            self.seleccion_cambiada.emit()
            self.update()
            return
        if que[0] == "vertice":
            i = que[1]
            if acumular:
                if i in self.seleccion_multiple:
                    self.seleccion_multiple.discard(i)
                else:
                    self.seleccion_multiple.add(i)
            elif i not in self.seleccion_multiple:
                # Pinchar un vertice fuera del grupo empieza una seleccion nueva;
                # pinchar uno de dentro conserva el grupo, para poder arrastrarlo.
                self.seleccion_multiple = {i}
        else:
            self.seleccion_multiple = set()
        self.seleccion = que
        self.seleccion_cambiada.emit()
        if que[0] in ("vertice", "control"):
            self._arrastre = que
        self.update()

    def _aplicar_herramienta(self, que, s: float, z: float) -> None:
        """Ejecuta la herramienta activa sobre lo que se ha pinchado."""
        herramienta = self.herramienta
        if herramienta == H_INSERTAR:
            self.seleccion = ("vertice", self.rasante.insertar(s, z))
            self._emitir_cambio()
        elif herramienta == H_BORRAR:
            if que and que[0] == "vertice" and self.rasante.borrar(que[1]):
                self.seleccion = None
                self._emitir_cambio()
        elif herramienta in (H_RECTA, H_ARCO, H_BEZIER, H_NURBS):
            indice = self._segmento_de(que)
            if indice is not None and self.rasante.set_tipo(indice, herramienta):
                self.seleccion = ("segmento", indice)
                self._emitir_cambio()
        elif herramienta == H_CONTROL:
            indice = self._segmento_de(que)
            if indice is not None and self.rasante.anadir_control(indice):
                self.seleccion = ("segmento", indice)
                self._emitir_cambio()

    def _segmento_de(self, que) -> Optional[int]:
        """Segmento al que se refiere lo pinchado, sea un segmento o un vertice."""
        if not que:
            return None
        if que[0] == "segmento":
            return que[1]
        return min(que[1], len(self.rasante) - 2)

    def leaveEvent(self, _event) -> None:
        """Al salir del widget no queda nada resaltado ni ninguna lectura viva."""
        self._resaltado = None
        self._cursor = None
        self.update()

    def mouseMoveEvent(self, event) -> None:
        x, y = self._pos(event)
        if self._pan is not None:
            x0, y0, (s0, s1, z0, z1) = self._pan
            _a, _b, _c, _d, _cx, _cy, esc_s, esc_z = self._geometria()
            ds = (x0 - x) / esc_s
            dz = (y - y0) / esc_z
            self._ventana = (s0 + ds, s1 + ds, z0 + dz, z1 + dz)
            self.update()
            return
        self._caja = self._geometria()
        s, z = self.datos(x, y)
        self._cursor = (s, z)
        if self._goma is not None:
            self._goma = (self._goma[0], self._goma[1], x, y)
            self.update()
            return
        if self._arrastre is not None:
            s, z = self._ajustar(s, z)
            if self._arrastre[0] == "vertice":
                self._arrastrar_vertices(self._arrastre[1], s, z)
            else:
                _c, i, j = self._arrastre
                v = self.rasante[i]
                if 0 <= j < len(v.control):
                    v.control[j] = (s, z)
            self.update()
            self.cambiada.emit()
            return
        self.posicion.emit(s, z)
        que = self._que_hay_en(x, y)
        self._resaltado = que
        self.setCursor(CURSOR_MANO if que else CURSOR_CRUZ)
        self.update()

    def _arrastrar_vertices(self, indice: int, s: float, z: float) -> None:
        """Mueve el vertice arrastrado y, con el, los demas seleccionados.

        Los otros se desplazan **el mismo incremento**, no a la misma posicion:
        de lo que se trata es de subir o bajar un tramo sin deformarlo.
        """
        grupo = self.seleccion_multiple
        if len(grupo) > 1 and indice in grupo:
            v = self.rasante[indice]
            ds, dz = s - v.s, z - v.z
            self.rasante.mover_varios(grupo, ds, dz)
            return
        self.rasante.mover(indice, s, z)

    def _cerrar_goma(self) -> None:
        """Selecciona los vertices que caen dentro de la ventana dibujada."""
        if self._goma is None:
            return
        x0, y0, x1, y1 = self._goma
        self._goma = None
        if abs(x1 - x0) < 4.0 and abs(y1 - y0) < 4.0:
            self.update()
            return
        izq, der = min(x0, x1), max(x0, x1)
        arriba, abajo = min(y0, y1), max(y0, y1)
        dentro = []
        for i, v in enumerate(self.rasante.vertices):
            q = self.px(v.s, v.z)
            if izq <= q.x() <= der and arriba <= q.y() <= abajo:
                dentro.append(i)
        if dentro:
            self.seleccionar_varios(dentro, anadir=True)
        else:
            self.update()

    def mouseReleaseEvent(self, _event) -> None:
        if self._goma is not None:
            self._caja = self._geometria()
            self._cerrar_goma()
            return
        if self._arrastre is not None:
            self._arrastre = None
            # Arrastrar un vertice por delante del siguiente es normal: se
            # reordena al soltar, no mientras se mueve.
            self.rasante.ordenar()
            self._emitir_cambio()
        self._pan = None

    def wheelEvent(self, event) -> None:
        delta = event.angleDelta().y() if hasattr(event, "angleDelta") else 0
        if not delta:
            return
        factor = 0.85 if delta > 0 else 1.0 / 0.85
        pos = getattr(event, "position", None)
        if callable(pos):
            x, y = pos().x(), pos().y()
        else:
            x, y = float(event.x()), float(event.y())
        self._caja = self._geometria()
        s_c, z_c = self.datos(x, y)
        s0, s1, z0, z1 = self._limites()
        self._ventana = (
            s_c + (s0 - s_c) * factor,
            s_c + (s1 - s_c) * factor,
            z_c + (z0 - z_c) * factor,
            z_c + (z1 - z_c) * factor,
        )
        self.update()

    def keyPressEvent(self, event) -> None:
        if event.key() == TECLA_ESCAPE:
            self.set_herramienta(H_MOVER)
            return
        if event.key() == TECLA_SUPRIMIR:
            if self._borrar_seleccionados():
                return
        if event.key() == TECLA_A and bool(event.modifiers() & MOD_CONTROL):
            self.seleccionar_todos()
            return
        super().keyPressEvent(event)

    def _borrar_seleccionados(self) -> bool:
        """Quita los vertices seleccionados, sean uno o varios."""
        if len(self.seleccion_multiple) > 1:
            quitados = self.rasante.borrar_varios(self.seleccion_multiple)
            if quitados:
                self.seleccion_multiple = set()
                self.seleccion = None
                self._emitir_cambio()
                return True
            return False
        i = self.vertice_seleccionado()
        if i is not None and self.seleccion[0] == "vertice" and self.rasante.borrar(i):
            self.seleccion_multiple = set()
            self.seleccion = None
            self._emitir_cambio()
            return True
        return False

    def _emitir_cambio(self) -> None:
        self.seleccion_cambiada.emit()
        self.cambiada.emit()
        self.update()

    # -- pintado -----------------------------------------------------------
    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(ANTIALIAS, True)
        p.fillRect(self.rect(), COL_FONDO)
        self._caja = self._geometria()
        if self.rasante.vacia and not self.terreno:
            p.setPen(QPen(COL_SUAVE))
            p.drawText(
                QRectF(self.rect()),
                AL_CENTRO,
                t("Choose the alignment and start the grade line from the "
                  "terrain."),
            )
            p.end()
            return
        self._rejilla(p)
        self._relleno(p)
        self._polilinea(p, self.terreno, COL_TERRENO, 1.6)
        if not self.rasante.vacia:
            self._polilinea(
                p, self.rasante.muestrear(self._paso_muestreo()), COL_RASANTE, 2.2
            )
            self._resaltar_segmento(p)
            self._controles(p)
            self._vertices(p)
            self._rotulos(p)
        self._marcas_pk(p)
        self._cursor_raton(p)
        self._ventana_goma(p)
        p.end()

    def _fuente(self, p: QPainter, puntos: float, negrita: bool = False) -> None:
        f = QFont(p.font())
        f.setPointSizeF(max(6.0, puntos))
        f.setBold(negrita)
        p.setFont(f)

    def _rejilla(self, p: QPainter) -> None:
        s0, s1, z0, z1, _cx, _cy, _es, _ez = self._caja
        self._fuente(p, 7.5)
        paso_z = _paso_bonito((z1 - z0) / 6.0)
        z = math.ceil(z0 / paso_z) * paso_z
        while z <= z1:
            a, b = self.px(s0, z), self.px(s1, z)
            p.setPen(QPen(COL_REJILLA, 0.8))
            p.drawLine(a, b)
            p.setPen(QPen(COL_SUAVE))
            p.drawText(
                QRectF(2.0, a.y() - 7.0, MARGEN_IZQ - 6.0, 14.0),
                AL_DER | AL_VCENTRO,
                f"{z:.2f}",
            )
            z += paso_z
        paso_s = _paso_bonito((s1 - s0) / 8.0)
        s = math.ceil(s0 / paso_s) * paso_s
        while s <= s1:
            a, b = self.px(s, z0), self.px(s, z1)
            p.setPen(QPen(COL_REJILLA, 0.8))
            p.drawLine(a, b)
            p.setPen(QPen(COL_SUAVE))
            p.drawText(
                QRectF(a.x() - 28.0, self.height() - MARGEN_INF + 3.0, 56.0, 12.0),
                AL_CENTRO,
                f"{s:.0f}",
            )
            s += paso_s

    def _relleno(self, p: QPainter) -> None:
        """Sombra de desmonte y de terraplen entre rasante y terreno."""
        if self.rasante.vacia or len(self.terreno) < 2:
            return
        paso = self._paso_muestreo()
        s_ini = max(self.rasante.s_ini, self.terreno[0][0])
        s_fin = min(self.rasante.s_fin, self.terreno[-1][0])
        if s_fin <= s_ini:
            return
        n = max(2, int((s_fin - s_ini) / max(paso, 0.1)))
        abscisas = [s_ini + (s_fin - s_ini) * i / n for i in range(n + 1)]
        cotas = self.rasante.cotas_en(abscisas)
        tramo: List[Tuple[float, float, float]] = []
        signo = 0
        p.setPen(SIN_PLUMA)
        for s, zr in zip(abscisas, cotas):
            zt = self._z_terreno(s)
            if zr is None or zt is None:
                continue
            nuevo = 1 if zr > zt else -1
            if signo and nuevo != signo and tramo:
                self._pinta_zona(p, tramo, signo)
                tramo = [tramo[-1]]
            signo = nuevo
            tramo.append((s, zr, zt))
        if tramo and signo:
            self._pinta_zona(p, tramo, signo)

    def _pinta_zona(self, p: QPainter, tramo, signo: int) -> None:
        poli = QPolygonF([self.px(s, zr) for s, zr, _zt in tramo])
        for s, _zr, zt in reversed(tramo):
            poli.append(self.px(s, zt))
        p.setBrush(COL_TERRAPLEN if signo > 0 else COL_DESMONTE)
        p.drawPolygon(poli)

    def _polilinea(self, p: QPainter, puntos, color: QColor, ancho: float) -> None:
        if len(puntos) < 2:
            return
        p.setBrush(SIN_PINCEL)
        p.setPen(QPen(color, ancho))
        p.drawPolyline(QPolygonF([self.px(s, z) for s, z in puntos]))

    def _resaltar_segmento(self, p: QPainter) -> None:
        """Marca en grueso el segmento bajo el raton o el seleccionado.

        Con una herramienta de tipo activa es imprescindible: dice sobre cual se
        va a aplicar antes de pulsar.
        """
        for objetivo, color, grosor in (
            (self.seleccion, COL_SEL, 3.4),
            (self._resaltado, COL_RASANTE, 4.2),
        ):
            if not objetivo or objetivo[0] != "segmento":
                continue
            muestras = self.rasante.muestras_segmento(objetivo[1], 24)
            if len(muestras) < 2:
                continue
            pluma = QPen(QColor(color.red(), color.green(), color.blue(), 90), grosor)
            p.setPen(pluma)
            p.setBrush(SIN_PINCEL)
            p.drawPolyline(QPolygonF([self.px(s, z) for s, z in muestras]))

    def _controles(self, p: QPainter) -> None:
        for i, v in enumerate(self.rasante.vertices[:-1]):
            if v.tipo == RECTA or not v.control:
                continue
            puntos = self.rasante._control_completo(i)
            p.setBrush(SIN_PINCEL)
            pluma = QPen(COL_CONTROL, 0.9)
            pluma.setStyle(LINEA_TRAZOS)
            p.setPen(pluma)
            p.drawPolyline(QPolygonF([self.px(s, z) for s, z in puntos]))
            for j, c in enumerate(v.control):
                q = self.px(c[0], c[1])
                elegido = self.seleccion == ("control", i, j)
                if self._resaltado == ("control", i, j):
                    # Halo: dice «esto se coge» antes de intentarlo.
                    p.setBrush(SIN_PINCEL)
                    p.setPen(QPen(COL_CONTROL, 1.0))
                    p.drawEllipse(q, RADIO_TIRADOR + 3.5, RADIO_TIRADOR + 3.5)
                p.setBrush(COL_SEL if elegido else COL_CONTROL)
                p.setPen(QPen(COL_BLANCO, 1.4))
                p.drawEllipse(q, RADIO_TIRADOR, RADIO_TIRADOR)

    def _vertices(self, p: QPainter) -> None:
        sel = self.seleccion
        for i, v in enumerate(self.rasante.vertices):
            q = self.px(v.s, v.z)
            elegido = sel is not None and sel[0] == "vertice" and sel[1] == i
            if self._resaltado == ("vertice", i):
                p.setBrush(SIN_PINCEL)
                p.setPen(QPen(COL_RASANTE, 1.0))
                p.drawEllipse(q, LADO_VERTICE + 4.0, LADO_VERTICE + 4.0)
            en_grupo = i in self.seleccion_multiple
            p.setBrush(COL_SEL if (elegido or en_grupo) else COL_BLANCO)
            p.setPen(QPen(COL_SEL if (elegido or en_grupo) else COL_RASANTE, 1.6))
            lado = LADO_VERTICE + (0.8 if elegido else 0.0)
            p.drawRect(QRectF(q.x() - lado, q.y() - lado, lado * 2.0, lado * 2.0))

    def _rotulos(self, p: QPainter) -> None:
        r = self.rasante
        self._fuente(p, 7.5)
        # Pendiente de cada segmento, en el centro del tramo.
        for i in range(len(r) - 1):
            v, w = r[i], r[i + 1]
            if w.s - v.s < 1e-6:
                continue
            s_med = (v.s + w.s) / 2.0
            z_med = r.z_en(s_med)
            if z_med is None:
                continue
            q = self.px(s_med, z_med)
            m = r.pendiente(i) * 100.0
            texto = f"{m:+.2f} %"
            if v.tipo != RECTA:
                texto += "  " + etiqueta_segmento(v.tipo)
            elegido = self.seleccion == ("segmento", i)
            p.setPen(QPen(COL_SEL if elegido else COL_RASANTE))
            p.drawText(
                QRectF(q.x() - 40.0, q.y() - 20.0, 80.0, 12.0), AL_CENTRO, texto
            )
        # Cota y PK de cada vertice, y L y K del acuerdo.
        for i, v in enumerate(r.vertices):
            q = self.px(v.s, v.z)
            p.setPen(QPen(COL_TEXTO))
            p.drawText(
                QRectF(q.x() - 45.0, q.y() + 5.0, 90.0, 12.0),
                AL_CENTRO,
                f"{v.s:.0f} / {v.z:.2f}",
            )
            if v.acuerdo > 0.0 and 0 < i < len(r) - 1:
                self._rotulo_acuerdo(p, i, q)

    def _rotulo_acuerdo(self, p: QPainter, i: int, q: QPointF) -> None:
        """L y K del acuerdo del vertice ``i``, y sus dos extremos marcados."""
        r = self.rasante
        v = r[i]
        k = r.parametro_k(i)
        util = r._acuerdo_util(i)
        texto = f"L={v.acuerdo:.0f}"
        if k:
            texto += f"  K={k:.0f}"  # L y K son notacion universal
        # En rojo si el acuerdo no cabe entre sus vertices y se ha recortado.
        p.setPen(QPen(COL_AVISO if util < v.acuerdo - 1e-6 else COL_CONTROL))
        p.drawText(QRectF(q.x() - 45.0, q.y() + 17.0, 90.0, 12.0), AL_CENTRO, texto)
        if util <= 0.0:
            return
        for s_e in (v.s - util / 2.0, v.s + util / 2.0):
            z_e = r.z_en(s_e)
            if z_e is None:
                continue
            p.setBrush(SIN_PINCEL)
            p.setPen(QPen(COL_CONTROL, 1.0))
            p.drawEllipse(self.px(s_e, z_e), 2.6, 2.6)

    def _marcas_pk(self, p: QPainter) -> None:
        if not self.pks:
            return
        _s0, _s1, z0, z1, _cx, _cy, _es, _ez = self._caja
        self._fuente(p, 7.0)
        for s, texto in self.pks:
            a, b = self.px(s, z0), self.px(s, z1)
            pluma = QPen(COL_MARCA_PK, 0.9)
            pluma.setStyle(LINEA_PUNTOS)
            p.setPen(pluma)
            p.drawLine(a, b)
            p.setPen(QPen(COL_SUAVE))
            p.drawText(
                QRectF(a.x() - 30.0, MARGEN_SUP - 14.0, 60.0, 12.0), AL_CENTRO, texto
            )

    def _ventana_goma(self, p: QPainter) -> None:
        """Rectangulo de la seleccion por ventana, mientras se arrastra."""
        if self._goma is None:
            return
        x0, y0, x1, y1 = self._goma
        pluma = QPen(COL_SEL, 1.0)
        pluma.setStyle(LINEA_TRAZOS)
        p.setPen(pluma)
        p.setBrush(QColor(COL_SEL.red(), COL_SEL.green(), COL_SEL.blue(), 28))
        p.drawRect(QRectF(min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0)))

    def _cursor_raton(self, p: QPainter) -> None:
        if self._cursor is None:
            return
        s, z = self._cursor
        q = self.px(s, z)
        p.setPen(QPen(COL_SUAVE, 0.8))
        p.drawLine(QPointF(q.x(), MARGEN_SUP), QPointF(q.x(), self.height() - MARGEN_INF))
        self._fuente(p, 7.5)
        p.setPen(QPen(COL_TEXTO))
        zt = self._z_terreno(s)
        texto = t(
            "Sta {s:.2f}   elevation {z:.2f}", s=s, z=z
        )
        if len(self.seleccion_multiple) > 1:
            texto = (
                t("[{n} vertices]   ", n=len(self.seleccion_multiple)) + texto
            )
        if zt is not None:
            texto += t("   terrain {z:.2f}", z=zt)
            zr = self.rasante.z_en(s)
            if zr is not None:
                texto += t("   cut/fill {z:+.2f}", z=zr - zt)
        p.drawText(
            QRectF(MARGEN_IZQ, 2.0, self.width() - MARGEN_IZQ - MARGEN_DER, 13.0),
            AL_IZQ | AL_VCENTRO,
            texto,
        )


def _distancia_a_segmento(x: float, y: float, a: QPointF, b: QPointF) -> float:
    dx, dy = b.x() - a.x(), b.y() - a.y()
    largo = dx * dx + dy * dy
    if largo < 1e-12:
        return math.hypot(x - a.x(), y - a.y())
    t = max(0.0, min(1.0, ((x - a.x()) * dx + (y - a.y()) * dy) / largo))
    return math.hypot(x - (a.x() + t * dx), y - (a.y() + t * dy))


__all__ = [
    "ACCIONES",
    "MODOS",
    "PISTAS",
    "HERRAMIENTAS",
    "H_ARCO",
    "H_BEZIER",
    "H_BORRAR",
    "H_CONTROL",
    "H_INSERTAR",
    "H_MOVER",
    "H_NURBS",
    "H_RECTA",
    "RasanteView",
]
