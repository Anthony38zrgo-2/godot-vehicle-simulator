"""Dialogo de generacion de planos del ultimo corredor calculado.

Genera las capas de dibujo en espacio papel y las composiciones de QGIS, y deja
todo dentro de un grupo y del gestor de composiciones. La exportacion a PDF y a
DXF es opcional: normalmente se retoca el cajetin antes de imprimir.
"""

from __future__ import annotations

import os
from typing import Optional

from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ..core.cruces import cruces_de_seccion, interseccion_con_recorrido
from ..core.paperspace import (
    ESCALAS_NORMALIZADAS,
    Escala,
    OpcionesDibujo,
    Reticula,
    laminas_de_transversales,
    laminas_longitudinal,
)
from ..gis.estilos import estilo_hojas
from ..gis.laminas import (
    capas_de_hojas,
    exportar_dxf,
    hojas_de_planta,
    hojas_de_planta_varias,
)
from ..gis.outputs import (
    cargar_en_grupo,
    clave_de_etiqueta,
    nombre_de_grupo_libre,
)
from ..i18n import t
from ..gis.planos import (
    PAPELES,
    OpcionesPlano,
    anadir_al_proyecto,
    exportar_pdf,
    layout_longitudinal,
    layout_planta,
    layout_transversales,
    papel_necesario,
)
from .ayuda_dialog import abrir_ayuda_en
from .dialogos import ajustar_a_pantalla, cuerpo_con_scroll
from .qtcompat import ROL_ACCION, ROL_AYUDA, ROL_RECHAZAR
from .selector_capas import SelectorCapas, es_salida_de_corredor
from .selector_tramos import SelectorTramos


from ..gis.registro import avisar


#: Como se reparten los planos cuando hay varias alineaciones marcadas.
HOJAS_PRINCIPAL = "principal"
HOJAS_TODAS = "todas"
#: ``(clave, rotulo, ayuda)``. Los textos van en ingles y se traducen al
#: llenar el desplegable.
MODOS_HOJAS = (
    (
        HOJAS_PRINCIPAL,
        "A single set, that of the main alignment",
        "The drawings are those of the main alignment: its cross sections, "
        "its longitudinal profile and the plan sheets framed on it. The "
        "other alignments do not bring their own set; they appear where "
        "they cut those planes, dashed. This is what you want with "
        "alignments that run together: otherwise the same thing is "
        "printed several times.",
    ),
    (
        HOJAS_TODAS,
        "A complete set per alignment",
        "Each alignment generates its own cross sections, its longitudinal "
        "profile and its plan sheets, one after another. It is needed when "
        "the alignments are different works and each one needs its own "
        "framing.",
    ),
)


def _p() -> str:
    """Titulo de los avisos del dialogo."""
    return t("Drawings")


class PlanosDialog(QDialog):
    """Genera planos de planta, longitudinal y transversales."""

    def __init__(self, iface, result, parent=None, corredores=None):
        super().__init__(parent)
        self.iface = iface
        #: ``{nombre: resultado}`` de la sesion. Si no se da, solo el que llegue.
        self.corredores = dict(corredores or {})
        self.result = result
        if not self.corredores and result is not None:
            self.corredores[getattr(result, "nombre", "") or t("Corridor")] = result
        self.setWindowTitle(t("Generate corridor drawings"))
        ajustar_a_pantalla(self, 620, 620)

        # El cuerpo va en un area con desplazamiento y la botonera fuera:
        # asi el dialogo cabe en cualquier pantalla y los botones se ven
        # siempre.
        lay, raiz = cuerpo_con_scroll(self)
        lay.addWidget(self._grupo_que())
        lay.addWidget(self._grupo_transversales())
        lay.addWidget(self._grupo_longitudinal())
        lay.addWidget(self._grupo_planta())
        lay.addWidget(self._grupo_salida())
        self.selector_capas.recargar(directrices=self._directrices())

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(110)
        lay.addWidget(self.log, 1)

        botones = QDialogButtonBox()
        self.btn = botones.addButton(t("Generate"), ROL_ACCION)
        self.btn.clicked.connect(self.generar)
        btn_ayuda = botones.addButton(t("Help"), ROL_AYUDA)
        btn_ayuda.clicked.connect(lambda: abrir_ayuda_en("planos", self))
        botones.addButton(t("Close"), ROL_RECHAZAR)
        botones.rejected.connect(self.reject)
        raiz.addWidget(botones)

        self.selector.set_corredores(self.corredores, marcar_todo=True)
        if self.selector.vacio:
            self.log.append(
                "<b>"
                + t("There is no computed corridor.")
                + "</b> "
                + t("Compute one first, or import a saved corridor.")
            )
            self.btn.setEnabled(False)
        else:
            self._actualizar_titulo()

    def _actualizar_titulo(self) -> None:
        """El titulo por defecto sigue al corredor de la alineacion actual."""
        marcadas = self.selector.seleccionados()
        self.btn.setEnabled(bool(marcadas))
        actual = self.selector.actual()
        if actual is None:
            return
        nombre = actual[1]
        if self.ed_titulo.text().strip() in ("", t("Corridor"), *self.corredores):
            self.ed_titulo.setText(nombre)

    # -- interfaz ----------------------------------------------------------
    def _grupo_que(self) -> QWidget:
        g = QGroupBox(t("Which drawings"))
        f = QFormLayout(g)
        self.selector = SelectorTramos(t("Alignments that appear in the drawings"))
        self.selector.cambiado.connect(self._actualizar_titulo)
        f.addRow(self.selector)
        # Estos dos mandan sobre los tres planos —transversales, longitudinal y
        # planta—, asi que van aqui arriba y no dentro de un grupo concreto.
        self.cmb_hojas = QComboBox()
        for clave, rotulo, _tip in MODOS_HOJAS:
            self.cmb_hojas.addItem(t(rotulo), clave)
        self.cmb_hojas.setToolTip(
            chr(10).join(
                f"{t(rotulo)}: {t(tip)}" for _c, rotulo, tip in MODOS_HOJAS
            )
        )
        f.addRow(t("Drawing set"), self.cmb_hojas)
        self.chk_otros = QCheckBox(
            t("draw the other corridors where they cross or run close")
        )
        self.chk_otros.setChecked(True)
        self.chk_otros.setToolTip(
            t(
                "On the cross sections, the trace of the other corridors on "
                "that very cutting plane; on the longitudinal profile, where "
                "they cut its vertical plane. They come out dashed and "
                "purple. In plan they always appear, because the map draws "
                "their layers."
            )
        )
        f.addRow(t("Others"), self.chk_otros)
        self.ed_titulo = QLineEdit(t("Corridor"))
        f.addRow(t("Title"), self.ed_titulo)
        fila = QHBoxLayout()
        self.ed_plantilla = QLineEdit()
        self.ed_plantilla.setPlaceholderText(
            t("optional: .qpt template with the title block")
        )
        btn = QPushButton("...")
        btn.setMaximumWidth(30)
        btn.clicked.connect(self._elegir_plantilla)
        fila.addWidget(self.ed_plantilla, 1)
        fila.addWidget(btn)
        f.addRow(t("Template"), fila)
        return g

    def _grupo_transversales(self) -> QWidget:
        g = QGroupBox(t("Cross sections"))
        f = QFormLayout(g)
        self.chk_tr = QCheckBox(t("generate"))
        self.chk_tr.setChecked(True)
        f.addRow("", self.chk_tr)
        fila = QHBoxLayout()
        self.sp_col = QSpinBox()
        self.sp_col.setRange(1, 10)
        self.sp_col.setValue(3)
        self.sp_fil = QSpinBox()
        self.sp_fil.setRange(1, 12)
        self.sp_fil.setValue(4)
        fila.addWidget(QLabel(t("columns")))
        fila.addWidget(self.sp_col)
        fila.addWidget(QLabel(t("rows")))
        fila.addWidget(self.sp_fil)
        fila.addStretch(1)
        f.addRow(t("Grid"), fila)
        self.cmb_papel_tr = QComboBox()
        self.cmb_papel_tr.addItems(list(PAPELES))
        self.cmb_papel_tr.setCurrentText("A3")
        self.cmb_papel_tr.setToolTip(
            t(
                "The cells are sized to fill this format: the drawing comes "
                "out as large as possible instead of sitting small in the "
                "middle of the sheet."
            )
        )
        f.addRow(t("Paper"), self.cmb_papel_tr)
        self.chk_cubicaciones = QCheckBox(
            t("add a closing earthwork sheet with totals")
        )
        self.chk_cubicaciones.setChecked(True)
        f.addRow("", self.chk_cubicaciones)
        self.cmb_escala_tr = QComboBox()
        self.cmb_escala_tr.addItem(t("automatic"), 0.0)
        for e in ESCALAS_NORMALIZADAS:
            self.cmb_escala_tr.addItem(f"1:{e:.0f}", e)
        f.addRow(t("Scale"), self.cmb_escala_tr)
        return g

    def _grupo_longitudinal(self) -> QWidget:
        g = QGroupBox(t("Longitudinal profile"))
        f = QFormLayout(g)
        self.chk_lo = QCheckBox(t("generate"))
        self.chk_lo.setChecked(True)
        f.addRow("", self.chk_lo)
        fila = QHBoxLayout()
        self.cmb_eh = QComboBox()
        self.cmb_ev = QComboBox()
        for e in ESCALAS_NORMALIZADAS + (5000.0,):
            self.cmb_eh.addItem(f"1:{e:.0f}", e)
        for e in ESCALAS_NORMALIZADAS:
            self.cmb_ev.addItem(f"1:{e:.0f}", e)
        self.cmb_eh.setCurrentText("1:1000")
        self.cmb_ev.setCurrentText("1:100")
        fila.addWidget(QLabel("H"))
        fila.addWidget(self.cmb_eh)
        fila.addWidget(QLabel("V"))
        fila.addWidget(self.cmb_ev)
        fila.addStretch(1)
        f.addRow(t("Scales"), fila)
        self.cmb_papel_lo = QComboBox()
        self.cmb_papel_lo.addItems(list(PAPELES))
        self.cmb_papel_lo.setCurrentText("A3")
        self.cmb_papel_lo.setToolTip(
            t(
                "The profile is split into as many sheets of this format as "
                "needed: one kilometre at 1:1000 measures one metre of paper."
            )
        )
        f.addRow(t("Paper"), self.cmb_papel_lo)
        self.sp_cada = QSpinBox()
        self.sp_cada.setRange(1, 50)
        self.sp_cada.setValue(1)
        self.sp_cada.setToolTip(
            t("Data band columns: 1 = one per section; 5 = one in five.")
        )
        f.addRow(t("Data band every"), self.sp_cada)
        return g

    def _grupo_planta(self) -> QWidget:
        g = QGroupBox(t("Plan by sheets (atlas)"))
        f = QFormLayout(g)
        self.chk_pl = QCheckBox(t("generate"))
        self.chk_pl.setChecked(True)
        f.addRow("", self.chk_pl)
        self.cmb_papel = QComboBox()
        self.cmb_papel.addItems(list(PAPELES))
        self.cmb_papel.setCurrentText("A3")
        f.addRow(t("Paper"), self.cmb_papel)
        self.cmb_escala_pl = QComboBox()
        for e in (500.0, 1000.0, 2000.0, 5000.0):
            self.cmb_escala_pl.addItem(f"1:{e:.0f}", e)
        self.cmb_escala_pl.setCurrentText("1:1000")
        f.addRow(t("Scale"), self.cmb_escala_pl)
        self.sp_solape = _spin(5.0, 0.0, 50.0, " %", 1)
        f.addRow(t("Overlap between sheets"), self.sp_solape)
        self.selector_capas = SelectorCapas()
        f.addRow(self.selector_capas)
        return g

    def _grupo_salida(self) -> QWidget:
        g = QGroupBox(t("Export (optional)"))
        f = QFormLayout(g)
        fila = QHBoxLayout()
        self.ed_carpeta = QLineEdit()
        self.ed_carpeta.setPlaceholderText(
            t("folder for the PDFs and DXFs; empty = do not export")
        )
        btn = QPushButton("...")
        btn.setMaximumWidth(30)
        btn.clicked.connect(self._elegir_carpeta)
        fila.addWidget(self.ed_carpeta, 1)
        fila.addWidget(btn)
        f.addRow(t("Folder"), fila)
        self.chk_pdf = QCheckBox("PDF")
        self.chk_pdf.setChecked(True)
        self.chk_dxf = QCheckBox("DXF")
        fila2 = QHBoxLayout()
        fila2.addWidget(self.chk_pdf)
        fila2.addWidget(self.chk_dxf)
        fila2.addStretch(1)
        f.addRow("", fila2)
        return g

    def _elegir_plantilla(self) -> None:
        ruta, _ = QFileDialog.getOpenFileName(
            self, t("Layout template"), "", t("Templates (*.qpt)")
        )
        if ruta:
            self.ed_plantilla.setText(ruta)

    def _elegir_carpeta(self) -> None:
        ruta = QFileDialog.getExistingDirectory(self, t("Output folder"))
        if ruta:
            self.ed_carpeta.setText(ruta)

    def _log(self, texto: str, aviso: bool = False) -> None:
        color = "#b06000" if aviso else "#333"
        self.log.append(f'<span style="color:{color}">{texto}</span>')
        QApplication.processEvents()

    # -- generacion --------------------------------------------------------
    def generar(self) -> None:
        tramos = self._tramos_marcados()
        if tramos is None:
            return
        self.btn.setEnabled(False)
        titulo = self.ed_titulo.text().strip() or "Corredor"
        plantilla = self.ed_plantilla.text().strip()
        capas_grupo: list = []
        layouts: list = []
        try:
            if self.chk_tr.isChecked():
                capas_grupo += self._transversales(tramos, titulo, plantilla, layouts)
            if self.chk_lo.isChecked():
                capas_grupo += self._longitudinal(tramos, titulo, plantilla, layouts)
            if self.chk_pl.isChecked():
                capas_grupo += self._planta(
                    [r for _n, r, _ss in tramos], titulo, plantilla, layouts
                )
        except Exception as exc:  # noqa: BLE001
            import traceback

            self._log(traceback.format_exc(), aviso=True)
            QMessageBox.critical(
                self, _p(), t("Unexpected error: {error}", error=exc)
            )
            self.btn.setEnabled(True)
            return

        if capas_grupo:
            proyecto = QgsProject.instance()
            nombre = nombre_de_grupo_libre(
                proyecto.layerTreeRoot(), titulo + "-" + t("drawings")
            )
            cargar_en_grupo(capas_grupo, nombre, proyecto)
            self._log(t("drawing group: {n}", n=nombre))
        self._exportar(titulo, layouts, capas_grupo)
        self._log(
            "<b>"
            + t("Done.")
            + "</b> "
            + t("The drawings are in the layout manager.")
        )
        self.btn.setEnabled(True)

    def _tramos_marcados(self):
        """``[(nombre, run, secciones)]`` de lo marcado, o ``None`` si no hay nada.

        Cada alineacion aporta sus secciones; las que no llegan a dos se omiten y
        se dice cuales, porque si no parece que el plano ha salido incompleto sin
        motivo.
        """
        marcadas = self.selector.seleccionados()
        if not marcadas:
            QMessageBox.warning(
                self, _p(), t("Check at least one alignment in the list.")
            )
            return None
        tramos = []
        sin_secciones = []
        for _i, nombre, run in marcadas:
            secciones = [s for s in run.sections if s.vertices]
            if len(secciones) < 2:
                sin_secciones.append(nombre + " · " + run.etiqueta)
                continue
            tramos.append((nombre, run, secciones))
        if not tramos:
            QMessageBox.warning(
                self,
                _p(),
                t("None of the checked alignments has sections."),
            )
            return None
        self.log.clear()
        if sin_secciones:
            self._log(
                t(
                    "no sections, they are skipped: {lista}",
                    lista=", ".join(sin_secciones),
                ),
                aviso=True,
            )
        if len(tramos) > 1:
            n = sum(len(ss) for _n, _r, ss in tramos)
            self._log(
                t(
                    "{a} alignments, {s} sections in total",
                    a=len(tramos),
                    s=n,
                )
            )
        return tramos

    def _exportar(self, titulo: str, layouts: list, capas_grupo: list) -> None:
        """PDF de cada composicion y DXF del dibujo, si se ha pedido carpeta."""
        carpeta = self.ed_carpeta.text().strip()
        if not carpeta:
            return
        if not os.path.isdir(carpeta):
            self._log(
                t("the folder {c} does not exist: nothing is exported", c=carpeta),
                aviso=True,
            )
            return
        if self.chk_pdf.isChecked():
            for lay in layouts:
                ruta = os.path.join(
                    carpeta, _seguro(f"{titulo}_{lay.name()}") + ".pdf"
                )
                ok, msg = exportar_pdf(lay, ruta)
                self._log(
                    "PDF "
                    + (t("written") if ok else t("FAILED"))
                    + f": {ruta} {msg}",
                    aviso=not ok,
                )
        if self.chk_dxf.isChecked() and capas_grupo:
            ruta = os.path.join(carpeta, _seguro(f"{titulo}_dibujo") + ".dxf")
            ok, msg = exportar_dxf(capas_grupo, ruta)
            self._log(
                "DXF "
                + (t("written") if ok else t("FAILED"))
                + f": {ruta} {msg}",
                aviso=not ok,
            )

    def _cruces_de(self, tramos) -> dict:
        """``{id(seccion): [(etiqueta, traza)]}`` de los corredores que cruzan.

        Para cada seccion se corta el plano transversal con las lineas
        caracteristicas de los **demas** tramos: lo que sale es la seccion de esos
        corredores en ese mismo plano. En una obra con dos trazados juntos, es lo
        que deja ver si se tocan.
        """
        if not self.chk_otros.isChecked() or len(tramos) < 2:
            return {}
        salida: dict = {}
        n = 0
        for _nombre, run, secciones in self._tramos_a_dibujar(tramos):
            otros = [
                (r.etiqueta, r) for _n2, r, _ss in tramos if r is not run
            ]
            for sec in secciones:
                # Sin filtro de ancho: lo que no quepa en la celda lo recorta el
                # dibujo, que es quien sabe cuanto mide el marco.
                trazas = cruces_de_seccion(sec, otros)
                if trazas:
                    salida[id(sec)] = [(t.etiqueta, t.puntos) for t in trazas]
                    n += len(trazas)
        if n:
            self._log(
                t(
                    "other corridors: {n} traces drawn on the cross sections",
                    n=n,
                )
            )
        return salida

    def _tramos_a_dibujar(self, tramos) -> list:
        """Los tramos que llevan planos propios, segun el juego elegido.

        Un plano es el de **un** eje: sus transversales son los cortes de su
        recorrido y su longitudinal es su plano vertical. Con «un solo juego»,
        eso quiere decir los de la alineacion principal y nada mas; las demas no
        traen sus propias hojas, salen dibujadas donde cortan las de ella. Antes
        salian los transversales de todas, que es imprimir varios planos
        distintos mezclados en la misma lamina.
        """
        if self.cmb_hojas.currentData() == HOJAS_TODAS or len(tramos) < 2:
            return list(tramos)
        principal = self._tramo_principal(tramos)
        return [principal] if principal is not None else []

    def _tramo_principal(self, tramos):
        """El tramo de la alineacion principal, o el primero si no se sabe."""
        elegida = self.selector.principal()
        if elegida is not None:
            for entrada in tramos:
                if entrada[1] is elegida[2]:
                    return entrada
        return tramos[0] if tramos else None

    def _cortes_del_longitudinal(self, principal, tramos) -> list:
        """Donde los demas corredores cortan el plano vertical de la principal."""
        if not self.chk_otros.isChecked() or len(tramos) < 2:
            return []
        pts = list(principal.alignment.pts)
        salida = []
        for _nombre, otro, _ss in tramos:
            if otro is principal:
                continue
            puntos = interseccion_con_recorrido(otro, pts)
            if len(puntos) >= 2:
                salida.append((otro.etiqueta, puntos))
                self._log(
                    "   "
                    + t(
                        "{e} cuts the main axis at {n} points, Sta {a:.0f} "
                        "to {b:.0f}",
                        e=otro.etiqueta,
                        n=len(puntos),
                        a=puntos[0][0],
                        b=puntos[-1][0],
                    )
                )
        return salida

    def _avisar_de_la_escala(self, hojas, ancho_util: float, opts) -> None:
        """Dice si las hojas se estan cortando por desnivel en vez de por ancho.

        Es lo que descoloca al ver el plano: se piden hojas A3 y salen tiras que
        ocupan la mitad. No es un fallo —si el dibujo no cabe de alto, hay que
        cortar—, pero conviene decirlo y sugerir la escala vertical que lo
        arreglaria.
        """
        if len(hojas) < 2:
            return
        largos = [h.pk_fin - h.pk_ini for h in hojas[:-1]]
        if not largos:
            return
        usado = max(largos) * 1000.0 / opts.escala.horizontal
        fraccion = usado / ancho_util if ancho_util else 1.0
        if fraccion >= 0.85:
            return
        sugerida = opts.escala.vertical / max(fraccion, 0.05)
        normal = min(
            (e for e in (100.0, 200.0, 250.0, 500.0, 1000.0) if e >= sugerida),
            default=sugerida,
        )
        self._log(
            t(
                "the sheets are cut by height, not by width: they take up "
                "{pct:.0f} % of the paper. With a vertical scale of 1:{sug:.0f} "
                "instead of 1:{act:.0f} they would fill the sheet.",
                pct=fraccion * 100,
                sug=normal,
                act=opts.escala.vertical,
            ),
            aviso=True,
        )

    def _opciones_plano(self, titulo: str, plantilla: str, papel: str) -> OpcionesPlano:
        return OpcionesPlano(papel=papel, plantilla=plantilla, titulo=titulo)

    def _transversales(self, tramos, titulo, plantilla, layouts) -> list:
        dibujados = self._tramos_a_dibujar(tramos)
        if not dibujados:
            self._log(t("cross sections: there is no main alignment"), aviso=True)
            return []
        if len(tramos) > len(dibujados):
            _n, run, _ss = dibujados[0]
            self._log(
                t(
                    "cross sections of {e} (the main one). The others appear "
                    "where they cut each cutting plane.",
                    e=run.etiqueta,
                )
            )
        secciones = [s for _n, _r, ss in dibujados for s in ss]
        papel = self.cmb_papel_tr.currentText()
        ancho_papel, alto_papel = PAPELES.get(papel, PAPELES["A3"])
        reticula = Reticula.ajustada(
            ancho_papel,
            alto_papel,
            columnas=self.sp_col.value(),
            filas=self.sp_fil.value(),
        )
        den = self.cmb_escala_tr.currentData()
        automatica = not den
        opts = OpcionesDibujo(
            escala=Escala(den or 200.0, den or 200.0)
        )
        hojas = laminas_de_transversales(
            secciones,
            reticula,
            opts,
            escala_automatica=automatica,
            cruces=self._cruces_de(tramos),
        )
        if not hojas:
            self._log(t("cross sections: nothing to draw"), aviso=True)
            return []
        if self.chk_cubicaciones.isChecked():
            from ..core.medicion import medir
            from ..core.paperspace import laminas_de_cubicaciones

            # Una tabla por alineacion: los volumenes se calculan entre secciones
            # consecutivas, asi que medir tramos distintos juntos inventaria un
            # volumen entre el final de uno y el principio del otro.
            hojas = list(hojas)
            for _n, run, ss in dibujados:
                medicion = medir(ss)
                sufijo = f"  {run.etiqueta}" if len(dibujados) > 1 else ""
                cubica = laminas_de_cubicaciones(
                    medicion,
                    opts=opts,
                    x_hoja=len(hojas) * opts.paso_hoja,
                    paso_hoja=opts.paso_hoja,
                    numero_inicial=len(hojas) + 1,
                    titulo=t("EARTHWORKS") + f"  {titulo}{sufijo}",
                )
                if cubica:
                    hojas += cubica
                    self._log(
                        t("earthworks")
                        + sufijo
                        + t(
                            ": {n} sheet(s). {resumen}",
                            n=len(cubica),
                            resumen=medicion.resumen(),
                        )
                    )
        capas = capas_de_hojas(hojas, titulo + " " + t("cross sections"))
        lay = anadir_al_proyecto(
            layout_transversales(
                hojas,
                capas,
                self._opciones_plano(titulo, plantilla, papel),
                ajustar_papel=False,
            )
        )
        layouts.append(lay)
        self._log(
            t(
                "cross sections: {h} sheets, {s} sections, cell {a:.0f}x"
                "{b:.0f} mm on {papel}, layout '{lay}'",
                h=len(hojas),
                s=len(secciones),
                a=reticula.ancho_celda,
                b=reticula.alto_celda,
                papel=papel,
                lay=lay.name(),
            )
        )
        return capas

    def _longitudinal(self, tramos, titulo, plantilla, layouts) -> list:
        """Perfil longitudinal de las alineaciones que llevan planos propios.

        Un longitudinal es un plano: el del recorrido de un eje. Con «un solo
        juego» sale el de la principal y las demas no llevan su propia tira —eso
        serian planos distintos—, sino que aparecen donde **cortan** ese plano
        vertical.
        """
        opts = OpcionesDibujo(
            escala=Escala(self.cmb_eh.currentData(), self.cmb_ev.currentData())
        )
        papel = self.cmb_papel_lo.currentText()
        ancho_papel, alto_papel = PAPELES.get(papel, PAPELES["A3"])
        margen = 14.0
        ancho_util = ancho_papel - 2 * margen - 26.0
        dibujados = self._tramos_a_dibujar(tramos)
        if not dibujados:
            self._log(
                t("longitudinal profile: there is no main alignment"),
                aviso=True,
            )
            return []
        if len(tramos) > len(dibujados):
            self._log(
                t(
                    "longitudinal profile of {e} (the main one). The others "
                    "appear where they cut its vertical plane.",
                    e=dibujados[0][1].etiqueta,
                )
            )
        hojas: list = []
        for _nombre, run, secciones in dibujados:
            tira = laminas_longitudinal(
                secciones,
                ancho_util=ancho_util,
                alto_util=alto_papel - 2 * margen,
                opts=opts,
                cada_guitarra=self.sp_cada.value(),
                x_hoja=len(hojas) * opts.paso_hoja,
                numero_inicial=len(hojas) + 1,
                etiqueta=run.etiqueta if len(dibujados) > 1 else "",
                otros=self._cortes_del_longitudinal(run, tramos),
            )
            hojas += tira
        self._avisar_de_la_escala(hojas, ancho_util, opts)
        if not hojas:
            self._log(t("longitudinal profile: nothing to draw"), aviso=True)
            return []
        capas = capas_de_hojas(hojas, titulo + " " + t("longitudinal profile"))
        lay = anadir_al_proyecto(
            layout_longitudinal(
                hojas,
                capas,
                self._opciones_plano(titulo, plantilla, papel),
                ajustar_papel=False,
            )
        )
        layouts.append(lay)
        self._log(
            t(
                "longitudinal profile: {esc}, {h} sheets on {papel}, layout "
                "'{lay}'",
                esc=opts.escala.etiqueta(),
                h=len(hojas),
                papel=papel,
                lay=lay.name(),
            )
        )
        return capas

    def _planta(self, alineaciones, titulo, plantilla, layouts) -> list:
        papel = self.cmb_papel.currentText()
        ancho, alto = PAPELES.get(papel, PAPELES["A3"])
        escala = self.cmb_escala_pl.currentData()
        modo = self.cmb_hojas.currentData()
        ejes = self._ejes_de_las_hojas(alineaciones, modo)
        if not ejes:
            self._log(t("plan: there is no alignment"), aviso=True)
            return []
        comun = dict(
            escala=escala,
            solape=self.sp_solape.value() / 100.0,
            crs=self._crs(),
        )
        if len(ejes) == 1:
            capa_hojas = hojas_de_planta(ejes[0], ancho, alto, **comun)
        else:
            capa_hojas = hojas_de_planta_varias(ejes, ancho, alto, **comun)
        if not capa_hojas.featureCount():
            self._log(t("plan: no sheets could be generated"), aviso=True)
            return []
        estilo_hojas(capa_hojas)
        proyecto = QgsProject.instance()
        proyecto.addMapLayer(capa_hojas, False)

        # En el plano rotado los PK necesitan su propia rotulacion: la capa de PK
        # normal gira la etiqueta con el azimut, y al girar tambien el mapa las
        # etiquetas acaban verticales. Aqui se hace una copia rotulada para el
        # plano.
        capa_pk = self._capa_pk_para_plano()
        if capa_pk is not None:
            proyecto.addMapLayer(capa_pk, False)

        lay = anadir_al_proyecto(
            layout_planta(
                capa_hojas,
                [capa_hojas] + ([capa_pk] if capa_pk else []) + self._capas_de_fondo(),
                self._opciones_plano(titulo, plantilla, papel),
            )
        )
        layouts.append(lay)
        detalle = (
            t("following {e}", e=self.selector.etiqueta_principal())
            if modo == HOJAS_PRINCIPAL and len(alineaciones) > 1
            else t("{n} alignment(s)", n=len(ejes))
        )
        self._log(
            t(
                "plan: {h} sheets at 1:{esc:.0f} on {papel} ({detalle}), "
                "{f} background layers, layout '{lay}' with atlas",
                h=capa_hojas.featureCount(),
                esc=escala,
                papel=papel,
                detalle=detalle,
                f=len(self._capas_de_fondo()),
                lay=lay.name(),
            )
        )
        return [capa_hojas] + ([capa_pk] if capa_pk else [])

    def _ejes_de_las_hojas(self, alineaciones, modo) -> list:
        """Alineaciones que definen las hojas, segun el modo elegido.

        Con «principal» sale un solo juego encajado sobre ella, y las demas
        aparecen en las hojas donde entren: con dos trazados que van juntos, un
        juego por cada uno seria imprimir dos veces lo mismo.
        """
        ejes = [r.alignment for r in alineaciones]
        if modo != HOJAS_PRINCIPAL or len(ejes) < 2:
            return ejes
        principal = self.selector.principal()
        if principal is None:
            return ejes[:1]
        buscado = principal[2].alignment
        for eje in ejes:
            if eje is buscado:
                return [eje]
        return ejes[:1]

    def _capas_de_fondo(self) -> list:
        """Las capas que el usuario ha marcado en el selector.

        Antes iban **todas** las del proyecto, y en un proyecto de verdad —con
        catastro, ortofotos y capas de trabajo— eso da un plano ilegible y una
        exportacion lentisima.
        """
        salida = []
        for capa in self.selector_capas.marcadas():
            # La capa de PK del corredor gira la etiqueta con el azimut, que en un
            # mapa ya girado sale vertical. En el plano va la copia rotulada para
            # el, asi que la original se queda fuera.
            if clave_de_etiqueta(capa.name().split(" - ")[-1]) == "pk":
                continue
            salida.append(capa)
        return salida

    def _directrices(self) -> list:
        """Capas de las que salen los corredores, para marcarlas de partida.

        Se buscan por geometria y no por nombre: el corredor puede llamarse de
        cualquier manera, pero el primer punto de cada alineacion tiene que estar
        en la capa de la que salio.
        """
        from qgis.core import QgsProject, QgsWkbTypes

        arranques = []
        for res in self.corredores.values():
            for run in getattr(res, "runs", []) or []:
                pts = getattr(run.alignment, "pts", None)
                if pts:
                    arranques.append((pts[0][0], pts[0][1]))
        if not arranques:
            return []
        salida = []
        for capa in QgsProject.instance().mapLayers().values():
            if not hasattr(capa, "geometryType"):
                continue
            if capa.geometryType() != QgsWkbTypes.LineGeometry:
                continue
            if es_salida_de_corredor(capa):
                continue
            if self._empieza_en(capa, arranques):
                salida.append(capa)
        return salida

    @staticmethod
    def _empieza_en(capa, arranques) -> bool:
        """True si algun feature de la capa arranca en uno de esos puntos."""
        for f in capa.getFeatures():
            g = f.geometry()
            if g.isEmpty():
                continue
            for parte in g.constParts():
                vertices = list(parte.vertices())
                if not vertices:
                    continue
                v = vertices[0]
                for x, y in arranques:
                    if abs(v.x() - x) < 0.001 and abs(v.y() - y) < 0.001:
                        return True
        return False

    def _capa_pk_para_plano(self):
        """Copia de los PK con la etiqueta girada para el plano rotado.

        Si el mapa gira ``90 - azimut`` y la etiqueta gira ``azimut - 90``, en el
        papel sale horizontal, que es como se lee un PK en un plano de planta.
        """
        from qgis.core import QgsPalLayerSettings, QgsProperty, QgsTextFormat
        from qgis.core import QgsVectorLayerSimpleLabeling

        from ..gis.outputs import features_pk, fields_pk, memory_layer
        from qgis.core import QgsWkbTypes

        capa = memory_layer(
            t("stations (plan)"),
            QgsWkbTypes.PointZ,
            self._crs(),
            fields_pk(),
            features_pk(self.result),
        )
        if not capa.featureCount():
            return None
        from ..gis.estilos import estilo_pk

        estilo_pk(capa)
        try:
            ajustes = capa.labeling().settings()
            props = ajustes.dataDefinedProperties()
            props.setProperty(
                QgsPalLayerSettings.LabelRotation,
                QgsProperty.fromExpression('"angle" - 90'),
            )
            ajustes.setDataDefinedProperties(props)
            capa.setLabeling(QgsVectorLayerSimpleLabeling(ajustes))
            capa.setLabelsEnabled(True)
        except Exception as exc:  # noqa: BLE001 - si no se puede, se deja como este
            avisar("hojas de planta sin rotulos girados", exc)
        return capa

    def _crs(self):
        for run in self.result.runs:
            del run
            break
        capa = self.iface.activeLayer() if self.iface is not None else None
        if capa is not None and capa.crs().isValid():
            return capa.crs()
        return QgsProject.instance().crs()


def _seguro(nombre: str) -> str:
    """Nombre de archivo sin caracteres problematicos."""
    return "".join(c if c.isalnum() or c in " -_." else "_" for c in nombre).strip()


def _spin(valor, minimo, maximo, sufijo, decimales) -> QDoubleSpinBox:
    w = QDoubleSpinBox()
    w.setRange(minimo, maximo)
    w.setDecimals(decimales)
    w.setValue(valor)
    if sufijo:
        w.setSuffix(sufijo)
    return w


__all__ = ["PlanosDialog"]
