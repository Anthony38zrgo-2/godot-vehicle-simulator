"""Ventana de ayuda del plugin.

La documentacion es un unico HTML (``docs/ayuda.html``) que se muestra en un
``QTextBrowser``. El indice de la izquierda **no se escribe a mano**: se saca de
los ``<h2 id="...">`` del propio documento, asi que anadir una seccion a la ayuda
no obliga a tocar este archivo.

Todo va empaquetado con el plugin: la ayuda funciona sin conexion.
"""

from __future__ import annotations

import os
import re

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QFont, QTextDocument
from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSplitter,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from ..i18n import IDIOMAS, NOMBRES, idioma, t
from .qtcompat import HORIZONTAL, ROL_ACCION, ROL_RECHAZAR, ROL_USUARIO

CARPETA_DOCS = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs"
)

#: Plantilla del nombre del archivo de ayuda. Hay uno por idioma.
ARCHIVO_AYUDA = "ayuda_{lang}.html"

#: Encabezados de nivel 2 con ancla: ``<h2 id="x">1. Titulo</h2>``.
_SECCION = re.compile(
    r'<h2\s+id="(?P<ancla>[^"]+)"\s*>(?P<titulo>.*?)</h2>', re.IGNORECASE | re.DOTALL
)


def ruta_ayuda(lang: str = "") -> str:
    """Archivo de ayuda del idioma pedido, o de cualquier otro que si este.

    La ayuda es un documento por idioma, no una traduccion cadena a cadena: son
    setenta kilobytes de prosa con sus propios ejemplos. Mientras falte la de un
    idioma se entrega la del otro, que es mucho mejor que una ventana vacia;
    :func:`es_de_otro_idioma` deja avisarlo.
    """
    lang = lang or idioma()
    ruta = os.path.join(CARPETA_DOCS, ARCHIVO_AYUDA.format(lang=lang))
    if os.path.exists(ruta):
        return ruta
    for otro in IDIOMAS:
        alternativa = os.path.join(CARPETA_DOCS, ARCHIVO_AYUDA.format(lang=otro))
        if os.path.exists(alternativa):
            return alternativa
    return ruta


def es_de_otro_idioma(lang: str = "") -> str:
    """Codigo del idioma en que se va a mostrar la ayuda, si no es el pedido.

    Cadena vacia cuando la ayuda esta en el idioma que toca.
    """
    lang = lang or idioma()
    if os.path.basename(ruta_ayuda(lang)) == ARCHIVO_AYUDA.format(lang=lang):
        return ""
    for otro in IDIOMAS:
        if os.path.basename(ruta_ayuda(lang)) == ARCHIVO_AYUDA.format(lang=otro):
            return otro
    return ""


def leer_ayuda(lang: str = "") -> str:
    """Contenido del HTML de ayuda, o un mensaje si no esta."""
    ruta = ruta_ayuda(lang)
    try:
        with open(ruta, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError as exc:
        return (
            "<h1>" + t("The help file cannot be found") + "</h1>"
            "<p>"
            + t(
                "Could not read <tt>{ruta}</tt>: {error}", ruta=ruta, error=exc
            )
            + "</p><p>"
            + t(
                "Run <tt>instalar.bat</tt> again: the <tt>docs</tt> folder was "
                "probably not copied."
            )
            + "</p>"
        )


def secciones(html: str) -> list:
    """``[(ancla, titulo)]`` de los encabezados de nivel 2 del documento."""
    salida = []
    for m in _SECCION.finditer(html):
        titulo = re.sub(r"<[^>]+>", "", m.group("titulo"))
        titulo = " ".join(titulo.split())
        salida.append((m.group("ancla"), titulo))
    return salida


class AyudaDialog(QDialog):
    """Documentacion del plugin, con indice y busqueda."""

    def __init__(self, parent=None, ancla: str = ""):
        super().__init__(parent)
        self.setWindowTitle("AQGIS-Sivil3D — " + t("Help"))
        self.resize(1020, 720)
        self._html = leer_ayuda()

        raiz = QVBoxLayout(self)
        raiz.addLayout(self._barra())

        otro = es_de_otro_idioma()
        if otro:
            # La ayuda de este idioma todavia no esta traducida: se entrega la
            # que hay y se dice, en vez de dejar la ventana vacia.
            aviso = QLabel(
                t(
                    "The help is not available in this language yet; it is "
                    "shown in {idioma}.",
                    idioma=NOMBRES.get(otro, otro),
                )
            )
            aviso.setWordWrap(True)
            aviso.setStyleSheet("color:#a06000;")
            raiz.addWidget(aviso)

        divisor = QSplitter(HORIZONTAL)
        self.indice = QListWidget()
        self.indice.setMinimumWidth(230)
        self.indice.setMaximumWidth(330)
        self.indice.currentItemChanged.connect(self._ir_a_seccion)
        divisor.addWidget(self.indice)

        self.texto = QTextBrowser()
        self.texto.setOpenExternalLinks(True)
        # Para que las rutas relativas del HTML (si algun dia hay imagenes) se
        # resuelvan dentro de la carpeta de documentacion.
        self.texto.setSearchPaths([CARPETA_DOCS])
        self.texto.setHtml(self._html)
        divisor.addWidget(self.texto)
        divisor.setStretchFactor(0, 0)
        divisor.setStretchFactor(1, 1)
        raiz.addWidget(divisor, 1)

        botones = QDialogButtonBox()
        btn_inicio = botones.addButton(t("Go to the top"), ROL_ACCION)
        btn_inicio.clicked.connect(lambda: self.texto.moveCursor(_INICIO))
        botones.addButton(t("Close"), ROL_RECHAZAR)
        botones.rejected.connect(self.accept)
        raiz.addWidget(botones)

        self._llenar_indice()
        #: Ancla pendiente: el salto se aplica al mostrarse, porque hasta que el
        #: documento no esta maquetado ``scrollToAnchor`` no tiene donde ir.
        self._pendiente = ancla
        if ancla:
            self.ir_a(ancla)

    # -- interfaz ----------------------------------------------------------
    def _barra(self) -> QHBoxLayout:
        b = QHBoxLayout()
        b.addWidget(QLabel(t("Find")))
        self.ed_buscar = QLineEdit()
        self.ed_buscar.setPlaceholderText(
            t("text to find in the help; Enter goes to the next match")
        )
        self.ed_buscar.returnPressed.connect(self._buscar)
        b.addWidget(self.ed_buscar, 1)
        btn = QPushButton(t("Next"))
        btn.clicked.connect(self._buscar)
        b.addWidget(btn)
        self.lbl_busqueda = QLabel()
        self.lbl_busqueda.setStyleSheet("color:#a06000;")
        b.addWidget(self.lbl_busqueda)
        return b

    def _llenar_indice(self) -> None:
        self.indice.clear()
        for ancla, titulo in secciones(self._html):
            item = QListWidgetItem(titulo)
            item.setData(ROL_USUARIO, ancla)
            self.indice.addItem(item)
        if not self.indice.count():
            self.indice.addItem(t("(the help has no sections)"))

    # -- navegacion --------------------------------------------------------
    def _ir_a_seccion(self, actual, _anterior) -> None:
        if actual is None:
            return
        ancla = actual.data(ROL_USUARIO)
        if ancla:
            self.texto.scrollToAnchor(ancla)

    def ir_a(self, ancla: str) -> bool:
        """Salta a una seccion por su ancla y la marca en el indice."""
        for i in range(self.indice.count()):
            item = self.indice.item(i)
            if item.data(ROL_USUARIO) == ancla:
                self.indice.setCurrentRow(i)
                return True
        self.texto.scrollToAnchor(ancla)
        return False

    def showEvent(self, evento) -> None:
        super().showEvent(evento)
        if self._pendiente:
            self.texto.scrollToAnchor(self._pendiente)
            self._pendiente = ""

    def _buscar(self) -> None:
        texto = self.ed_buscar.text().strip()
        if not texto:
            self.lbl_busqueda.clear()
            return
        if self.texto.find(texto):
            self.lbl_busqueda.clear()
            return
        # No hay mas apariciones: se vuelve al principio y se reintenta, que es lo
        # que espera cualquiera al pulsar "siguiente" al final del documento.
        self.texto.moveCursor(_INICIO)
        if self.texto.find(texto):
            self.lbl_busqueda.setText(t("(wrapped to the top)"))
        else:
            self.lbl_busqueda.setText(t("no matches"))


def _cursor_inicio():
    """``QTextCursor.Start``, con o sin ambito segun la version de Qt."""
    from qgis.PyQt.QtGui import QTextCursor

    ambito = getattr(QTextCursor, "MoveOperation", QTextCursor)
    return getattr(ambito, "Start")


_INICIO = _cursor_inicio()


def abrir_ayuda_en(ancla: str, padre=None) -> None:
    """Abre la ayuda en una seccion concreta. La usan los botones de los dialogos."""
    from .qtcompat import ejecutar_modal

    ejecutar_modal(AyudaDialog(padre, ancla))


__all__ = [
    "AyudaDialog",
    "abrir_ayuda_en",
    "ruta_ayuda",
    "leer_ayuda",
    "secciones",
    "es_de_otro_idioma",
    "CARPETA_DOCS",
]
