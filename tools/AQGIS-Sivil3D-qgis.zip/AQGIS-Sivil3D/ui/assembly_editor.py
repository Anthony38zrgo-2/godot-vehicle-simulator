"""Editor de secciones tipo.

La seccion se edita como lo que es: una cadena ordenada de elementos, por
separado en cada lado y con dos alternativas al final (desmonte / terraplen). El
orden dentro de cada grupo es el orden de construccion, asi que subir y bajar
elementos cambia la geometria; de ahi que los botones de orden esten a la vista.

A la derecha se ve la seccion resuelta sobre una ladera sintetica cuya pendiente
se puede mover: es la forma rapida de comprobar que el talud engancha, que la
banqueta cabe y que los dos lados hacen lo que se espera.
"""

from __future__ import annotations

import os
from typing import Optional

from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTextEdit,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .dialogos import ajustar_a_pantalla
from .qtcompat import (
    BOTON_SI,
    ROL_AYUDA,
    GRIS,
    HORIZONTAL,
    ITEM_HABILITADO,
    POPUP_INSTANTANEO,
    ROL_ACEPTAR,
    ROL_RECHAZAR,
    ROL_USUARIO,
    SEL_SIMPLE,
    VERTICAL,
)

from ..core.elements import GRUPO_LABEL, GRUPOS, elements_for
from ..core.library import AssemblyLibrary, default_library
from ..core.params import ParamError
from ..core.preview import campos_referenciados, sanitize_for_preview
from ..core.resolver import SectionOptions
from ..core.schema import Assembly, Element
from ..core.templates import TEMPLATES, load_template
from ..etiquetas import origen_cota as etiqueta_origen_cota
from ..i18n import t
from .ayuda_dialog import abrir_ayuda_en
from .param_form import ParamForm
from .section_preview import SectionPreview

ROL_DATOS = ROL_USUARIO


# --------------------------------------------------------------------------


class BranchPanel(QWidget):
    """Arbol de una rama (un lado) con sus botones de edicion."""

    cambiado = pyqtSignal()
    seleccion = pyqtSignal(int, object)  # (side, Element | None)
    copiar_a_otro_lado = pyqtSignal(int)  # side de origen

    def __init__(self, side: int, parent=None):
        super().__init__(parent)
        self.side = side
        self.branch = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(3)

        titulo = QLabel(
            "<b>" + (t("Left") if side < 0 else t("Right")) + "</b>"
        )
        cab = QHBoxLayout()
        cab.addWidget(titulo)
        cab.addStretch(1)
        btn_copiar = QToolButton()
        btn_copiar.setText(t("copy to the other side"))
        btn_copiar.setToolTip(
            t(
                "Overwrites the branch on the other side with this one. "
                "Handy for symmetric sections: define one side and copy it."
            )
        )
        btn_copiar.clicked.connect(lambda: self.copiar_a_otro_lado.emit(self.side))
        cab.addWidget(btn_copiar)
        lay.addLayout(cab)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setSelectionMode(SEL_SIMPLE)
        self.tree.setRootIsDecorated(True)
        self.tree.setUniformRowHeights(True)
        self.tree.currentItemChanged.connect(self._cambio_seleccion)
        lay.addWidget(self.tree, 1)

        barra = QHBoxLayout()
        barra.setSpacing(2)
        self.btn_add = QToolButton()
        self.btn_add.setText(t("Add"))
        self.btn_add.setPopupMode(POPUP_INSTANTANEO)
        self.menu_add = QMenu(self.btn_add)
        self.btn_add.setMenu(self.menu_add)
        self.menu_add.aboutToShow.connect(self._llenar_menu_add)
        barra.addWidget(self.btn_add)
        for texto, tip, slot in (
            (t("Duplicate"), t("Duplicates the selected element"), self._duplicar),
            (t("Remove"), t("Deletes the selected element"), self._quitar),
            (
                t("Up"),
                t("Moves the element earlier in the chain"),
                lambda: self._mover(-1),
            ),
            (
                t("Down"),
                t("Moves the element later in the chain"),
                lambda: self._mover(1),
            ),
        ):
            b = QToolButton()
            b.setText(texto)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            barra.addWidget(b)
        barra.addStretch(1)
        lay.addLayout(barra)

    # -- modelo ------------------------------------------------------------
    def set_branch(self, branch) -> None:
        self.branch = branch
        self.recargar()

    def recargar(self, seleccionar: Optional[tuple] = None) -> None:
        self.tree.blockSignals(True)
        self.tree.clear()
        if self.branch is not None:
            for grupo in GRUPOS:
                raiz = QTreeWidgetItem([t(GRUPO_LABEL[grupo])])
                f = QFont(raiz.font(0))
                f.setBold(True)
                raiz.setFont(0, f)
                raiz.setData(0, ROL_DATOS, (grupo, -1))
                raiz.setFlags(ITEM_HABILITADO)
                self.tree.addTopLevelItem(raiz)
                elementos = self.branch.grupo(grupo)
                if not elementos:
                    hueco = QTreeWidgetItem([t("(empty)")])
                    hueco.setForeground(0, GRIS)
                    hueco.setFlags(ITEM_HABILITADO)
                    hueco.setData(0, ROL_DATOS, (grupo, -1))
                    raiz.addChild(hueco)
                for i, el in enumerate(elementos):
                    desc = el.describe()
                    hijo = QTreeWidgetItem(
                        [f"{el.codigo}   {('· ' + desc) if desc else ''}"]
                    )
                    hijo.setToolTip(0, t(el.definicion().descripcion))
                    hijo.setData(0, ROL_DATOS, (grupo, i))
                    raiz.addChild(hijo)
                raiz.setExpanded(True)
        self.tree.blockSignals(False)
        if seleccionar is not None:
            self._seleccionar(*seleccionar)
        self._cambio_seleccion(self.tree.currentItem(), None)

    def _seleccionar(self, grupo: str, idx: int) -> None:
        for i in range(self.tree.topLevelItemCount()):
            raiz = self.tree.topLevelItem(i)
            g, _ = raiz.data(0, ROL_DATOS)
            if g != grupo:
                continue
            for j in range(raiz.childCount()):
                hijo = raiz.child(j)
                gg, ii = hijo.data(0, ROL_DATOS)
                if ii == idx:
                    self.tree.setCurrentItem(hijo)
                    return

    # -- estado de la seleccion -------------------------------------------
    def _actual(self) -> tuple:
        """``(grupo, indice)``; indice -1 si no hay elemento seleccionado."""
        it = self.tree.currentItem()
        if it is None:
            return ("", -1)
        datos = it.data(0, ROL_DATOS)
        if not datos:
            return ("", -1)
        return datos

    def _grupo_destino(self) -> str:
        grupo, _ = self._actual()
        if grupo:
            return grupo
        it = self.tree.currentItem()
        if it is not None and it.parent() is not None:
            return it.parent().data(0, ROL_DATOS)[0]
        return GRUPOS[0]

    def _cambio_seleccion(self, actual, _anterior) -> None:
        grupo, idx = self._actual()
        if self.branch is None or idx < 0:
            self.seleccion.emit(self.side, None)
            return
        elementos = self.branch.grupo(grupo)
        self.seleccion.emit(
            self.side, elementos[idx] if 0 <= idx < len(elementos) else None
        )

    def deseleccionar(self) -> None:
        """Quita la seleccion sin emitir nada (la gestiona el editor)."""
        self.tree.blockSignals(True)
        self.tree.setCurrentItem(None)
        self.tree.clearSelection()
        self.tree.blockSignals(False)

    # -- acciones ----------------------------------------------------------
    def _llenar_menu_add(self) -> None:
        self.menu_add.clear()
        for grupo in GRUPOS:
            sub = self.menu_add.addMenu(t(GRUPO_LABEL[grupo]))
            for d in elements_for(grupo):
                acc = sub.addAction(t(d.label))
                acc.setToolTip(t(d.descripcion))
                acc.triggered.connect(
                    lambda _c=False, g=grupo, t=d.tipo: self._anadir(g, t)
                )

    def _anadir(self, grupo: str, tipo: str) -> None:
        if self.branch is None:
            return
        el = Element(tipo=tipo)
        el.params = dict(el.definicion().defaults())
        elementos = self.branch.grupo(grupo)
        grupo_actual, idx = self._actual()
        pos = idx + 1 if (grupo_actual == grupo and idx >= 0) else len(elementos)
        elementos.insert(pos, el)
        self.recargar((grupo, pos))
        self.cambiado.emit()

    def _duplicar(self) -> None:
        grupo, idx = self._actual()
        if self.branch is None or idx < 0:
            return
        elementos = self.branch.grupo(grupo)
        elementos.insert(idx + 1, elementos[idx].copy())
        self.recargar((grupo, idx + 1))
        self.cambiado.emit()

    def _quitar(self) -> None:
        grupo, idx = self._actual()
        if self.branch is None or idx < 0:
            return
        elementos = self.branch.grupo(grupo)
        elementos.pop(idx)
        self.recargar((grupo, min(idx, len(elementos) - 1)))
        self.cambiado.emit()

    def _mover(self, delta: int) -> None:
        grupo, idx = self._actual()
        if self.branch is None or idx < 0:
            return
        elementos = self.branch.grupo(grupo)
        j = idx + delta
        if j < 0 or j >= len(elementos):
            return
        elementos[idx], elementos[j] = elementos[j], elementos[idx]
        self.recargar((grupo, j))
        self.cambiado.emit()

    def refrescar_textos(self) -> None:
        """Actualiza el rotulo del elemento seleccionado, sin tocar el arbol.

        Reconstruir el arbol en cada pulsacion de tecla haria que el formulario
        se regenerase y el campo que se esta escribiendo perdiese el foco y el
        cursor, asi que aqui solo se reescribe el texto de la fila.
        """
        it = self.tree.currentItem()
        grupo, idx = self._actual()
        if it is None or self.branch is None or idx < 0:
            return
        elementos = self.branch.grupo(grupo)
        if not (0 <= idx < len(elementos)):
            return
        el = elementos[idx]
        desc = el.describe()
        it.setText(0, f"{el.codigo}   {('· ' + desc) if desc else ''}")


# --------------------------------------------------------------------------


class AssemblyEditor(QDialog):
    """Dialogo de edicion de la libreria de secciones."""

    def __init__(self, library: Optional[AssemblyLibrary] = None, path: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle(t("Typical cross sections"))
        ajustar_a_pantalla(self, 1180, 720)
        self.library = library.copy() if library is not None else default_library()
        self.path = path
        self._asm: Optional[Assembly] = None
        self._cargando = False
        self._side_activo = -1

        raiz = QHBoxLayout(self)
        raiz.addWidget(self._panel_libreria(), 0)
        raiz.addWidget(self._panel_seccion(), 1)

        self._recargar_lista(self.library.first())

    # -- paneles -----------------------------------------------------------
    def _panel_libreria(self) -> QWidget:
        caja = QGroupBox(t("Library"))
        caja.setMinimumWidth(220)
        caja.setMaximumWidth(280)
        lay = QVBoxLayout(caja)
        self.lista = QListWidget()
        self.lista.currentTextChanged.connect(self._elegir_seccion)
        lay.addWidget(self.lista, 1)

        fila1 = QHBoxLayout()
        self.btn_nueva = QToolButton()
        self.btn_nueva.setText(t("New"))
        self.btn_nueva.setPopupMode(POPUP_INSTANTANEO)
        menu = QMenu(self.btn_nueva)
        menu.addAction(t("Empty"), self._nueva_vacia)
        sub = menu.addMenu(t("From template"))
        for clave in TEMPLATES:
            sub.addAction(
                load_template(clave).nombre,
                lambda _c=False, k=clave: self._nueva_plantilla(k)
            )
        self.btn_nueva.setMenu(menu)
        fila1.addWidget(self.btn_nueva)
        for texto, slot in (
            (t("Duplicate"), self._duplicar_seccion),
            (t("Rename"), self._renombrar_seccion),
            (t("Remove"), self._quitar_seccion),
        ):
            b = QToolButton()
            b.setText(texto)
            b.clicked.connect(slot)
            fila1.addWidget(b)
        lay.addLayout(fila1)

        fila2 = QHBoxLayout()
        for texto, slot in (
            (t("Up"), lambda: self._mover_seccion(-1)),
            (t("Down"), lambda: self._mover_seccion(1)),
            (t("Import..."), self._importar),
            (t("Export..."), self._exportar)
        ):
            b = QToolButton()
            b.setText(texto)
            b.clicked.connect(slot)
            fila2.addWidget(b)
        lay.addLayout(fila2)

        self.lbl_ruta = QLabel()
        self.lbl_ruta.setWordWrap(True)
        f = QFont(self.lbl_ruta.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1.0))
        self.lbl_ruta.setFont(f)
        self.lbl_ruta.setStyleSheet("color:#777;")
        lay.addWidget(self.lbl_ruta)
        return caja

    def _panel_seccion(self) -> QWidget:
        cont = QWidget()
        lay = QVBoxLayout(cont)
        lay.setContentsMargins(0, 0, 0, 0)

        # --- cabecera: nombre, descripcion, eje ---
        cab = QFormLayout()
        self.ed_nombre = QLineEdit()
        self.ed_nombre.editingFinished.connect(self._nombre_editado)
        cab.addRow(t("Name"), self.ed_nombre)
        self.ed_desc = QLineEdit()
        self.ed_desc.textEdited.connect(self._desc_editada)
        cab.addRow(t("Description"), self.ed_desc)

        fila_eje = QHBoxLayout()
        self.cmb_cota = QComboBox()
        # Se ve traducido, se guarda la clave interna: va al JSON de la
        # libreria y tiene que leerse igual en los dos idiomas.
        for clave in ("terreno", "directriz"):
            self.cmb_cota.addItem(etiqueta_origen_cota(clave), clave)
        self.cmb_cota.setToolTip(
            t(
                "Where the axis elevation comes from. 'terrain' takes it "
                "from the DEM; 'alignment Z' takes it from the Z of the "
                "line (a grade line already designed). It can be forced in "
                "the corridor dialog."
            )
        )
        self.cmb_cota.currentIndexChanged.connect(
            lambda i, c=self.cmb_cota: self._set_eje("cota", c.itemData(i))
        )
        fila_eje.addWidget(QLabel(t("elevation")))
        fila_eje.addWidget(self.cmb_cota)
        self.sp_desnivel = QDoubleSpinBox()
        self.sp_desnivel.setRange(-1000.0, 1000.0)
        self.sp_desnivel.setDecimals(3)
        self.sp_desnivel.setSuffix(" m")
        self.sp_desnivel.setToolTip(
            t(
                "Height of the axis relative to that elevation. Negative "
                "excavates (trench)."
            )
        )
        self.sp_desnivel.valueChanged.connect(
            lambda v: self._set_eje("desnivel", float(v))
        )
        fila_eje.addWidget(QLabel(t("height difference")))
        fila_eje.addWidget(self.sp_desnivel)
        self.sp_desplaz = QDoubleSpinBox()
        self.sp_desplaz.setRange(-1000.0, 1000.0)
        self.sp_desplaz.setDecimals(3)
        self.sp_desplaz.setSuffix(" m")
        self.sp_desplaz.setToolTip(
            t(
                "Shifts the origin of offsets along the normal. It lets the "
                "layer line be something other than the section axis."
            )
        )
        self.sp_desplaz.valueChanged.connect(
            lambda v: self._set_eje("desplazamiento", float(v))
        )
        fila_eje.addWidget(QLabel(t("shift")))
        fila_eje.addWidget(self.sp_desplaz)
        fila_eje.addStretch(1)
        cab.addRow(t("Axis"), fila_eje)
        lay.addLayout(cab)

        # --- ramas + parametros + previsualizacion ---
        vertical = QSplitter(VERTICAL)

        arriba = QSplitter(HORIZONTAL)
        ramas = QWidget()
        lr = QHBoxLayout(ramas)
        lr.setContentsMargins(0, 0, 0, 0)
        self.panel_izq = BranchPanel(-1)
        self.panel_der = BranchPanel(1)
        for panel in (self.panel_izq, self.panel_der):
            panel.cambiado.connect(self._modelo_cambiado)
            panel.seleccion.connect(self._elemento_elegido)
            panel.copiar_a_otro_lado.connect(self._copiar_rama)
            lr.addWidget(panel)
        arriba.addWidget(ramas)

        self.form = ParamForm()
        self.form.cambiado.connect(self._params_cambiados)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.form)
        scroll.setMinimumWidth(290)
        arriba.addWidget(scroll)
        arriba.setStretchFactor(0, 3)
        arriba.setStretchFactor(1, 2)
        vertical.addWidget(arriba)

        vertical.addWidget(self._panel_preview())
        vertical.setStretchFactor(0, 3)
        vertical.setStretchFactor(1, 2)
        lay.addWidget(vertical, 1)

        self.lbl_problemas = QLabel()
        self.lbl_problemas.setWordWrap(True)
        self.lbl_problemas.setStyleSheet("color:#b06000;")
        lay.addWidget(self.lbl_problemas)

        botones = QDialogButtonBox()
        self.btn_guardar = botones.addButton(t("Save"), ROL_ACEPTAR)
        btn_ayuda = botones.addButton(t("Help"), ROL_AYUDA)
        btn_ayuda.clicked.connect(
            lambda: abrir_ayuda_en("editor", self)
        )
        botones.addButton(t("Close without saving"), ROL_RECHAZAR)
        botones.accepted.connect(self._guardar_y_cerrar)
        botones.rejected.connect(self.reject)
        lay.addWidget(botones)
        return cont

    def _panel_preview(self) -> QWidget:
        caja = QGroupBox(t("Preview over a synthetic hillside"))
        lay = QVBoxLayout(caja)
        lay.setContentsMargins(4, 4, 4, 4)
        self.preview = SectionPreview()
        lay.addWidget(self.preview, 1)

        ctr = QHBoxLayout()
        self.sp_pend = QDoubleSpinBox()
        self.sp_pend.setRange(-200.0, 200.0)
        self.sp_pend.setValue(20.0)
        self.sp_pend.setSuffix(" %")
        self.sp_pend.setToolTip(
            t(
                "Cross slope of the test terrain. With a high value you see "
                "the side-hill case: one side in cut and the other in fill."
            )
        )
        ctr.addWidget(QLabel(t("terrain")))
        ctr.addWidget(self.sp_pend)
        self.sp_delta = QDoubleSpinBox()
        self.sp_delta.setRange(-200.0, 200.0)
        self.sp_delta.setValue(0.0)
        self.sp_delta.setSuffix(" m")
        self.sp_delta.setToolTip(
            t(
                "Terrain elevation at the axis relative to the grade line. "
                "Positive = the terrain is above (cut); negative = fill."
            )
        )
        ctr.addWidget(QLabel(t("terrain at axis")))
        ctr.addWidget(self.sp_delta)
        self.sp_exa = QDoubleSpinBox()
        self.sp_exa.setRange(0.2, 20.0)
        self.sp_exa.setValue(1.0)
        self.sp_exa.setSingleStep(0.5)
        self.sp_exa.setToolTip(t("Vertical exaggeration of the drawing."))
        ctr.addWidget(QLabel(t("Z exag.")))
        ctr.addWidget(self.sp_exa)
        self.sp_ancho = QDoubleSpinBox()
        self.sp_ancho.setRange(5.0, 2000.0)
        self.sp_ancho.setValue(200.0)
        self.sp_ancho.setSuffix(" m")
        self.sp_ancho.setToolTip(t("Maximum half-width of the terrain search."))
        ctr.addWidget(QLabel(t("max width")))
        ctr.addWidget(self.sp_ancho)
        self.chk_codigos = QCheckBox(t("codes"))
        self.chk_codigos.setChecked(True)
        ctr.addWidget(self.chk_codigos)
        ctr.addStretch(1)
        for w in (self.sp_pend, self.sp_delta, self.sp_exa, self.sp_ancho):
            w.valueChanged.connect(self._refrescar_preview)
        self.chk_codigos.toggled.connect(self._refrescar_preview)
        lay.addLayout(ctr)

        self.ed_valores = QLineEdit()
        self.ed_valores.setPlaceholderText(
            t("test values for the @fields, e.g.  width=7, cut_slope=1:1")
        )
        self.ed_valores.setToolTip(
            t(
                "Only affects the preview. The '@field' parameters are "
                "replaced by these values; anything not given uses the "
                "default of the parameter."
            )
        )
        self.ed_valores.textEdited.connect(self._refrescar_preview)
        self.lbl_campos = QLabel()
        self.lbl_campos.setStyleSheet("color:#777;")
        f = QFont(self.lbl_campos.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1.0))
        self.lbl_campos.setFont(f)
        lay.addWidget(self.ed_valores)
        lay.addWidget(self.lbl_campos)
        return caja

    # -- libreria ----------------------------------------------------------
    def _recargar_lista(self, seleccionar: Optional[str]) -> None:
        self._cargando = True
        self.lista.clear()
        self.lista.addItems(self.library.names())
        self._cargando = False
        if seleccionar and seleccionar in self.library:
            for i in range(self.lista.count()):
                if self.lista.item(i).text() == seleccionar:
                    self.lista.setCurrentRow(i)
                    break
        elif self.lista.count():
            self.lista.setCurrentRow(0)
        else:
            self._asm = None
            self._pintar_seccion()
        self.lbl_ruta.setText(
            t("File: {ruta}", ruta=self.path)
            if self.path
            else t("Library not saved yet")
        )

    def _elegir_seccion(self, nombre: str) -> None:
        if self._cargando:
            return
        self._asm = self.library.get(nombre)
        self._pintar_seccion()

    def _nueva_vacia(self) -> None:
        asm = Assembly(nombre=t("New section"))
        nombre = self.library.add(asm)
        self._recargar_lista(nombre)

    def _nueva_plantilla(self, clave: str) -> None:
        nombre = self.library.add(load_template(clave))
        self._recargar_lista(nombre)

    def _duplicar_seccion(self) -> None:
        it = self.lista.currentItem()
        if it is None:
            return
        self._recargar_lista(self.library.duplicate(it.text()))

    def _renombrar_seccion(self) -> None:
        it = self.lista.currentItem()
        if it is None:
            return
        nuevo, ok = QInputDialog.getText(
            self, t("Rename section"), t("Name:"), text=it.text()
        )
        if not ok:
            return
        try:
            self._recargar_lista(self.library.rename(it.text(), nuevo))
        except ParamError as exc:
            QMessageBox.warning(self, t("Rename"), str(exc))

    def _quitar_seccion(self) -> None:
        it = self.lista.currentItem()
        if it is None:
            return
        if (
            QMessageBox.question(
                self,
                t("Remove section"),
                t("Remove '{n}' from the library?", n=it.text()),
            )
            != BOTON_SI
        ):
            return
        self.library.remove(it.text())
        self._recargar_lista(self.library.first())

    def _mover_seccion(self, delta: int) -> None:
        it = self.lista.currentItem()
        if it is None:
            return
        self.library.move(it.text(), delta)
        self._recargar_lista(it.text())

    def _importar(self) -> None:
        ruta, _ = QFileDialog.getOpenFileName(
            self, t("Import sections"), "", t("Sections (*.json)")
        )
        if not ruta:
            return
        try:
            otra = AssemblyLibrary.load(ruta)
        except (OSError, ParamError) as exc:
            QMessageBox.warning(self, t("Import"), str(exc))
            return
        ultimo = None
        for asm in otra.assemblies.values():
            ultimo = self.library.add(asm)
        self._recargar_lista(ultimo)

    def _exportar(self) -> None:
        ruta, _ = QFileDialog.getSaveFileName(
            self, t("Export sections"), "secciones.json", t("Sections (*.json)")
        )
        if not ruta:
            return
        if not ruta.lower().endswith(".json"):
            ruta += ".json"
        try:
            self.library.save(ruta)
        except OSError as exc:
            QMessageBox.warning(self, t("Export"), str(exc))
            return
        QMessageBox.information(
            self, t("Export"), t("Saved to {ruta}", ruta=ruta)
        )

    # -- seccion actual ----------------------------------------------------
    def _pintar_seccion(self) -> None:
        self._cargando = True
        asm = self._asm
        hay = asm is not None
        for w in (
            self.ed_nombre,
            self.ed_desc,
            self.cmb_cota,
            self.sp_desnivel,
            self.sp_desplaz,
        ):
            w.setEnabled(hay)
        if not hay:
            self.ed_nombre.clear()
            self.ed_desc.clear()
            self.panel_izq.set_branch(None)
            self.panel_der.set_branch(None)
            self.form.set_element(None)
            self.preview.limpiar(t("The library is empty. Create a section."))
            self.lbl_problemas.clear()
            self._cargando = False
            return
        self.ed_nombre.setText(asm.nombre)
        self.ed_desc.setText(asm.descripcion)
        cota = str(asm.eje.get("cota", "terreno"))
        i = self.cmb_cota.findData(cota)
        self.cmb_cota.setCurrentIndex(i if i >= 0 else 0)
        self.sp_desnivel.setValue(_num(asm.eje.get("desnivel"), 0.0))
        self.sp_desplaz.setValue(_num(asm.eje.get("desplazamiento"), 0.0))
        self.panel_izq.set_branch(asm.izquierda)
        self.panel_der.set_branch(asm.derecha)
        self._cargando = False
        self._refrescar_preview()

    def _nombre_editado(self) -> None:
        if self._cargando or self._asm is None:
            return
        viejo = self._asm.nombre
        nuevo = self.ed_nombre.text().strip()
        if not nuevo or nuevo == viejo:
            self.ed_nombre.setText(viejo)
            return
        try:
            self._recargar_lista(self.library.rename(viejo, nuevo))
        except ParamError as exc:
            QMessageBox.warning(self, t("Name"), str(exc))
            self.ed_nombre.setText(viejo)

    def _desc_editada(self, texto: str) -> None:
        if self._cargando or self._asm is None:
            return
        self._asm.descripcion = texto

    def _set_eje(self, clave: str, valor) -> None:
        if self._cargando or self._asm is None:
            return
        self._asm.eje[clave] = valor
        self._refrescar_preview()

    def _elemento_elegido(self, side: int, element) -> None:
        """Solo un lado a la vez manda en el formulario.

        Sin esto, cualquier refresco del panel que no tiene seleccion emitiria
        ``None`` y vaciaria el formulario del lado que si la tiene.
        """
        if element is not None:
            self._side_activo = side
            otro = self.panel_der if side < 0 else self.panel_izq
            otro.deseleccionar()
            self.form.set_element(element, self._cierra_grupo(side, element))
        elif side == self._side_activo:
            self.form.set_element(None)

    def _cierra_grupo(self, side: int, element) -> bool:
        """Si el elemento es el ultimo de su grupo.

        Gobierna los parametros de traspaso al elemento siguiente: en el ultimo
        no hay a quien traspasar, asi que el formulario los inhabilita.
        """
        if self._asm is None:
            return True
        rama = self._asm.branch(side)
        for grupo in GRUPOS:
            elementos = rama.grupo(grupo)
            for i, e in enumerate(elementos):
                if e is element:
                    return i == len(elementos) - 1
        return True

    def _params_cambiados(self) -> None:
        self.panel_izq.refrescar_textos()
        self.panel_der.refrescar_textos()
        self._refrescar_preview()

    def _modelo_cambiado(self) -> None:
        self._refrescar_preview()

    def _copiar_rama(self, side: int) -> None:
        if self._asm is None:
            return
        origen = self._asm.branch(side)
        if side < 0:
            self._asm.derecha = origen.copy()
        else:
            self._asm.izquierda = origen.copy()
        self.panel_izq.set_branch(self._asm.izquierda)
        self.panel_der.set_branch(self._asm.derecha)
        self._refrescar_preview()

    # -- previsualizacion --------------------------------------------------
    def _refrescar_preview(self) -> None:
        if self._cargando:
            return
        asm = self._asm
        if asm is None:
            self.preview.limpiar()
            return
        campos = campos_referenciados(asm)
        self.lbl_campos.setText(
            t("Fields used by this section: {campos}", campos=", ".join(campos))
            if campos
            else t("This section does not depend on layer fields.")
        )
        limpia = sanitize_for_preview(asm, _parsear_valores(self.ed_valores.text()))
        try:
            mat = limpia.materialize()
        except ParamError as exc:
            self.preview.limpiar(t("Invalid parameter: {error}", error=exc))
            self._pintar_problemas(asm, [str(exc)])
            return
        self.preview.pendiente_terreno = self.sp_pend.value()
        self.preview.delta_terreno = self.sp_delta.value()
        self.preview.exageracion = self.sp_exa.value()
        self.preview.mostrar_codigos = self.chk_codigos.isChecked()
        self.preview.actualizar(
            mat, SectionOptions(paso=0.25, ancho_max=self.sp_ancho.value())
        )
        self._pintar_problemas(asm, [])

    def _pintar_problemas(self, asm: Assembly, extra: list) -> None:
        problemas = list(extra) + asm.validate()
        if not problemas:
            self.lbl_problemas.setText("")
            return
        self.lbl_problemas.setText("⚠ " + "   ⚠ ".join(problemas[:4]))

    # -- cierre ------------------------------------------------------------
    def _guardar_y_cerrar(self) -> None:
        if not self.path:
            ruta, _ = QFileDialog.getSaveFileName(
                self,
                t("Save sections"),
                "secciones.json",
                t("Sections (*.json)"),
            )
            if not ruta:
                return
            self.path = ruta if ruta.lower().endswith(".json") else ruta + ".json"
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            self.library.save(self.path)
        except OSError as exc:
            QMessageBox.critical(
                self, t("Save"), t("Cannot save: {error}", error=exc)
            )
            return
        self.accept()


# --------------------------------------------------------------------------


def _num(valor, defecto: float) -> float:
    try:
        return float(valor)
    except (TypeError, ValueError):
        return defecto


def _parsear_valores(texto: str) -> dict:
    """``"ancho=7, talud=1:1"`` -> ``{'ancho': '7', 'talud': '1:1'}``."""
    salida = {}
    for trozo in (texto or "").replace(";", ",").split(","):
        if "=" not in trozo:
            continue
        k, v = trozo.split("=", 1)
        k, v = k.strip().lstrip("@"), v.strip()
        if k:
            salida[k] = v
    return salida


__all__ = ["AssemblyEditor", "BranchPanel"]
