"""Selector de alineaciones, compartido por el visor de perfiles y los planos.

Un corredor calculado puede tener varias alineaciones (una por *feature* de la
capa de directrices), y en una sesion puede haber varios corredores. Las dos
herramientas necesitan lo mismo: **elegir cuales entran**, no una sola.

De ahi este widget: una lista con casilla por alineacion.

* Las **marcadas** (casilla) son las que salen en el dibujo: todas a la vez en
  el perfil longitudinal y en el diagrama de masas, y todas en los planos.
* La **principal** (el desplegable de arriba) es la que manda donde solo cabe
  una: la seccion transversal, la navegacion por PK y, en los planos, el trazado
  que define las hojas de planta.

Asi se puede comparar dos trazados en el longitudinal sin perder la posibilidad
de ir mirando la seccion de uno de ellos.

La principal es un desplegable y no «la fila que este resaltada» a proposito: de
ella depende que sale en los planos, y eso no puede quedar escondido en un
detalle de la seleccion de una lista.

Indice estable
--------------
La lista se puede reordenar (por nombre o por fecha de creacion), asi que la
posicion de una fila no identifica a la alineacion. Cada una lleva su **indice
estable** —el orden en que se cargo— en ``ROL_USUARIO``, y es ese indice el que
se usa para el color y para devolverla al que pregunta. Asi el color de una
alineacion no cambia porque se haya cambiado el orden de la lista.
"""

from __future__ import annotations

from typing import Optional

from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QIcon, QPixmap
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QToolButton,
    QVBoxLayout,
)

from .qtcompat import (
    AJUSTE_MINIMO,
    BARRA_CUANDO_HAGA_FALTA,
    ELIDIR_DERECHA,
    ITEM_HABILITADO,
    ITEM_MARCABLE,
    ITEM_SELECCIONABLE,
    MARCADO,
    ROL_USUARIO,
    SIN_MARCAR,
)
from ..i18n import t

#: Colores con los que se distinguen las alineaciones cuando se dibujan juntas.
#: Se evita el azul del proyecto y el marron del terreno para no confundirlos.
COLORES = (
    QColor(20, 90, 190),
    QColor(200, 60, 60),
    QColor(120, 60, 170),
    QColor(0, 130, 100),
    QColor(210, 120, 0),
    QColor(70, 70, 70),
    QColor(180, 40, 130),
    QColor(40, 130, 190),
)


def color_de(indice: int) -> QColor:
    return COLORES[indice % len(COLORES)]


#: Criterios de orden de la lista. La clave es interna; el texto que se ve va
#: en ``ETIQUETA_ORDEN``.
ORDEN_FECHA = "fecha de creacion"
ORDEN_NOMBRE = "nombre"
ORDENES = (ORDEN_FECHA, ORDEN_NOMBRE)

ETIQUETA_ORDEN = {
    ORDEN_FECHA: "creation date",
    ORDEN_NOMBRE: "name",
}

#: Que sale marcado al cargar.
MARCAR_TODAS = "todas"
MARCAR_NINGUNA = "ninguna"
#: Solo las alineaciones de la capa activa en el arbol de capas. Si la capa
#: activa no es una capa de directrices con corredor, no se marca ninguna: es
#: mejor que el usuario elija a dibujar de golpe trazados que no ha pedido.
MARCAR_CAPA_ACTIVA = "capa activa"


def _politica(marcar) -> str:
    """Normaliza el ``marcar_todo`` recibido a una de las politicas."""
    if isinstance(marcar, bool):
        return MARCAR_TODAS if marcar else MARCAR_NINGUNA
    texto = str(marcar or "")
    return texto if texto in (MARCAR_TODAS, MARCAR_NINGUNA, MARCAR_CAPA_ACTIVA) else MARCAR_TODAS


def _icono(color: QColor, lado: int = 12) -> QIcon:
    """Cuadradito de color para identificar la alineacion en la lista."""
    pm = QPixmap(lado, lado)
    pm.fill(color)
    # PyQt5 no acepta un QPixmap donde se espera un QIcon: hay que envolverlo.
    return QIcon(pm)


class SelectorTramos(QGroupBox):
    """Lista de alineaciones con casilla, y una de ellas como actual."""

    #: Ha cambiado el conjunto de alineaciones marcadas.
    cambiado = pyqtSignal()
    #: Ha cambiado la alineacion actual (la que manda en la seccion y los PK).
    actual_cambiado = pyqtSignal()

    def __init__(self, titulo: str = "", parent=None):
        super().__init__(titulo or t("Alignments"), parent)
        self._corredores: dict = {}
        #: ``[(nombre_corredor, run)]`` en el orden de carga. El orden de la
        #: lista puede ser otro; la posicion en la lista no identifica nada.
        self._filas: list = []
        #: Texto de cada fila, en el mismo orden que ``_filas``.
        self._etiquetas: list = []
        self._marcar = MARCAR_TODAS
        self._capa_activa = ""
        self._silencio = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 4, 6, 6)
        lay.setSpacing(3)

        orden = QHBoxLayout()
        orden.setSpacing(4)
        orden.addWidget(QLabel(t("Order:")))
        self.cmb_orden = QComboBox()
        # Se muestra traducido y se guarda la clave interna.
        for clave in ORDENES:
            self.cmb_orden.addItem(t(ETIQUETA_ORDEN[clave]), clave)
        self.cmb_orden.setSizeAdjustPolicy(AJUSTE_MINIMO)
        self.cmb_orden.setToolTip(
            t(
                "How the list is sorted. By creation date the oldest corridors "
                "come first; by name, alphabetically. The colour of each "
                "alignment does not change when reordering."
            )
        )
        self.cmb_orden.currentIndexChanged.connect(self._orden_elegido)
        orden.addWidget(self.cmb_orden, 1)
        lay.addLayout(orden)

        cabecera = QHBoxLayout()
        cabecera.setSpacing(4)
        cabecera.addWidget(QLabel(t("Main:")))
        self.cmb_principal = QComboBox()
        self.cmb_principal.setMinimumWidth(140)
        self.cmb_principal.setSizeAdjustPolicy(AJUSTE_MINIMO)
        self.cmb_principal.setToolTip(
            t(
                "The alignment that rules where only one fits: the cross "
                "section, the station navigation and the layout that defines "
                "the plan sheets."
            )
        )
        self.cmb_principal.currentIndexChanged.connect(self._principal_elegida)
        cabecera.addWidget(self.cmb_principal, 1)
        lay.addLayout(cabecera)

        self.lista = QListWidget()
        self.lista.setMinimumHeight(130)
        self.lista.setMaximumHeight(320)
        # Ancho comodo para leer 'nombre del corredor · fid n · seccion tipo',
        # pero acotado: el que manda es el panel. Si la lista impusiera el ancho
        # del nombre mas largo, un corredor con nombre kilometrico haria el dock
        # mas ancho que la pantalla y Qt recortaria la barra de titulo.
        self.lista.setMinimumWidth(300)
        self.lista.setHorizontalScrollBarPolicy(BARRA_CUANDO_HAGA_FALTA)
        self.lista.setTextElideMode(ELIDIR_DERECHA)
        self.lista.setToolTip(
            t(
                "Check the alignments you want in the drawing. The main one is "
                "chosen in the drop-down above."
            )
        )
        self.lista.itemChanged.connect(self._item_cambiado)
        self.lista.currentRowChanged.connect(self._fila_cambiada)
        lay.addWidget(self.lista, 1)

        barra = QHBoxLayout()
        barra.setSpacing(3)
        for texto, tip, slot in (
            (
                t("All"),
                t("Check every alignment"),
                lambda: self.marcar_todas(True),
            ),
            (t("None"), t("Uncheck every alignment"), lambda: self.marcar_todas(False)),
            (
                t("This one only"),
                t("Leave only the current row checked"),
                self.solo_actual,
            ),
        ):
            b = QToolButton()
            b.setText(texto)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            barra.addWidget(b)
        barra.addStretch(1)
        self.lbl_cuenta = QLabel()
        f = QFont(self.lbl_cuenta.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1.0))
        self.lbl_cuenta.setFont(f)
        self.lbl_cuenta.setStyleSheet("color:#777;")
        barra.addWidget(self.lbl_cuenta)
        lay.addLayout(barra)

    # -- carga -------------------------------------------------------------
    def set_corredores(
        self,
        corredores: dict,
        marcar_todo=True,
        capa_activa: str = "",
    ) -> None:
        """Rellena la lista con todas las alineaciones de todos los corredores.

        ``marcar_todo`` acepta :data:`MARCAR_TODAS`, :data:`MARCAR_NINGUNA` o
        :data:`MARCAR_CAPA_ACTIVA`; tambien un booleano, por comodidad de quien
        solo quiere «todas o ninguna». Con :data:`MARCAR_CAPA_ACTIVA` se marcan
        solo las alineaciones de ``capa_activa`` (el id de la capa activa en el
        arbol de capas).
        """
        self._corredores = dict(corredores or {})
        self._marcar = _politica(marcar_todo)
        self._capa_activa = capa_activa
        self._filas = []
        self._etiquetas = []
        for nombre, result in self._corredores.items():
            for run in getattr(result, "runs", []) or []:
                # Con un solo corredor el nombre es redundante y solo estorba.
                self._etiquetas.append(
                    f"{run.etiqueta} · {run.asm_nombre}"
                    if len(self._corredores) == 1
                    else f"{nombre} · {run.etiqueta}"
                )
                self._filas.append((nombre, run))
        self._repintar()

    def _repintar(self) -> None:
        """Rehace la lista y el desplegable en el orden elegido."""
        self._silencio = True
        self.lista.clear()
        for indice in self._orden_de_filas():
            nombre, run = self._filas[indice]
            item = QListWidgetItem(self._etiquetas[indice])
            item.setIcon(_icono(color_de(indice)))
            item.setFlags(ITEM_HABILITADO | ITEM_MARCABLE | ITEM_SELECCIONABLE)
            item.setCheckState(MARCADO if self._marcado(indice) else SIN_MARCAR)
            item.setData(ROL_USUARIO, indice)
            n_secciones = sum(1 for s in run.sections if s.vertices)
            capa = getattr(run.alignment, "capa_nombre", "") or ""
            item.setToolTip(
                nombre
                + chr(10)
                + t(
                    "{etiqueta}: {n} sections, typical section '{asm}'",
                    etiqueta=run.etiqueta,
                    n=n_secciones,
                    asm=run.asm_nombre,
                )
                + (
                    chr(10) + t("alignment layer: {capa}", capa=capa)
                    if capa
                    else ""
                )
            )
            self.lista.addItem(item)
        self.cmb_principal.blockSignals(True)
        self.cmb_principal.clear()
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            self.cmb_principal.addItem(
                item.icon(), item.text(), item.data(ROL_USUARIO)
            )
        self.cmb_principal.blockSignals(False)
        self._silencio = False
        if self._filas:
            self.lista.setCurrentRow(0)
            self.cmb_principal.setCurrentIndex(0)
        self._actualizar_cuenta()
        self.cambiado.emit()
        self.actual_cambiado.emit()

    def _orden_de_filas(self) -> list:
        """Indices estables en el orden en que se van a mostrar."""
        indices = list(range(len(self._filas)))
        if self.cmb_orden.currentData() == ORDEN_NOMBRE:
            return sorted(indices, key=lambda i: self._etiquetas[i].lower())
        # Por fecha: la del corredor, y dentro de el el orden de calculo. Los
        # corredores sin fecha (archivos anteriores) van delante, en su orden.
        def clave(i):
            nombre, _run = self._filas[i]
            creado = str(getattr(self._corredores.get(nombre), "creado", "") or "")
            return (creado, i)

        return sorted(indices, key=clave)

    def _marcado(self, indice: int) -> bool:
        """Si la fila sale marcada al cargar, segun la politica elegida."""
        if self._marcar == MARCAR_TODAS:
            return True
        if self._marcar == MARCAR_NINGUNA:
            return False
        if not self._capa_activa:
            return False
        _nombre, run = self._filas[indice]
        return getattr(run.alignment, "capa_id", "") == self._capa_activa

    def set_orden(self, orden: str) -> None:
        """Cambia el criterio de orden de la lista."""
        if orden in ORDENES:
            i = self.cmb_orden.findData(orden)
            if i >= 0:
                self.cmb_orden.setCurrentIndex(i)

    def _orden_elegido(self, _indice: int) -> None:
        if self._filas:
            # Se conserva lo que estuviese marcado: reordenar no es recargar.
            marcadas = {i for i, _n, _r in self.seleccionados()}
            self._marcar, previo = MARCAR_NINGUNA, self._marcar
            self._repintar()
            self._marcar = previo
            self._silencio = True
            for i in range(self.lista.count()):
                if self.lista.item(i).data(ROL_USUARIO) in marcadas:
                    self.lista.item(i).setCheckState(MARCADO)
            self._silencio = False
            self._actualizar_cuenta()

    @property
    def vacio(self) -> bool:
        return not self._filas

    def __len__(self) -> int:
        return len(self._filas)

    # -- consulta ----------------------------------------------------------
    def seleccionados(self) -> list:
        """``[(indice, nombre_corredor, run)]`` de las alineaciones marcadas."""
        salida = []
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            if item.checkState() == MARCADO:
                indice = item.data(ROL_USUARIO)
                nombre, run = self._filas[indice]
                salida.append((indice, nombre, run))
        return salida

    def actual(self) -> Optional[tuple]:
        """``(indice, nombre_corredor, run)`` de la **principal**, o ``None``.

        Es la del desplegable, no la fila que este resaltada en la lista: de la
        principal depende lo que sale en los planos. El indice es el estable, no
        la posicion en la lista.
        """
        indice = self.cmb_principal.currentData()
        if indice is None or not 0 <= indice < len(self._filas):
            return None
        nombre, run = self._filas[indice]
        return (indice, nombre, run)

    #: Alias legible: en los planos se habla de «la principal».
    principal = actual

    def set_principal(self, indice: int) -> None:
        """Elige la alineacion principal por su indice estable."""
        pos = self.cmb_principal.findData(indice)
        if pos >= 0:
            self.cmb_principal.setCurrentIndex(pos)

    def set_principal_de_corredor(self, nombre: str) -> bool:
        """Hace principal la primera alineacion del corredor ``nombre``."""
        for indice, (n, _run) in enumerate(self._filas):
            if n == nombre:
                self.set_principal(indice)
                return True
        return False

    def color_actual(self) -> QColor:
        actual = self.actual()
        return color_de(actual[0] if actual else 0)

    def etiqueta_principal(self) -> str:
        """Texto de la alineacion principal, para los rotulos y el registro."""
        if self.actual() is None:
            return ""
        return self.cmb_principal.currentText()

    # -- acciones ----------------------------------------------------------
    def marcar_todas(self, marcar: bool) -> None:
        self._silencio = True
        for i in range(self.lista.count()):
            self.lista.item(i).setCheckState(MARCADO if marcar else SIN_MARCAR)
        self._silencio = False
        self._actualizar_cuenta()
        self.cambiado.emit()

    def solo_actual(self) -> None:
        """Deja marcada solo la principal."""
        actual = self.actual()
        if actual is None:
            return
        self._silencio = True
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            item.setCheckState(
                MARCADO if item.data(ROL_USUARIO) == actual[0] else SIN_MARCAR
            )
        self._silencio = False
        self._actualizar_cuenta()
        self.cambiado.emit()

    def marcar(self, indice: int, marcar: bool = True) -> None:
        """Marca o desmarca una alineacion por su indice estable."""
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            if item.data(ROL_USUARIO) == indice:
                item.setCheckState(MARCADO if marcar else SIN_MARCAR)
                return

    # -- interno -----------------------------------------------------------
    def _item_cambiado(self, _item) -> None:
        if self._silencio:
            return
        self._actualizar_cuenta()
        self.cambiado.emit()

    def _fila_cambiada(self, fila: int) -> None:
        """Resaltar una fila tambien la hace principal: es lo que se espera."""
        if self._silencio or fila < 0 or fila >= len(self._filas):
            return
        if self.cmb_principal.currentIndex() != fila:
            self.cmb_principal.setCurrentIndex(fila)
            return  # el cambio del combo ya emite la senal
        self.actual_cambiado.emit()

    def _principal_elegida(self, indice: int) -> None:
        if self._silencio or indice < 0 or indice >= len(self._filas):
            return
        if self.lista.currentRow() != indice:
            self._silencio = True
            self.lista.setCurrentRow(indice)
            self._silencio = False
        self.actual_cambiado.emit()

    def _actualizar_cuenta(self) -> None:
        n = len(self.seleccionados())
        total = len(self._filas)
        self.lbl_cuenta.setText(
            t("{n} of {total}", n=n, total=total) if total else t("no alignments")
        )


__all__ = [
    "SelectorTramos",
    "COLORES",
    "color_de",
    "ORDENES",
    "ETIQUETA_ORDEN",
    "ORDEN_FECHA",
    "ORDEN_NOMBRE",
    "MARCAR_TODAS",
    "MARCAR_NINGUNA",
    "MARCAR_CAPA_ACTIVA",
]
