"""Enums de Qt validos en PyQt5 (QGIS 3.x) y PyQt6 (QGIS 4.x).

En PyQt5 los enums se leen sin ambito (``Qt.UserRole``); en PyQt6 hay que dar el
ambito (``Qt.ItemDataRole.UserRole``) y el acceso plano ya no existe. En vez de
sembrar el codigo de ``try/except``, se resuelve todo una vez aqui y el resto de
la interfaz usa estas constantes.
"""

from __future__ import annotations

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPainter
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDialog,
    QFrame,
    QAbstractItemView,
    QDialogButtonBox,
    QMessageBox,
    QSizePolicy,
    QToolButton,
)


def ejecutar_modal(dialogo) -> int:
    """Abre el dialogo en modo modal, en PyQt5 y en PyQt6.

    PyQt6 elimino ``exec_()``, que en PyQt5 existia solo por compatibilidad con
    Python 2. ``exec()`` esta en las dos, pero se comprueba de todas formas para
    no depender de la version concreta de PyQt instalada.
    """
    metodo = getattr(dialogo, "exec", None) or getattr(dialogo, "exec_", None)
    if metodo is None:  # pragma: no cover
        raise AttributeError(f"{type(dialogo).__name__} no tiene exec() ni exec_()")
    return int(metodo())


def miembro(clase, nombre: str, *ambitos: str):
    """Miembro de enum, buscando primero en los ambitos y luego en la clase."""
    for a in ambitos:
        sub = getattr(clase, a, None)
        if sub is not None and hasattr(sub, nombre):
            return getattr(sub, nombre)
    if hasattr(clase, nombre):
        return getattr(clase, nombre)
    raise AttributeError(f"{clase.__name__}: no se encuentra '{nombre}'")


# -- Qt ---------------------------------------------------------------------
ROL_USUARIO = miembro(Qt, "UserRole", "ItemDataRole")
AL_CENTRO = miembro(Qt, "AlignCenter", "AlignmentFlag")
AL_IZQ = miembro(Qt, "AlignLeft", "AlignmentFlag")
AL_DER = miembro(Qt, "AlignRight", "AlignmentFlag")
AL_VCENTRO = miembro(Qt, "AlignVCenter", "AlignmentFlag")
TXT_AJUSTE = miembro(Qt, "TextWordWrap", "TextFlag")
SIN_PLUMA = miembro(Qt, "NoPen", "PenStyle")
SIN_PINCEL = miembro(Qt, "NoBrush", "BrushStyle")
GRIS = miembro(Qt, "gray", "GlobalColor")
VERTICAL = miembro(Qt, "Vertical", "Orientation")
HORIZONTAL = miembro(Qt, "Horizontal", "Orientation")
ITEM_HABILITADO = miembro(Qt, "ItemIsEnabled", "ItemFlag")
ITEM_MARCABLE = miembro(Qt, "ItemIsUserCheckable", "ItemFlag")
ITEM_SELECCIONABLE = miembro(Qt, "ItemIsSelectable", "ItemFlag")
ITEM_EDITABLE = miembro(Qt, "ItemIsEditable", "ItemFlag")
MARCADO = miembro(Qt, "Checked", "CheckState")
SIN_MARCAR = miembro(Qt, "Unchecked", "CheckState")
AREA_DOCK_ABAJO = miembro(Qt, "BottomDockWidgetArea", "DockWidgetArea")
BOTON_IZQUIERDO = miembro(Qt, "LeftButton", "MouseButton")
BOTON_MEDIO = miembro(Qt, "MiddleButton", "MouseButton")
BOTON_DERECHO = miembro(Qt, "RightButton", "MouseButton")
TECLA_SUPRIMIR = miembro(Qt, "Key_Delete", "Key")
TECLA_ESCAPE = miembro(Qt, "Key_Escape", "Key")
TECLA_A = miembro(Qt, "Key_A", "Key")
CURSOR_CRUZ = miembro(Qt, "CrossCursor", "CursorShape")
CURSOR_MANO = miembro(Qt, "PointingHandCursor", "CursorShape")
FOCO_FUERTE = miembro(Qt, "StrongFocus", "FocusPolicy")
LINEA_TRAZOS = miembro(Qt, "DashLine", "PenStyle")
LINEA_PUNTOS = miembro(Qt, "DotLine", "PenStyle")
MOD_CONTROL = miembro(Qt, "ControlModifier", "KeyboardModifier")
MOD_MAYUSCULAS = miembro(Qt, "ShiftModifier", "KeyboardModifier")

# -- widgets ----------------------------------------------------------------
SEL_SIMPLE = miembro(QAbstractItemView, "SingleSelection", "SelectionMode")
POPUP_INSTANTANEO = miembro(QToolButton, "InstantPopup", "ToolButtonPopupMode")
ROL_ACEPTAR = miembro(QDialogButtonBox, "AcceptRole", "ButtonRole")
ROL_RECHAZAR = miembro(QDialogButtonBox, "RejectRole", "ButtonRole")
ROL_ACCION = miembro(QDialogButtonBox, "ActionRole", "ButtonRole")
ROL_AYUDA = miembro(QDialogButtonBox, "HelpRole", "ButtonRole")
BOTON_SI = miembro(QMessageBox, "Yes", "StandardButton")
BOTON_OK = miembro(QDialogButtonBox, "Ok", "StandardButton")
BOTON_CANCELAR = miembro(QDialogButtonBox, "Cancel", "StandardButton")
DIALOGO_ACEPTADO = int(miembro(QDialog, "Accepted", "DialogCode"))
POL_EXPANDIR = miembro(QSizePolicy, "Expanding", "Policy")
FORMA_LINEA_VERTICAL = miembro(QFrame, "VLine", "Shape")
SIN_MARCO = miembro(QFrame, "NoFrame", "Shape")
BARRA_CUANDO_HAGA_FALTA = miembro(Qt, "ScrollBarAsNeeded", "ScrollBarPolicy")
ELIDIR_DERECHA = miembro(Qt, "ElideRight", "TextElideMode")
AJUSTE_MINIMO = miembro(QComboBox, "AdjustToMinimumContentsLengthWithIcon", "SizeAdjustPolicy")
ANTIALIAS = miembro(QPainter, "Antialiasing", "RenderHint")

__all__ = [
    "ejecutar_modal",
    "miembro",
    "ROL_USUARIO",
    "ITEM_EDITABLE",
    "BOTON_IZQUIERDO",
    "BOTON_DERECHO",
    "BOTON_MEDIO",
    "CURSOR_CRUZ",
    "CURSOR_MANO",
    "FOCO_FUERTE",
    "LINEA_PUNTOS",
    "MOD_CONTROL",
    "MOD_MAYUSCULAS",
    "LINEA_TRAZOS",
    "TECLA_A",
    "TECLA_ESCAPE",
    "TECLA_SUPRIMIR",
    "AL_CENTRO",
    "AL_IZQ",
    "AL_DER",
    "AL_VCENTRO",
    "TXT_AJUSTE",
    "SIN_PLUMA",
    "SIN_PINCEL",
    "GRIS",
    "VERTICAL",
    "HORIZONTAL",
    "ITEM_HABILITADO",
    "ITEM_MARCABLE",
    "ITEM_SELECCIONABLE",
    "MARCADO",
    "SIN_MARCAR",
    "AREA_DOCK_ABAJO",
    "SEL_SIMPLE",
    "POPUP_INSTANTANEO",
    "ROL_ACEPTAR",
    "ROL_RECHAZAR",
    "ROL_ACCION",
    "ROL_AYUDA",
    "BOTON_SI",
    "BOTON_OK",
    "BOTON_CANCELAR",
    "DIALOGO_ACEPTADO",
    "FORMA_LINEA_VERTICAL",
    "SIN_MARCO",
    "AJUSTE_MINIMO",
    "BARRA_CUANDO_HAGA_FALTA",
    "ELIDIR_DERECHA",
    "POL_EXPANDIR",
    "ANTIALIAS",
]
