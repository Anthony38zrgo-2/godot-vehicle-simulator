"""Que los dialogos quepan en la pantalla, siempre.

Un dialogo de Qt no puede ser mas pequeno que la suma de lo que piden sus
widgets. Con varios grupos de opciones, listas y tablas, ese minimo se pasa de
largo del alto de una pantalla normal, y entonces pasa esto: la ventana se sale,
los botones de *Generar* y *Cerrar* quedan fuera y, si el dialogo es modal, QGIS
se queda esperando a que se cierre algo que no se puede ni ver. Parece colgado.

La solucion es la de siempre: el **cuerpo** del dialogo va dentro de un area con
desplazamiento —asi puede encogerse todo lo que haga falta— y la **botonera** se
queda fuera, pegada abajo, para que este siempre a mano.
"""

from __future__ import annotations

from qgis.PyQt.QtWidgets import (
    QApplication,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .qtcompat import SIN_MARCO

#: Fraccion de la pantalla que puede ocupar un dialogo al abrirse.
FRACCION = 0.9


def cuerpo_con_scroll(dialogo, margen: int = 6) -> tuple:
    """Prepara el dialogo y devuelve ``(cuerpo, raiz)``.

    ``cuerpo`` es el layout donde van los grupos de opciones —dentro del area con
    desplazamiento— y ``raiz`` el del propio dialogo, para la botonera y todo lo
    que tenga que verse siempre.
    """
    raiz = QVBoxLayout(dialogo)
    raiz.setContentsMargins(margen, margen, margen, margen)
    raiz.setSpacing(4)

    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(SIN_MARCO)
    interior = QWidget()
    cuerpo = QVBoxLayout(interior)
    cuerpo.setContentsMargins(0, 0, 0, 0)
    area.setWidget(interior)
    raiz.addWidget(area, 1)
    return cuerpo, raiz


def ajustar_a_pantalla(dialogo, ancho: int, alto: int) -> None:
    """Abre el dialogo al tamano pedido, pero sin pasarse de la pantalla.

    Tambien baja su tamano minimo, porque el que calcula Qt a partir de los
    widgets puede ser mayor que el monitor y entonces la ventana no se deja
    encoger.
    """
    disponible = None
    pantalla = QApplication.primaryScreen()
    if pantalla is not None:
        disponible = pantalla.availableGeometry()
    if disponible is not None:
        ancho = min(ancho, int(disponible.width() * FRACCION))
        alto = min(alto, int(disponible.height() * FRACCION))
    dialogo.setMinimumSize(320, 240)
    dialogo.resize(ancho, alto)


__all__ = ["FRACCION", "ajustar_a_pantalla", "cuerpo_con_scroll"]
