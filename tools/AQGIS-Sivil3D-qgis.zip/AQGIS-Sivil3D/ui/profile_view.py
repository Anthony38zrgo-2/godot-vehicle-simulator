"""Dibujo de un perfil: proyecto contra terreno.

Un perfil longitudinal y una seccion transversal son el mismo dibujo: dos
polilineas de cota contra un eje horizontal, que en un caso es el PK y en el otro
la distancia al eje. Asi que hay un solo motor de dibujo y los dos visores son
este mismo widget con datos distintos.

Convenciones
------------
* marron = terreno, azul = proyecto;
* ocre = desmonte (proyecto por debajo), verde = terraplen (por encima), los
  mismos colores que la capa de TIN;
* circulo verde = punto donde el proyecto corta el terreno (daylight); rojo = el
  talud se ha truncado sin llegar a cortar.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from qgis.PyQt.QtCore import QPointF, QRectF, pyqtSignal
from qgis.PyQt.QtGui import (
    QColor,
    QFont,
    QFontMetricsF,
    QPainter,
    QPainterPath,
    QPen,
)
from qgis.PyQt.QtWidgets import QSizePolicy, QWidget

from ..core.perfil import SIGNO_DESMONTE, SIGNO_TERRAPLEN, tramos
from .qtcompat import (
    AL_CENTRO,
    AL_IZQ,
    ANTIALIAS,
    POL_EXPANDIR,
    SIN_PINCEL,
    SIN_PLUMA,
    TXT_AJUSTE,
)
from ..i18n import t

COL_FONDO = QColor(252, 252, 250)
COL_REJILLA = QColor(226, 226, 220)
COL_EJE = QColor(150, 150, 150)
COL_TERRENO = QColor(150, 105, 60)
COL_PROYECTO = QColor(20, 90, 190)
COL_DESMONTE = QColor(214, 170, 60, 90)
COL_TERRAPLEN = QColor(90, 170, 90, 90)
COL_DAY = QColor(0, 130, 60)
COL_TRUNCADO = QColor(200, 40, 40)
COL_TEXTO = QColor(70, 70, 70)
COL_AVISO = QColor(170, 40, 40)
COL_MARCA = QColor(20, 90, 190, 120)

MARGEN_IZQ = 46.0
MARGEN_DER = 12.0
MARGEN_SUP = 20.0
MARGEN_INF = 26.0

#: Clases de punto que se marcan con un circulo.
KIND_DAYLIGHT = "daylight"
KIND_TRUNCADO = "truncado"


@dataclass
class Marca:
    """Un punto rotulado del perfil."""

    x: float
    z: float
    texto: str = ""
    kind: str = "punto"


@dataclass
class Serie:
    """Una linea adicional superpuesta al perfil.

    Es lo que permite comparar dos alineaciones en el mismo dibujo: la principal
    va como ``proyecto`` y las demas entran aqui, cada una con su color.
    """

    puntos: list = field(default_factory=list)  #: [(x, z)]
    color: QColor = field(default_factory=lambda: QColor(120, 60, 170))
    etiqueta: str = ""
    grosor: float = 1.6
    discontinua: bool = False


@dataclass
class DatosPerfil:
    """Lo que hace falta para dibujar un perfil."""

    proyecto: list = field(default_factory=list)  #: [(x, z)]
    terreno: list = field(default_factory=list)  #: [(x, z)]
    marcas: list = field(default_factory=list)  #: [Marca]
    #: Lineas verticales de referencia, ``[(x, texto)]``: los PK del longitudinal
    #: o el eje de la seccion.
    verticales: list = field(default_factory=list)
    titulo: str = ""
    subtitulo: str = ""
    #: Nombre de la linea principal, para la leyenda cuando hay comparacion.
    titulo_proyecto: str = ""
    avisos: list = field(default_factory=list)
    unidad_x: str = "m"
    #: Cota que se resta en las etiquetas del eje vertical. Con ``None`` se
    #: rotulan cotas absolutas.
    z_referencia: Optional[float] = None
    #: ``False`` cuando los dos ejes no son de la misma magnitud (masas).
    isotropo: bool = True
    #: Lineas superpuestas, para comparar varias alineaciones a la vez.
    extras: list = field(default_factory=list)

    @property
    def todas_las_lineas(self) -> list:
        """Todas las polilineas del dibujo, para calcular los limites."""
        salida = [self.proyecto, self.terreno]
        salida.extend(e.puntos for e in self.extras)
        return [p for p in salida if p]

    @property
    def vacio(self) -> bool:
        return not any(len(p) >= 2 for p in self.todas_las_lineas)


class ProfileView(QWidget):
    """Vista de un perfil. Sirve para el longitudinal y para el transversal."""

    #: Se emite al pinchar: la abscisa del perfil donde se ha pinchado.
    pinchado = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(150)
        self.setSizePolicy(POL_EXPANDIR, POL_EXPANDIR)
        self.exageracion = 1.0
        self.mostrar_marcas = True
        self.mostrar_relleno = True
        #: Con ``True`` la escala horizontal y la vertical son la misma (salvo
        #: ``exageracion``), que es lo correcto para un perfil de terreno. Con
        #: ``False`` cada eje se ajusta por su cuenta: hace falta cuando los dos
        #: ejes no son de la misma magnitud, como en el diagrama de masas, que
        #: enfrenta metros con metros cubicos.
        self.isotropo = True
        #: Abscisa marcada con una linea vertical (el PK actual, por ejemplo).
        self.cursor: Optional[float] = None
        self._datos = DatosPerfil()
        self._mensaje = t("No data")
        self._caja = None  # transformacion vigente, para el pinchado

    # -- API ---------------------------------------------------------------
    def set_datos(self, datos: DatosPerfil, mensaje: str = "Sin datos") -> None:
        self._datos = datos or DatosPerfil()
        self._mensaje = mensaje
        # Los datos pueden imponer escalas independientes (diagrama de masas).
        self.isotropo = self._datos.isotropo
        self.update()

    def limpiar(self, mensaje: str = "Sin datos") -> None:
        self.set_datos(DatosPerfil(), mensaje)

    @property
    def datos(self) -> DatosPerfil:
        return self._datos

    # -- interaccion -------------------------------------------------------
    def mousePressEvent(self, event) -> None:
        if self._caja is None:
            return
        x0, esc_x, cx = self._caja
        self.pinchado.emit(x0 + (event.position().x() - cx) / esc_x
                           if hasattr(event, "position")
                           else x0 + (event.x() - cx) / esc_x)

    # -- pintado -----------------------------------------------------------
    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(ANTIALIAS, True)
        p.fillRect(self.rect(), COL_FONDO)
        d = self._datos
        if d.vacio:
            self._texto_centrado(p, self._mensaje)
            p.end()
            self._caja = None
            return

        puntos = [q for linea in d.todas_las_lineas for q in linea]
        x_min = min(q[0] for q in puntos)
        x_max = max(q[0] for q in puntos)
        z_min = min(q[1] for q in puntos)
        z_max = max(q[1] for q in puntos)
        if x_max - x_min < 1e-9:
            x_min, x_max = x_min - 1.0, x_max + 1.0
        if z_max - z_min < 1e-9:
            z_min, z_max = z_min - 1.0, z_max + 1.0

        w = max(1.0, self.width() - MARGEN_IZQ - MARGEN_DER)
        h = max(1.0, self.height() - MARGEN_SUP - MARGEN_INF)
        esc_x = w / (x_max - x_min)
        esc_z = h / (z_max - z_min)
        if self.isotropo:
            # Misma escala en los dos ejes salvo exageracion. En el longitudinal
            # la exageracion es imprescindible: si no, la rasante es una raya.
            esc_xf = min(esc_x, esc_z / max(self.exageracion, 1e-6))
            esc_zf = esc_xf * self.exageracion
        else:
            esc_xf, esc_zf = esc_x, esc_z
        cx = MARGEN_IZQ + (w - (x_max - x_min) * esc_xf) / 2.0
        cy = MARGEN_SUP + (h + (z_max - z_min) * esc_zf) / 2.0
        self._caja = (x_min, esc_xf, cx)

        def px(x: float, z: float) -> QPointF:
            return QPointF(cx + (x - x_min) * esc_xf, cy - (z - z_min) * esc_zf)

        self._rejilla(p, x_min, x_max, z_min, z_max, px)
        if self.mostrar_relleno:
            self._relleno(p, px)
        self._verticales(p, px, z_min, z_max)
        self._polilinea(p, d.terreno, COL_TERRENO, 1.8, px)
        self._polilinea(p, d.proyecto, COL_PROYECTO, 2.0, px)
        for extra in d.extras:
            self._polilinea(
                p,
                extra.puntos,
                extra.color,
                extra.grosor,
                px,
                discontinua=extra.discontinua,
            )
        self._marcas(p, px)
        self._leyenda(p)
        self._cursor(p, px, z_min, z_max)
        self._rotulos(p)
        p.end()

    # -- piezas ------------------------------------------------------------
    def _texto_centrado(self, p: QPainter, texto: str) -> None:
        p.setPen(QPen(COL_TEXTO))
        p.drawText(self.rect(), AL_CENTRO | TXT_AJUSTE, texto)

    def _rejilla(self, p, x_min, x_max, z_min, z_max, px) -> None:
        f = QFont(self.font())
        f.setPointSizeF(7.5)
        p.setFont(f)
        fm = QFontMetricsF(f)
        paso_x = _paso_bonito((x_max - x_min) / 8.0)
        paso_z = _paso_bonito((z_max - z_min) / 5.0)
        z_ref = self._datos.z_referencia

        x = math.ceil(x_min / paso_x) * paso_x
        while x <= x_max:
            a, b = px(x, z_min), px(x, z_max)
            p.setPen(QPen(COL_EJE if abs(x) < 1e-9 else COL_REJILLA, 1.0))
            p.drawLine(a, b)
            p.setPen(QPen(COL_TEXTO))
            txt = f"{x:.0f}"
            p.drawText(
                QPointF(a.x() - fm.horizontalAdvance(txt) / 2.0, a.y() + 13.0), txt
            )
            x += paso_x

        z = math.ceil(z_min / paso_z) * paso_z
        while z <= z_max:
            a, b = px(x_min, z), px(x_max, z)
            p.setPen(QPen(COL_REJILLA, 1.0))
            p.drawLine(a, b)
            p.setPen(QPen(COL_TEXTO))
            txt = f"{z:.1f}" if z_ref is None else f"{z - z_ref:+.1f}"
            p.drawText(
                QPointF(a.x() - fm.horizontalAdvance(txt) - 4.0, a.y() + 3.0), txt
            )
            z += paso_z

    def _relleno(self, p, px) -> None:
        d = self._datos
        if len(d.proyecto) < 2 or len(d.terreno) < 2:
            return
        p.setPen(SIN_PLUMA)
        for tramo in tramos(d.proyecto, d.terreno):
            if tramo.signo == SIGNO_DESMONTE:
                p.setBrush(COL_DESMONTE)
            elif tramo.signo == SIGNO_TERRAPLEN:
                p.setBrush(COL_TERRAPLEN)
            else:
                continue
            camino = QPainterPath()
            camino.moveTo(px(tramo.muestras[0][0], tramo.muestras[0][1]))
            for x, zp, _zt in tramo.muestras[1:]:
                camino.lineTo(px(x, zp))
            for x, _zp, zt in reversed(tramo.muestras):
                camino.lineTo(px(x, zt))
            camino.closeSubpath()
            p.drawPath(camino)
        p.setBrush(SIN_PINCEL)

    def _verticales(self, p, px, z_min, z_max) -> None:
        if not self._datos.verticales:
            return
        f = QFont(self.font())
        f.setPointSizeF(7.0)
        p.setFont(f)
        fm = QFontMetricsF(f)
        for x, texto in self._datos.verticales:
            p.setPen(QPen(COL_EJE, 0.8))
            p.drawLine(px(x, z_min), px(x, z_max))
            if texto:
                a = px(x, z_max)
                p.setPen(QPen(COL_TEXTO))
                p.drawText(
                    QPointF(a.x() - fm.horizontalAdvance(texto) / 2.0, a.y() - 3.0),
                    texto,
                )

    def _polilinea(self, p, pts, color, ancho, px, discontinua: bool = False) -> None:
        if len(pts) < 2:
            return
        pluma = QPen(color, ancho)
        if discontinua:
            pluma.setDashPattern([5.0, 3.0])
        p.setPen(pluma)
        camino = QPainterPath()
        camino.moveTo(px(*pts[0]))
        for x, z in pts[1:]:
            camino.lineTo(px(x, z))
        p.drawPath(camino)

    def _marcas(self, p, px) -> None:
        if not self.mostrar_marcas:
            return
        f = QFont(self.font())
        f.setPointSizeF(7.0)
        p.setFont(f)
        fm = QFontMetricsF(f)
        ocupados: list = []
        for m in self._datos.marcas:
            pt = px(m.x, m.z)
            if m.kind == KIND_TRUNCADO:
                p.setPen(QPen(COL_TRUNCADO, 2.0))
                p.setBrush(SIN_PINCEL)
                p.drawEllipse(pt, 4.5, 4.5)
            elif m.kind == KIND_DAYLIGHT:
                p.setPen(QPen(COL_DAY, 2.0))
                p.setBrush(SIN_PINCEL)
                p.drawEllipse(pt, 4.5, 4.5)
            else:
                p.setPen(QPen(COL_PROYECTO, 1.0))
                p.setBrush(COL_PROYECTO)
                p.drawEllipse(pt, 2.0, 2.0)
            if not m.texto:
                continue
            p.setBrush(SIN_PINCEL)
            p.setPen(QPen(COL_TEXTO))
            ancho = fm.horizontalAdvance(m.texto) + 4.0
            alto = fm.height()
            caja = None
            for dy in (-18.0, 10.0, -30.0, 22.0):
                cand = QRectF(pt.x() - ancho / 2.0, pt.y() + dy, ancho, alto)
                if cand.top() < MARGEN_SUP or cand.bottom() > self.height() - 14.0:
                    continue
                if not any(cand.intersects(c) for c in ocupados):
                    caja = cand
                    break
            if caja is None:
                continue
            ocupados.append(caja.adjusted(-2, -1, 2, 1))
            p.drawText(caja, AL_CENTRO, m.texto)

    def _cursor(self, p, px, z_min, z_max) -> None:
        if self.cursor is None:
            return
        p.setPen(QPen(COL_MARCA, 2.0))
        p.drawLine(px(self.cursor, z_min), px(self.cursor, z_max))

    def _leyenda(self, p) -> None:
        """Leyenda de lineas, solo cuando hay mas de una alineacion dibujada."""
        items = _leyenda_items(self._datos)
        if len(items) < 2:
            return
        f = QFont(self.font())
        f.setPointSizeF(7.5)
        p.setFont(f)
        fm = QFontMetricsF(f)
        ancho = max(fm.horizontalAdvance(t) for _c, t in items) + 26.0
        alto = len(items) * (fm.height() + 2.0) + 6.0
        x = self.width() - MARGEN_DER - ancho
        y = MARGEN_SUP + 2.0
        p.setPen(QPen(COL_REJILLA, 1.0))
        p.setBrush(QColor(255, 255, 255, 220))
        p.drawRect(QRectF(x, y, ancho, alto))
        p.setBrush(SIN_PINCEL)
        yy = y + 3.0
        for color, texto in items:
            p.setPen(QPen(color, 2.4))
            p.drawLine(
                QPointF(x + 4.0, yy + fm.height() / 2.0),
                QPointF(x + 20.0, yy + fm.height() / 2.0),
            )
            p.setPen(QPen(COL_TEXTO))
            p.drawText(QRectF(x + 23.0, yy, ancho - 26.0, fm.height()), AL_IZQ, texto)
            yy += fm.height() + 2.0

    def _rotulos(self, p) -> None:
        d = self._datos
        f = QFont(self.font())
        f.setPointSizeF(8.0)
        p.setFont(f)
        if d.titulo or d.subtitulo:
            p.setPen(QPen(COL_TEXTO))
            texto = d.titulo + ("   " + d.subtitulo if d.subtitulo else "")
            p.drawText(QRectF(6, 2, self.width() - 12, 15), AL_IZQ, texto)
        if d.avisos:
            p.setPen(QPen(COL_AVISO))
            p.drawText(
                QRectF(6, self.height() - 14, self.width() - 12, 13),
                AL_IZQ,
                "  ".join(d.avisos)[:220],
            )


def _leyenda_items(datos: DatosPerfil) -> list:
    """``[(color, etiqueta)]`` de las lineas que merece rotular."""
    items = []
    if datos.proyecto and datos.titulo_proyecto:
        items.append((COL_PROYECTO, datos.titulo_proyecto))
    for e in datos.extras:
        if e.etiqueta:
            items.append((e.color, e.etiqueta))
    return items


def _paso_bonito(bruto: float) -> float:
    """Redondea un paso de rejilla a 1, 2, 5 x 10^n."""
    if bruto <= 0.0:
        return 1.0
    exp = math.floor(math.log10(bruto))
    base = bruto / (10.0**exp)
    for cand in (1.0, 2.0, 5.0, 10.0):
        if base <= cand:
            return cand * (10.0**exp)
    return 10.0 ** (exp + 1)


# --------------------------------------------------------------------------
# Constructores de datos a partir del resultado del calculo
# --------------------------------------------------------------------------


def datos_de_seccion(sec, con_codigos: bool = True) -> DatosPerfil:
    """Datos de dibujo de una seccion transversal resuelta."""
    from ..core.elements import KIND_DAYLIGHT as K_DAY
    from ..core.elements import KIND_TRUNCADO as K_TRUNC

    marcas = []
    for v in sec.vertices:
        kind = (
            KIND_DAYLIGHT
            if v.kind == K_DAY
            else (KIND_TRUNCADO if v.kind == K_TRUNC else "punto")
        )
        marcas.append(Marca(v.offset, v.z, v.code if con_codigos else "", kind))
    des, ter = sec.areas()
    sub = t("cut {des:.2f} m2   fill {ter:.2f} m2", des=des, ter=ter)
    if sec.cota_roja is not None:
        sub = (
            t("cut/fill depth {v:+.2f} m   ", v=sec.cota_roja) + sub
        )
    return DatosPerfil(
        proyecto=sec.perfil,
        terreno=list(sec.terreno),
        marcas=marcas,
        verticales=[(0.0, "")],
        titulo=t("Sta {s:.2f}", s=sec.station.s),
        subtitulo=sub,
        avisos=list(sec.warnings),
        z_referencia=sec.z_eje if math.isfinite(sec.z_eje) else None,
    )


def datos_longitudinal(sections, pks=None) -> DatosPerfil:
    """Datos de dibujo del perfil longitudinal de un tramo.

    El proyecto es la rasante (cota del eje) y el terreno, la cota del DEM en el
    eje. Los PK redondos se marcan como lineas verticales.
    """
    proyecto = [
        (s.station.s, s.z_eje) for s in sections if math.isfinite(s.z_eje)
    ]
    terreno = [
        (s.station.s, s.z_terreno) for s in sections if s.z_terreno is not None
    ]
    verticales = [(st.s, "") for st in (pks or [])]
    avisos = []
    malas = sum(1 for s in sections if not s.ok)
    if malas:
        avisos.append(t("{n} sections with warnings", n=malas))
    return DatosPerfil(
        proyecto=proyecto,
        terreno=terreno,
        verticales=verticales,
        titulo=t("Longitudinal profile"),
        subtitulo=(
            t("Sta {a:.0f} to {b:.0f}", a=proyecto[0][0], b=proyecto[-1][0])
            if proyecto
            else ""
        ),
        avisos=avisos,
    )


def datos_masas(medicion) -> DatosPerfil:
    """Diagrama de masas: volumen neto acumulado contra PK."""
    if not medicion.masas:
        return DatosPerfil()
    return DatosPerfil(
        proyecto=list(medicion.masas),
        terreno=[(medicion.masas[0][0], 0.0), (medicion.masas[-1][0], 0.0)],
        titulo=t("Mass haul diagram"),
        subtitulo=medicion.resumen() + t("   (+ borrow, - surplus)"),
        unidad_x="m",
        isotropo=False,
    )


__all__ = [
    "ProfileView",
    "DatosPerfil",
    "Serie",
    "Marca",
    "datos_de_seccion",
    "datos_longitudinal",
    "datos_masas",
]
