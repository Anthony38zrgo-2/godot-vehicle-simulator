"""Previsualizacion de una seccion tipo sobre una ladera sintetica.

Es lo que se ve en el editor. El dibujo lo hace :class:`ProfileView`, el mismo
motor que el visor de perfiles, para que lo que se ve al definir la seccion y lo
que sale despues en el mapa y en los planos se lean igual.

Lo unico propio de este widget es el **terreno de prueba**: una ladera cuya
pendiente y desnivel respecto a la rasante se pueden mover, que es la forma
rapida de comprobar que el talud engancha, que la banqueta cabe y que los dos
lados hacen lo que se espera, sin necesidad de un DEM ni de una directriz.
"""

from __future__ import annotations

from ..core.resolver import SectionOptions, Station, plane_terrain, resolve_section
from ..etiquetas import modo as etiqueta_modo
from ..i18n import t
from .profile_view import ProfileView, datos_de_seccion

#: Cota arbitraria del eje en la previsualizacion. Da igual cual sea: el eje
#: vertical se rotula como desnivel respecto a ella.
Z_EJE_PREVIA = 100.0


class SectionPreview(ProfileView):
    """Vista transversal de una seccion resuelta contra un terreno sintetico."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(240)
        #: Pendiente transversal del terreno de prueba, en %.
        self.pendiente_terreno = 20.0
        #: Cota del terreno en el eje respecto a la rasante. Positivo = el
        #: terreno esta por encima, o sea desmonte en los dos lados.
        self.delta_terreno = 0.0
        self._sec = None
        self.limpiar()

    # -- compatibilidad con el editor --------------------------------------
    @property
    def mostrar_codigos(self) -> bool:
        return self.mostrar_marcas

    @mostrar_codigos.setter
    def mostrar_codigos(self, valor: bool) -> None:
        self.mostrar_marcas = bool(valor)

    @property
    def _section(self):
        """La ultima seccion resuelta, o ``None``."""
        return self._sec

    # -- API ---------------------------------------------------------------
    def actualizar(self, asm_materializada, opts: SectionOptions = None) -> None:
        """Resuelve la seccion contra el terreno de prueba y repinta."""
        self._sec = None
        if asm_materializada is None:
            self.limpiar()
            return
        opts = opts or SectionOptions()
        tz = plane_terrain(
            z_ref=Z_EJE_PREVIA + self.delta_terreno,
            pendiente_pct=self.pendiente_terreno,
            nx=0.0,
            ny=1.0,
        )
        st = Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0)
        try:
            sec = resolve_section(asm_materializada, st, tz, opts, z_eje=Z_EJE_PREVIA)
        except Exception as exc:  # noqa: BLE001 - se le muestra al usuario
            self.limpiar(t("Cannot resolve: {error}", error=exc))
            return
        if not sec.vertices:
            self.limpiar(t("The section does not generate any point"))
            return
        self._sec = sec
        datos = datos_de_seccion(sec, con_codigos=self.mostrar_marcas)
        # En el editor no hay PK: lo util en el titulo es el modo de cada lado.
        datos.titulo = t(
            "left: {modo_izq} ({ancho_izq:.2f} m)    "
            "right: {modo_der} ({ancho_der:.2f} m)    {n} points",
            modo_izq=etiqueta_modo(sec.modo_izq),
            ancho_izq=sec.ancho_izq,
            modo_der=etiqueta_modo(sec.modo_der),
            ancho_der=sec.ancho_der,
            n=len(sec.vertices),
        )
        self.set_datos(datos)

    def limpiar(self, mensaje: str = "") -> None:
        self._sec = None
        super().limpiar(mensaje or t("No section"))


__all__ = ["SectionPreview", "Z_EJE_PREVIA"]
