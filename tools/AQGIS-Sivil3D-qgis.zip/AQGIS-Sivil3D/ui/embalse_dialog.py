"""Dialogo de la curva de embalse: cota - volumen - superficie de un vaso.

Se elige el DEM y, si se quiere, un poligono con el que recortarlo. Sin recorte
se cubica el DEM tal cual y las salidas son el CSV y el PNG. Con recorte, ademas,
el DEM recortado se carga en el proyecto estilado como lamina de agua, con la
rampa estirada entre su cota minima y su maxima.
"""

from __future__ import annotations

import os
from typing import Optional

from qgis.core import QgsMapLayerProxyModel, QgsProject, QgsWkbTypes
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..core.embalse import cotas as vector_de_cotas
from ..gis.embalse import calcular_curva, capa_de_vaso, info_raster, recortar
from ..gis.registro import avisar
from ..i18n import numero, t
from .ayuda_dialog import abrir_ayuda_en
from .curva_view import CurvaView, datos_de_lectura
from .dialogos import ajustar_a_pantalla, cuerpo_con_scroll
from .qtcompat import ROL_ACCION, ROL_AYUDA, ROL_RECHAZAR

#: Tope de cotas de la curva. Con paso de 1 cm son 500 m de altura de presa.
MAX_COTAS = 200_000


def _titulo() -> str:
    """Titulo de los avisos del dialogo."""
    return t("Reservoir capacity curve")


def _nombre_seguro(texto: str) -> str:
    limpio = "".join(c if c.isalnum() or c in " -_." else "_" for c in texto)
    return limpio.strip().replace(" ", "_") or "curva"


class EmbalseDialog(QDialog):
    """Calcula la curva caracteristica de un embalse o balsa a partir del DEM."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle(
            t("Reservoir capacity curve (elevation - volume - area)")
        )
        ajustar_a_pantalla(self, 900, 720)
        self.curva = None
        self._ruta_recorte = ""
        self._nombre_dem = ""
        #: Se anade al nombre de los archivos cuando la curva es de un recorte,
        #: para no machacar la del DEM completo con la del vaso.
        self._sufijo = ""

        # El cuerpo va en un area con desplazamiento y la botonera fuera:
        # asi el dialogo cabe en cualquier pantalla y los botones se ven
        # siempre.
        lay, raiz = cuerpo_con_scroll(self)
        lay.addWidget(self._grupo_entrada())
        lay.addWidget(self._grupo_cotas())
        lay.addWidget(self._grupo_salidas())

        self.vista = CurvaView()
        self.lbl_lectura = QLabel(
            t(
                "Move the mouse over the curve to read values; click to "
                "pin an elevation."
            )
        )
        self.lbl_lectura.setStyleSheet("color:#666;")
        self.vista.cota_recorrida.connect(self._leer)
        self.vista.cota_pinchada.connect(self._fijar)
        lay.addWidget(self.lbl_lectura)
        lay.addWidget(self.vista, 1)

        self.barra = QProgressBar()
        self.barra.setVisible(False)
        lay.addWidget(self.barra)
        self.lbl_estado = QLabel(t("Choose the basin DEM and press Compute."))
        self.lbl_estado.setWordWrap(True)
        lay.addWidget(self.lbl_estado)

        botones = QDialogButtonBox()
        self.btn = botones.addButton(t("Compute curve"), ROL_ACCION)
        self.btn.clicked.connect(self.calcular)
        self.btn_csv = botones.addButton(t("Save CSV") + "…", ROL_ACCION)
        self.btn_csv.clicked.connect(self.guardar_csv)
        self.btn_png = botones.addButton(t("Save PNG") + "…", ROL_ACCION)
        self.btn_png.clicked.connect(self.guardar_png)
        botones.addButton(t("Close"), ROL_RECHAZAR).clicked.connect(self.reject)
        ayuda = botones.addButton(t("Help"), ROL_AYUDA)
        ayuda.clicked.connect(lambda: abrir_ayuda_en("embalse", self))
        raiz.addWidget(botones)
        self._habilitar_salidas(False)

        self.cmb_dem.layerChanged.connect(self._dem_cambiado)
        self._dem_cambiado()

    # -- construccion ------------------------------------------------------
    def _grupo_entrada(self) -> QWidget:
        g = QGroupBox("1 · " + t("Input data"))
        form = QFormLayout(g)
        self.cmb_dem = QgsMapLayerComboBox()
        self.cmb_dem.setFilters(QgsMapLayerProxyModel.RasterLayer)
        form.addRow(t("Basin DEM"), self.cmb_dem)

        fila = QHBoxLayout()
        self.chk_recorte = QCheckBox(t("Clip with a polygon"))
        self.chk_recorte.setToolTip(
            t(
                "With clipping only the area inside is evaluated, and "
                "the clipped DEM is loaded in the project styled as a "
                "water surface."
            )
        )
        self.cmb_pol = QgsMapLayerComboBox()
        self.cmb_pol.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cmb_pol.setEnabled(False)
        self.chk_sel = QCheckBox(t("selected features only"))
        self.chk_sel.setEnabled(False)
        self.chk_recorte.toggled.connect(self.cmb_pol.setEnabled)
        self.chk_recorte.toggled.connect(self.chk_sel.setEnabled)
        fila.addWidget(self.cmb_pol, 1)
        fila.addWidget(self.chk_sel)
        form.addRow(self.chk_recorte, fila)

        self.lbl_info = QLabel("-")
        self.lbl_info.setWordWrap(True)
        self.lbl_info.setStyleSheet("color:#555; font-family:monospace;")
        form.addRow(t("Raster"), self.lbl_info)
        return g

    def _grupo_cotas(self) -> QWidget:
        g = QGroupBox("2 · " + t("Elevations to compute"))
        form = QFormLayout(g)
        self.sp_ini = QDoubleSpinBox()
        self.sp_fin = QDoubleSpinBox()
        for sp in (self.sp_ini, self.sp_fin):
            sp.setRange(-11000.0, 9000.0)
            sp.setDecimals(3)
            sp.setSuffix(" m")
        self.sp_paso = QDoubleSpinBox()
        self.sp_paso.setRange(0.001, 100.0)
        self.sp_paso.setDecimals(3)
        self.sp_paso.setValue(0.1)
        self.sp_paso.setSuffix(" m")
        self.chk_auto = QCheckBox(
            t("From the raster minimum to its maximum (or the clip's, if any)")
        )
        self.chk_auto.setChecked(True)
        self.chk_auto.toggled.connect(self._auto_cambiado)
        form.addRow(self.chk_auto)
        fila = QHBoxLayout()
        fila.addWidget(QLabel(t("from")))
        fila.addWidget(self.sp_ini, 1)
        fila.addWidget(QLabel(t("to")))
        fila.addWidget(self.sp_fin, 1)
        fila.addWidget(QLabel(t("step")))
        fila.addWidget(self.sp_paso)
        form.addRow(t("Range"), fila)
        self.sp_ini.setEnabled(False)
        self.sp_fin.setEnabled(False)
        return g

    def _grupo_salidas(self) -> QWidget:
        g = QGroupBox("3 · " + t("Outputs"))
        form = QFormLayout(g)
        fila = QHBoxLayout()
        self.ed_carpeta = QLineEdit()
        self.ed_carpeta.setPlaceholderText(
            t("folder for the CSV, the PNG and the clipped DEM (optional)")
        )
        btn = QPushButton("…")
        btn.setMaximumWidth(30)
        btn.clicked.connect(self._elegir_carpeta)
        fila.addWidget(self.ed_carpeta, 1)
        fila.addWidget(btn)
        form.addRow(t("Folder"), fila)
        self.chk_auto_guardar = QCheckBox(
            t("Write the CSV and the PNG when the computation finishes")
        )
        self.chk_auto_guardar.setChecked(True)
        form.addRow(self.chk_auto_guardar)
        self.chk_cargar = QCheckBox(
            t("Load the clipped DEM in the project styled as a water surface")
        )
        self.chk_cargar.setChecked(True)
        self.chk_cargar.setToolTip(
            t("Only has an effect with clipping: it is the clip that is loaded.")
        )
        form.addRow(self.chk_cargar)
        return g

    # -- entradas ----------------------------------------------------------
    def _elegir_carpeta(self) -> None:
        ruta = QFileDialog.getExistingDirectory(
            self, t("Output folder"), self.ed_carpeta.text()
        )
        if ruta:
            self.ed_carpeta.setText(ruta)

    def _auto_cambiado(self, auto: bool) -> None:
        self.sp_ini.setEnabled(not auto)
        self.sp_fin.setEnabled(not auto)
        if auto:
            self._dem_cambiado()

    def _dem_cambiado(self, *_a) -> None:
        capa = self.cmb_dem.currentLayer()
        if capa is None:
            self.lbl_info.setText("-")
            return
        try:
            info = info_raster(capa)
        except Exception as exc:  # noqa: BLE001
            self.lbl_info.setText(t("could not be read: {error}", error=exc))
            return
        self._nombre_dem = capa.name()
        self.lbl_info.setText(
            t(
                "{ancho} x {alto} px, cell {rx:.4g} x {ry:.4g} m "
                "({area:.4g} m2), {crs}, elevations {zmin:.2f} to "
                "{zmax:.2f} m, NoData {nodata}",
                ancho=info["ancho"],
                alto=info["alto"],
                rx=info["res"][0],
                ry=info["res"][1],
                area=info["area_celda"],
                crs=info["crs"],
                zmin=info["min"],
                zmax=info["max"],
                nodata=(
                    t("not declared")
                    if info["nodata"] is None
                    else f"{info['nodata']:.6g}"
                ),
            )
        )
        if self.chk_auto.isChecked():
            self.sp_ini.setValue(info["min"])
            self.sp_fin.setValue(info["max"])

    # -- calculo -----------------------------------------------------------
    def _progreso(self, pct: float) -> None:
        self.barra.setValue(int(pct))
        QApplication.processEvents()

    def _habilitar_salidas(self, on: bool) -> None:
        self.btn_csv.setEnabled(on)
        self.btn_png.setEnabled(on)

    def calcular(self) -> None:
        capa = self.cmb_dem.currentLayer()
        if capa is None:
            QMessageBox.warning(self, _titulo(), t("Choose a DEM."))
            return
        mensajes: list = []
        self._ruta_recorte = ""
        self._sufijo = ""
        capa_calculo = capa

        if self.chk_recorte.isChecked():
            capa_calculo = self._preparar_recorte(capa, mensajes)
            if capa_calculo is None:
                return

        rango = self._rango(capa_calculo)
        if rango is None:
            return
        ini, fin, paso, n = rango
        if not self._cubicar(capa_calculo, ini, fin, paso, n):
            return
        mensajes.append(self.curva.resumen())
        if self.chk_auto_guardar.isChecked():
            mensajes += self._guardar_todo()
        self.lbl_estado.setText(" · ".join(m for m in mensajes if m))

    def _preparar_recorte(self, capa, mensajes: list):
        """Recorta el DEM y devuelve la capa recortada, o ``None`` si no se puede."""
        poligonos = self.cmb_pol.currentLayer()
        if poligonos is None:
            QMessageBox.warning(
                self, _titulo(), t("Choose the polygon layer for the clip.")
            )
            return None
        if (
            QgsWkbTypes.geometryType(poligonos.wkbType())
            != QgsWkbTypes.PolygonGeometry
        ):
            QMessageBox.warning(
                self, _titulo(), t("The clip layer must be a polygon layer.")
            )
            return None
        destino = ""
        carpeta = self.ed_carpeta.text().strip()
        if carpeta and os.path.isdir(carpeta):
            destino = os.path.join(
                carpeta, _nombre_seguro(f"{capa.name()}_vaso") + ".tif"
            )
        self.barra.setVisible(True)
        self.barra.setValue(0)
        self.lbl_estado.setText(t("Clipping the DEM") + "…")
        QApplication.processEvents()
        ruta, msgs = recortar(
            capa,
            poligonos,
            destino=destino,
            solo_seleccionados=self.chk_sel.isChecked(),
        )
        mensajes += msgs
        if ruta is None:
            self.barra.setVisible(False)
            self.lbl_estado.setText(" · ".join(mensajes))
            QMessageBox.warning(self, _titulo(), chr(10).join(mensajes))
            return None
        recorte = capa_de_vaso(ruta, capa.name() + " · " + t("basin"))
        if recorte is None:
            self.barra.setVisible(False)
            QMessageBox.warning(
                self, _titulo(), t("The clipped DEM could not be opened.")
            )
            return None
        self._ruta_recorte = ruta
        self._sufijo = "-" + t("basin")
        if self.chk_cargar.isChecked():
            QgsProject.instance().addMapLayer(recorte)
            mensajes.append(t("layer loaded and styled: {n}", n=recorte.name()))
        return recorte

    def _rango(self, capa):
        """``(ini, fin, paso, n cotas)`` validado, o ``None`` si no vale."""
        info = info_raster(capa)
        if self.chk_auto.isChecked():
            ini, fin = info["min"], info["max"]
        else:
            ini, fin = self.sp_ini.value(), self.sp_fin.value()
        paso = self.sp_paso.value()
        # Cuantas cotas saldrian, sin construir la lista: con un paso absurdo
        # serian millones y montarla solo para rechazarla es tirar memoria.
        n = int((fin - ini) / paso) + 1 if paso > 0 and fin > ini else 0
        if n <= MAX_COTAS:
            try:
                n = len(vector_de_cotas(ini, fin, paso))
            except ValueError as exc:
                self.barra.setVisible(False)
                QMessageBox.warning(self, _titulo(), str(exc))
                return None
        if n > MAX_COTAS:
            self.barra.setVisible(False)
            QMessageBox.warning(
                self,
                _titulo(),
                t(
                    "That step would give {n} elevations (maximum "
                    "{maximo}). Increase the step.",
                    n=numero(n),
                    maximo=numero(MAX_COTAS),
                ),
            )
            return None
        return (ini, fin, paso, n)

    def _cubicar(self, capa, ini: float, fin: float, paso: float, n: int) -> bool:
        """Calcula la curva y la deja en la vista. ``False`` si no hay resultado."""
        self.barra.setVisible(True)
        self.barra.setValue(0)
        self.lbl_estado.setText(t("Computing {n} elevations", n=n) + "…")
        self.btn.setEnabled(False)
        QApplication.processEvents()
        try:
            self.curva = calcular_curva(
                capa,
                cota_ini=ini,
                cota_fin=fin,
                paso=paso,
                progreso=self._progreso,
            )
        except Exception as exc:  # noqa: BLE001
            import traceback

            avisar("fallo al cubicar la curva de embalse", exc)
            avisar(traceback.format_exc())
            self.btn.setEnabled(True)
            self.barra.setVisible(False)
            QMessageBox.critical(
                self, _titulo(), t("Error in the computation: {error}", error=exc)
            )
            return False
        self.btn.setEnabled(True)
        self.barra.setVisible(False)
        if self.curva.vacia:
            self._habilitar_salidas(False)
            self.vista.limpiar(t("The raster has no valid cells"))
            self.lbl_estado.setText(
                t("No valid cell was found. Check the NoData or the clip.")
            )
            return False
        self.vista.set_curva(self.curva, _titulo() + " · " + capa.name())
        self._habilitar_salidas(True)
        return True

    # -- salidas -----------------------------------------------------------
    def _base(self) -> str:
        nombre = self._nombre_dem or t("reservoir")
        return _nombre_seguro(t("Capacity-Curve-") + nombre + self._sufijo)

    def _guardar_todo(self) -> list:
        carpeta = self.ed_carpeta.text().strip()
        if not carpeta:
            return [t("no folder: the CSV and the PNG have not been written")]
        if not os.path.isdir(carpeta):
            return [
                t(
                    "the folder {c} does not exist: nothing has been written",
                    c=carpeta,
                )
            ]
        salida = []
        csv = os.path.join(carpeta, self._base() + ".csv")
        png = os.path.join(carpeta, self._base() + ".png")
        if self._escribir_csv(csv):
            salida.append(f"CSV: {csv}")
        if self._escribir_png(png):
            salida.append(f"PNG: {png}")
        return salida

    def _escribir_csv(self, ruta: str) -> bool:
        try:
            # utf-8-sig para que Excel en Windows lo abra con los acentos bien.
            with open(ruta, "w", encoding="utf-8-sig", newline="") as f:
                f.write(self.curva.csv())
        except OSError as exc:
            QMessageBox.warning(
                self, _titulo(), t("Could not write the CSV: {error}", error=exc)
            )
            return False
        return True

    def _escribir_png(self, ruta: str) -> bool:
        img = self.vista.imagen()
        if not img.save(ruta, "PNG"):
            QMessageBox.warning(self, _titulo(), t("Could not write the PNG."))
            return False
        return True

    def guardar_csv(self) -> None:
        if self.curva is None:
            return
        inicial = os.path.join(self.ed_carpeta.text().strip(), self._base() + ".csv")
        ruta, _f = QFileDialog.getSaveFileName(
            self, t("Save the curve as CSV"), inicial, "CSV (*.csv)"
        )
        if ruta and self._escribir_csv(ruta):
            self.lbl_estado.setText(t("CSV written: {ruta}", ruta=ruta))

    def guardar_png(self) -> None:
        if self.curva is None:
            return
        inicial = os.path.join(self.ed_carpeta.text().strip(), self._base() + ".png")
        ruta, _f = QFileDialog.getSaveFileName(
            self, t("Save the chart"), inicial, t("PNG image (*.png)")
        )
        if ruta and self._escribir_png(ruta):
            self.lbl_estado.setText(t("PNG written: {ruta}", ruta=ruta))

    # -- lectura -----------------------------------------------------------
    def _leer(self, cota: float) -> None:
        if self.curva is None:
            return
        c, v, a = datos_de_lectura(self.curva, cota)
        self.lbl_lectura.setText(
            t("Elevation {c}   |   Volume {v}   |   Area {a}", c=c, v=v, a=a)
        )

    def _fijar(self, cota: float) -> None:
        if self.curva is None:
            return
        c, v, a = datos_de_lectura(self.curva, cota)
        self.lbl_estado.setText(
            t(
                "Pinned elevation {c}: {v} stored over {a} of water "
                "surface.",
                c=c,
                v=v,
                a=a,
            )
        )


__all__ = ["EmbalseDialog"]
