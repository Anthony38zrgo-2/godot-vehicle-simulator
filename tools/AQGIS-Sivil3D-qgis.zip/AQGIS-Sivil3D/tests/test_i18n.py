"""Pruebas del idioma del plugin. Python puro, sin QGIS.

Lo que se comprueba aqui no es que las traducciones sean bonitas, sino las tres
cosas que romperian el plugin sin que salte nada:

* que el idioma por defecto sea el ingles y que ``t()`` degrade al original;
* que el catalogo castellano no tenga huecos de formato distintos del original,
  porque entonces ``t()`` devolveria la cadena sin rellenar;
* que los dos catalogos de secciones tipo sean coherentes consigo mismos: el
  nombre de la seccion y los codigos de punto viajan a las capas y al JSON.
"""

import re
import unittest

from .. import etiquetas, i18n
from ..core import resolver, templates
from ..core.library import default_library
from ..core.schema import codigo_del_eje, codigos_del_eje, prefijo_de_lado
from ..i18n import es

#: Huecos con nombre de ``str.format``: ``{ancho}``, ``{v:.2f}``...
_HUECO = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)(?:![rsa])?(?::[^}]*)?\}")


def huecos(texto: str) -> set:
    return set(_HUECO.findall(texto))


class TestIdioma(unittest.TestCase):
    def setUp(self):
        i18n._reset_para_tests()

    def tearDown(self):
        i18n._reset_para_tests()

    def test_el_idioma_por_defecto_es_el_ingles(self):
        self.assertEqual(i18n.POR_DEFECTO, "en")
        self.assertEqual(i18n.idioma(), "en")

    def test_en_ingles_el_texto_sale_tal_cual(self):
        i18n.set_idioma("en", guardar=False)
        self.assertEqual(i18n.t("Compute"), "Compute")

    def test_en_castellano_se_traduce(self):
        i18n.set_idioma("es", guardar=False)
        self.assertEqual(i18n.t("Compute"), "Calcular")

    def test_lo_que_no_esta_en_el_catalogo_cae_al_ingles(self):
        i18n.set_idioma("es", guardar=False)
        self.assertEqual(i18n.t("Wibble wobble"), "Wibble wobble")

    def test_un_idioma_desconocido_cae_al_de_por_defecto(self):
        self.assertEqual(i18n.set_idioma("fr", guardar=False), "en")

    def test_los_huecos_se_rellenan(self):
        i18n.set_idioma("es", guardar=False)
        self.assertEqual(
            i18n.t("group created: {n}", n="mi grupo"), "grupo creado: mi grupo"
        )

    def test_en_idioma_no_cambia_el_que_esta_puesto(self):
        i18n.set_idioma("en", guardar=False)
        self.assertEqual(i18n.en_idioma("Compute", "es"), "Calcular")
        self.assertEqual(i18n.idioma(), "en")

    def test_todas_las_formas_da_las_dos(self):
        self.assertEqual(set(i18n.todas_las_formas("cut")), {"cut", "desmonte"})

    def test_el_separador_de_miles_es_el_del_idioma(self):
        i18n.set_idioma("en", guardar=False)
        self.assertEqual(i18n.numero(1234567.89, 1), "1,234,567.9")
        i18n.set_idioma("es", guardar=False)
        self.assertEqual(i18n.numero(1234567.89, 1), "1.234.567,9")
        self.assertEqual(i18n.numero(-12.0, 0, signo=True), "-12")


class TestCatalogo(unittest.TestCase):
    """El catalogo castellano tiene que ser utilizable, no solo estar."""

    def test_los_huecos_coinciden_con_los_del_original(self):
        malas = [
            k for k, v in es.TEXTOS.items() if huecos(k) != huecos(v)
        ]
        self.assertEqual(malas, [], "huecos que no cuadran entre original y traduccion")

    def test_ninguna_traduccion_esta_vacia(self):
        vacias = [k for k, v in es.TEXTOS.items() if not v.strip()]
        self.assertEqual(vacias, [])

    def test_las_etiquetas_de_dominio_estan_todas_traducidas(self):
        i18n.set_idioma("es", guardar=False)
        try:
            for tabla in (
                etiquetas.MODOS,
                etiquetas.GRUPOS,
                etiquetas.LADOS,
                etiquetas.ZONAS,
                etiquetas.SEGMENTOS,
                etiquetas.OPCIONES,
                etiquetas.ORIGENES_COTA,
            ):
                for original in tabla.values():
                    # 'Bezier', 'NURBS' y 'horizontal' se escriben igual en los
                    # dos idiomas: no necesitan entrada.
                    if original in ("Bezier", "NURBS", "horizontal"):
                        continue
                    self.assertIn(original, es.TEXTOS, original)
        finally:
            i18n._reset_para_tests()


class TestCatalogoDeSecciones(unittest.TestCase):
    """Cada idioma trae su catalogo de arranque, coherente consigo mismo."""

    def tearDown(self):
        i18n._reset_para_tests()

    def test_hay_las_mismas_secciones_en_los_dos_idiomas(self):
        self.assertEqual(
            len(default_library("en")), len(default_library("es"))
        )
        self.assertEqual(len(default_library("en")), len(templates.TEMPLATES))

    def test_los_nombres_son_distintos_en_cada_idioma(self):
        en = default_library("en").names()
        es_ = default_library("es").names()
        self.assertEqual(en[0], "Road 1+1")
        self.assertEqual(es_[0], "Carretera 1+1")

    def test_los_codigos_de_punto_van_en_el_idioma_del_catalogo(self):
        izq = templates.carretera_1x1("es").izquierda
        self.assertEqual([e.codigo for e in izq.fijos][0], "CALZADA")
        izq = templates.carretera_1x1("en").izquierda
        self.assertEqual([e.codigo for e in izq.fijos][0], "CARRIAGEWAY")

    def test_todas_las_plantillas_validan_en_los_dos_idiomas(self):
        for lang in i18n.IDIOMAS:
            for nombre, asm in default_library(lang).assemblies.items():
                self.assertEqual(asm.validate(), [], f"{lang}: {nombre}")

    def test_la_seccion_resuelta_lleva_los_codigos_del_idioma(self):
        for lang, calzada, eje in (("en", "R_CARRIAGEWAY", "AXIS"),
                                   ("es", "D_CALZADA", "EJE")):
            i18n.set_idioma(lang, guardar=False)
            asm = templates.carretera_1x1(lang).materialize()
            st = resolver.Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0)
            tz = resolver.plane_terrain(
                z_ref=98.0, pendiente_pct=10.0, nx=0.0, ny=1.0
            )
            sec = resolver.resolve_section(
                asm, st, tz, resolver.SectionOptions(), z_eje=100.0
            )
            self.assertIn(calzada, sec.codes(), lang)
            self.assertIn(eje, sec.codes(), lang)

    def test_los_prefijos_de_lado_siguen_al_idioma(self):
        i18n.set_idioma("en", guardar=False)
        self.assertEqual((prefijo_de_lado(-1), prefijo_de_lado(1)), ("L_", "R_"))
        self.assertEqual(codigo_del_eje(), "AXIS")
        i18n.set_idioma("es", guardar=False)
        self.assertEqual((prefijo_de_lado(-1), prefijo_de_lado(1)), ("I_", "D_"))
        self.assertEqual(codigo_del_eje(), "EJE")

    def test_el_eje_se_reconoce_escrito_en_el_otro_idioma(self):
        """Un corredor calculado en castellano se reabre en ingles."""
        i18n.set_idioma("en", guardar=False)
        self.assertEqual(set(codigos_del_eje()), {"AXIS", "EJE"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
