"""Pruebas del corte entre corredores. Python puro, sin QGIS."""

import math
import unittest

from ..core.cruces import (
    MARGEN,
    TrazaCruce,
    lineas_de_run,
    rasante_en_abscisas,
    traza_en_seccion,
)


class Estacion:
    """Lo justo de una estacion para cortar un plano."""

    def __init__(self, s, x, y, nx=0.0, ny=1.0):
        self.s = s
        self.x = x
        self.y = y
        self.nx = nx
        self.ny = ny
        self.fid = 1
        self.part = 0


class Seccion:
    def __init__(self, station):
        self.station = station
        self.vertices = [1, 2]
        self.z_eje = 100.0


def eje_en_x(s, y=0.0):
    """Estacion de un eje que avanza en +X: su normal apunta a +Y."""
    return Seccion(Estacion(s=s, x=s, y=y, nx=0.0, ny=1.0))


class TestTrazaEnSeccion(unittest.TestCase):
    """El plano de una seccion corta las lineas de otro corredor."""

    def test_una_linea_paralela_al_eje_se_corta_una_vez(self):
        # Eje en X en y=0; el otro corredor va paralelo en y=40.
        seccion = eje_en_x(100.0)
        lineas = {"AXIS": [(0.0, 40.0, 105.0), (200.0, 40.0, 107.0)]}
        traza = traza_en_seccion(seccion, lineas, etiqueta="otro")
        self.assertEqual(len(traza.puntos), 1)
        offset, z = traza.puntos[0]
        self.assertAlmostEqual(offset, 40.0, places=6)
        self.assertAlmostEqual(z, 106.0, places=6)
        self.assertEqual(traza.codigos, ["AXIS"])
        self.assertEqual(traza.etiqueta, "otro")

    def test_varias_lineas_dan_la_seccion_del_otro(self):
        seccion = eje_en_x(50.0)
        lineas = {
            "IZQ": [(0.0, 36.0, 104.0), (100.0, 36.0, 104.0)],
            "AXIS": [(0.0, 40.0, 105.0), (100.0, 40.0, 105.0)],
            "DER": [(0.0, 44.0, 104.0), (100.0, 44.0, 104.0)],
        }
        traza = traza_en_seccion(seccion, lineas)
        self.assertEqual(len(traza.puntos), 3)
        # Ordenada de izquierda a derecha por offset.
        offsets = [o for o, _z in traza.puntos]
        self.assertEqual(offsets, sorted(offsets))
        self.assertAlmostEqual(offsets[0], 36.0)
        self.assertAlmostEqual(offsets[-1], 44.0)

    def test_offset_negativo_al_otro_lado(self):
        seccion = eje_en_x(50.0)
        lineas = {"AXIS": [(0.0, -25.0, 100.0), (100.0, -25.0, 100.0)]}
        traza = traza_en_seccion(seccion, lineas)
        self.assertAlmostEqual(traza.puntos[0][0], -25.0, places=6)

    def test_una_linea_que_no_cruza_no_da_nada(self):
        # El otro corredor acaba antes de llegar al plano de la seccion.
        seccion = eje_en_x(500.0)
        lineas = {"AXIS": [(0.0, 40.0, 100.0), (100.0, 40.0, 100.0)]}
        self.assertTrue(traza_en_seccion(seccion, lineas).vacia)

    def test_la_cota_se_interpola_en_el_corte(self):
        seccion = eje_en_x(25.0)
        lineas = {"AXIS": [(0.0, 10.0, 100.0), (100.0, 10.0, 110.0)]}
        traza = traza_en_seccion(seccion, lineas)
        self.assertAlmostEqual(traza.puntos[0][1], 102.5, places=6)

    def test_un_eje_girado(self):
        """La normal manda: el offset se mide sobre ella, no sobre Y."""
        # Eje a 45 grados: avanza en (1,1)/raiz(2), normal derecha (1,-1)/raiz(2).
        r = math.sqrt(2.0) / 2.0
        seccion = Seccion(Estacion(s=0.0, x=0.0, y=0.0, nx=r, ny=-r))
        # Un punto sobre la normal, a 10 m: (10r, -10r).
        lineas = {"P": [(10 * r - 5 * r, -10 * r - 5 * r, 100.0),
                        (10 * r + 5 * r, -10 * r + 5 * r, 100.0)]}
        traza = traza_en_seccion(seccion, lineas)
        self.assertEqual(len(traza.puntos), 1)
        self.assertAlmostEqual(traza.puntos[0][0], 10.0, places=5)

    def test_el_limite_de_ancho_descarta_lo_lejano(self):
        seccion = eje_en_x(50.0)
        # Dos lineas: con una sola no habria traza que dibujar de todos modos.
        lineas = {
            "A": [(0.0, 200.0, 100.0), (100.0, 200.0, 100.0)],
            "B": [(0.0, 204.0, 100.0), (100.0, 204.0, 100.0)],
        }
        self.assertTrue(
            traza_en_seccion(seccion, lineas, ancho_max=20.0).vacia,
            "a 200 m y con limite de 20, no entra",
        )
        self.assertFalse(traza_en_seccion(seccion, lineas).vacia)

    def test_una_sola_linea_no_da_traza_dibujable(self):
        """Un punto suelto no es una seccion: hacen falta dos para una polilinea."""
        seccion = eje_en_x(50.0)
        traza = traza_en_seccion(
            seccion, {"AXIS": [(0.0, 40.0, 100.0), (100.0, 40.0, 100.0)]}
        )
        self.assertEqual(len(traza.puntos), 1)
        self.assertTrue(traza.vacia)

    def test_el_orden_de_codigos_manda_si_se_da(self):
        seccion = eje_en_x(50.0)
        lineas = {
            "B": [(0.0, 44.0, 104.0), (100.0, 44.0, 104.0)],
            "A": [(0.0, 36.0, 104.0), (100.0, 36.0, 104.0)],
        }
        traza = traza_en_seccion(seccion, lineas, orden=["B", "A"])
        self.assertEqual(traza.codigos, ["B", "A"])

    def test_lineas_vacias(self):
        self.assertTrue(traza_en_seccion(eje_en_x(0.0), {}).vacia)
        self.assertTrue(
            traza_en_seccion(eje_en_x(0.0), {"A": [(0.0, 0.0, 0.0)]}).vacia
        )

    def test_traza_vacia(self):
        self.assertTrue(TrazaCruce().vacia)
        self.assertTrue(TrazaCruce(puntos=[(0.0, 1.0)]).vacia)
        self.assertFalse(TrazaCruce(puntos=[(0.0, 1.0), (1.0, 1.0)]).vacia)


class Run:
    """Tramo minimo: lo que necesitan lineas_de_run y rasante_en_abscisas."""

    def __init__(self, secciones, etiqueta="fid 1"):
        self.sections = secciones
        self.etiqueta = etiqueta


class TestRasanteEnAbscisas(unittest.TestCase):
    """Superponer la rasante de otro eje en el longitudinal de este."""

    def _run(self, y, z0, dz=0.0, n=11, paso=20.0):
        secs = []
        for i in range(n):
            s = i * paso
            sec = eje_en_x(s, y=y)
            sec.z_eje = z0 + dz * s
            secs.append(sec)
        return Run(secs)

    def test_dos_ejes_paralelos_comparten_abscisas(self):
        principal = self._run(0.0, 100.0, 0.01)
        otro = self._run(40.0, 105.0, 0.01)
        puntos = rasante_en_abscisas(otro, principal)
        self.assertEqual(len(puntos), len(otro.sections))
        # Cada punto cae en la abscisa del principal mas cercano en planta.
        for (s, z), sec in zip(puntos, otro.sections):
            self.assertAlmostEqual(s, sec.station.s, places=6)
            self.assertAlmostEqual(z, sec.z_eje, places=6)

    def test_las_abscisas_salen_ordenadas(self):
        principal = self._run(0.0, 100.0)
        otro = self._run(30.0, 102.0)
        puntos = rasante_en_abscisas(otro, principal)
        self.assertEqual([s for s, _z in puntos], sorted(s for s, _z in puntos))

    def test_un_tramo_sin_secciones_no_da_nada(self):
        self.assertEqual(rasante_en_abscisas(Run([]), self._run(0.0, 100.0)), [])

    def test_sin_principal_se_usan_sus_propias_abscisas(self):
        otro = self._run(0.0, 100.0)
        puntos = rasante_en_abscisas(otro, Run([]))
        self.assertEqual(len(puntos), len(otro.sections))

    def test_dos_secciones_en_la_misma_abscisa_se_promedian(self):
        principal = self._run(0.0, 100.0, n=3, paso=100.0)
        otro = Run([eje_en_x(10.0, y=5.0), eje_en_x(20.0, y=5.0)])
        otro.sections[0].z_eje = 100.0
        otro.sections[1].z_eje = 110.0
        puntos = rasante_en_abscisas(otro, principal)
        self.assertEqual(len(puntos), 1, "las dos caen en el PK 0 del principal")
        self.assertAlmostEqual(puntos[0][1], 105.0)


class TestEjesQueSeCruzan(unittest.TestCase):
    """Dos trazados en angulo recto: el caso que no veia el metodo anterior.

    Cortando solo las lineas caracteristicas —que son longitudinales— un eje
    perpendicular nunca aparece: sus lineas son **paralelas** al plano de corte.
    Hay que cortar tambien las secciones transversales del otro corredor.
    """

    def _lineas_de_eje_en_y(self, x=50.0):
        """Un corredor que avanza en +Y, con sus dos familias de polilineas."""
        lineas = {}
        # Longitudinales: paralelas al eje, o sea en direccion Y.
        for offset in (-4.0, 0.0, 4.0):
            lineas[f"L{offset}"] = [
                (x + offset, y, 100.0) for y in (0.0, 50.0, 100.0)
            ]
        # Transversales: una por PK, en direccion X.
        for i, y in enumerate((0.0, 50.0, 100.0)):
            lineas[f"@seccion{i}"] = [
                (x - 4.0, y, 100.0), (x, y, 100.0), (x + 4.0, y, 100.0)
            ]
        return lineas

    def test_las_longitudinales_solas_no_cortan_un_eje_perpendicular(self):
        """Justificacion de por que hacen falta las dos familias."""
        seccion = eje_en_x(50.0)  # plano x = 50
        solo_largas = {
            k: v for k, v in self._lineas_de_eje_en_y().items()
            if not k.startswith("@")
        }
        self.assertTrue(
            traza_en_seccion(seccion, solo_largas).vacia,
            "son paralelas al plano: no lo cruzan",
        )

    def test_con_las_transversales_si_se_ve(self):
        seccion = eje_en_x(50.0)
        traza = traza_en_seccion(seccion, self._lineas_de_eje_en_y())
        self.assertFalse(traza.vacia)
        self.assertGreaterEqual(len(traza.puntos), 2)
        for _offset, z in traza.puntos:
            self.assertAlmostEqual(z, 100.0, places=6)

    def test_no_salen_puntos_repetidos(self):
        """Donde una longitudinal cruza una transversal, el punto sale dos veces."""
        seccion = eje_en_x(50.0)
        traza = traza_en_seccion(seccion, self._lineas_de_eje_en_y())
        offsets = [o for o, _z in traza.puntos]
        for a, b in zip(offsets, offsets[1:]):
            self.assertGreater(b - a, 0.01, f"puntos pegados: {offsets}")

    def test_el_ancho_acota_una_traza_larguisima(self):
        """Un eje que cruza en angulo recto deja una traza de cientos de metros."""
        seccion = eje_en_x(50.0)
        lineas = {
            "@seccion0": [(50.0 - 300.0, 0.0, 100.0), (50.0 + 300.0, 0.0, 100.0)],
            "@seccion1": [(50.0 - 300.0, 20.0, 100.0), (50.0 + 300.0, 20.0, 100.0)],
        }
        # Sin acotar, la traza abarca todo el recorrido del otro eje.
        libre = traza_en_seccion(seccion, lineas)
        self.assertFalse(libre.vacia)
        anchura = max(o for o, _z in libre.puntos) - min(o for o, _z in libre.puntos)
        self.assertGreater(anchura, 15.0)
        # Acotada, entra en el dibujo de una seccion normal.
        corta = traza_en_seccion(seccion, lineas, ancho_max=10.0)
        for offset, _z in corta.puntos:
            self.assertLessEqual(abs(offset), 10.0 + MARGEN + 1e-9)


def _seccion_real(s, x, y, nx, ny, z, ancho=5.0):
    """Seccion con vertices de verdad: ``feature_lines`` necesita codigo y world."""
    from aqgis_sivil3d.core.elements import Vertex

    seccion = Seccion(Estacion(s=s, x=x, y=y, nx=nx, ny=ny))
    seccion.vertices = [
        Vertex(offset=-ancho, z=z, code="IZQ"),
        Vertex(offset=0.0, z=z, code="AXIS"),
        Vertex(offset=ancho, z=z, code="DER"),
    ]
    seccion.world = lambda v, st=seccion.station: (
        st.x + st.nx * v.offset,
        st.y + st.ny * v.offset,
        v.z,
    )
    seccion.world_points = lambda sec=seccion: [sec.world(v) for v in sec.vertices]
    return seccion


class TestCorteConElRecorrido(unittest.TestCase):
    """Un longitudinal es el plano vertical que sigue un eje.

    Los demas corredores salen **donde lo cortan**, no a lo largo de todo el
    dibujo: si no lo cruzan, no aparecen.
    """

    #: Eje principal: de (0,0) a (100,0), o sea 100 m en +X.
    PTS = [(0.0, 0.0, None), (100.0, 0.0, None)]

    def _run_transversal(self, x=40.0, z=105.0, ancho=6.0):
        """Un corredor que cruza el principal perpendicularmente en ``x``.

        Avanza en +Y con la normal en +X, asi que sus secciones se despliegan a lo
        largo del eje principal: es el caso del cruce en aspa.
        """
        secs = []
        for y in (-20.0, 0.0, 20.0):
            secs.append(
                _seccion_real(s=y + 20.0, x=x, y=y, nx=1.0, ny=0.0, z=z, ancho=ancho)
            )
        return Run(secs, etiqueta="cruzado")

    def test_un_eje_que_cruza_aparece_solo_en_el_cruce(self):
        from ..core.cruces import interseccion_con_recorrido

        run = self._run_transversal(x=40.0, z=105.0, ancho=6.0)
        puntos = interseccion_con_recorrido(run, self.PTS)
        self.assertTrue(puntos, "tiene que cruzar")
        eses = [s for s, _z in puntos]
        # El otro corredor cruza en x=40 y mide 6 m a cada lado: en el
        # longitudinal ocupa justo esos 12 m, ni mas ni menos.
        self.assertAlmostEqual(min(eses), 34.0, delta=0.5)
        self.assertAlmostEqual(max(eses), 46.0, delta=0.5)
        self.assertAlmostEqual((min(eses) + max(eses)) / 2, 40.0, delta=0.5)
        for _s, z in puntos:
            self.assertAlmostEqual(z, 105.0, places=6)

    def test_el_ancho_del_cruce_es_el_del_otro_corredor(self):
        from ..core.cruces import interseccion_con_recorrido

        for ancho in (3.0, 10.0):
            puntos = interseccion_con_recorrido(
                self._run_transversal(ancho=ancho), self.PTS
            )
            eses = [s for s, _z in puntos]
            self.assertAlmostEqual(
                max(eses) - min(eses), ancho * 2, delta=0.5, msg=f"ancho {ancho}"
            )

    def test_un_eje_paralelo_no_corta_nada(self):
        """Va al lado, pero no lo cruza: en el longitudinal no pinta nada."""
        from ..core.cruces import interseccion_con_recorrido

        secs = [
            _seccion_real(s=x, x=x, y=30.0, nx=0.0, ny=1.0, z=100.0, ancho=4.0)
            for x in (0.0, 50.0, 100.0)
        ]
        run = Run(secs, etiqueta="paralelo")
        self.assertEqual(interseccion_con_recorrido(run, self.PTS), [])

    def test_las_abscisas_salen_ordenadas_y_sin_repetir(self):
        from ..core.cruces import interseccion_con_recorrido

        run = self._run_transversal()
        puntos = interseccion_con_recorrido(run, self.PTS)
        eses = [s for s, _z in puntos]
        self.assertEqual(eses, sorted(eses))
        for a, b in zip(eses, eses[1:]):
            self.assertGreater(b - a, 0.0)

    def test_un_recorrido_degenerado(self):
        from ..core.cruces import interseccion_con_recorrido

        self.assertEqual(
            interseccion_con_recorrido(self._run_transversal(), [(0.0, 0.0, None)]),
            [],
        )


if __name__ == "__main__":
    unittest.main()
