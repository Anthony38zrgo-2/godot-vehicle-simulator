"""Tests del dibujo en espacio papel. No necesitan QGIS."""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from aqgis_sivil3d.core.paperspace import (  # noqa: E402
    CLASE_ACOTACION,
    CLASE_DESMONTE,
    CLASE_EJE,
    CLASE_GUITARRA,
    CLASE_OTRO,
    CLASE_MARCO,
    CLASE_PROYECTO,
    CLASE_TERRAPLEN,
    CLASE_TERRENO,
    CLASE_TEXTO,
    Celda,
    Escala,
    OpcionesDibujo,
    Reticula,
    ESCALAS_NORMALIZADAS,
    cabe,
    elegir_escala,
    dibujar_perfil,
    guitarra,
    lamina_longitudinal,
    laminas_de_cubicaciones,
    laminas_de_transversales,
    laminas_longitudinal,
)
from aqgis_sivil3d.core.resolver import (  # noqa: E402
    SectionOptions,
    Station,
    plane_terrain,
    resolve_section,
)
from aqgis_sivil3d.core.templates import load_template  # noqa: E402


def secciones(n=13, pct=25.0, desnivel=-2.0, paso_pk=20.0):
    asm = load_template("carretera_1x1")
    asm.eje["desnivel"] = desnivel
    mat = asm.materialize()
    tz = plane_terrain(z_ref=100.0, pendiente_pct=pct, nx=0.0, ny=1.0)
    opts = SectionOptions(paso=0.25, ancho_max=100.0, muestras_terreno=80)
    return [
        resolve_section(
            mat,
            Station(s=i * paso_pk, x=i * paso_pk, y=0.0, nx=0.0, ny=1.0),
            tz,
            opts,
        )
        for i in range(n)
    ]


class TestEscala(unittest.TestCase):
    def test_conversion_a_milimetros(self):
        e = Escala(horizontal=100.0, vertical=100.0)
        # 1:100 -> 1 m de terreno son 10 mm de papel
        self.assertAlmostEqual(e.mm_x(1.0), 10.0)
        self.assertAlmostEqual(e.mm_z(1.0), 10.0)
        self.assertAlmostEqual(e.mm_x(12.5), 125.0)

    def test_escalas_distintas_dan_exageracion(self):
        e = Escala(horizontal=1000.0, vertical=100.0)
        self.assertAlmostEqual(e.exageracion, 10.0)
        self.assertAlmostEqual(e.mm_x(100.0), 100.0)
        self.assertAlmostEqual(e.mm_z(100.0), 1000.0)

    def test_etiqueta(self):
        self.assertEqual(Escala(200.0, 200.0).etiqueta(), "S 1:200")
        self.assertIn("H 1:1000", Escala(1000.0, 100.0).etiqueta())


class TestReticula(unittest.TestCase):
    def test_reparto_por_hojas(self):
        r = Reticula(columnas=3, filas=4)
        self.assertEqual(r.por_hoja, 12)
        self.assertEqual(r.celda(0)[0], 0)
        self.assertEqual(r.celda(11)[0], 0)
        self.assertEqual(r.celda(12)[0], 1, "la 13.a seccion va a la hoja 2")
        self.assertEqual(r.celda(25)[0], 2)

    def test_las_filas_van_de_arriba_abajo(self):
        r = Reticula(columnas=2, filas=2)
        _h, c0 = r.celda(0)
        _h, c2 = r.celda(2)
        self.assertGreater(c0.y, c2.y, "la primera fila va arriba")

    def test_las_columnas_van_de_izquierda_a_derecha(self):
        r = Reticula(columnas=2, filas=2)
        _h, c0 = r.celda(0)
        _h, c1 = r.celda(1)
        self.assertLess(c0.x, c1.x)

    def test_tamano_de_hoja(self):
        r = Reticula(
            columnas=3, filas=4, ancho_celda=90.0, alto_celda=65.0,
            separacion_x=6.0, separacion_y=8.0, margen_x=10.0, margen_y=10.0,
        )
        self.assertAlmostEqual(r.ancho_hoja(), 20 + 3 * 90 + 2 * 6)
        self.assertAlmostEqual(r.alto_hoja(), 20 + 4 * 65 + 3 * 8)

    def test_las_celdas_no_se_solapan(self):
        r = Reticula(columnas=3, filas=3)
        celdas = [r.celda(i)[1] for i in range(9)]
        for i, a in enumerate(celdas):
            for b in celdas[i + 1 :]:
                solapa_x = a.x < b.x_fin - 1e-9 and b.x < a.x_fin - 1e-9
                solapa_y = a.y < b.y_fin - 1e-9 and b.y < a.y_fin - 1e-9
                self.assertFalse(solapa_x and solapa_y)


class TestDibujarPerfil(unittest.TestCase):
    def setUp(self):
        # 90 mm a 1:200 solo dan para 18 m de seccion; la de prueba mide mas de
        # 21, asi que la celda se dimensiona para que quepa de verdad.
        self.celda = Celda(0.0, 0.0, 130.0, 80.0)
        self.opts = OpcionesDibujo(escala=Escala(200.0, 200.0))
        self.sec = secciones(n=1)[0]

    def test_genera_las_clases_esperadas(self):
        ents = dibujar_perfil(
            self.sec.perfil, self.sec.terreno, self.celda, self.opts, titulo="PK 0"
        )
        clases = {e.clase for e in ents}
        for esperada in (
            CLASE_MARCO, CLASE_TERRENO, CLASE_PROYECTO, CLASE_EJE,
            CLASE_ACOTACION, CLASE_TEXTO,
        ):
            self.assertIn(esperada, clases)

    def test_todo_en_milimetros_dentro_de_la_celda(self):
        ents = dibujar_perfil(self.sec.perfil, self.sec.terreno, self.celda, self.opts)
        for e in ents:
            if e.clase in (CLASE_ACOTACION, CLASE_TEXTO):
                continue  # los rotulos van por fuera del marco a proposito
            for x, y in e.puntos:
                self.assertGreaterEqual(x, self.celda.x - 1e-6)
                self.assertLessEqual(x, self.celda.x_fin + 1e-6)
                self.assertGreaterEqual(y, self.celda.y - 1e-6)
                self.assertLessEqual(y, self.celda.y_fin + 1e-6)

    def test_el_relleno_lleva_el_area(self):
        ents = dibujar_perfil(self.sec.perfil, self.sec.terreno, self.celda, self.opts)
        rellenos = [e for e in ents if e.clase in (CLASE_DESMONTE, CLASE_TERRAPLEN)]
        self.assertTrue(rellenos)
        for e in rellenos:
            self.assertTrue(e.poligono)
            self.assertGreater(e.atributos["area"], 0.0)

    def test_la_suma_de_areas_coincide_con_la_medicion(self):
        ents = dibujar_perfil(self.sec.perfil, self.sec.terreno, self.celda, self.opts)
        des_dibujo = sum(
            e.atributos["area"] for e in ents if e.clase == CLASE_DESMONTE
        )
        des_medido, _ter = self.sec.areas()
        # El atributo va redondeado a 4 decimales (0.1 cm2).
        self.assertAlmostEqual(des_dibujo, des_medido, places=3)

    def test_la_escala_se_respeta(self):
        """Dos metros de terreno son siempre los mismos milimetros de papel."""
        opts = OpcionesDibujo(escala=Escala(100.0, 100.0))
        ents = dibujar_perfil(self.sec.perfil, self.sec.terreno, self.celda, opts)
        linea = [e for e in ents if e.clase == CLASE_PROYECTO][0]
        ancho_mm = max(p[0] for p in linea.puntos) - min(p[0] for p in linea.puntos)
        ancho_m = max(p[0] for p in self.sec.perfil) - min(
            p[0] for p in self.sec.perfil
        )
        self.assertAlmostEqual(ancho_mm, ancho_m * 10.0, places=6)

    def test_sin_marco_ni_rejilla(self):
        opts = OpcionesDibujo(con_marco=False, con_rejilla=False, con_relleno=False)
        ents = dibujar_perfil(self.sec.perfil, self.sec.terreno, self.celda, opts)
        clases = {e.clase for e in ents}
        self.assertNotIn(CLASE_MARCO, clases)
        self.assertNotIn(CLASE_DESMONTE, clases)
        self.assertIn(CLASE_PROYECTO, clases)

    def test_perfil_vacio(self):
        self.assertEqual(dibujar_perfil([], [], self.celda, self.opts), [])

    def test_cabe(self):
        chica = Celda(0.0, 0.0, 10.0, 10.0)
        self.assertFalse(cabe(self.sec.perfil, self.sec.terreno, chica, self.opts))
        self.assertTrue(cabe(self.sec.perfil, self.sec.terreno, self.celda, self.opts))


class TestEleccionDeEscala(unittest.TestCase):
    def test_elige_la_mayor_que_cabe(self):
        secs = secciones(n=5)
        perfiles = [(s.perfil, s.terreno) for s in secs]
        celda = Celda(0.0, 0.0, 90.0, 65.0)
        e = elegir_escala(perfiles, celda)
        self.assertIsNotNone(e)
        self.assertIn(e.horizontal, ESCALAS_NORMALIZADAS)
        # Y de verdad cabe a esa escala.
        opts = OpcionesDibujo(escala=e)
        for pro, ter in perfiles:
            self.assertTrue(cabe(pro, ter, celda, opts))

    def test_la_escala_elegida_es_normalizada(self):
        secs = secciones(n=5)
        e = elegir_escala(
            [(s.perfil, s.terreno) for s in secs], Celda(0.0, 0.0, 90.0, 65.0)
        )
        self.assertIn(e.horizontal, ESCALAS_NORMALIZADAS)

    def test_ninguna_escala_vale_en_una_celda_minuscula(self):
        secs = secciones(n=2)
        e = elegir_escala(
            [(s.perfil, s.terreno) for s in secs],
            Celda(0.0, 0.0, 2.0, 2.0),
            escalas=(50.0, 100.0),
        )
        self.assertIsNone(e)

    def test_todas_las_secciones_caben_con_escala_automatica(self):
        secs = secciones(n=13)
        reticula = Reticula(columnas=3, filas=4)
        hojas = laminas_de_transversales(secs, reticula, escala_automatica=True)
        _h, celda = reticula.celda(0)
        for h in hojas:
            for e in h.entidades:
                if e.clase not in (CLASE_PROYECTO, CLASE_TERRENO):
                    continue
                ancho = max(p[0] for p in e.puntos) - min(p[0] for p in e.puntos)
                self.assertLessEqual(ancho, celda.ancho + 1e-6)


class TestLaminasDeTransversales(unittest.TestCase):
    def test_reparte_en_hojas(self):
        secs = secciones(n=25)
        hojas = laminas_de_transversales(secs, Reticula(columnas=3, filas=4))
        self.assertEqual(len(hojas), 3)  # 12 + 12 + 1
        self.assertEqual([h.numero for h in hojas], [1, 2, 3])

    def test_cada_hoja_tiene_su_rango_de_pk(self):
        secs = secciones(n=25, paso_pk=20.0)
        hojas = laminas_de_transversales(secs, Reticula(columnas=3, filas=4))
        self.assertAlmostEqual(hojas[0].pk_ini, 0.0)
        self.assertAlmostEqual(hojas[0].pk_fin, 11 * 20.0)
        self.assertAlmostEqual(hojas[1].pk_ini, 12 * 20.0)

    def test_las_hojas_no_se_pisan_en_la_capa(self):
        secs = secciones(n=25)
        opts = OpcionesDibujo(paso_hoja=1000.0)
        hojas = laminas_de_transversales(secs, Reticula(columnas=3, filas=4), opts)
        for a, b in zip(hojas, hojas[1:]):
            self.assertLessEqual(a.extent[2], b.extent[0] + 1e-9)

    def test_los_atributos_llevan_pk_y_areas(self):
        hojas = laminas_de_transversales(secciones(n=3))
        ents = [e for e in hojas[0].entidades if e.clase == CLASE_PROYECTO]
        self.assertTrue(ents)
        a = ents[0].atributos
        for clave in ("hoja", "pk", "area_des", "area_ter"):
            self.assertIn(clave, a)

    def test_secciones_vacias_se_omiten(self):
        secs = secciones(n=3)
        secs[1].vertices = []
        hojas = laminas_de_transversales(secs)
        pks = {
            e.atributos["pk"]
            for h in hojas
            for e in h.entidades
            if "pk" in e.atributos
        }
        self.assertNotIn(secs[1].station.s, pks)

    def test_sin_secciones(self):
        self.assertEqual(laminas_de_transversales([]), [])


class TestGuitarra(unittest.TestCase):
    def setUp(self):
        self.secs = secciones(n=11, paso_pk=20.0)
        self.celda = Celda(30.0, 50.0, 200.0, 60.0)
        self.opts = OpcionesDibujo(escala=Escala(1000.0, 100.0))

    def test_una_columna_por_seccion(self):
        ents = guitarra(self.secs, self.celda, self.opts)
        columnas = [
            e for e in ents if e.atributos.get("fila") == "columna"
        ]
        self.assertEqual(len(columnas), len(self.secs))

    def test_cada_n_reduce_las_columnas(self):
        ents = guitarra(self.secs, self.celda, self.opts, cada=5)
        columnas = [e for e in ents if e.atributos.get("fila") == "columna"]
        self.assertLess(len(columnas), len(self.secs))
        self.assertGreaterEqual(len(columnas), 2)

    def test_las_filas_esperadas(self):
        ents = guitarra(self.secs, self.celda, self.opts)
        rotulos = {e.texto for e in ents if e.clase == CLASE_ACOTACION}
        for esperado in ("STATION", "GROUND LEVEL", "DESIGN LEVEL", "CUT / FILL"):
            self.assertIn(esperado, rotulos)

    def test_los_valores_van_girados(self):
        ents = guitarra(self.secs, self.celda, self.opts)
        textos = [e for e in ents if e.clase == CLASE_TEXTO]
        self.assertTrue(textos)
        self.assertTrue(all(abs(e.angulo - 90.0) < 1e-9 for e in textos))

    def test_la_cota_roja_lleva_signo(self):
        ents = guitarra(self.secs, self.celda, self.opts)
        rojas = [
            e.texto for e in ents
            if e.clase == CLASE_TEXTO and e.atributos.get("fila") == "roja"
        ]
        self.assertTrue(rojas)
        self.assertTrue(all(t[0] in "+-" for t in rojas if t))

    def test_la_guitarra_queda_debajo_de_la_celda(self):
        ents = guitarra(self.secs, self.celda, self.opts)
        for e in ents:
            for _x, y in e.puntos:
                self.assertLessEqual(y, self.celda.y + 1e-6)

    def test_sin_secciones(self):
        self.assertEqual(guitarra([], self.celda, self.opts), [])


class TestLaminaLongitudinal(unittest.TestCase):
    def test_lamina_completa(self):
        h = lamina_longitudinal(secciones(n=15, paso_pk=20.0))
        clases = {e.clase for e in h.entidades}
        self.assertIn(CLASE_PROYECTO, clases)
        self.assertIn(CLASE_TERRENO, clases)
        self.assertIn(CLASE_GUITARRA, clases)
        self.assertAlmostEqual(h.pk_ini, 0.0)
        self.assertAlmostEqual(h.pk_fin, 280.0)

    def test_el_extent_engloba_el_dibujo(self):
        h = lamina_longitudinal(secciones(n=15))
        x0, y0, x1, y1 = h.extent
        for e in h.entidades:
            for x, y in e.puntos:
                self.assertGreaterEqual(x, x0 - 1e-6)
                self.assertLessEqual(x, x1 + 1e-6)
                self.assertGreaterEqual(y, y0 - 1e-6)
                self.assertLessEqual(y, y1 + 1e-6)

    def test_no_dibuja_eje_vertical(self):
        """En un longitudinal no hay 'eje' que marcar: el eje es el dibujo."""
        h = lamina_longitudinal(secciones(n=10))
        self.assertNotIn(CLASE_EJE, {e.clase for e in h.entidades})

    def test_sin_secciones(self):
        h = lamina_longitudinal([])
        self.assertEqual(h.entidades, [])


class TestReticulaAjustada(unittest.TestCase):
    """La reticula se dimensiona al papel, no al contrario."""

    def test_llena_el_papel(self):
        r = Reticula.ajustada(420.0, 297.0, columnas=3, filas=4)
        self.assertLessEqual(r.ancho_hoja(), 420.0 + 1e-9)
        self.assertLessEqual(r.alto_hoja(), 297.0 + 1e-9)
        # Y lo aprovecha: no se queda a mas de 2 cm del borde.
        self.assertGreater(r.ancho_hoja(), 420.0 - 20.0)

    def test_mas_columnas_da_celdas_mas_estrechas(self):
        a = Reticula.ajustada(420.0, 297.0, columnas=2, filas=4)
        b = Reticula.ajustada(420.0, 297.0, columnas=4, filas=4)
        self.assertGreater(a.ancho_celda, b.ancho_celda)

    def test_celdas_con_tamano_minimo(self):
        r = Reticula.ajustada(100.0, 100.0, columnas=9, filas=9)
        self.assertGreaterEqual(r.ancho_celda, 20.0)
        self.assertGreaterEqual(r.alto_celda, 20.0)


class TestLongitudinalPaginado(unittest.TestCase):
    def test_parte_por_ancho(self):
        secs = secciones(n=41, paso_pk=20.0, pct=0.0)
        opts = OpcionesDibujo(escala=Escala(1000.0, 1000.0))
        hojas = laminas_longitudinal(secs, ancho_util=200.0, alto_util=200.0, opts=opts)
        # 800 m a 1:1000 son 800 mm: no caben en 200 -> varias hojas
        self.assertGreater(len(hojas), 3)
        for h in hojas:
            self.assertLess(h.extent[2] - h.extent[0], 200.0 + 40.0)

    def test_parte_tambien_por_alto(self):
        """A 1:100 en vertical, una ladera fuerte desborda el alto antes que el ancho."""
        secs = secciones(n=41, paso_pk=20.0)
        for s in secs:
            s.z_terreno = 100.0 + 0.15 * s.station.s
            s.z_eje = s.z_terreno - 2.0
        opts = OpcionesDibujo(escala=Escala(1000.0, 100.0))
        hojas = laminas_longitudinal(secs, ancho_util=380.0, alto_util=240.0, opts=opts)
        self.assertGreater(len(hojas), 1, "debe partir por desnivel, no solo por ancho")
        for h in hojas:
            self.assertLess(h.extent[3] - h.extent[1], 240.0 + 60.0)

    def test_las_hojas_empalman(self):
        secs = secciones(n=31, paso_pk=20.0)
        hojas = laminas_longitudinal(
            secs,
            ancho_util=150.0,
            alto_util=200.0,
            opts=OpcionesDibujo(escala=Escala(1000.0, 1000.0)),
        )
        for a, b in zip(hojas, hojas[1:]):
            self.assertAlmostEqual(a.pk_fin, b.pk_ini, places=6)

    def test_sin_secciones(self):
        self.assertEqual(laminas_longitudinal([]), [])


class TestCubicaciones(unittest.TestCase):
    def _medicion(self, n=21):
        from aqgis_sivil3d.core.medicion import medir

        return medir(secciones(n=n, paso_pk=20.0))

    def test_una_fila_por_tramo(self):
        m = self._medicion()
        hojas = laminas_de_cubicaciones(m)
        self.assertEqual(len(hojas), 1)
        textos = [e for e in hojas[0].entidades if e.clase == CLASE_TEXTO]
        self.assertGreaterEqual(len(textos), 9 * (1 + len(m.volumenes)))

    def test_pagina_cuando_no_caben(self):
        m = self._medicion(n=61)
        hojas = laminas_de_cubicaciones(m, filas_por_hoja=20)
        self.assertEqual(len(hojas), 3)
        self.assertAlmostEqual(hojas[0].pk_ini, 0.0)
        self.assertGreater(hojas[-1].pk_fin, hojas[0].pk_fin)

    def test_los_totales_van_en_la_ultima(self):
        m = self._medicion(n=61)
        hojas = laminas_de_cubicaciones(m, filas_por_hoja=20)

        def tiene_totales(h):
            return any(e.atributos.get("fila") == "total" for e in h.entidades)

        self.assertFalse(tiene_totales(hojas[0]))
        self.assertTrue(tiene_totales(hojas[-1]))

    def test_el_total_rotulado_coincide_con_la_medicion(self):
        m = self._medicion()
        hojas = laminas_de_cubicaciones(m)
        textos = [
            e.texto for e in hojas[0].entidades if e.atributos.get("fila") == "total"
        ]
        # El separador de miles es el del idioma: en ingles, la coma.
        esperado = f"{m.total_desmonte:,.1f} m3"
        self.assertIn(esperado, textos)

    def test_hojas_separadas_en_la_capa(self):
        m = self._medicion(n=61)
        hojas = laminas_de_cubicaciones(m, filas_por_hoja=20, paso_hoja=1000.0)
        for a, b in zip(hojas, hojas[1:]):
            self.assertLess(a.extent[2], b.extent[0])

    def test_sin_volumenes(self):
        from aqgis_sivil3d.core.medicion import Medicion

        self.assertEqual(laminas_de_cubicaciones(Medicion()), [])


class TestAlturasDeTexto(unittest.TestCase):
    def test_cada_clase_tiene_su_altura(self):
        opts = OpcionesDibujo()
        self.assertGreater(opts.altura("titulo"), opts.altura("acotacion"))
        self.assertGreaterEqual(opts.altura("acotacion"), 1.8)

    def test_las_entidades_de_texto_llevan_altura_y_anclaje(self):
        sec = secciones(n=1)[0]
        ents = dibujar_perfil(
            sec.perfil,
            sec.terreno,
            Celda(0.0, 0.0, 130.0, 80.0),
            OpcionesDibujo(),
            titulo="PK 0",
            subtitulo="D 1 T 2",
        )
        textos = [e for e in ents if e.clase in (CLASE_TEXTO, CLASE_ACOTACION)]
        self.assertTrue(textos)
        validos = (
            "centro", "izquierda", "derecha", "arriba", "abajo",
            "abajo_izquierda", "arriba_izquierda",
        )
        for e in textos:
            self.assertGreater(e.altura, 0.0, e.texto)
            self.assertIn(e.anclaje, validos)

    def test_las_cotas_se_anclan_por_la_derecha(self):
        """Asi no se meten dentro del marco."""
        sec = secciones(n=1)[0]
        celda = Celda(0.0, 0.0, 130.0, 80.0)
        ents = dibujar_perfil(sec.perfil, sec.terreno, celda, OpcionesDibujo())
        cotas = [
            e for e in ents if e.clase == CLASE_ACOTACION and e.anclaje == "derecha"
        ]
        self.assertTrue(cotas)
        for e in cotas:
            self.assertLess(e.puntos[0][0], celda.x)


class TestOtrosCorredores(unittest.TestCase):
    """La traza de otro corredor superpuesta, recortada al marco de la celda."""

    CELDA = Celda(0.0, 0.0, 100.0, 50.0)

    def _opts(self):
        return OpcionesDibujo(escala=Escala(200.0, 200.0))

    def _perfil(self):
        sec = secciones(n=1)[0]
        return sec.perfil, sec.terreno

    def test_la_traza_ajena_se_dibuja_con_su_clase(self):
        proyecto, terreno = self._perfil()
        z = proyecto[0][1]
        ents = dibujar_perfil(
            proyecto,
            terreno,
            self.CELDA,
            self._opts(),
            otros=[("otro eje", [(-4.0, z), (0.0, z + 0.2), (4.0, z)])],
        )
        ajenas = [e for e in ents if e.clase == CLASE_OTRO]
        self.assertEqual(len(ajenas), 1)
        self.assertEqual(len(ajenas[0].puntos), 3)
        self.assertEqual(ajenas[0].atributos.get("fila"), "otro eje")

    def test_sin_otros_no_se_dibuja_nada_de_mas(self):
        proyecto, terreno = self._perfil()
        ents = dibujar_perfil(proyecto, terreno, self.CELDA, self._opts())
        self.assertEqual([e for e in ents if e.clase == CLASE_OTRO], [])

    def test_lo_que_no_cabe_en_el_marco_se_recorta(self):
        """Un corredor lejano no puede salir pintado por encima del cajetin."""
        proyecto, terreno = self._perfil()
        z = proyecto[0][1]
        ents = dibujar_perfil(
            proyecto,
            terreno,
            self.CELDA,
            self._opts(),
            otros=[("lejano", [(500.0, z), (520.0, z)])],
        )
        self.assertEqual([e for e in ents if e.clase == CLASE_OTRO], [])

    def test_la_traza_recortada_no_se_sale_del_marco(self):
        proyecto, terreno = self._perfil()
        z = proyecto[0][1]
        ents = dibujar_perfil(
            proyecto,
            terreno,
            self.CELDA,
            self._opts(),
            otros=[("medio dentro", [(0.0, z), (400.0, z)])],
        )
        for e in [x for x in ents if x.clase == CLASE_OTRO]:
            for x, y in e.puntos:
                self.assertGreaterEqual(x, self.CELDA.x - 0.5)
                self.assertLessEqual(x, self.CELDA.x_fin + 0.5)
                self.assertGreaterEqual(y, self.CELDA.y - 0.5)
                self.assertLessEqual(y, self.CELDA.y_fin + 0.5)

    def test_una_traza_que_entra_y_sale_da_varios_trozos(self):
        proyecto, terreno = self._perfil()
        z = proyecto[0][1]
        puntos = [
            (-8.0, z), (-4.0, z + 200.0), (0.0, z), (4.0, z + 200.0), (8.0, z)
        ]
        ents = dibujar_perfil(
            proyecto, terreno, self.CELDA, self._opts(), otros=[("zig", puntos)]
        )
        ajenas = [e for e in ents if e.clase == CLASE_OTRO]
        self.assertGreaterEqual(len(ajenas), 2, "cada trozo va por separado")
        for e in ajenas:
            self.assertGreaterEqual(len(e.puntos), 2)

    def test_el_longitudinal_superpone_las_rasantes(self):
        secs = secciones(n=15, paso_pk=20.0)
        z = secs[0].z_eje
        otra = [(s.station.s, z + 1.5) for s in secs]
        hojas = laminas_longitudinal(secs, otros=[("eje 2", otra)])
        self.assertTrue(hojas)
        ajenas = [e for h in hojas for e in h.entidades if e.clase == CLASE_OTRO]
        self.assertTrue(ajenas, "la rasante del otro eje tiene que salir")
        self.assertEqual(ajenas[0].atributos.get("fila"), "eje 2")

    def test_cada_hoja_lleva_solo_su_trozo(self):
        secs = secciones(n=40, paso_pk=20.0)
        z = secs[0].z_eje
        otra = [(s.station.s, z + 1.0) for s in secs]
        hojas = laminas_longitudinal(
            secs, ancho_util=150.0, otros=[("eje 2", otra)]
        )
        self.assertGreater(len(hojas), 1, "tiene que paginarse")
        for h in hojas:
            for e in [x for x in h.entidades if x.clase == CLASE_OTRO]:
                xs = [q[0] for q in e.puntos]
                self.assertLessEqual(
                    max(xs) - min(xs), 200.0, "no puede llevar el perfil entero"
                )

    def test_sin_rasantes_ajenas_el_longitudinal_sale_igual(self):
        secs = secciones(n=15)
        con = laminas_longitudinal(secs, otros=[])
        sin = laminas_longitudinal(secs)
        self.assertEqual(len(con), len(sin))
        self.assertEqual(
            len([e for h in con for e in h.entidades]),
            len([e for h in sin for e in h.entidades]),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
