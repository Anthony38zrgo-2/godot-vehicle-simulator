"""Pruebas de la geometria de la rasante. Python puro, sin QGIS."""

import math
import unittest

from ..core.rasante_geom import (
    ARCO,
    BEZIER,
    NURBS,
    RECTA,
    Rasante,
    Vertice,
    simplificar,
)


def recta(m=0.02, z0=100.0, s0=0.0, s1=400.0):
    return Rasante.de_puntos([(s0, z0), (s1, z0 + m * (s1 - s0))])


class TestBasico(unittest.TestCase):
    def test_una_recta_interpola_lo_que_debe(self):
        r = recta(0.02, 100.0)
        self.assertAlmostEqual(r.z_en(0.0), 100.0)
        self.assertAlmostEqual(r.z_en(100.0), 102.0)
        self.assertAlmostEqual(r.z_en(400.0), 108.0)

    def test_fuera_de_la_rasante_no_hay_cota(self):
        r = recta()
        self.assertIsNone(r.z_en(-10.0))
        self.assertIsNone(r.z_en(500.0))

    def test_una_rasante_de_un_vertice_esta_vacia(self):
        self.assertTrue(Rasante.de_puntos([(0.0, 10.0)]).vacia)
        self.assertIsNone(Rasante().z_en(0.0))

    def test_muestrear_da_los_extremos(self):
        pts = recta().muestrear(50.0)
        self.assertAlmostEqual(pts[0][0], 0.0)
        self.assertAlmostEqual(pts[-1][0], 400.0)
        self.assertAlmostEqual(pts[-1][1], 108.0)

    def test_una_recta_no_se_densifica(self):
        """No hay por que meter vertices donde la ley es lineal."""
        self.assertEqual(len(recta().muestrear(5.0)), 2)

    def test_pendiente_y_resumen(self):
        r = recta(-0.035)
        self.assertAlmostEqual(r.pendiente(0), -0.035)
        self.assertIn("3.5 %", r.resumen())
        self.assertIn("2 vertices", r.resumen())

    def test_varios_tramos_seguidos(self):
        r = Rasante.de_puntos([(0, 100), (100, 105), (200, 103)])
        self.assertAlmostEqual(r.z_en(50), 102.5)
        self.assertAlmostEqual(r.z_en(100), 105.0)
        self.assertAlmostEqual(r.z_en(150), 104.0)
        self.assertAlmostEqual(r.pendiente(1), -0.02)

    def test_cotas_en_es_lo_mismo_que_z_en(self):
        r = Rasante.de_puntos([(0, 100), (100, 105), (200, 103)])
        abscisas = [0.0, 33.0, 100.0, 150.0, 200.0, 500.0]
        self.assertEqual(
            [None if v is None else round(v, 9) for v in r.cotas_en(abscisas)],
            [None if r.z_en(s) is None else round(r.z_en(s), 9) for s in abscisas],
        )


class TestEdicion(unittest.TestCase):
    def test_insertar_por_abscisa(self):
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        i = r.insertar(100.0, 110.0)
        self.assertEqual(i, 1)
        self.assertEqual([v.s for v in r.vertices], [0.0, 100.0, 200.0])
        self.assertAlmostEqual(r.z_en(50.0), 105.0)

    def test_insertar_en_un_segmento_curvo_lo_deja_recto(self):
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        r.set_tipo(0, BEZIER)
        r.insertar(100.0, 110.0)
        self.assertEqual(r[0].tipo, RECTA, "no se puede partir una Bezier a medias")
        self.assertEqual(r[0].control, [])

    def test_borrar_no_deja_menos_de_dos(self):
        r = Rasante.de_puntos([(0, 100), (100, 105), (200, 103)])
        self.assertTrue(r.borrar(1))
        self.assertEqual(len(r), 2)
        self.assertFalse(r.borrar(0))
        self.assertEqual(len(r), 2)

    def test_mover_arrastra_los_controles(self):
        r = Rasante.de_puntos([(0, 100), (100, 100)])
        r.set_tipo(0, BEZIER)
        antes = [tuple(c) for c in r[0].control]
        r.mover(0, 10.0, 105.0)
        for (s0, z0), (s1, z1) in zip(antes, r[0].control):
            self.assertAlmostEqual(s1 - s0, 10.0)
            self.assertAlmostEqual(z1 - z0, 5.0)

    def test_ordenar_tras_arrastrar_por_delante(self):
        r = Rasante.de_puntos([(0, 100), (100, 105), (200, 110)])
        r.mover(1, 250.0, 105.0)
        r.ordenar()
        self.assertEqual([v.s for v in r.vertices], [0.0, 200.0, 250.0])

    def test_anadir_al_final(self):
        r = Rasante.de_puntos([(0, 100)])
        r.anadir(100.0, 90.0)
        self.assertFalse(r.vacia)
        self.assertAlmostEqual(r.z_en(50.0), 95.0)

    def test_del_terreno_arranca_pegada_a_el(self):
        terreno = [(s, 100.0 + 0.01 * s) for s in range(0, 401, 10)]
        r = Rasante.del_terreno(terreno, n_vertices=4)
        self.assertEqual(len(r), 4)
        for s in (0.0, 120.0, 400.0):
            self.assertAlmostEqual(r.z_en(s), 100.0 + 0.01 * s, places=6)

    def test_del_terreno_con_offset(self):
        terreno = [(s, 100.0) for s in range(0, 401, 10)]
        r = Rasante.del_terreno(terreno, n_vertices=3, offset=-0.5)
        self.assertAlmostEqual(r.z_en(200.0), 99.5)


class TestTiposDeSegmento(unittest.TestCase):
    def test_cambiar_de_tipo_no_mueve_la_rasante(self):
        """Los controles por defecto van sobre la cuerda: la forma no salta."""
        for tipo in (ARCO, BEZIER, NURBS):
            r = Rasante.de_puntos([(0, 100), (200, 110)])
            r.set_tipo(0, tipo)
            for s in (0.0, 50.0, 100.0, 150.0, 200.0):
                self.assertAlmostEqual(
                    r.z_en(s), 100.0 + 0.05 * s, places=3, msg=f"{tipo} en s={s}"
                )

    def test_el_arco_pasa_por_su_punto_de_control(self):
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        r.set_tipo(0, ARCO)
        r[0].control = [(100.0, 90.0)]
        self.assertAlmostEqual(r.z_en(100.0), 90.0, places=2)
        # Y es simetrico, que es lo propio de un arco por tres puntos.
        self.assertAlmostEqual(r.z_en(50.0), r.z_en(150.0), places=3)
        self.assertLess(r.z_en(50.0), 100.0)

    def test_el_arco_colineal_es_la_cuerda(self):
        r = Rasante.de_puntos([(0, 100), (200, 120)])
        r.set_tipo(0, ARCO)
        r[0].control = [(100.0, 110.0)]
        self.assertAlmostEqual(r.z_en(50.0), 105.0, places=6)

    def test_la_bezier_no_pasa_por_sus_tiradores_pero_les_hace_caso(self):
        r = Rasante.de_puntos([(0, 100), (300, 100)])
        r.set_tipo(0, BEZIER)
        r[0].control = [(100.0, 130.0), (200.0, 130.0)]
        z = r.z_en(150.0)
        self.assertGreater(z, 100.0, "debe subir hacia los tiradores")
        self.assertLess(z, 130.0, "pero no llega a ellos")
        # Extremos clavados.
        self.assertAlmostEqual(r.z_en(0.0), 100.0, places=6)
        self.assertAlmostEqual(r.z_en(300.0), 100.0, places=6)

    def test_el_nurbs_pasa_por_los_extremos(self):
        r = Rasante.de_puntos([(0, 100), (400, 120)])
        r.set_tipo(0, NURBS)
        r[0].control = [(120.0, 140.0), (280.0, 90.0)]
        self.assertAlmostEqual(r.z_en(0.0), 100.0, places=4)
        self.assertAlmostEqual(r.z_en(400.0), 120.0, places=4)

    def test_el_peso_del_nurbs_tira_de_la_curva(self):
        r = Rasante.de_puntos([(0, 100), (400, 100)])
        r.set_tipo(0, NURBS)
        r[0].control = [(200.0, 140.0)]
        suave = r.z_en(200.0)
        r.set_peso(0, 1, 8.0)
        tirado = r.z_en(200.0)
        self.assertGreater(tirado, suave, "mas peso, mas cerca del control")
        self.assertLess(tirado, 140.0)

    def test_anadir_control_a_un_nurbs(self):
        r = Rasante.de_puntos([(0, 100), (400, 100)])
        r.set_tipo(0, NURBS)
        n = len(r[0].control)
        self.assertTrue(r.anadir_control(0))
        self.assertEqual(len(r[0].control), n + 1)
        # En una recta, meter controles sobre la cuerda no la deforma.
        self.assertAlmostEqual(r.z_en(200.0), 100.0, places=3)

    def test_anadir_control_solo_vale_en_nurbs(self):
        r = Rasante.de_puntos([(0, 100), (400, 100)])
        r.set_tipo(0, BEZIER)
        self.assertFalse(r.anadir_control(0))

    def test_el_nurbs_con_muchos_controles_sigue_siendo_funcion(self):
        r = Rasante.de_puntos([(0, 100), (400, 130)])
        r.set_tipo(0, NURBS)
        r[0].control = [(80, 110), (160, 105), (240, 125), (320, 120)]
        muestras = r.muestrear(5.0)
        self.assertTrue(
            all(b[0] > a[0] for a, b in zip(muestras, muestras[1:])),
            "las abscisas deben crecer",
        )

    def test_muestreo_de_un_segmento_curvo_se_densifica(self):
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        r.set_tipo(0, ARCO)
        r[0].control = [(100.0, 80.0)]
        self.assertGreater(len(r.muestrear(5.0)), 10)

    def test_volver_a_poner_el_mismo_tipo_no_recoloca_los_tiradores(self):
        """Si no, mover un tirador y volver a pulsar el boton borraria el trabajo."""
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        self.assertTrue(r.set_tipo(0, BEZIER))
        r[0].control = [(60.0, 130.0), (140.0, 130.0)]
        self.assertFalse(r.set_tipo(0, BEZIER), "no hay nada que cambiar")
        self.assertEqual([tuple(c) for c in r[0].control], [(60.0, 130.0), (140.0, 130.0)])
        # Y con forzar se recolocan a proposito: es como se reinicia una curva.
        self.assertTrue(r.set_tipo(0, BEZIER, forzar=True))
        self.assertAlmostEqual(r.z_en(100.0), 100.0, places=3)

    def test_cambiar_a_otro_tipo_si_recoloca(self):
        r = Rasante.de_puntos([(0, 100), (200, 100)])
        r.set_tipo(0, BEZIER)
        r[0].control = [(60.0, 130.0), (140.0, 130.0)]
        self.assertTrue(r.set_tipo(0, ARCO))
        self.assertEqual(len(r[0].control), 1)
        self.assertAlmostEqual(r.z_en(100.0), 100.0, places=3)

    def test_tipo_invalido(self):
        r = recta()
        self.assertFalse(r.set_tipo(0, "espiral"))
        self.assertFalse(r.set_tipo(7, ARCO))


class TestAcuerdos(unittest.TestCase):
    def _en_v(self, longitud=100.0):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_acuerdo(1, longitud)
        return r

    def test_el_acuerdo_levanta_el_fondo_de_la_v(self):
        r = self._en_v(100.0)
        # Parabola simetrica: en el vertice sube A*L/8 sobre la interseccion de
        # tangentes. Aqui A = 0.05 - (-0.05) = 0.10, L = 100 -> 1.25 m.
        self.assertAlmostEqual(r.z_en(200.0), 90.0 + 0.10 * 100.0 / 8.0, places=6)

    def test_el_acuerdo_empieza_y_acaba_en_las_tangentes(self):
        r = self._en_v(100.0)
        self.assertAlmostEqual(r.z_en(150.0), 92.5, places=6)
        self.assertAlmostEqual(r.z_en(250.0), 92.5, places=6)

    def test_es_simetrico(self):
        r = self._en_v(120.0)
        for d in (10.0, 30.0, 59.0):
            self.assertAlmostEqual(r.z_en(200.0 - d), r.z_en(200.0 + d), places=6)

    def test_sin_acuerdo_es_una_esquina(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        self.assertAlmostEqual(r.z_en(200.0), 90.0, places=9)

    def test_k_y_su_inverso(self):
        r = self._en_v(100.0)
        # A = 10 % -> K = L / |A| = 10 m por cada 1 %.
        self.assertAlmostEqual(r.parametro_k(1), 10.0, places=6)
        self.assertTrue(r.set_k(1, 25.0))
        self.assertAlmostEqual(r[1].acuerdo, 250.0, places=6)
        self.assertAlmostEqual(r.parametro_k(1), 25.0, places=6)

    def test_sin_cambio_de_pendiente_no_hay_k(self):
        r = Rasante.de_puntos([(0, 100), (200, 110), (400, 120)])
        r.set_acuerdo(1, 100.0)
        self.assertIsNone(r.parametro_k(1))
        self.assertFalse(r.set_k(1, 20.0))
        self.assertAlmostEqual(r.z_en(200.0), 110.0, places=9)

    def test_el_acuerdo_no_cabe_y_se_recorta(self):
        r = Rasante.de_puntos([(0, 100), (100, 90), (200, 100)])
        r.set_acuerdo(1, 400.0)
        avisos = r.avisos()
        self.assertTrue(any("no cabe" in a for a in avisos), avisos)
        # Y aun asi la rasante se puede evaluar de punta a punta.
        self.assertIsNotNone(r.z_en(0.0))
        self.assertIsNotNone(r.z_en(100.0))
        self.assertIsNotNone(r.z_en(200.0))

    def test_no_hay_acuerdo_en_los_extremos(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        self.assertFalse(r.set_acuerdo(0, 50.0))
        self.assertFalse(r.set_acuerdo(2, 50.0))

    def test_el_acuerdo_sobre_una_curva_se_ignora_y_se_avisa(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_tipo(0, BEZIER)
        r.set_acuerdo(1, 100.0)
        self.assertAlmostEqual(r.z_en(200.0), 90.0, places=6)
        self.assertTrue(any("no es una recta" in a for a in r.avisos()))

    def test_dos_acuerdos_seguidos_no_se_pisan(self):
        r = Rasante.de_puntos([(0, 100), (100, 110), (200, 100), (300, 110)])
        r.set_acuerdo(1, 90.0)
        r.set_acuerdo(2, 90.0)
        muestras = r.muestrear(2.0)
        self.assertTrue(all(b[0] > a[0] for a, b in zip(muestras, muestras[1:])))
        self.assertLess(r.z_en(110.0), 110.0)

    def test_las_piezas_cubren_toda_la_rasante(self):
        r = self._en_v(100.0)
        piezas = r.piezas()
        self.assertAlmostEqual(piezas[0].s_ini, 0.0)
        self.assertAlmostEqual(piezas[-1].s_fin, 400.0)
        for a, b in zip(piezas, piezas[1:]):
            self.assertAlmostEqual(a.s_fin, b.s_ini, places=6)
        self.assertIn("acuerdo", [p.clase for p in piezas])


class TestAvisos(unittest.TestCase):
    def test_pendiente_excesiva(self):
        r = recta(0.20)
        avisos = r.avisos(pendiente_max=0.12)
        self.assertTrue(any("20.0 %" in a for a in avisos), avisos)

    def test_pendiente_admisible_no_avisa(self):
        self.assertEqual(recta(0.05).avisos(), [])

    def test_abscisa_no_creciente(self):
        r = Rasante([Vertice(100.0, 100.0), Vertice(100.0, 110.0)])
        self.assertTrue(any("is not greater" in a for a in r.avisos()))

    def test_curva_que_se_vuelve_sobre_si_misma(self):
        r = Rasante.de_puntos([(0, 100), (100, 100)])
        r.set_tipo(0, BEZIER)
        r[0].control = [(180.0, 110.0), (-80.0, 90.0)]
        self.assertTrue(any("folds back on itself" in a for a in r.avisos()))
        # Aun asi z_en no explota: se queda con la envolvente creciente.
        self.assertIsNotNone(r.z_en(50.0))

    def test_rasante_vacia(self):
        self.assertTrue(any("two vertices" in a for a in Rasante().avisos()))


class TestSimplificar(unittest.TestCase):
    """La rasante es una ley de cotas, no una copia de los vertices de la planta."""

    def test_una_recta_se_queda_en_dos_puntos(self):
        recta_larga = [(s, 100.0 + 0.02 * s) for s in range(0, 501, 5)]
        self.assertEqual(len(simplificar(recta_larga, 0.01)), 2)

    def test_se_conservan_los_quiebros(self):
        # Dos rampas: el vertice del medio no se puede perder.
        puntos = [(s, 100.0 + 0.03 * s) for s in range(0, 201, 5)]
        puntos += [(s, 106.0 - 0.02 * (s - 200)) for s in range(205, 401, 5)]
        salida = simplificar(puntos, 0.05)
        self.assertLess(len(salida), 10)
        self.assertTrue(any(abs(s - 200.0) < 1e-6 for s, _z in salida))

    def test_respeta_la_tolerancia(self):
        import math

        puntos = [(s, 100.0 + 3.0 * math.sin(s / 40.0)) for s in range(0, 401, 2)]
        for tol in (0.02, 0.1, 0.5):
            r = Rasante.de_puntos(puntos, tolerancia=tol)
            desvios = [abs(r.z_en(s) - z) for s, z in puntos]
            self.assertLessEqual(max(desvios), tol + 1e-9, f"tolerancia {tol}")

    def test_a_mas_tolerancia_menos_vertices(self):
        import math

        puntos = [(s, 100.0 + 3.0 * math.sin(s / 40.0)) for s in range(0, 401, 2)]
        tam = [len(Rasante.de_puntos(puntos, tolerancia=t)) for t in (0.01, 0.1, 1.0)]
        self.assertGreater(tam[0], tam[1])
        self.assertGreater(tam[1], tam[2])
        self.assertGreaterEqual(tam[2], 2)

    def test_sin_tolerancia_no_se_toca_nada(self):
        puntos = [(s, 100.0 + 0.02 * s) for s in range(0, 101, 5)]
        self.assertEqual(len(Rasante.de_puntos(puntos)), len(puntos))
        self.assertEqual(simplificar(puntos, 0.0), puntos)

    def test_simplificar_en_el_sitio(self):
        puntos = [(s, 100.0 + 0.02 * s) for s in range(0, 501, 5)]
        r = Rasante.de_puntos(puntos)
        n = len(r)
        quitados = r.simplificar_a(0.01)
        self.assertEqual(quitados, n - 2)
        self.assertEqual(len(r), 2)
        self.assertAlmostEqual(r.z_en(250.0), 105.0, places=6)

    def test_simplificar_conserva_los_acuerdos_que_sobreviven(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_acuerdo(1, 80.0)
        r.simplificar_a(0.05)
        self.assertEqual(len(r), 3, "los tres vertices hacen falta")
        self.assertAlmostEqual(r[1].acuerdo, 80.0)

    def test_simplificar_lo_que_no_se_puede(self):
        r = Rasante.de_puntos([(0, 100), (100, 110)])
        self.assertEqual(r.simplificar_a(0.5), 0)
        self.assertEqual(r.simplificar_a(0.0), 0)


class TestVariosVertices(unittest.TestCase):
    """Mover y borrar varios a la vez: un tramo largo no se edita de uno en uno."""

    def _rasante(self):
        return Rasante.de_puntos([(0, 100), (100, 105), (200, 103), (300, 108), (400, 106)])

    def test_mover_varios_el_mismo_incremento(self):
        r = self._rasante()
        antes = [(v.s, v.z) for v in r.vertices]
        r.mover_varios([1, 2, 3], 0.0, 4.0)
        for i, (s0, z0) in enumerate(antes):
            v = r[i]
            self.assertAlmostEqual(v.s, s0)
            esperado = z0 + (4.0 if i in (1, 2, 3) else 0.0)
            self.assertAlmostEqual(v.z, esperado, msg=f"vertice {i}")

    def test_mover_varios_no_deforma_el_tramo(self):
        """Las pendientes internas del grupo se conservan: es todo el sentido."""
        r = self._rasante()
        antes = [r.pendiente(i) for i in (1, 2)]
        r.mover_varios([1, 2, 3], 0.0, 6.0)
        for i, m in zip((1, 2), antes):
            self.assertAlmostEqual(r.pendiente(i), m, places=9)

    def test_mover_varios_arrastra_los_tiradores(self):
        r = self._rasante()
        r.set_tipo(1, BEZIER)
        antes = [tuple(c) for c in r[1].control]
        r.mover_varios([1, 2], 5.0, 2.0)
        for (s0, z0), (s1, z1) in zip(antes, r[1].control):
            self.assertAlmostEqual(s1 - s0, 5.0)
            self.assertAlmostEqual(z1 - z0, 2.0)

    def test_indices_fuera_de_rango_se_ignoran(self):
        r = self._rasante()
        r.mover_varios([0, 99, -3], 0.0, 1.0)
        self.assertAlmostEqual(r[0].z, 101.0)

    def test_borrar_varios(self):
        r = self._rasante()
        self.assertEqual(r.borrar_varios([1, 3]), 2)
        self.assertEqual(len(r), 3)
        self.assertEqual([v.s for v in r.vertices], [0.0, 200.0, 400.0])

    def test_borrar_varios_nunca_deja_menos_de_dos(self):
        r = self._rasante()
        quitados = r.borrar_varios(range(len(r)))
        self.assertEqual(len(r), 2, "siempre quedan dos")
        self.assertEqual(quitados, 3)

    def test_borrar_varios_en_una_rasante_minima(self):
        r = Rasante.de_puntos([(0, 100), (100, 110)])
        self.assertEqual(r.borrar_varios([0, 1]), 0)
        self.assertEqual(len(r), 2)


class TestSerializacion(unittest.TestCase):
    def test_va_y_vuelve(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_acuerdo(1, 120.0)
        r.set_tipo(0, NURBS)
        r[0].control = [(60.0, 95.0), (140.0, 92.0)]
        r.set_peso(0, 1, 3.5)
        copia = Rasante.de_dict(r.a_dict())
        self.assertEqual(len(copia), len(r))
        self.assertAlmostEqual(copia[1].acuerdo, 120.0)
        self.assertEqual(copia[0].tipo, NURBS)
        self.assertEqual([tuple(c) for c in copia[0].control], [(60.0, 95.0), (140.0, 92.0)])
        for s in (0.0, 50.0, 200.0, 399.0):
            self.assertAlmostEqual(copia.z_en(s), r.z_en(s), places=9)

    def test_una_recta_no_guarda_ruido(self):
        d = recta().a_dict()
        self.assertEqual(list(d["vertices"][0].keys()), ["s", "z"])

    def test_de_dict_vacio(self):
        self.assertTrue(Rasante.de_dict({}).vacia)
        self.assertTrue(Rasante.de_dict(None).vacia)

    def test_la_copia_es_independiente(self):
        r = Rasante.de_puntos([(0, 100), (200, 90)])
        c = r.copia()
        c.mover(0, 0.0, 200.0)
        self.assertAlmostEqual(r[0].z, 100.0)


class TestContraElTerreno(unittest.TestCase):
    """Lo que se le va a pedir de verdad: cotas en los PK de un eje."""

    def test_cotas_en_los_pk(self):
        r = Rasante.de_puntos([(0, 100), (200, 120), (400, 110)])
        r.set_acuerdo(1, 100.0)
        pks = [i * 20.0 for i in range(21)]
        cotas = r.cotas_en(pks)
        self.assertEqual(len(cotas), len(pks))
        self.assertTrue(all(c is not None for c in cotas))
        # Monotona hasta el acuerdo y luego baja: el maximo esta dentro del acuerdo.
        i_max = max(range(len(cotas)), key=lambda i: cotas[i])
        self.assertTrue(150.0 <= pks[i_max] <= 250.0)

    def test_una_rasante_muy_muestreada_no_se_desvia_de_la_ley(self):
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_acuerdo(1, 200.0)
        for s in [i * 1.0 for i in range(0, 401)]:
            z = r.z_en(s)
            self.assertTrue(math.isfinite(z))
            self.assertGreaterEqual(z, 89.0)
            self.assertLessEqual(z, 100.01)


if __name__ == "__main__":
    unittest.main()
