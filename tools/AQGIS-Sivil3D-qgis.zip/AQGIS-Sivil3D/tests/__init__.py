"""Tests del plugin.

``test_core.py`` no necesita QGIS: se ejecuta con un interprete normal::

    python -m unittest discover -s aqgis_sivil3d/tests -p "test_core*.py"

``test_gis.py`` si lo necesita, y se lanza con el python de QGIS.
"""
