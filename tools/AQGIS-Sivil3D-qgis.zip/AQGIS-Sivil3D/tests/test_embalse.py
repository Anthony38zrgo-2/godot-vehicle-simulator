"""Pruebas del cubicaje de la curva de embalse. Python puro, sin QGIS."""

import unittest

from ..core.embalse import Acumulador, CurvaEmbalse, cotas, curva_de_bloques


class TestVectorDeCotas(unittest.TestCase):
    def test_paso_que_cuadra(self):
        self.assertEqual(cotas(100.0, 102.0, 0.5), [100.0, 100.5, 101.0, 101.5, 102.0])

    def test_la_ultima_cota_es_siempre_la_pedida(self):
        v = cotas(100.0, 101.3, 0.5)
        self.assertAlmostEqual(v[-1], 101.3)
        self.assertAlmostEqual(v[-2], 101.0)

    def test_paso_de_diez_centimetros(self):
        v = cotas(115.0, 161.0, 0.1)
        self.assertEqual(len(v), 461)
        self.assertAlmostEqual(v[1], 115.1)
        self.assertAlmostEqual(v[-1], 161.0)

    def test_errores(self):
        with self.assertRaises(ValueError):
            cotas(100.0, 110.0, 0.0)
        with self.assertRaises(ValueError):
            cotas(110.0, 100.0, 1.0)


class TestCubicaje(unittest.TestCase):
    """Un vaso de laboratorio, para poder hacer la cuenta a mano."""

    def test_vaso_plano(self):
        """100 celdas de 1 m2 a la cota 100: a la 101 hay 100 m3 y 100 m2."""
        curva = curva_de_bloques([[100.0] * 100], cotas(100.0, 102.0, 1.0), 1.0)
        self.assertEqual(curva.cotas, [100.0, 101.0, 102.0])
        # En la propia cota del fondo no hay agua todavia.
        self.assertAlmostEqual(curva.vol_m3[0], 0.0)
        self.assertAlmostEqual(curva.area_m2[0], 0.0)
        self.assertAlmostEqual(curva.vol_m3[1], 100.0)
        self.assertAlmostEqual(curva.area_m2[1], 100.0)
        self.assertAlmostEqual(curva.vol_m3[2], 200.0)

    def test_celda_de_cuatro_metros(self):
        curva = curva_de_bloques([[100.0] * 10], cotas(100.0, 101.0, 1.0), 4.0)
        self.assertAlmostEqual(curva.area_m2[1], 40.0)
        self.assertAlmostEqual(curva.vol_m3[1], 40.0)

    def test_vaso_escalonado(self):
        """Dos escalones: 10 celdas a 100 y 10 a 101, celda de 1 m2."""
        v = cotas(100.0, 103.0, 1.0)
        curva = curva_de_bloques([[100.0] * 10 + [101.0] * 10], v, 1.0)
        # A la 101 solo cuenta el escalon bajo: 10 celdas, 1 m de calado.
        self.assertAlmostEqual(curva.area_m2[1], 10.0)
        self.assertAlmostEqual(curva.vol_m3[1], 10.0)
        # A la 102 cuentan los dos: 10 * 2 + 10 * 1.
        self.assertAlmostEqual(curva.area_m2[2], 20.0)
        self.assertAlmostEqual(curva.vol_m3[2], 30.0)

    def test_vaso_en_rampa(self):
        """Fondo lineal: el volumen es el de un prisma triangular."""
        fondo = [100.0 + i * 0.01 for i in range(1000)]  # de 100 a 109.99
        v = cotas(100.0, 110.0, 0.5)
        curva = curva_de_bloques([fondo], v, 1.0)
        # A la cota 105: 500 celdas mojadas, calado medio 2.5 m.
        self.assertAlmostEqual(curva.area_m2[10], 500.0, places=6)
        self.assertAlmostEqual(curva.vol_m3[10], 500 * 2.5 + 0.5 * 500 * 0.01, places=3)

    def test_las_celdas_por_encima_no_cuentan_pero_se_ven(self):
        v = cotas(100.0, 101.0, 1.0)
        curva = curva_de_bloques([[100.0] * 5 + [200.0] * 5], v, 1.0)
        self.assertAlmostEqual(curva.area_m2[1], 5.0, msg="solo las de debajo")
        self.assertAlmostEqual(curva.cota_max, 200.0, msg="pero la maxima es real")
        self.assertEqual(curva.n_celdas, 10)

    def test_por_bloques_es_igual_que_de_una_vez(self):
        fondo = [100.0 + (i % 37) * 0.3 for i in range(500)]
        v = cotas(100.0, 112.0, 0.25)
        entera = curva_de_bloques([fondo], v, 2.0)
        troceada = curva_de_bloques(
            [fondo[i : i + 61] for i in range(0, len(fondo), 61)], v, 2.0
        )
        self.assertEqual(len(entera.cotas), len(troceada.cotas))
        for a, b in zip(entera.vol_m3, troceada.vol_m3):
            self.assertAlmostEqual(a, b, places=9)
        for a, b in zip(entera.area_m2, troceada.area_m2):
            self.assertAlmostEqual(a, b, places=9)

    def test_el_volumen_crece_y_el_area_no_baja(self):
        fondo = [100.0 + (i * 7 % 53) * 0.2 for i in range(400)]
        curva = curva_de_bloques([fondo], cotas(100.0, 115.0, 0.5), 1.0)
        for a, b in zip(curva.vol_m3, curva.vol_m3[1:]):
            self.assertLessEqual(a, b + 1e-9)
        for a, b in zip(curva.area_m2, curva.area_m2[1:]):
            self.assertLessEqual(a, b + 1e-9)

    def test_sin_celdas_validas(self):
        curva = curva_de_bloques([[]], cotas(100.0, 110.0, 1.0), 1.0)
        self.assertTrue(curva.vacia)
        self.assertIn("sin curva", curva.resumen())

    def test_los_nan_se_ignoran(self):
        curva = curva_de_bloques(
            [[100.0, float("nan"), 100.0, float("inf")]], cotas(100.0, 101.0, 1.0), 1.0
        )
        self.assertEqual(curva.n_celdas, 2)
        self.assertAlmostEqual(curva.vol_m3[1], 2.0)

    def test_extremos_reales_del_raster(self):
        curva = curva_de_bloques(
            [[103.5, 100.25, 118.0]], cotas(100.0, 120.0, 1.0), 1.0
        )
        self.assertAlmostEqual(curva.cota_min, 100.25)
        self.assertAlmostEqual(curva.cota_max, 118.0)

    def test_acumulador_devuelve_cuantas_ha_contado(self):
        acc = Acumulador(cotas(100.0, 110.0, 1.0))
        self.assertEqual(acc.anadir([100.0, None, float("nan"), 105.0]), 2)
        self.assertEqual(acc.n_celdas, 2)

    def test_el_camino_de_numpy_da_lo_mismo_que_el_de_python(self):
        try:
            import numpy as np
        except ImportError:
            self.skipTest("sin numpy")
        fondo = [100.0 + (i % 23) * 0.4 for i in range(300)]
        v = cotas(100.0, 110.0, 0.2)
        con_np = curva_de_bloques([np.asarray(fondo)], v, 1.5)
        con_py = curva_de_bloques([fondo], v, 1.5)
        for a, b in zip(con_np.vol_m3, con_py.vol_m3):
            self.assertAlmostEqual(a, b, places=6)
        self.assertEqual(con_np.n_celdas, con_py.n_celdas)


class TestConsultas(unittest.TestCase):
    def _curva(self):
        fondo = [100.0 + i * 0.01 for i in range(1000)]
        return curva_de_bloques([fondo], cotas(100.0, 110.0, 0.5), 1.0)

    def test_interpolar_entre_cotas(self):
        c = self._curva()
        v104 = c.volumen_en(104.0)
        v105 = c.volumen_en(105.0)
        self.assertLess(v104, c.volumen_en(104.5) or 0.0)
        self.assertLess(c.volumen_en(104.5) or 0.0, v105)

    def test_fuera_de_rango_se_agarra_al_extremo(self):
        c = self._curva()
        self.assertAlmostEqual(c.volumen_en(50.0), c.vol_m3[0])
        self.assertAlmostEqual(c.volumen_en(500.0), c.vol_m3[-1])
        self.assertAlmostEqual(c.area_en(500.0), c.area_m2[-1])

    def test_la_pregunta_al_reves(self):
        c = self._curva()
        cota = c.cota_para_volumen(c.vol_m3[10])
        self.assertAlmostEqual(cota, c.cotas[10], places=6)
        self.assertAlmostEqual(c.cota_para_volumen(-1.0), c.cotas[0])
        self.assertAlmostEqual(c.cota_para_volumen(1e12), c.cotas[-1])

    def test_curva_vacia_no_contesta(self):
        c = CurvaEmbalse()
        self.assertIsNone(c.volumen_en(100.0))
        self.assertIsNone(c.area_en(100.0))
        self.assertIsNone(c.cota_para_volumen(1.0))


class TestSalidas(unittest.TestCase):
    def _curva(self):
        return curva_de_bloques([[100.0] * 100], cotas(100.0, 102.0, 1.0), 1.0)

    def test_csv_para_excel_espanol(self):
        texto = self._curva().csv()
        lineas = texto.strip().split("\n")
        self.assertEqual(len(lineas), 4, "cabecera y tres cotas")
        self.assertIn("Cota (msnm);Volumen (hm3)", lineas[0])
        self.assertIn(",", lineas[1], "decimal con coma")
        self.assertNotIn(".", lineas[1].split(";")[0])

    def test_csv_en_formato_internacional(self):
        texto = self._curva().csv(separador=",", decimal=".")
        self.assertIn("101.000,0.000100,0.0100,100.00,100.00", texto)

    def test_las_cinco_columnas(self):
        texto = self._curva().csv()
        self.assertEqual(len(texto.strip().split("\n")[1].split(";")), 5)

    def test_unidades_derivadas(self):
        c = self._curva()
        self.assertAlmostEqual(c.vol_hm3[1], 100.0 / 1e6)
        self.assertAlmostEqual(c.area_ha[1], 100.0 / 1e4)

    def test_resumen(self):
        r = self._curva().resumen()
        self.assertIn("3 cotas", r)
        self.assertIn("100.00", r)
        self.assertIn("hm3", r)

    def test_ida_y_vuelta_por_diccionario(self):
        c = self._curva()
        d = c.a_dict()
        self.assertEqual(d["n_celdas"], 100)
        self.assertEqual(len(d["cotas"]), 3)
        self.assertAlmostEqual(d["area_celda"], 1.0)


if __name__ == "__main__":
    unittest.main()
