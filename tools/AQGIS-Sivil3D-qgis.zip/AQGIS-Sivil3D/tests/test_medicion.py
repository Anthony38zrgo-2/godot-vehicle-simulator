"""Tests de perfiles y mediciones. No necesitan QGIS.

Los casos son geometrias con solucion analitica: si el area de un triangulo o de
un trapecio no sale exacta, es que hay un error, no una imprecision.
"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from aqgis_sivil3d.core.medicion import (  # noqa: E402
    METODO_AREAS_MEDIAS,
    METODO_PRISMATOIDE,
    AreaSeccion,
    areas_de_secciones,
    diagrama_masas,
    medir,
    volumenes_entre,
)
from aqgis_sivil3d.core.perfil import (  # noqa: E402
    SIGNO_DESMONTE,
    SIGNO_TERRAPLEN,
    areas,
    muestrear,
    tramos,
    z_en,
)
from aqgis_sivil3d.core.resolver import (  # noqa: E402
    SectionOptions,
    Station,
    plane_terrain,
    resolve_section,
)
from aqgis_sivil3d.core.schema import Assembly, branch, el  # noqa: E402
from aqgis_sivil3d.core.templates import load_template  # noqa: E402


class TestZEn(unittest.TestCase):
    def test_interpolacion(self):
        p = [(0.0, 10.0), (10.0, 20.0)]
        self.assertAlmostEqual(z_en(p, 0.0), 10.0)
        self.assertAlmostEqual(z_en(p, 5.0), 15.0)
        self.assertAlmostEqual(z_en(p, 10.0), 20.0)

    def test_fuera_de_rango(self):
        p = [(0.0, 10.0), (10.0, 20.0)]
        self.assertIsNone(z_en(p, -5.0))
        self.assertIsNone(z_en(p, 15.0))

    def test_tramo_vertical_se_queda_con_el_segundo(self):
        # Un bordillo: dos vertices con el mismo offset.
        p = [(0.0, 10.0), (5.0, 10.0), (5.0, 10.5), (8.0, 10.5)]
        self.assertAlmostEqual(z_en(p, 5.0), 10.5)
        self.assertAlmostEqual(z_en(p, 6.0), 10.5)

    def test_perfil_vacio(self):
        self.assertIsNone(z_en([], 0.0))


class TestTramos(unittest.TestCase):
    def test_todo_terraplen(self):
        pro = [(0.0, 10.0), (10.0, 10.0)]
        ter = [(0.0, 8.0), (10.0, 8.0)]
        ts = tramos(pro, ter)
        self.assertEqual(len(ts), 1)
        self.assertEqual(ts[0].signo, SIGNO_TERRAPLEN)
        self.assertAlmostEqual(ts[0].area(), 2.0 * 10.0)

    def test_todo_desmonte(self):
        pro = [(0.0, 8.0), (10.0, 8.0)]
        ter = [(0.0, 10.0), (10.0, 10.0)]
        ts = tramos(pro, ter)
        self.assertEqual(len(ts), 1)
        self.assertEqual(ts[0].signo, SIGNO_DESMONTE)
        self.assertAlmostEqual(ts[0].area(), 20.0)

    def test_un_cruce_parte_en_dos(self):
        # Se cruzan en x=5. A cada lado queda un triangulo de base 5 y altura 4
        # (la diferencia entre las dos lineas en el extremo) -> 10 m2 cada uno.
        pro = [(0.0, 8.0), (10.0, 12.0)]
        ter = [(0.0, 12.0), (10.0, 8.0)]
        ts = tramos(pro, ter)
        self.assertEqual(len(ts), 2)
        self.assertEqual(ts[0].signo, SIGNO_DESMONTE)
        self.assertEqual(ts[1].signo, SIGNO_TERRAPLEN)
        self.assertAlmostEqual(ts[0].x_fin, 5.0, places=6)
        self.assertAlmostEqual(ts[0].area(), 10.0, places=6)
        self.assertAlmostEqual(ts[1].area(), 10.0, places=6)

    def test_solo_el_solape_cuenta(self):
        pro = [(0.0, 10.0), (20.0, 10.0)]
        ter = [(5.0, 8.0), (15.0, 8.0)]
        ts = tramos(pro, ter)
        self.assertAlmostEqual(ts[0].x_ini, 5.0)
        self.assertAlmostEqual(ts[0].x_fin, 15.0)
        self.assertAlmostEqual(ts[0].area(), 2.0 * 10.0)

    def test_lineas_coincidentes_no_dan_area(self):
        pro = [(0.0, 10.0), (10.0, 10.0)]
        self.assertAlmostEqual(sum(t.area() for t in tramos(pro, list(pro))), 0.0)

    def test_muestrear_conserva_los_quiebros(self):
        pro = [(0.0, 0.0), (3.0, 1.0), (7.0, 1.0), (10.0, 0.0)]
        ter = [(0.0, -5.0), (10.0, -5.0)]
        xs = [m[0] for m in muestrear(pro, ter)]
        for x in (3.0, 7.0):
            self.assertIn(x, xs)

    def test_escalon_vertical_no_falsea_el_area(self):
        """Con un muro, la cota de salida es la que vale al otro lado.

        Proyecto: plano a 10 hasta x=5, escalon a 10.5, plano a 10.5 hasta x=8.
        Terreno a 0. Area = 5*10 + 3*10.5 = 81.5 m2. Si el escalon se ignorase,
        el tramo derecho se integraria como rampa 10 -> 10.5 y saldria 80.75.
        """
        pro = [(0.0, 10.0), (5.0, 10.0), (5.0, 10.5), (8.0, 10.5)]
        ter = [(0.0, 0.0), (8.0, 0.0)]
        des, ter_ = areas(pro, ter)
        self.assertAlmostEqual(des, 0.0, places=9)
        self.assertAlmostEqual(ter_, 5 * 10.0 + 3 * 10.5, places=6)

    def test_areas_devuelve_las_dos(self):
        pro = [(0.0, 8.0), (10.0, 12.0)]
        ter = [(0.0, 12.0), (10.0, 8.0)]
        des, ter_ = areas(pro, ter)
        self.assertAlmostEqual(des, 10.0, places=6)
        self.assertAlmostEqual(ter_, 10.0, places=6)


class TestAreasDeSecciones(unittest.TestCase):
    def _seccion(self, ancho: float, desnivel: float, z_terreno: float = 100.0):
        """Plataforma horizontal de semiancho ``ancho`` a ``desnivel`` del terreno."""
        asm = Assembly(
            izquierda=branch(
                fijos=[el("offset_pendiente", "P", ancho=ancho, pendiente=0.0)],
                desmonte=[el("talud_daylight", "T", talud="1:1")],
                terraplen=[el("talud_daylight", "T", talud="1:1")],
            ),
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=ancho, pendiente=0.0)],
                desmonte=[el("talud_daylight", "T", talud="1:1")],
                terraplen=[el("talud_daylight", "T", talud="1:1")],
            ),
            eje={"cota": "terreno", "desnivel": desnivel, "desplazamiento": 0.0},
        ).materialize()
        tz = plane_terrain(z_ref=z_terreno, pendiente_pct=0.0, nx=0.0, ny=1.0)
        return resolve_section(
            asm,
            Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0),
            tz,
            SectionOptions(paso=0.1, ancho_max=100.0, muestras_terreno=200),
        )

    def test_la_seccion_guarda_su_terreno(self):
        sec = self._seccion(5.0, -2.0)
        self.assertGreater(len(sec.terreno), 50)
        # Cubre toda la seccion mas margen.
        self.assertLess(sec.terreno[0][0], min(v.offset for v in sec.vertices))
        self.assertGreater(sec.terreno[-1][0], max(v.offset for v in sec.vertices))

    def test_cota_del_terreno_en_el_eje(self):
        sec = self._seccion(5.0, -2.0)
        self.assertAlmostEqual(sec.z_terreno, 100.0, places=6)
        self.assertAlmostEqual(sec.z_eje, 98.0, places=6)

    def test_cota_roja(self):
        self.assertAlmostEqual(self._seccion(5.0, -2.0).cota_roja, -2.0, places=6)
        self.assertAlmostEqual(self._seccion(5.0, 3.0).cota_roja, 3.0, places=6)

    def test_area_de_desmonte_exacta(self):
        """Cajero 1:1 y plataforma horizontal: el area sale a mano.

        Con semiancho a y profundidad h, la seccion excavada es un trapecio de
        bases 2a y 2a+2h y altura h -> area = h*(2a + h).
        """
        a, h = 5.0, 2.0
        sec = self._seccion(a, -h)
        des, ter = sec.areas()
        self.assertAlmostEqual(ter, 0.0, places=6)
        self.assertAlmostEqual(des, h * (2 * a + h), places=3)

    def test_area_de_terraplen_exacta(self):
        a, h = 4.0, 3.0
        sec = self._seccion(a, h)
        des, ter = sec.areas()
        self.assertAlmostEqual(des, 0.0, places=6)
        self.assertAlmostEqual(ter, h * (2 * a + h), places=3)

    def test_seccion_a_cota_no_mide_nada(self):
        sec = self._seccion(5.0, 0.0)
        des, ter = sec.areas()
        self.assertAlmostEqual(des, 0.0, places=6)
        self.assertAlmostEqual(ter, 0.0, places=6)

    def test_media_ladera_mide_las_dos(self):
        asm = load_template("carretera_1x1").materialize()
        tz = plane_terrain(z_ref=100.0, pendiente_pct=30.0, nx=0.0, ny=1.0)
        sec = resolve_section(
            asm,
            Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0),
            tz,
            SectionOptions(paso=0.1, ancho_max=100.0, muestras_terreno=200),
        )
        des, ter = sec.areas()
        self.assertGreater(des, 0.5)
        self.assertGreater(ter, 0.5)

    def test_sin_terreno_guardado_no_mide(self):
        asm = load_template("camino").materialize()
        tz = plane_terrain(z_ref=100.0, pendiente_pct=10.0, nx=0.0, ny=1.0)
        sec = resolve_section(
            asm,
            Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0),
            tz,
            SectionOptions(muestras_terreno=0),
        )
        self.assertEqual(sec.terreno, [])
        self.assertEqual(sec.areas(), (0.0, 0.0))


class TestVolumenes(unittest.TestCase):
    def test_areas_medias(self):
        areas_ = [AreaSeccion(pk=0.0, desmonte=10.0), AreaSeccion(pk=20.0, desmonte=20.0)]
        vols = volumenes_entre(areas_)
        self.assertEqual(len(vols), 1)
        self.assertAlmostEqual(vols[0].desmonte, 15.0 * 20.0)
        self.assertAlmostEqual(vols[0].longitud, 20.0)

    def test_area_constante_da_prisma(self):
        areas_ = [AreaSeccion(pk=p, terraplen=8.0) for p in (0.0, 10.0, 20.0)]
        vols = volumenes_entre(areas_)
        self.assertAlmostEqual(sum(v.terraplen for v in vols), 8.0 * 20.0)

    def test_prismatoide_da_menos_cuando_un_area_es_cero(self):
        """Al pasar de terraplen a nada, las areas medias sobreestiman."""
        areas_ = [AreaSeccion(pk=0.0, terraplen=12.0), AreaSeccion(pk=10.0, terraplen=0.0)]
        medias = volumenes_entre(areas_, METODO_AREAS_MEDIAS)[0].terraplen
        prisma = volumenes_entre(areas_, METODO_PRISMATOIDE)[0].terraplen
        self.assertAlmostEqual(medias, 60.0)
        self.assertLess(prisma, medias)

    def test_prismatoide_igual_que_medias_si_varia_linealmente(self):
        areas_ = [AreaSeccion(pk=0.0, desmonte=10.0), AreaSeccion(pk=10.0, desmonte=20.0)]
        a = volumenes_entre(areas_, METODO_AREAS_MEDIAS)[0].desmonte
        b = volumenes_entre(areas_, METODO_PRISMATOIDE)[0].desmonte
        self.assertAlmostEqual(a, b, places=6)

    def test_pk_repetido_se_ignora(self):
        areas_ = [AreaSeccion(pk=0.0, desmonte=1.0), AreaSeccion(pk=0.0, desmonte=1.0)]
        self.assertEqual(volumenes_entre(areas_), [])

    def test_volumen_neto(self):
        areas_ = [
            AreaSeccion(pk=0.0, desmonte=10.0, terraplen=2.0),
            AreaSeccion(pk=10.0, desmonte=10.0, terraplen=2.0),
        ]
        v = volumenes_entre(areas_)[0]
        self.assertAlmostEqual(v.desmonte, 100.0)
        self.assertAlmostEqual(v.terraplen, 20.0)
        self.assertAlmostEqual(v.neto, -80.0)


class TestDiagramaDeMasas(unittest.TestCase):
    def test_acumulado(self):
        areas_ = [
            AreaSeccion(pk=0.0, terraplen=10.0),
            AreaSeccion(pk=10.0, terraplen=10.0),
            AreaSeccion(pk=20.0, desmonte=10.0, terraplen=0.0),
        ]
        masas = diagrama_masas(volumenes_entre(areas_))
        self.assertAlmostEqual(masas[0][1], 0.0)
        self.assertAlmostEqual(masas[1][1], 100.0)  # 10 m2 x 10 m de terraplen
        # Segundo tramo: terraplen 5x10=50, desmonte 5x10=50 -> neto 0
        self.assertAlmostEqual(masas[2][1], 100.0)

    def test_esponjamiento_reduce_el_desmonte_aprovechable(self):
        areas_ = [
            AreaSeccion(pk=0.0, desmonte=10.0),
            AreaSeccion(pk=10.0, desmonte=10.0),
        ]
        vols = volumenes_entre(areas_)
        sin = diagrama_masas(vols, esponjamiento=1.0)[-1][1]
        con = diagrama_masas(vols, esponjamiento=0.9)[-1][1]
        self.assertAlmostEqual(sin, -100.0)
        self.assertAlmostEqual(con, -90.0)

    def test_arranca_en_el_pk_inicial(self):
        masas = diagrama_masas([], pk_inicial=1000.0)
        self.assertEqual(masas, [(1000.0, 0.0)])


class TestMedir(unittest.TestCase):
    def _secciones(self, n=21, desnivel=-2.0):
        asm = load_template("carretera_1x1")
        asm.eje["desnivel"] = desnivel
        mat = asm.materialize()
        tz = plane_terrain(z_ref=100.0, pendiente_pct=0.0, nx=0.0, ny=1.0)
        opts = SectionOptions(paso=0.2, ancho_max=100.0, muestras_terreno=120)
        return [
            resolve_section(
                mat, Station(s=i * 10.0, x=i * 10.0, y=0.0, nx=0.0, ny=1.0), tz, opts
            )
            for i in range(n)
        ]

    def test_medicion_completa(self):
        m = medir(self._secciones())
        self.assertEqual(len(m.areas), 21)
        self.assertEqual(len(m.volumenes), 20)
        self.assertAlmostEqual(m.longitud, 200.0)
        self.assertGreater(m.total_desmonte, 0.0)
        self.assertAlmostEqual(m.total_terraplen, 0.0, places=3)
        self.assertIn("cut", m.resumen())

    def test_volumen_es_area_por_longitud_en_seccion_constante(self):
        """Terreno horizontal: todas las secciones iguales -> prisma recto."""
        secs = self._secciones()
        m = medir(secs)
        area = m.areas[0].desmonte
        self.assertAlmostEqual(m.total_desmonte, area * 200.0, places=2)

    def test_diagrama_de_masas_monotono_en_desmonte_puro(self):
        m = medir(self._secciones())
        acumulados = [a for _pk, a in m.masas]
        self.assertTrue(all(b <= a + 1e-9 for a, b in zip(acumulados, acumulados[1:])))
        self.assertLess(acumulados[-1], 0.0)

    def test_medicion_vacia(self):
        m = medir([])
        self.assertEqual(m.areas, [])
        self.assertEqual(m.volumenes, [])
        self.assertAlmostEqual(m.longitud, 0.0)
        self.assertAlmostEqual(m.total_neto, 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
