"""Tests del nucleo de calculo. No necesitan QGIS."""

from __future__ import annotations

import math
import os
import sys
import tempfile
import unittest

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from aqgis_sivil3d.core.elements import (  # noqa: E402
    KIND_DAYLIGHT,
    KIND_PUNTO,
    KIND_QUIEBRO,
    KIND_TRUNCADO,
    SUF_DAY,
)
from aqgis_sivil3d.core.geom2d import RingIndex, densify, signed_area  # noqa: E402
from aqgis_sivil3d.core.library import (  # noqa: E402
    AssemblyLibrary,
    default_library,
)
from aqgis_sivil3d.core.merge import (  # noqa: E402
    MergeOptions,
    merge_with_terrain,
)
from aqgis_sivil3d.core.params import (  # noqa: E402
    ParamError,
    format_slope,
    parse_number,
    parse_percent,
    parse_slope,
    parse_slope_opt,
)
from aqgis_sivil3d.core.preview import (  # noqa: E402
    campos_referenciados,
    sanitize_for_preview,
)
from aqgis_sivil3d.core.resolver import (  # noqa: E402
    MODO_DESMONTE,
    MODO_TERRAPLEN,
    SectionOptions,
    Station,
    plane_terrain,
    resolve_section,
)
from aqgis_sivil3d.core.schema import Assembly, branch, el  # noqa: E402
from aqgis_sivil3d.core.templates import load_template, template_names  # noqa: E402
from aqgis_sivil3d.core.tin import (  # noqa: E402
    boundary_ring,
    build_mesh,
    daylight_lines,
    feature_lines,
    lcs_pairs,
)

OPTS = SectionOptions(paso=0.25, ancho_max=150.0)


def st(s: float = 0.0) -> Station:
    """PK en el origen con la normal hacia +Y, de forma que offset == y."""
    return Station(s=s, x=s, y=0.0, nx=0.0, ny=1.0, fid=1)


def llano(z: float = 100.0):
    return plane_terrain(z_ref=z, pendiente_pct=0.0, nx=0.0, ny=1.0)


def ladera(pct: float, z: float = 100.0):
    return plane_terrain(z_ref=z, pendiente_pct=pct, nx=0.0, ny=1.0)


# --------------------------------------------------------------------------


class TestParams(unittest.TestCase):
    def test_numeros_con_coma(self):
        self.assertAlmostEqual(parse_number("4,25"), 4.25)
        self.assertAlmostEqual(parse_number(" -3.5 "), -3.5)

    def test_taludes(self):
        self.assertAlmostEqual(parse_slope("1:1.5"), 1 / 1.5)
        self.assertAlmostEqual(parse_slope("1:1,5"), 1 / 1.5)
        self.assertAlmostEqual(parse_slope("2:3"), 2 / 3)
        self.assertAlmostEqual(parse_slope("50%"), 0.5)
        self.assertAlmostEqual(parse_slope(1.5), 1 / 1.5)  # numero desnudo = H

    def test_taludes_invalidos(self):
        for malo in ("1:0", "0:1", "0%", -2, "hola"):
            with self.assertRaises(ParamError):
                parse_slope(malo)

    def test_un_porcentaje_negativo_se_rechaza(self):
        """Antes se tomaba el valor absoluto en silencio: hacia lo contrario."""
        with self.assertRaises(ParamError) as caso:
            parse_slope("-66%")
        self.assertIn("no puede ser negativo", str(caso.exception))
        # Y dice por donde salir.
        self.assertIn("Offset con pendiente", str(caso.exception))
        self.assertAlmostEqual(parse_slope("66%"), 0.66)

    def test_talud_opcional_admite_cero(self):
        self.assertEqual(parse_slope_opt(0.0), 0.0)
        self.assertEqual(parse_slope_opt(""), 0.0)
        self.assertEqual(parse_slope_opt("auto"), 0.0)
        self.assertAlmostEqual(parse_slope_opt("1:2"), 0.5)

    def test_formato_talud_es_inverso(self):
        for texto in ("1:1", "1:1.5", "1:2", "1:0.75"):
            self.assertEqual(format_slope(parse_slope(texto)), texto)

    def test_pendiente_con_signo(self):
        self.assertAlmostEqual(parse_percent("-2%"), -2.0)
        self.assertAlmostEqual(parse_percent("-2,0"), -2.0)


class TestElementos(unittest.TestCase):
    def test_offset_pendiente_geometria(self):
        asm = Assembly(
            izquierda=branch(
                fijos=[el("offset_pendiente", "B", ancho=4.0, pendiente=-2.0)]
            ),
            derecha=branch(
                fijos=[el("offset_pendiente", "B", ancho=4.0, pendiente=-2.0)]
            ),
        ).materialize()
        sec = resolve_section(asm, st(), llano(), OPTS)
        izq = sec.vertex_by_code("L_B")
        der = sec.vertex_by_code("R_B")
        self.assertAlmostEqual(izq.offset, -4.0)
        self.assertAlmostEqual(der.offset, 4.0)
        # -2% sobre 4 m baja 8 cm, en los dos lados
        self.assertAlmostEqual(izq.z, sec.z_eje - 0.08)
        self.assertAlmostEqual(der.z, sec.z_eje - 0.08)

    def test_vertical_no_avanza(self):
        asm = Assembly(
            derecha=branch(fijos=[el("vertical", "M", desnivel=0.15)])
        ).materialize()
        sec = resolve_section(asm, st(), llano(), OPTS)
        v = sec.vertex_by_code("R_M")
        self.assertAlmostEqual(v.offset, 0.0)
        self.assertAlmostEqual(v.z, sec.z_eje + 0.15)

    def test_cuneta_triangular_y_trapecial(self):
        tri = Assembly(
            derecha=branch(
                fijos=[
                    el(
                        "cuneta",
                        "C",
                        profundidad=0.4,
                        ancho_fondo=0.0,
                        talud_interior="1:1",
                        talud_exterior="1:1",
                    )
                ]
            )
        ).materialize()
        sec = resolve_section(tri, st(), llano(), OPTS)
        codigos = sec.codes()
        self.assertIn("R_C_BOTTOM_START", codigos)
        self.assertNotIn("R_C_BOTTOM_END", codigos)  # triangular: sin fondo plano
        fondo = sec.vertex_by_code("R_C_BOTTOM_START")
        self.assertAlmostEqual(fondo.offset, 0.4)  # 0.4 de profundidad a 1:1
        self.assertAlmostEqual(fondo.z, sec.z_eje - 0.4)
        fin = sec.vertex_by_code("R_C_END")
        self.assertAlmostEqual(fin.z, sec.z_eje)  # vuelve a la cota de entrada

        trap = Assembly(
            derecha=branch(
                fijos=[
                    el(
                        "cuneta",
                        "C",
                        profundidad=0.5,
                        ancho_fondo=0.6,
                        talud_interior="1:1",
                        talud_exterior="1:1",
                    )
                ]
            )
        ).materialize()
        sec2 = resolve_section(trap, st(), llano(), OPTS)
        self.assertIn("R_C_BOTTOM_END", sec2.codes())

    def test_talud_daylight_corta_donde_toca(self):
        # Terreno 2 m por encima del eje, talud 1:1 en desmonte: corta a 2 m.
        asm = Assembly(
            derecha=branch(desmonte=[el("talud_daylight", "T", talud="1:1")])
        ).materialize()
        sec = resolve_section(asm, st(), llano(102.0), OPTS, z_eje=100.0)
        v = sec.vertex_by_code("R_T" + SUF_DAY)
        self.assertEqual(v.kind, KIND_DAYLIGHT)
        self.assertAlmostEqual(v.offset, 2.0, places=3)
        self.assertAlmostEqual(v.z, 102.0, places=3)

    def test_talud_truncado_si_no_alcanza(self):
        asm = Assembly(
            derecha=branch(desmonte=[el("talud_daylight", "T", talud="1:1")])
        ).materialize()
        sec = resolve_section(
            asm, st(), llano(500.0), SectionOptions(paso=0.5, ancho_max=20.0),
            z_eje=100.0,
        )
        v = sec.vertices[-1]
        self.assertEqual(v.kind, KIND_TRUNCADO)
        self.assertFalse(sec.ok)
        self.assertTrue(any("does not cut" in w for w in sec.warnings))

    def test_altura_maxima_limita_el_talud(self):
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T", talud="1:1", altura_max=3.0)
                ]
            )
        ).materialize()
        sec = resolve_section(asm, st(), llano(120.0), OPTS, z_eje=100.0)
        v = sec.vertices[-1]
        self.assertEqual(v.kind, KIND_TRUNCADO)
        self.assertAlmostEqual(v.z - 100.0, 3.0, places=3)


class TestTaludDosPendientes(unittest.TestCase):
    """Talud 1:1 hasta 2 m de desnivel y 1:1.5 a partir de ahi.

    Los dos tramos buscan el terreno: manda el primero que lo alcance, y si el
    primero se queda corto cierra en un quiebro y sigue el segundo.
    """

    def _sec(self, z_terreno: float, opts=None, s=0.0, **kw):
        p1 = dict(talud="1:1", limite_tramo=2.0)
        p1.update(kw)
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T1", **p1),
                    el("talud_daylight", "T2", talud="1:1.5"),
                ]
            )
        ).materialize()
        return resolve_section(
            asm, st(s), llano(z_terreno), opts or OPTS, z_eje=100.0
        )

    def test_corta_en_el_primer_tramo(self):
        # Terreno 1.5 m arriba: el talud 1:1 llega antes de agotar los 2 m.
        sec = self._sec(101.5)
        v = sec.vertices[-1]
        self.assertEqual(v.kind, KIND_DAYLIGHT)
        self.assertAlmostEqual(v.offset, 1.5, places=3)
        self.assertNotIn("R_T1_Q1", sec.codes())  # no hay quiebro
        self.assertTrue(sec.ok)

    def test_traspasa_al_segundo_tramo(self):
        # Terreno 5 m arriba: el 1:1 agota sus 2 m en el offset 2 y el 1:1.5
        # recorre los 3 m que faltan en 4.5 m horizontales.
        sec = self._sec(105.0)
        quiebro = sec.vertex_by_code("R_T1_Q1")
        self.assertEqual(quiebro.kind, KIND_QUIEBRO)
        self.assertAlmostEqual(quiebro.offset, 2.0, places=3)
        self.assertAlmostEqual(quiebro.z, 102.0, places=3)
        v = sec.vertices[-1]
        self.assertEqual(v.kind, KIND_DAYLIGHT)
        self.assertAlmostEqual(v.offset, 6.5, places=3)
        self.assertAlmostEqual(v.z, 105.0, places=3)
        self.assertTrue(sec.ok)

    def test_el_quiebro_no_marca_la_seccion_como_fallida(self):
        """El fin de tramo es un desenlace normal, no un aviso."""
        sec = self._sec(105.0)
        self.assertEqual(sec.warnings, [])

    def test_si_ninguno_alcanza_el_terreno_trunca_y_avisa(self):
        sec = self._sec(500.0, opts=SectionOptions(paso=0.5, ancho_max=20.0))
        self.assertEqual(sec.vertex_by_code("R_T1_Q1").kind, KIND_QUIEBRO)
        self.assertEqual(sec.vertices[-1].kind, KIND_TRUNCADO)
        self.assertFalse(sec.ok)
        self.assertTrue(any("does not cut" in w for w in sec.warnings))

    def test_si_se_agota_el_ancho_maximo_no_traspasa(self):
        """Sin sitio no hay nada que traspasar: el tope que ata es el ancho."""
        sec = self._sec(500.0, opts=SectionOptions(paso=0.25, ancho_max=1.0))
        self.assertEqual(sec.vertices[-1].kind, KIND_TRUNCADO)
        self.assertAlmostEqual(sec.vertices[-1].offset, 1.0, places=3)
        self.assertNotIn("R_T1_Q1", sec.codes())
        self.assertFalse(sec.ok)

    def test_limite_por_cota_frente_a_horizontal(self):
        # Talud 1:2 y limite 2: por cota son 4 m horizontales (2 de desnivel);
        # en horizontal son 2 m horizontales (1 de desnivel).
        cota = self._sec(105.0, talud="1:2", limite_modo="cota")
        horiz = self._sec(105.0, talud="1:2", limite_modo="horizontal")
        self.assertAlmostEqual(cota.vertex_by_code("R_T1_Q1").offset, 4.0, places=3)
        self.assertAlmostEqual(cota.vertex_by_code("R_T1_Q1").z, 102.0, places=3)
        self.assertAlmostEqual(horiz.vertex_by_code("R_T1_Q1").offset, 2.0, places=3)
        self.assertAlmostEqual(horiz.vertex_by_code("R_T1_Q1").z, 101.0, places=3)

    def test_los_quiebros_se_numeran_solos(self):
        """Los taludes de una cadena pueden llamarse todos igual.

        Compartir el codigo es lo deseable: mantiene una sola linea de daylight.
        Para que sus quiebros no se pisen, se numeran.
        """
        asm = Assembly(
            derecha=branch(
                terraplen=[
                    el("talud_daylight", "TALUD", talud="1:1", limite_tramo=2.0),
                    el("talud_daylight", "TALUD", talud="1:1", limite_tramo=2.0),
                    el("talud_daylight", "TALUD", talud="1:2"),
                ]
            )
        ).materialize()
        sec = resolve_section(asm, st(), llano(90.0), OPTS, z_eje=100.0)
        codigos = [v.code for v in sec.vertices]
        self.assertEqual(
            codigos, ["AXIS", "R_TALUD_Q1", "R_TALUD_Q2", "R_TALUD" + SUF_DAY]
        )
        self.assertEqual(len(set(codigos)), len(codigos), "sin codigos repetidos")

    def test_una_cadena_con_el_mismo_codigo_da_lineas_limpias(self):
        """El sintoma que tenia: polilineas que iban y venian en cada PK."""
        asm = Assembly(
            derecha=branch(
                terraplen=[
                    el("talud_daylight", "TALUD", talud="1:1", limite_tramo=2.0),
                    el("talud_daylight", "TALUD", talud="1:2"),
                ]
            )
        ).materialize()
        secs = [
            resolve_section(asm, st(i * 20.0), llano(90.0), OPTS, z_eje=100.0)
            for i in range(3)
        ]
        lineas = dict(feature_lines(secs))
        self.assertEqual(len(lineas["R_TALUD_Q1"]), 3)
        self.assertEqual(len(lineas["R_TALUD" + SUF_DAY]), 3)
        # Cada linea avanza monotonamente en el offset, no va y vuelve.
        for code, pts in lineas.items():
            offsets = [p[1] for p in pts]  # con la normal en +Y, la Y es el offset
            self.assertEqual(
                len(set(round(o, 3) for o in offsets)), 1,
                f"{code}: la linea deberia ir recta, sale {offsets}",
            )

    def test_la_linea_de_daylight_es_una_sola(self):
        """Corte el tramo que corte, el vertice de daylight lleva el mismo codigo.

        Es lo que mantiene continua la linea de coronacion y lo que le da al
        cosido del TIN un ancla estable cuando el numero de tramos cambia de un
        PK al siguiente.
        """
        a = self._sec(105.0, s=0.0)  # corta en el segundo tramo
        b = self._sec(105.0, s=20.0)
        c = self._sec(101.5, s=40.0)  # corta en el primero
        self.assertEqual(a.codes()[-1], "R_T2" + SUF_DAY)
        self.assertEqual(c.codes()[-1], "R_T2" + SUF_DAY)
        lineas = dict(feature_lines([a, b, c]))
        self.assertEqual(len(lineas["R_T2" + SUF_DAY]), 3)
        # Y el quiebro sale como su propia linea caracteristica donde existe.
        self.assertEqual(len(lineas["R_T1_Q1"]), 2)


class TestElementosCiegosEnLaCadena(unittest.TestCase):
    """Lo que va detras de un talud tambien se para en el terreno.

    Los elementos que no buscan terreno son ciegos: dibujan su forma sin mirar el
    suelo. Delante del primer talud eso esta bien -son continuacion de la
    plataforma-, pero dentro de la cadena que va a buscar el terreno no: una
    banqueta entre dos taludes lo atravesaria sin que nadie se enterase.
    """

    def _asm(self, ciego_primero: bool = False):
        talud = el("talud_daylight", "T1", talud="1:1", limite_tramo=6.0)
        banqueta = el("offset_pendiente", "B", ancho=3.0, pendiente=0.0)
        cierre = el("talud_daylight", "T2", talud="1:2")
        orden = [banqueta, talud, cierre] if ciego_primero else [talud, banqueta, cierre]
        return Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=3.0, pendiente=0.0)],
                terraplen=orden,
            )
        ).materialize()

    def _sec(self, asm, tz):
        return resolve_section(
            asm, st(), tz, SectionOptions(paso=0.25, ancho_max=100.0), z_eje=100.0
        )

    def test_la_banqueta_de_la_cadena_corta_en_el_terreno(self):
        """Terraplen contra una ladera que sube al alejarse del eje.

        Plataforma hasta (3, 100); el talud 1:1 baja sus 6 m hasta (9, 94) sin
        alcanzar el terreno, que ahi va por 92; y la banqueta horizontal se lo
        encuentra 2 m mas alla, en el offset 11.
        """
        tz = plane_terrain(z_ref=83.0, pendiente_pct=100.0, nx=0.0, ny=1.0)
        sec = self._sec(self._asm(), tz)
        self.assertAlmostEqual(sec.vertex_by_code("R_T1_Q1").offset, 9.0, places=3)
        v = sec.vertices[-1]
        self.assertEqual(v.kind, KIND_DAYLIGHT)
        self.assertAlmostEqual(v.offset, 11.0, places=2)
        self.assertAlmostEqual(v.z, 94.0, places=2)
        # Y lleva el codigo de daylight del grupo, no el de la banqueta: la linea
        # de pie de terraplen tiene que seguir siendo una sola.
        self.assertEqual(v.code, "R_T2" + SUF_DAY)
        self.assertTrue(sec.ok)
        self.assertEqual(sec.warnings, [])

    def test_si_no_cruza_la_banqueta_queda_intacta(self):
        sec = self._sec(self._asm(), llano(80.0))
        b = sec.vertex_by_code("R_B")
        self.assertIsNotNone(b, "la banqueta tiene que estar completa")
        self.assertAlmostEqual(b.offset, 12.0, places=3)  # 3 + 6 (talud) + 3
        self.assertAlmostEqual(b.z, 94.0, places=3)
        self.assertEqual(b.kind, KIND_PUNTO)

    def test_un_ciego_delante_del_primer_talud_no_busca_terreno(self):
        """Es lo que deja intactas las cunetas de las plantillas.

        La ladera esta puesta para que la banqueta **si** cruzase el terreno (en
        el offset 4.5) si buscase: delante del talud tiene que llegar entera al 6.
        """
        tz = plane_terrain(z_ref=95.5, pendiente_pct=100.0, nx=0.0, ny=1.0)
        sec = self._sec(self._asm(ciego_primero=True), tz)
        self.assertLess(tz(0.0, 3.0), 100.0, "en el enganche tiene que ser terraplen")
        self.assertGreater(tz(0.0, 6.0), 100.0, "y la banqueta cruzaria el terreno")
        b = sec.vertex_by_code("R_B")
        self.assertIsNotNone(b)
        self.assertAlmostEqual(b.offset, 6.0, places=3)  # 3 + 3, sin recortar
        self.assertEqual(b.kind, KIND_PUNTO)

    def test_la_cuneta_delante_del_talud_no_se_recorta(self):
        """Una cuneta cuya salida cruza el terreno: sigue entera."""
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=3.0, pendiente=0.0)],
                desmonte=[
                    el(
                        "cuneta",
                        "C",
                        profundidad=0.5,
                        ancho_fondo=1.0,
                        talud_interior="1:1",
                        talud_exterior="1:1",
                    ),
                    el("talud_daylight", "T", talud="1:1"),
                ],
            )
        ).materialize()
        tz = plane_terrain(z_ref=101.2, pendiente_pct=-25.0, nx=0.0, ny=1.0)
        sec = self._sec(asm, tz)
        codigos = sec.codes()
        for suf in ("_BOTTOM_START", "_BOTTOM_END", "_END"):
            self.assertIn("R_C" + suf, codigos)

    def test_nodata_bajo_la_banqueta_no_la_recorta(self):
        """Sin datos no se decide: cerrar la superficie es cosa del talud.

        El hueco cae dentro de la banqueta (9 -> 12) y fuera del talud de cierre.
        """
        def tz(x, y):
            return None if 9.5 < y < 11.5 else 80.0

        sec = self._sec(self._asm(), tz)
        b = sec.vertex_by_code("R_B")
        self.assertIsNotNone(b)
        self.assertAlmostEqual(b.offset, 12.0, places=3)


class TestBanquetas(unittest.TestCase):
    def _sec(self, z_terreno: float, **kw):
        params = dict(
            talud="1:1",
            altura_banqueta=5.0,
            ancho_banqueta=2.0,
            pendiente_banqueta=0.0,
            max_banquetas=6,
        )
        params.update(kw)
        asm = Assembly(
            derecha=branch(desmonte=[el("talud_banqueta", "T", **params)])
        ).materialize()
        return resolve_section(
            asm, st(), llano(z_terreno), SectionOptions(paso=0.25, ancho_max=200.0),
            z_eje=100.0,
        )

    def test_cuenta_banquetas_segun_altura(self):
        # 12 m de desmonte con banquetas cada 5 m -> 2 banquetas completas
        sec = self._sec(112.0)
        codigos = sec.codes()
        self.assertIn("R_T_B1_START", codigos)
        self.assertIn("R_T_B2_START", codigos)
        self.assertNotIn("R_T_B3_START", codigos)
        self.assertEqual(sec.vertices[-1].kind, KIND_DAYLIGHT)
        self.assertTrue(sec.ok)

    def test_daylight_dentro_del_primer_talud(self):
        # 3 m de desmonte: corta antes de la primera banqueta
        sec = self._sec(103.0)
        self.assertEqual(sec.codes()[-1], "R_T" + SUF_DAY)
        self.assertNotIn("R_T_B1_START", sec.codes())
        self.assertAlmostEqual(sec.vertices[-1].offset, 3.0, places=3)

    def test_sufijo_de_daylight_igual_con_y_sin_banquetas(self):
        """Es lo que permite coser secciones con distinto numero de banquetas."""
        a = self._sec(103.0).codes()[-1]
        b = self._sec(112.0).codes()[-1]
        self.assertEqual(a, b)

    def test_talud_siguientes_se_aplica(self):
        suave = self._sec(112.0, talud_siguientes="1:4")
        duro = self._sec(112.0, talud_siguientes="1:1")
        self.assertGreater(suave.ancho_der, duro.ancho_der)

    def test_max_banquetas_cero_es_sin_limite(self):
        sec = self._sec(112.0, max_banquetas=0)
        self.assertTrue(sec.ok)
        self.assertIn("R_T_B2_START", sec.codes())


class TestEleccionDeRama(unittest.TestCase):
    def _asm(self):
        return Assembly(
            izquierda=branch(
                fijos=[el("offset_pendiente", "P", ancho=3.0, pendiente=0.0)],
                desmonte=[el("talud_daylight", "T", talud="1:1")],
                terraplen=[el("talud_daylight", "T", talud="1:2")],
            ),
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=3.0, pendiente=0.0)],
                desmonte=[el("talud_daylight", "T", talud="1:1")],
                terraplen=[el("talud_daylight", "T", talud="1:2")],
            ),
        ).materialize()

    def test_todo_desmonte(self):
        sec = resolve_section(self._asm(), st(), llano(110.0), OPTS, z_eje=100.0)
        self.assertEqual(sec.modo_izq, MODO_DESMONTE)
        self.assertEqual(sec.modo_der, MODO_DESMONTE)

    def test_todo_terraplen(self):
        sec = resolve_section(self._asm(), st(), llano(90.0), OPTS, z_eje=100.0)
        self.assertEqual(sec.modo_izq, MODO_TERRAPLEN)
        self.assertEqual(sec.modo_der, MODO_TERRAPLEN)

    def test_media_ladera_cada_lado_por_su_cuenta(self):
        # Ladera al 30%: a la izquierda (offset<0) el terreno baja, a la derecha
        # sube. El terraplen es 1:2 (50%), mas fuerte que la ladera, asi que
        # converge y engancha.
        sec = resolve_section(self._asm(), st(), ladera(30.0, 100.0), OPTS, z_eje=100.0)
        self.assertEqual(sec.modo_izq, MODO_TERRAPLEN)
        self.assertEqual(sec.modo_der, MODO_DESMONTE)
        self.assertTrue(sec.ok, sec.warnings)
        self.assertEqual(sec.vertices[0].kind, KIND_DAYLIGHT)
        self.assertEqual(sec.vertices[-1].kind, KIND_DAYLIGHT)

    def test_talud_paralelo_al_terreno_no_engancha(self):
        """Un terraplen 1:2 sobre una ladera al 50% es paralelo: nunca corta.

        Es un caso real de proyecto y tiene que salir como truncado y con aviso,
        no como una seccion valida.
        """
        sec = resolve_section(self._asm(), st(), ladera(50.0, 100.0), OPTS, z_eje=100.0)
        self.assertEqual(sec.modo_izq, MODO_TERRAPLEN)
        self.assertFalse(sec.ok)
        self.assertEqual(sec.vertices[0].kind, KIND_TRUNCADO)
        self.assertTrue(any("does not cut" in w for w in sec.warnings))
        # El lado en desmonte no tiene ese problema y engancha bien.
        self.assertEqual(sec.vertices[-1].kind, KIND_DAYLIGHT)

    def test_nodata_en_el_eje_devuelve_seccion_vacia(self):
        sec = resolve_section(self._asm(), st(), lambda x, y: None, OPTS)
        self.assertFalse(sec.ok)
        self.assertEqual(sec.vertices, [])

    def test_desplazamiento_mueve_el_origen(self):
        asm = self._asm()
        asm.eje["desplazamiento"] = 5.0
        sec = resolve_section(asm, st(), llano(110.0), OPTS, z_eje=100.0)
        self.assertAlmostEqual(sec.station.y, 5.0)

    def test_desnivel_del_eje(self):
        asm = self._asm()
        asm.eje["desnivel"] = -1.5
        sec = resolve_section(asm, st(), llano(100.0), OPTS)
        self.assertAlmostEqual(sec.z_eje, 98.5)


class TestSchema(unittest.TestCase):
    def test_roundtrip_json_de_todas_las_plantillas(self):
        for nombre in template_names():
            asm = load_template(nombre)
            self.assertEqual(Assembly.from_json(asm.to_json()).to_json(), asm.to_json())

    def test_plantillas_validas(self):
        for nombre in template_names():
            self.assertEqual(load_template(nombre).validate(), [], nombre)

    def test_codigo_repetido_en_fijos_se_detecta(self):
        asm = Assembly(
            izquierda=branch(
                fijos=[
                    el("offset_pendiente", "X", ancho=1.0),
                    el("offset_pendiente", "X", ancho=1.0),
                ],
                desmonte=[el("talud_daylight", "T")],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        problemas = " ".join(asm.validate())
        self.assertIn("repetidos", problemas)

    def test_mismo_codigo_en_desmonte_y_terraplen_es_valido(self):
        asm = Assembly(
            izquierda=branch(
                fijos=[el("offset_pendiente", "P", ancho=1.0)],
                desmonte=[el("talud_daylight", "T")],
                terraplen=[el("talud_daylight", "T")],
            ),
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=1.0)],
                desmonte=[el("talud_daylight", "T")],
                terraplen=[el("talud_daylight", "T")],
            ),
        )
        self.assertEqual(asm.validate(), [])

    def test_grupo_condicional_vacio_avisa(self):
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=1.0)],
                desmonte=[el("talud_daylight", "T")],
                terraplen=[],
            )
        )
        self.assertTrue(any("grupo vacio" in x for x in asm.validate()))

    def test_elemento_que_busca_terreno_no_ultimo_avisa(self):
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T"),
                    el("offset_pendiente", "X", ancho=1.0),
                ],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        self.assertTrue(any("no es el ultimo" in x for x in asm.validate()))

    def test_taludes_encadenados_pueden_repetir_codigo(self):
        """Es lo deseable: mantiene una sola linea de daylight."""
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho=1.0)],
                desmonte=[
                    el("talud_daylight", "TALUD", talud="1:1", limite_tramo=2.0),
                    el("talud_daylight", "TALUD", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "TALUD")],
            )
        )
        self.assertFalse(any("repetidos" in x for x in asm.validate()))

    def test_un_ciego_que_choca_con_fijos_sigue_avisando(self):
        """Ahi el codigo repetido si es ambiguo: son dos vertices distintos."""
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "BORDE", ancho=1.0)],
                desmonte=[
                    el("talud_daylight", "TALUD", talud="1:1", limite_tramo=2.0),
                    el("offset_pendiente", "BORDE", ancho=3.0),
                    el("talud_daylight", "TALUD", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "TALUD")],
            )
        )
        self.assertTrue(any("repetidos" in x for x in asm.validate()))

    def test_talud_intermedio_con_limite_de_tramo_es_valido(self):
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T1", talud="1:1", limite_tramo=2.0),
                    el("talud_daylight", "T2", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        self.assertFalse(any("se ignorara" in x for x in asm.validate()))

    def test_talud_intermedio_sin_limite_de_tramo_avisa(self):
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T1", talud="1:1"),
                    el("talud_daylight", "T2", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        self.assertTrue(
            any("no tiene limite de tramo" in x for x in asm.validate())
        )

    def test_altura_maxima_por_debajo_del_limite_avisa(self):
        """El traspaso seria inalcanzable: el talud de detras nunca actuaria."""
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el(
                        "talud_daylight",
                        "T1",
                        talud="1:1",
                        altura_max=1.0,
                        limite_tramo=2.0,
                    ),
                    el("talud_daylight", "T2", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        self.assertTrue(
            any("por debajo de su limite" in x for x in asm.validate())
        )

    def test_banquetas_intermedias_avisan(self):
        """Las banquetas no tienen tope de altura: siempre cierran la cadena."""
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_banqueta", "B"),
                    el("talud_daylight", "T", talud="1:1.5"),
                ],
                terraplen=[el("talud_daylight", "T2")],
            )
        )
        self.assertTrue(
            any("no admite limite de tramo" in x for x in asm.validate())
        )

    def test_ultimo_elemento_que_no_busca_terreno_avisa(self):
        asm = Assembly(
            derecha=branch(
                desmonte=[
                    el("talud_daylight", "T1", talud="1:1", limite_tramo=2.0),
                    el("offset_pendiente", "X", ancho=1.0),
                ],
                terraplen=[el("talud_daylight", "T")],
            )
        )
        self.assertTrue(
            any("quedara abierta" in x for x in asm.validate())
        )

    def test_elemento_en_grupo_no_permitido_avisa(self):
        asm = Assembly(
            derecha=branch(fijos=[el("talud_daylight", "T")])
        )
        self.assertTrue(any("no se puede usar" in x for x in asm.validate()))

    def test_parametro_desconocido_avisa(self):
        e = el("vertical", "M", desnivel=0.1)
        e.params["ancho_inventado"] = 3.0
        asm = Assembly(derecha=branch(fijos=[e]))
        self.assertTrue(any("desconocido" in x for x in asm.validate()))

    def test_materialize_no_toca_el_original(self):
        asm = load_template("carretera_1x1")
        antes = asm.to_json()
        asm.materialize()
        self.assertEqual(asm.to_json(), antes)

    def test_materialize_con_evaluador(self):
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho="@w", pendiente=-2.0)]
            )
        )
        valores = {"w": 6.0}
        mat = asm.materialize(
            lambda v: valores[v[1:]] if isinstance(v, str) and v.startswith("@") else v
        )
        self.assertAlmostEqual(mat.derecha.fijos[0].params["ancho"], 6.0)

    def test_materialize_error_indica_donde(self):
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho="no es numero")]
            )
        )
        with self.assertRaises(ParamError) as ctx:
            asm.materialize()
        self.assertIn("der/fijos/P", str(ctx.exception))


class TestLibreria(unittest.TestCase):
    def test_roundtrip_y_orden(self):
        lib = default_library()
        nombres = lib.names()
        otra = AssemblyLibrary.from_json(lib.to_json())
        self.assertEqual(otra.names(), nombres)

    def test_guardar_y_cargar(self):
        lib = default_library()
        with tempfile.TemporaryDirectory() as d:
            ruta = os.path.join(d, "l.json")
            lib.save(ruta)
            self.assertEqual(AssemblyLibrary.load(ruta).names(), lib.names())

    def test_nombres_duplicados_reciben_sufijo(self):
        lib = AssemblyLibrary()
        lib.add(Assembly(nombre="A"))
        lib.add(Assembly(nombre="A"))
        self.assertEqual(lib.names(), ["A", "A (2)"])

    def test_renombrar_conserva_el_orden(self):
        lib = default_library()
        segundo = lib.names()[1]
        lib.rename(segundo, "ZZZ")
        self.assertEqual(lib.names()[1], "ZZZ")
        self.assertEqual(lib["ZZZ"].nombre, "ZZZ")

    def test_renombrar_a_uno_existente_falla(self):
        lib = default_library()
        a, b = lib.names()[0], lib.names()[1]
        with self.assertRaises(ParamError):
            lib.rename(a, b)

    def test_mover(self):
        lib = default_library()
        primero = lib.names()[0]
        lib.move(primero, 2)
        self.assertEqual(lib.names().index(primero), 2)

    def test_archivo_con_una_sola_seccion(self):
        asm = load_template("camino")
        lib = AssemblyLibrary.from_json(asm.to_json())
        self.assertEqual(lib.names(), [asm.nombre])

    def test_json_invalido(self):
        with self.assertRaises(ParamError):
            AssemblyLibrary.from_json("{no es json")


class TestMallado(unittest.TestCase):
    def _secciones(self, plantilla="carretera_1x1", n=21, pct=25.0):
        asm = load_template(plantilla).materialize()
        tz = plane_terrain(z_ref=100.0, pendiente_pct=pct, nx=0.0, ny=1.0)
        return [
            resolve_section(asm, Station(s=i * 5.0, x=i * 5.0, y=0.0, nx=0.0, ny=1.0), tz, OPTS)
            for i in range(n)
        ]

    def test_lcs(self):
        self.assertEqual(lcs_pairs(list("abc"), list("abc")), [(0, 0), (1, 1), (2, 2)])
        self.assertEqual(lcs_pairs(list("abc"), list("axc")), [(0, 0), (2, 2)])
        self.assertEqual(lcs_pairs([], list("abc")), [])

    def test_malla_no_vacia_y_sin_degenerados(self):
        mesh = build_mesh(self._secciones())
        self.assertGreater(len(mesh.tris), 0)
        for i, j, k in mesh.tris:
            self.assertEqual(len({i, j, k}), 3)
            a, b, c = mesh.nodes[i], mesh.nodes[j], mesh.nodes[k]
            area2 = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            self.assertGreater(area2, 0.0)  # todos antihorarios

    def test_triangulos_cubren_la_banda_sin_solape(self):
        secs = self._secciones(n=11)
        mesh = build_mesh(secs)
        area_tri = sum(
            abs(
                0.5
                * (
                    (mesh.nodes[j][0] - mesh.nodes[i][0])
                    * (mesh.nodes[k][1] - mesh.nodes[i][1])
                    - (mesh.nodes[j][1] - mesh.nodes[i][1])
                    * (mesh.nodes[k][0] - mesh.nodes[i][0])
                )
            )
            for i, j, k in mesh.tris
        )
        # Area de la huella medida por el anillo: si hubiera solapes o huecos,
        # la suma de triangulos no coincidiria.
        anillo = boundary_ring(secs)
        self.assertAlmostEqual(area_tri, abs(signed_area(anillo)), delta=0.02 * area_tri)

    def test_cose_secciones_con_distinto_numero_de_vertices(self):
        """Una seccion con 2 banquetas y otra con 3 se cosen igual."""
        asm = load_template("desmonte_banqueado").materialize()

        def tz(x, y):
            # Lo que tiene que variar es la pendiente *transversal*: si solo
            # subiera con x, la cota del eje subiria igual y la seccion saldria
            # identica en todos los PK.
            return 100.0 + (0.25 + 0.010 * x) * y

        secs = [
            resolve_section(
                asm, Station(s=i * 5.0, x=i * 5.0, y=0.0, nx=0.0, ny=1.0), tz, OPTS
            )
            for i in range(25)
        ]
        cuentas = {len(s.vertices) for s in secs}
        self.assertGreater(len(cuentas), 1, "el test necesita secciones distintas")
        mesh = build_mesh(secs)
        self.assertGreater(len(mesh.tris), 0)
        for i, j, k in mesh.tris:
            self.assertEqual(len({i, j, k}), 3)

    def test_lineas_caracteristicas_por_codigo(self):
        secs = self._secciones()
        lineas = dict(feature_lines(secs))
        self.assertIn("AXIS", lineas)
        self.assertEqual(len(lineas["AXIS"]), len(secs))
        for codigo, pts in lineas.items():
            self.assertGreater(len(pts), 1, codigo)

    def test_daylight_izquierda_y_derecha(self):
        secs = self._secciones()
        nombres = [c for c, _ in daylight_lines(secs)]
        self.assertIn("DAYLIGHT_IZQ", nombres)
        self.assertIn("DAYLIGHT_DER", nombres)

    def test_anillo_cerrado_y_sin_repetidos(self):
        anillo = boundary_ring(self._secciones())
        self.assertGreater(len(anillo), 6)
        self.assertNotEqual(anillo[0][:2], anillo[-1][:2])
        for a, b in zip(anillo, anillo[1:]):
            self.assertGreater(math.dist(a[:2], b[:2]), 1e-9)

    def test_menos_de_dos_secciones_no_malla(self):
        self.assertTrue(build_mesh([]).is_empty)
        self.assertTrue(build_mesh(self._secciones(n=1)).is_empty)


class TestGeom2D(unittest.TestCase):
    def test_punto_en_anillo_convexo(self):
        cuadrado = [(0, 0), (10, 0), (10, 10), (0, 10)]
        ix = RingIndex(cuadrado)
        self.assertTrue(ix.contains(5, 5))
        self.assertFalse(ix.contains(-1, 5))
        self.assertFalse(ix.contains(15, 5))
        self.assertFalse(ix.contains(5, 20))

    def test_punto_en_anillo_concavo(self):
        # Forma de U
        u = [(0, 0), (10, 0), (10, 10), (7, 10), (7, 3), (3, 3), (3, 10), (0, 10)]
        ix = RingIndex(u)
        self.assertTrue(ix.contains(5, 1.5))
        self.assertFalse(ix.contains(5, 7))  # el hueco de la U
        self.assertTrue(ix.contains(8.5, 7))

    def test_densificar_respeta_longitud_e_interpola_z(self):
        pts = densify([(0, 0, 10.0), (10, 0, 20.0)], 2.0)
        self.assertEqual(len(pts), 6)
        for a, b in zip(pts, pts[1:]):
            self.assertLessEqual(math.dist(a[:2], b[:2]), 2.0 + 1e-9)
        self.assertAlmostEqual(pts[-1][2], 20.0)
        self.assertAlmostEqual(pts[1][2], 12.0)

    def test_densificar_cerrado_no_repite_el_primero(self):
        pts = densify([(0, 0), (4, 0), (4, 4), (0, 4)], 2.0, closed=True)
        self.assertNotEqual(pts[0], pts[-1])

    def test_area_con_signo(self):
        self.assertAlmostEqual(signed_area([(0, 0), (4, 0), (4, 4), (0, 4)]), 16.0)
        self.assertAlmostEqual(signed_area([(0, 0), (0, 4), (4, 4), (4, 0)]), -16.0)


class TestFusion(unittest.TestCase):
    def _corredor(self):
        asm = load_template("carretera_1x1").materialize()
        tz = plane_terrain(z_ref=100.0, pendiente_pct=25.0, nx=0.0, ny=1.0)
        secs = [
            resolve_section(
                asm, Station(s=i * 5.0, x=i * 5.0, y=0.0, nx=0.0, ny=1.0), tz, OPTS
            )
            for i in range(21)
        ]
        return build_mesh(secs), boundary_ring(secs), tz

    def test_fusion_cubre_el_rectangulo_sin_huecos(self):
        mesh, anillo, tz = self._corredor()
        fus, avisos = merge_with_terrain(
            mesh, [anillo], tz, opts=MergeOptions(celda=4.0, holgura=30.0)
        )
        self.assertGreater(len(fus.tris), len(mesh.tris))
        area = 0.0
        for i, j, k in fus.tris:
            a, b, c = fus.nodes[i], fus.nodes[j], fus.nodes[k]
            area += abs(
                0.5
                * ((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))
            )
        xs = [n[0] for n in fus.nodes]
        ys = [n[1] for n in fus.nodes]
        bbox = (max(xs) - min(xs)) * (max(ys) - min(ys))
        # Sin huecos ni solapes, la suma de areas es el rectangulo entero.
        self.assertAlmostEqual(area / bbox, 1.0, delta=0.02)

    def test_el_corredor_sigue_intacto_tras_fusionar(self):
        mesh, anillo, tz = self._corredor()
        fus, _ = merge_with_terrain(
            mesh, [anillo], tz, opts=MergeOptions(celda=4.0, holgura=20.0)
        )
        # Todos los nodos del corredor tienen que seguir estando.
        nodos = {(round(n[0], 4), round(n[1], 4), round(n[2], 4)) for n in fus.nodes}
        for n in mesh.nodes:
            self.assertIn((round(n[0], 4), round(n[1], 4), round(n[2], 4)), nodos)

    def test_nodata_no_rompe_la_fusion(self):
        mesh, anillo, tz = self._corredor()

        def con_hueco(x, y):
            if x > 60.0 and y > 20.0:
                return None
            return tz(x, y)

        fus, avisos = merge_with_terrain(
            mesh, [anillo], con_hueco, opts=MergeOptions(celda=4.0, holgura=30.0)
        )
        self.assertGreater(len(fus.tris), len(mesh.tris))
        self.assertTrue(any("NoData" in a for a in avisos))

    def test_sin_anillos_no_revienta(self):
        mesh, _anillo, tz = self._corredor()
        fus, avisos = merge_with_terrain(mesh, [], tz, opts=MergeOptions(celda=5.0))
        self.assertTrue(any("huella" in a or "nada" in a for a in avisos))


class TestPreview(unittest.TestCase):
    def test_campos_referenciados(self):
        asm = load_template("plataforma_por_campos")
        self.assertEqual(
            campos_referenciados(asm),
            ["camber", "cut_slope", "fill_slope", "width"],
        )

    def test_sanitize_usa_defaults_y_valores_dados(self):
        asm = load_template("plataforma_por_campos")
        limpia = sanitize_for_preview(asm, {"width": 9.0})
        mat = limpia.materialize()  # no debe lanzar
        self.assertAlmostEqual(mat.derecha.fijos[0].params["ancho"], 9.0)
        # bombeo no se ha dado: cae al default del ParamSpec
        self.assertAlmostEqual(mat.derecha.fijos[0].params["pendiente"], -2.0)

    def test_sanitize_no_modifica_el_original(self):
        asm = load_template("plataforma_por_campos")
        antes = asm.to_json()
        sanitize_for_preview(asm, {"width": 3.0})
        self.assertEqual(asm.to_json(), antes)

    def test_expresion_cae_al_default(self):
        asm = Assembly(
            derecha=branch(
                fijos=[el("offset_pendiente", "P", ancho="=1+2", pendiente=-2.0)]
            )
        )
        mat = sanitize_for_preview(asm).materialize()
        self.assertAlmostEqual(mat.derecha.fijos[0].params["ancho"], 3.5)


class TestSeccionesDePresa(unittest.TestCase):
    """Las secciones de obra hidraulica del pack.

    Un cuerpo de presa se levanta desde el terreno hasta la coronacion, asi que
    va entero en el grupo de **terraplen**: el talud baja desde el borde de
    coronacion hasta encontrar el terreno del valle.
    """

    #: Claves de plantilla, que no dependen del idioma. El nombre visible si:
    #: cada idioma tiene su catalogo, y los dos tienen que aguantar estas
    #: comprobaciones.
    CLAVES = (
        "presa_gravedad",
        "presa_escollera",
        "presa_materiales_sueltos",
        "pantalla_hormigon",
    )

    IDIOMAS = ("en", "es")

    @staticmethod
    def _nombre(clave, lang):
        from aqgis_sivil3d.core.templates import load_template

        return load_template(clave, lang).nombre

    def _seccion(self, clave, altura=30.0, pendiente=6.0, lang="en"):
        from aqgis_sivil3d.core.library import default_library

        asm = default_library(lang)[self._nombre(clave, lang)].materialize()
        tz = plane_terrain(
            z_ref=100.0 - altura, pendiente_pct=pendiente, nx=0.0, ny=1.0
        )
        st = Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0)
        opts = SectionOptions(paso=0.25, ancho_max=900.0, muestras_terreno=500)
        return resolve_section(asm, st, tz, opts, z_eje=100.0)

    @staticmethod
    def _talud(vertices):
        """``H:1V`` del paramento, medido entre el borde y el pie."""
        if len(vertices) < 2:
            return None
        pie = min(vertices, key=lambda v: v.z)
        alto = max(vertices, key=lambda v: v.z)
        dz = alto.z - pie.z
        if dz < 0.01:
            return None
        return abs(pie.offset - alto.offset) / dz

    def test_estan_en_el_pack_por_defecto(self):
        """En los dos catalogos, cada uno con su nombre."""
        from aqgis_sivil3d.core.library import default_library

        for lang in self.IDIOMAS:
            nombres = default_library(lang).names()
            for clave in self.CLAVES:
                self.assertIn(self._nombre(clave, lang), nombres, lang)

    def test_todas_validan(self):
        from aqgis_sivil3d.core.library import default_library

        for lang in self.IDIOMAS:
            lib = default_library(lang)
            for clave in self.CLAVES:
                nombre = self._nombre(clave, lang)
                self.assertEqual(lib[nombre].validate(), [], nombre)

    def test_el_cuerpo_es_terraplen(self):
        """Una presa se rellena: no puede salir excavacion bajo la coronacion."""
        for lang in self.IDIOMAS:
            for clave in self.CLAVES:
                sec = self._seccion(clave, lang=lang)
                desmonte, terraplen = sec.areas()
                self.assertGreater(terraplen, 0.0, clave)
                self.assertAlmostEqual(desmonte, 0.0, places=6, msg=clave)

    def test_el_perfil_de_gravedad_es_el_clasico(self):
        """Paramento de aguas arriba casi vertical y el de abajo tendido."""
        sec = self._seccion("presa_gravedad")
        arriba = self._talud([v for v in sec.vertices if v.offset < 0])
        abajo = self._talud([v for v in sec.vertices if v.offset > 0])
        self.assertAlmostEqual(arriba, 0.15, delta=0.02)
        self.assertAlmostEqual(abajo, 0.75, delta=0.02)
        self.assertLess(arriba, abajo, "el de aguas arriba es el mas vertical")

    def test_los_taludes_de_materiales_sueltos_son_tendidos(self):
        sec = self._seccion("presa_materiales_sueltos", altura=10.0)
        for lado in (-1, 1):
            talud = self._talud([v for v in sec.vertices if v.offset * lado > 0])
            self.assertAlmostEqual(talud, 2.5, delta=0.1)

    @staticmethod
    def _bermas(sec, lang="en"):
        """Vertices de berma: se llaman ``SLOPE_B1_START``, ``SLOPE_B1_END``...

        Con filtrar por ``_B`` no basta: ``L_EDGE`` tambien lo lleva.
        """
        from aqgis_sivil3d.i18n import en_idioma

        marca = en_idioma("SLOPE", lang) + "_B"
        return [v for v in sec.vertices if marca in v.code]

    def test_las_bermas_salen_cuando_la_presa_es_alta(self):
        """Con 15 m de altura de banqueta, una presa baja no lleva ninguna."""
        for clave in ("presa_escollera", "presa_materiales_sueltos"):
            sin = self._bermas(self._seccion(clave, altura=10.0))
            con = self._bermas(self._seccion(clave, altura=60.0))
            self.assertEqual(sin, [], f"{clave}: 10 m no llega a la primera berma")
            self.assertGreaterEqual(len(con), 4, f"{clave}: 60 m tiene que llevar")

    def test_a_mas_altura_mas_ancho(self):
        for clave in self.CLAVES:
            anchos = [
                self._seccion(clave, altura=h).ancho_izq
                + self._seccion(clave, altura=h).ancho_der
                for h in (10.0, 30.0, 60.0)
            ]
            self.assertLess(anchos[0], anchos[1], clave)
            self.assertLess(anchos[1], anchos[2], clave)

    def test_la_coronacion_es_horizontal_con_cota_impuesta(self):
        """Es como se calcula una presa: el eje a la cota de coronacion."""
        for altura in (10.0, 40.0):
            sec = self._seccion("presa_gravedad", altura=altura)
            self.assertAlmostEqual(sec.z_eje, 100.0, places=6)
            bordes = [v for v in sec.vertices if v.code.endswith("EDGE")]
            self.assertEqual(len(bordes), 2)
            for v in bordes:
                # Bombeo del 1-2 % sobre 5 o 6 m: unos centimetros.
                self.assertLess(abs(v.z - 100.0), 0.5)

    def test_el_pack_reproduce_el_paquete_de_referencia(self):
        """El pack tiene que dar lo mismo que ``docs/secciones_pack.json``.

        Ese archivo es el paquete del que salieron estas plantillas: si alguien
        toca una y no la otra, esto lo caza. Esta en castellano, asi que se
        compara con el catalogo castellano, codigos de punto incluidos: de paso
        comprueba que la traduccion de los codigos es exacta.
        """
        import os

        from aqgis_sivil3d.core.library import AssemblyLibrary, default_library

        ruta = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "docs",
            "secciones_pack.json",
        )
        if not os.path.exists(ruta):
            self.skipTest("no esta el paquete de referencia")
        referencia = AssemblyLibrary.load(ruta)
        pack = default_library("es")
        for clave in self.CLAVES:
            nombre = self._nombre(clave, "es")
            for altura in (8.0, 25.0, 60.0):
                tz = plane_terrain(
                    z_ref=100.0 - altura, pendiente_pct=6.0, nx=0.0, ny=1.0
                )
                st = Station(s=0.0, x=0.0, y=0.0, nx=0.0, ny=1.0)
                opts = SectionOptions(
                    paso=0.25, ancho_max=900.0, muestras_terreno=500
                )
                a = resolve_section(
                    referencia[nombre].materialize(), st, tz, opts, z_eje=100.0
                )
                b = resolve_section(
                    pack[nombre].materialize(), st, tz, opts, z_eje=100.0
                )
                self.assertEqual(
                    [(round(v.offset, 6), round(v.z, 6), v.code) for v in a.vertices],
                    [(round(v.offset, 6), round(v.z, 6), v.code) for v in b.vertices],
                    f"{nombre} a {altura} m",
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)
