"""Tests de la capa QGIS. Hay que lanzarlos con el python de QGIS.

En Windows, con QGIS instalado en la ruta por defecto::

    call "C:\\Program Files\\QGIS 3.40.6\\bin\\o4w_env.bat"
    set PYTHONPATH=%OSGEO4W_ROOT%\\apps\\qgis-ltr\\python;%PYTHONPATH%
    set QGIS_PREFIX_PATH=%OSGEO4W_ROOT%\\apps\\qgis-ltr
    set QT_QPA_PLATFORM=offscreen
    python -m unittest aqgis_sivil3d.tests.test_gis
"""

from __future__ import annotations

import math
import os
import sys
import tempfile
import unittest

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from qgis.core import (  # noqa: E402
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QMetaType  # noqa: E402

from aqgis_sivil3d.core.merge import MergeOptions  # noqa: E402
from aqgis_sivil3d.core.params import ParamError  # noqa: E402
from aqgis_sivil3d.core.resolver import SectionOptions  # noqa: E402
from aqgis_sivil3d.core.schema import Assembly, branch, el  # noqa: E402
from aqgis_sivil3d.core.templates import load_template  # noqa: E402
from aqgis_sivil3d.gis.alignment import (  # noqa: E402
    StationOptions,
    alignments_from_feature,
    parts_of,
    stations_along,
)
from aqgis_sivil3d.gis.build import (  # noqa: E402
    COTA_DIRECTRIZ,
    BuildOptions,
    build_corridor,
)
from aqgis_sivil3d.gis.expressions import (  # noqa: E402
    FeatureEvaluator,
    campos_usados,
)
from aqgis_sivil3d.gis.outputs import (  # noqa: E402
    features_huella,
    fields_eje,
    layers_from_result,
    features_lineas,
    features_puntos,
    features_secciones,
    features_triangulos,
)
from aqgis_sivil3d.gis.terrain import TerrainError, make_terrain  # noqa: E402

CRS = "EPSG:25830"
X0, Y0 = 500000.0, 4400000.0
_APP = None
_TMP = None


def setUpModule():
    global _APP, _TMP
    QgsApplication.setPrefixPath(os.environ.get("QGIS_PREFIX_PATH", ""), True)
    # Con GUI (segundo argumento True): hace falta para construir los dialogos
    # de TestInterfaz. Con QT_QPA_PLATFORM=offscreen no abre ninguna ventana.
    _APP = QgsApplication([], True)
    _APP.initQgis()
    _TMP = tempfile.mkdtemp(prefix="corridor_tests_")


def tearDownModule():
    if _APP is not None:
        _APP.exitQgis()


# --------------------------------------------------------------------------


def escribir_dem(
    nombre: str,
    nx: int = 300,
    ny: int = 300,
    px: float = 2.0,
    pendiente: float = 0.20,
    nodata_esquina: bool = False,
) -> str:
    """DEM sintetico plano inclinado en Y: ``z = 200 + pendiente * (y - Y0)``."""
    import numpy as np
    from osgeo import gdal, osr

    ruta = os.path.join(_TMP, nombre)
    ds = gdal.GetDriverByName("GTiff").Create(ruta, nx, ny, 1, gdal.GDT_Float32)
    ds.SetGeoTransform((X0, px, 0.0, Y0 + ny * px, 0.0, -px))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(25830)
    ds.SetProjection(srs.ExportToWkt())
    ys = (Y0 + ny * px) - (np.arange(ny) + 0.5) * px
    Z = np.tile((200.0 + pendiente * (ys - Y0))[:, None], (1, nx))
    banda = ds.GetRasterBand(1)
    banda.SetNoDataValue(-9999.0)
    if nodata_esquina:
        Z[:10, :10] = -9999.0
    banda.WriteArray(Z.astype("float32"))
    ds = None
    return ruta


def escribir_vaso(
    nombre: str,
    nx: int = 300,
    ny: int = 300,
    px: float = 2.0,
    z_fondo: float = 100.0,
    pendiente: float = 0.20,
) -> str:
    """Vaso conico: ``z = z_fondo + pendiente * r`` desde el centro del raster.

    Sirve para comprobar la curva de embalse contra la formula del cono, que es
    la unica manera de saber si el cubicaje esta bien y no solo si es coherente
    consigo mismo.
    """
    import numpy as np
    from osgeo import gdal, osr

    ruta = os.path.join(_TMP, nombre)
    ds = gdal.GetDriverByName("GTiff").Create(ruta, nx, ny, 1, gdal.GDT_Float32)
    ds.SetGeoTransform((X0, px, 0.0, Y0 + ny * px, 0.0, -px))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(25830)
    ds.SetProjection(srs.ExportToWkt())
    xs = X0 + (np.arange(nx) + 0.5) * px
    ys = (Y0 + ny * px) - (np.arange(ny) + 0.5) * px
    XX, YY = np.meshgrid(xs, ys)
    cx, cy = X0 + nx * px / 2.0, Y0 + ny * px / 2.0
    Z = z_fondo + pendiente * np.hypot(XX - cx, YY - cy)
    banda = ds.GetRasterBand(1)
    banda.SetNoDataValue(-9999.0)
    banda.WriteArray(Z.astype("float32"))
    ds = None
    return ruta


def capa_poligono(centro, radio: float, lados: int = 48) -> QgsVectorLayer:
    """Poligono regular, para recortar el vaso."""
    capa = QgsVectorLayer(f"Polygon?crs={CRS}", "area", "memory")
    anillo = [
        QgsPointXY(
            centro[0] + radio * math.cos(2 * math.pi * i / lados),
            centro[1] + radio * math.sin(2 * math.pi * i / lados),
        )
        for i in range(lados + 1)
    ]
    f = QgsFeature()
    f.setGeometry(QgsGeometry.fromPolygonXY([anillo]))
    capa.dataProvider().addFeatures([f])
    capa.updateExtents()
    return capa


def capa_lineas(features: list, campos: list = ()) -> QgsVectorLayer:
    capa = QgsVectorLayer(f"LineString?crs={CRS}", "dir", "memory")
    dp = capa.dataProvider()
    if campos:
        dp.addAttributes(list(campos))
        capa.updateFields()
    dp.addFeatures(features)
    capa.updateExtents()
    return capa


def feature_linea(capa: QgsVectorLayer, pts: list, attrs: list = ()) -> QgsFeature:
    f = QgsFeature(capa.fields())
    f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(*p) for p in pts]))
    if attrs:
        f.setAttributes(list(attrs))
    return f


# --------------------------------------------------------------------------


class TestTerreno(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ruta = escribir_dem("dem_terreno.tif", nodata_esquina=True)
        cls.capa = QgsRasterLayer(cls.ruta, "dem")
        if not cls.capa.isValid():
            raise RuntimeError(f"el DEM de prueba no es valido: {cls.ruta}")

    def test_capa_valida_y_resolucion(self):
        t = make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS))
        self.assertAlmostEqual(t.resolucion, 2.0)

    def test_interpolacion_bilineal_exacta_en_un_plano(self):
        """En un plano, la bilineal tiene que dar el valor analitico exacto."""
        t = make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS))
        for dy in (100.0, 133.7, 250.5, 401.25):
            z = t.z(X0 + 300.0, Y0 + dy)
            self.assertIsNotNone(z)
            self.assertAlmostEqual(z, 200.0 + 0.20 * dy, places=3)

    def test_nodata_devuelve_none(self):
        t = make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS))
        # La esquina NoData son las 10x10 primeras celdas: arriba-izquierda.
        self.assertIsNone(t.z(X0 + 5.0, Y0 + 600.0 - 5.0))

    def test_fuera_del_extent_devuelve_none(self):
        t = make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS))
        self.assertIsNone(t.z(X0 - 500.0, Y0 + 100.0))

    def test_factor_y_offset(self):
        t = make_terrain(
            self.capa, QgsCoordinateReferenceSystem(CRS), factor_z=2.0, offset_z=10.0
        )
        base = 200.0 + 0.20 * 100.0
        self.assertAlmostEqual(t.z(X0 + 300.0, Y0 + 100.0), base * 2.0 + 10.0, places=3)

    def test_banda_inexistente(self):
        with self.assertRaises(TerrainError):
            make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS), banda=7)

    def test_capa_invalida(self):
        with self.assertRaises(TerrainError):
            make_terrain(QgsRasterLayer("no_existe.tif", "x"))

    def test_capa_no_soportada(self):
        capa = capa_lineas([])
        with self.assertRaises(TerrainError):
            make_terrain(capa, QgsCoordinateReferenceSystem(CRS))

    def test_cache_de_teselas_reutiliza_lecturas(self):
        t = make_terrain(self.capa, QgsCoordinateReferenceSystem(CRS))
        for _ in range(500):
            t.z(X0 + 300.0, Y0 + 300.0)
        self.assertLessEqual(t.lecturas, 2)


class TestDirectriz(unittest.TestCase):
    def test_partes_de_multilinea(self):
        capa = QgsVectorLayer(f"MultiLineString?crs={CRS}", "m", "memory")
        f = QgsFeature()
        f.setGeometry(
            QgsGeometry.fromMultiPolylineXY(
                [
                    [QgsPointXY(0, 0), QgsPointXY(100, 0)],
                    [QgsPointXY(0, 50), QgsPointXY(80, 50)],
                ]
            )
        )
        partes = parts_of(f.geometry())
        self.assertEqual(len(partes), 2)
        self.assertEqual(len(partes[0]), 2)

    def test_geometria_no_lineal_falla_con_mensaje(self):
        g = QgsGeometry.fromPointXY(QgsPointXY(0, 0))
        with self.assertRaises(ValueError) as ctx:
            parts_of(g)
        self.assertIn("linea", str(ctx.exception))

    def test_vertices_repetidos_se_ignoran(self):
        g = QgsGeometry.fromPolylineXY(
            [QgsPointXY(0, 0), QgsPointXY(0, 0), QgsPointXY(50, 0)]
        )
        self.assertEqual(len(parts_of(g)[0]), 2)

    def test_z_se_conserva(self):
        from qgis.core import QgsLineString, QgsPoint

        g = QgsGeometry(QgsLineString([QgsPoint(0, 0, 10.0), QgsPoint(100, 0, 20.0)]))
        pts = parts_of(g)[0]
        self.assertAlmostEqual(pts[0][2], 10.0)
        self.assertAlmostEqual(pts[1][2], 20.0)

    def test_paso_y_extremo_final(self):
        pts = [(0.0, 0.0, None), (23.0, 0.0, None)]
        sts = stations_along(pts, StationOptions(paso=5.0, incluir_vertices=False))
        self.assertAlmostEqual(sts[0].s, 0.0)
        self.assertAlmostEqual(sts[-1].s, 23.0)  # el final siempre entra
        self.assertAlmostEqual(sts[1].s, 5.0)

    def test_normal_a_la_derecha_del_avance(self):
        pts = [(0.0, 0.0, None), (100.0, 0.0, None)]
        sts = stations_along(pts, StationOptions(paso=10.0))
        # Avanzando hacia +X, la derecha es -Y.
        self.assertAlmostEqual(sts[1].nx, 0.0, places=9)
        self.assertAlmostEqual(sts[1].ny, -1.0, places=9)
        self.assertAlmostEqual(math.hypot(sts[1].nx, sts[1].ny), 1.0)

    def test_normal_es_bisectriz_en_el_vertice(self):
        # Giro de 90 grados: la bisectriz apunta a 45 grados.
        pts = [(0.0, 0.0, None), (50.0, 0.0, None), (50.0, 50.0, None)]
        sts = stations_along(pts, StationOptions(paso=10.0))
        vert = [s for s in sts if s.es_vertice and abs(s.s - 50.0) < 1e-6]
        self.assertEqual(len(vert), 1)
        v = vert[0]
        # tangente bisectriz = (1,1)/sqrt2  ->  normal derecha = (1,-1)/sqrt2
        self.assertAlmostEqual(v.nx, 1.0 / math.sqrt(2.0), places=6)
        self.assertAlmostEqual(v.ny, -1.0 / math.sqrt(2.0), places=6)

    def test_offset_critico_en_curva_cerrada(self):
        pts = [(0.0, 0.0, None), (50.0, 0.0, None), (50.0, 50.0, None)]
        sts = stations_along(pts, StationOptions(paso=10.0))
        v = [s for s in sts if s.es_vertice and abs(s.s - 50.0) < 1e-6][0]
        # Giro de 90 grados, separacion 10 m -> 10 / (2*tan(45)) = 5 m
        self.assertAlmostEqual(v.offset_critico, 5.0, places=6)
        # Los PK que no son vertice no tienen cruce.
        rectos = [s for s in sts if not s.es_vertice]
        self.assertTrue(all(math.isinf(s.offset_critico) for s in rectos))

    def test_pk_inicial(self):
        pts = [(0.0, 0.0, None), (100.0, 0.0, None)]
        sts = stations_along(pts, StationOptions(paso=10.0, pk_inicio=1000.0))
        self.assertAlmostEqual(sts[0].s, 1000.0)
        self.assertAlmostEqual(sts[-1].s, 1100.0)

    def test_paso_invalido(self):
        with self.assertRaises(ValueError):
            stations_along(
                [(0.0, 0.0, None), (10.0, 0.0, None)], StationOptions(paso=0.0)
            )

    def test_alignments_from_feature(self):
        capa = capa_lineas([])
        f = feature_linea(capa, [(X0, Y0), (X0 + 100, Y0)])
        als = list(alignments_from_feature(f, StationOptions(paso=10.0)))
        self.assertEqual(len(als), 1)
        self.assertAlmostEqual(als[0].longitud, 100.0)
        self.assertFalse(als[0].tiene_z)


class TestExpresiones(unittest.TestCase):
    def setUp(self):
        self.campos = [
            QgsField("ancho", QMetaType.Type.Double),
            QgsField("clase", QMetaType.Type.QString, len=10),
            QgsField("vacio", QMetaType.Type.Double),
        ]
        self.capa = capa_lineas([], self.campos)
        f = feature_linea(self.capa, [(X0, Y0), (X0 + 50, Y0)], [7.5, "roca", None])
        self.capa.dataProvider().addFeatures([f])
        self.feat = next(self.capa.getFeatures())

    def test_referencia_a_campo(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        self.assertAlmostEqual(ev("@ancho"), 7.5)

    def test_literal_pasa_tal_cual(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        self.assertEqual(ev("1:1.5"), "1:1.5")
        self.assertEqual(ev(3.5), 3.5)

    def test_expresion(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        self.assertAlmostEqual(float(ev('="ancho" * 2')), 15.0)
        self.assertEqual(ev("=if(\"clase\" = 'roca', '1:0.5', '1:1.5')"), "1:0.5")

    def test_campo_inexistente_da_mensaje_util(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        with self.assertRaises(ParamError) as ctx:
            ev("@anchura")
        self.assertIn("anchura", str(ctx.exception))

    def test_campo_vacio_falla(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        with self.assertRaises(ParamError):
            ev("@vacio")

    def test_expresion_con_error_de_sintaxis(self):
        ev = FeatureEvaluator(self.capa, self.feat)
        with self.assertRaises(ParamError):
            ev("=if(")

    def test_campos_usados(self):
        asm = load_template("plataforma_por_campos")
        self.assertEqual(
            campos_usados(asm),
            ["camber", "cut_slope", "fill_slope", "width"],
        )


class TestBuild(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dem = QgsRasterLayer(escribir_dem("dem_build.tif"), "dem")
        cls.terreno = make_terrain(cls.dem, QgsCoordinateReferenceSystem(CRS))

    def _capa(self):
        campos = [
            QgsField("seccion", QMetaType.Type.QString, len=60),
            QgsField("width", QMetaType.Type.Double),
            QgsField("camber", QMetaType.Type.Double),
            QgsField("cut_slope", QMetaType.Type.QString, len=20),
            QgsField("fill_slope", QMetaType.Type.QString, len=20),
        ]
        capa = capa_lineas([], campos)
        fs = [
            feature_linea(
                capa,
                [(X0 + 100, Y0 + 200), (X0 + 400, Y0 + 200)],
                ["Road 1+1", 7.0, -2.0, "1:1", "1:1.5"],
            ),
            feature_linea(
                capa,
                [(X0 + 100, Y0 + 400), (X0 + 400, Y0 + 400)],
                ["Platform from fields", 9.0, -3.0, "1:1", "1:2"],
            ),
        ]
        capa.dataProvider().addFeatures(fs)
        capa.updateExtents()
        return capa

    def _opts(self, **kw):
        base = dict(
            stations=StationOptions(paso=10.0),
            section=SectionOptions(paso=0.5, ancho_max=150.0),
            campo_seccion="seccion",
            seccion_defecto="Road 1+1",
        )
        base.update(kw)
        return BuildOptions(**base)

    def _lib(self):
        from aqgis_sivil3d.core.library import default_library

        return default_library().assemblies

    def test_una_seccion_por_feature(self):
        res = build_corridor(self._capa(), self.terreno, self._lib(), self._opts())
        self.assertEqual(len(res.runs), 2)
        self.assertEqual(res.runs[0].asm_nombre, "Road 1+1")
        self.assertEqual(res.runs[1].asm_nombre, "Platform from fields")
        self.assertFalse(res.mesh.is_empty)

    def test_parametros_por_campo_se_aplican(self):
        res = build_corridor(self._capa(), self.terreno, self._lib(), self._opts())
        # El segundo tramo lleva ancho=9 por campo: media plataforma 9 m.
        sec = res.runs[1].sections[len(res.runs[1].sections) // 2]
        self.assertAlmostEqual(
            sec.vertex_by_code("R_PLATFORM").offset, 9.0, places=6
        )

    def test_seccion_desconocida_se_salta_con_aviso(self):
        capa = self._capa()
        capa.startEditing()
        for f in capa.getFeatures():
            capa.changeAttributeValue(f.id(), 0, "No existe")
            break
        capa.commitChanges()
        res = build_corridor(capa, self.terreno, self._lib(), self._opts())
        self.assertEqual(len(res.runs), 1)
        self.assertTrue(any("desconocida" in w for w in res.warnings))

    def test_campo_inexistente_falla_pronto(self):
        capa = capa_lineas(
            [], [QgsField("seccion", QMetaType.Type.QString, len=60)]
        )
        f = feature_linea(
            capa, [(X0 + 100, Y0 + 200), (X0 + 300, Y0 + 200)],
            ["Platform from fields"],
        )
        capa.dataProvider().addFeatures([f])
        with self.assertRaises(ValueError) as ctx:
            build_corridor(capa, self.terreno, self._lib(), self._opts())
        self.assertIn("campos que no existen", str(ctx.exception))

    def test_seccion_no_usada_con_campos_ajenos_no_estorba(self):
        """La libreria puede tener secciones que pidan campos de otras capas."""
        capa = capa_lineas(
            [], [QgsField("seccion", QMetaType.Type.QString, len=60)]
        )
        f = feature_linea(
            capa, [(X0 + 100, Y0 + 200), (X0 + 300, Y0 + 200)], ["Track 5 m"]
        )
        capa.dataProvider().addFeatures([f])
        res = build_corridor(capa, self.terreno, self._lib(), self._opts())
        self.assertEqual(len(res.runs), 1)

    def test_capa_de_puntos_rechazada(self):
        capa = QgsVectorLayer(f"Point?crs={CRS}", "p", "memory")
        with self.assertRaises(ValueError):
            build_corridor(capa, self.terreno, self._lib(), self._opts())

    def test_cota_de_la_directriz(self):
        from qgis.core import QgsLineString, QgsPoint

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "d", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("seccion", QMetaType.Type.QString, len=60)]
        )
        capa.updateFields()
        f = QgsFeature(capa.fields())
        f.setGeometry(
            QgsGeometry(
                QgsLineString(
                    [
                        QgsPoint(X0 + 100, Y0 + 200, 260.0),
                        QgsPoint(X0 + 400, Y0 + 200, 275.0),
                    ]
                )
            )
        )
        f.setAttributes(["Road 1+1"])
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        res = build_corridor(
            capa, self.terreno, self._lib(), self._opts(cota_eje=COTA_DIRECTRIZ)
        )
        sec = res.runs[0].sections[0]
        self.assertAlmostEqual(sec.z_eje, 260.0, places=3)
        ultima = res.runs[0].sections[-1]
        self.assertAlmostEqual(ultima.z_eje, 275.0, places=3)

    def test_solo_seleccionados_sin_seleccion_falla(self):
        capa = self._capa()
        with self.assertRaises(ValueError) as ctx:
            build_corridor(
                capa, self.terreno, self._lib(),
                self._opts(solo_seleccionados=True),
            )
        self.assertIn("seleccionado", str(ctx.exception))

    def test_solo_seleccionados(self):
        capa = self._capa()
        primero = next(capa.getFeatures())
        capa.selectByIds([primero.id()])
        res = build_corridor(
            capa, self.terreno, self._lib(), self._opts(solo_seleccionados=True)
        )
        self.assertEqual(len(res.runs), 1)

    def test_fusion_con_el_terreno(self):
        res = build_corridor(
            self._capa(),
            self.terreno,
            self._lib(),
            self._opts(fusionar=True, merge=MergeOptions(celda=5.0, holgura=25.0)),
        )
        self.assertIsNotNone(res.mesh_fusion)
        self.assertGreater(len(res.mesh_fusion.tris), len(res.mesh.tris))
        self.assertIs(res.mesh_final, res.mesh_fusion)

    def test_sin_fusion_mesh_final_es_el_corredor(self):
        res = build_corridor(self._capa(), self.terreno, self._lib(), self._opts())
        self.assertIsNone(res.mesh_fusion)
        self.assertIs(res.mesh_final, res.mesh)

    def test_directriz_fuera_del_dem(self):
        capa = capa_lineas(
            [], [QgsField("seccion", QMetaType.Type.QString, len=60)]
        )
        f = feature_linea(
            capa,
            [(X0 - 5000, Y0 - 5000), (X0 - 4800, Y0 - 5000)],
            ["Road 1+1"],
        )
        capa.dataProvider().addFeatures([f])
        res = build_corridor(capa, self.terreno, self._lib(), self._opts())
        self.assertTrue(res.mesh.is_empty)
        self.assertTrue(any("triangulo" in w for w in res.warnings))


class TestSalidas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_out.tif"), "dem")
        terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        capa = capa_lineas([], [QgsField("seccion", QMetaType.Type.QString, len=60)])
        f = feature_linea(
            capa, [(X0 + 100, Y0 + 200), (X0 + 400, Y0 + 220)], ["Road 1+1"]
        )
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        cls.res = build_corridor(
            capa,
            terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=10.0),
                section=SectionOptions(paso=0.5, ancho_max=150.0),
                campo_seccion="seccion",
                seccion_defecto="Road 1+1",
            ),
        )

    def test_secciones_tienen_z_y_atributos(self):
        fts = list(features_secciones(self.res))
        self.assertGreater(len(fts), 5)
        for ft in fts:
            self.assertTrue(ft.geometry().constGet().is3D())
            self.assertEqual(ft.geometry().wkbType(), QgsWkbTypes.LineStringZ)
        ft = fts[0]
        nombres = [f.name() for f in ft.fields()]
        self.assertIn("modo_izq", nombres)
        self.assertIn("ancho_der", nombres)
        self.assertEqual(ft["ok"], 1)

    def test_lineas_incluyen_eje_y_daylight(self):
        codigos = {ft["codigo"] for ft in features_lineas(self.res)}
        self.assertIn("AXIS", codigos)
        self.assertIn("DAYLIGHT_IZQ", codigos)
        self.assertIn("R_SLOPE_DAY", codigos)

    def test_huella_es_poligono_con_area(self):
        fts = list(features_huella(self.res))
        self.assertEqual(len(fts), 1)
        self.assertEqual(fts[0].geometry().wkbType(), QgsWkbTypes.PolygonZ)
        self.assertGreater(fts[0]["area"], 0.0)

    def test_triangulos_con_pendiente(self):
        fts = list(features_triangulos(self.res.mesh))
        self.assertEqual(len(fts), len(self.res.mesh.tris))
        for ft in fts[:50]:
            self.assertEqual(ft.geometry().wkbType(), QgsWkbTypes.PolygonZ)
            self.assertGreater(ft["area_2d"], 0.0)
            self.assertGreaterEqual(ft["pendiente"], 0.0)
            self.assertGreaterEqual(ft["z_max"], ft["z_min"])

    def test_puntos_uno_por_vertice(self):
        fts = list(features_puntos(self.res))
        total = sum(len(s.vertices) for r in self.res.runs for s in r.sections)
        self.assertEqual(len(fts), total)
        self.assertEqual(fts[0].geometry().wkbType(), QgsWkbTypes.PointZ)

    def test_malla_2dm_se_puede_cargar_en_qgis(self):
        from qgis.core import QgsMeshLayer

        from aqgis_sivil3d.core.tin import write_2dm

        ruta = os.path.join(_TMP, "salida.2dm")
        write_2dm(ruta, self.res.mesh)
        capa = QgsMeshLayer(ruta, "tin", "mdal")
        self.assertTrue(capa.isValid())
        self.assertEqual(capa.meshVertexCount(), len(self.res.mesh.nodes))
        self.assertEqual(capa.meshFaceCount(), len(self.res.mesh.tris))


class TestPK(unittest.TestCase):
    """PK rotulados sobre el eje, al estilo del modelo "PK en QGIS"."""

    def test_formato_pk(self):
        from aqgis_sivil3d.gis.alignment import formato_pk

        self.assertEqual(formato_pk(0.0), "0+000")
        self.assertEqual(formato_pk(250.0), "0+250")
        self.assertEqual(formato_pk(1250.0), "1+250")
        self.assertEqual(formato_pk(12345.4), "12+345")

    def test_formato_pk_redondeo_al_kilometro(self):
        """999.6 no puede salir como '0+1000'."""
        from aqgis_sivil3d.gis.alignment import formato_pk

        self.assertEqual(formato_pk(999.6), "1+000")

    def test_azimut_es_desde_el_norte_horario(self):
        from aqgis_sivil3d.gis.alignment import azimut

        # Avanzando hacia el este el azimut es 90; hacia el norte, 0.
        este = stations_along(
            [(0.0, 0.0, None), (100.0, 0.0, None)], StationOptions(paso=50.0)
        )[1]
        norte = stations_along(
            [(0.0, 0.0, None), (0.0, 100.0, None)], StationOptions(paso=50.0)
        )[1]
        self.assertAlmostEqual(azimut(este), 90.0, places=6)
        self.assertAlmostEqual(azimut(norte), 0.0, places=6)

    def test_desplazamiento_de_etiqueta_es_perpendicular(self):
        """La formula del QML usa cos(pi-a)/sin(pi-a); tiene que ser normal al eje."""
        import math

        from aqgis_sivil3d.gis.alignment import azimut

        st = stations_along(
            [(0.0, 0.0, None), (100.0, 60.0, None)], StationOptions(paso=50.0)
        )[1]
        a = math.radians(azimut(st))
        dx, dy = math.cos(math.pi - a), math.sin(math.pi - a)
        tx, ty = -st.ny, st.nx  # tangente
        self.assertAlmostEqual(dx * tx + dy * ty, 0.0, places=9)

    def test_intervalo_independiente_del_paso_de_calculo(self):
        al = next(
            alignments_from_feature(
                feature_linea(capa_lineas([]), [(0.0, 0.0), (450.0, 0.0)]),
                StationOptions(paso=10.0),
            )
        )
        pks = al.pk_stations(100.0)
        self.assertEqual([round(s.s) for s in pks], [0, 100, 200, 300, 400, 450])

    def test_intervalo_cero_no_genera_pk(self):
        al = next(
            alignments_from_feature(
                feature_linea(capa_lineas([]), [(0.0, 0.0), (450.0, 0.0)]),
                StationOptions(paso=10.0),
            )
        )
        self.assertEqual(al.pk_stations(0.0), [])

    def test_los_qml_del_modelo_estan_en_el_plugin(self):
        """No deben depender de la carpeta original ni de una ruta de red."""
        from aqgis_sivil3d.gis.estilos import CARPETA_ESTILOS

        for nombre in ("pk_puntos.qml", "pk_eje.qml"):
            ruta = os.path.join(CARPETA_ESTILOS, nombre)
            self.assertTrue(os.path.exists(ruta), ruta)
            with open(ruta, "r", encoding="utf-8") as fh:
                texto = fh.read()
            self.assertNotIn("srv-sevilla", texto)


class TestZonasYEstilos(unittest.TestCase):
    """Desmonte y terraplen tienen que salir en colores distintos."""

    @classmethod
    def setUpClass(cls):
        cls.dem = QgsRasterLayer(escribir_dem("dem_zonas.tif"), "dem")
        cls.terreno = make_terrain(cls.dem, QgsCoordinateReferenceSystem(CRS))

    def _resultado(self, desnivel: float, fusionar: bool = False):
        from aqgis_sivil3d.core.library import default_library

        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = desnivel
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 300), (X0 + 500, Y0 + 300)], ["x"])]
        )
        capa.updateExtents()
        return capa, build_corridor(
            capa,
            self.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=10.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0),
                seccion_defecto="Road 1+1",
                fusionar=fusionar,
                merge=MergeOptions(celda=5.0, holgura=20.0),
                intervalo_pk=100.0,
            ),
        )

    def test_desmonte_se_clasifica_con_espesor_negativo(self):
        _capa, res = self._resultado(-3.0)
        fts = list(features_triangulos(res.mesh, self.terreno))
        zonas = {ft["zona"] for ft in fts}
        self.assertIn("desmonte", zonas)
        self.assertNotIn("terraplen", zonas)
        for ft in fts:
            if ft["zona"] == "desmonte":
                self.assertLess(ft["espesor"], 0.0)

    def test_terraplen_se_clasifica_con_espesor_positivo(self):
        _capa, res = self._resultado(4.0)
        fts = list(features_triangulos(res.mesh, self.terreno))
        zonas = {ft["zona"] for ft in fts}
        self.assertIn("terraplen", zonas)
        self.assertNotIn("desmonte", zonas)
        for ft in fts:
            if ft["zona"] == "terraplen":
                self.assertGreater(ft["espesor"], 0.0)

    def test_media_ladera_da_las_dos_zonas(self):
        """Con el eje sobre el terreno y ladera transversal salen ambas."""
        _capa, res = self._resultado(0.0)
        zonas = {ft["zona"] for ft in features_triangulos(res.mesh, self.terreno)}
        self.assertIn("desmonte", zonas)
        self.assertIn("terraplen", zonas)

    def test_la_fusion_marca_el_terreno_natural(self):
        _capa, res = self._resultado(-3.0, fusionar=True)
        fts = list(features_triangulos(res.mesh_final, self.terreno))
        zonas = {ft["zona"] for ft in fts}
        self.assertIn("terreno natural", zonas)
        self.assertIn("desmonte", zonas)
        # Y el reparto tiene que cuadrar con lo que dijo la fusion.
        n_terreno = sum(1 for ft in fts if ft["zona"] == "terreno natural")
        self.assertEqual(n_terreno, len(res.mesh_final.tris) - len(res.mesh.tris))

    def test_sin_terreno_no_se_clasifica(self):
        _capa, res = self._resultado(-3.0)
        zonas = {ft["zona"] for ft in features_triangulos(res.mesh)}
        self.assertEqual(zonas, {""})

    def test_el_tin_sale_categorizado_con_colores_distintos(self):
        from qgis.core import QgsCategorizedSymbolRenderer

        capa, res = self._resultado(0.0)
        capas = layers_from_result(
            res, capa.crs(), tz=self.terreno, fusionada=False
        )
        tin = [c for c in capas if c.name().startswith("TIN")][0]
        r = tin.renderer()
        self.assertIsInstance(r, QgsCategorizedSymbolRenderer)
        colores = {}
        for cat in r.categories():
            if cat.value():
                colores[cat.value()] = cat.symbol().color().name()
        self.assertIn("desmonte", colores)
        self.assertIn("terraplen", colores)
        self.assertNotEqual(colores["desmonte"], colores["terraplen"])

    def test_las_capas_salen_en_orden_de_dibujo(self):
        capa, res = self._resultado(-3.0)
        capas = layers_from_result(
            res, capa.crs(), tz=self.terreno, con_puntos=True
        )
        nombres = [c.name() for c in capas]
        self.assertEqual(nombres[0], "stations")
        self.assertTrue(nombres[-1].startswith("TIN"))
        self.assertLess(nombres.index("axis"), nombres.index("footprint"))

    def test_eje_y_pk_tienen_estilo(self):
        capa, res = self._resultado(-3.0)
        capas = layers_from_result(res, capa.crs(), tz=self.terreno)
        pk = [c for c in capas if c.name() == "stations"][0]
        eje = [c for c in capas if c.name() == "axis"][0]
        self.assertTrue(pk.labelsEnabled())
        self.assertEqual(pk.labeling().settings().fieldName, "P.K.")
        # El simbolo del eje es el de carretera: varias capas de simbolo.
        self.assertGreaterEqual(eje.renderer().symbol().symbolLayerCount(), 3)

    def test_campos_de_pk_con_los_nombres_del_modelo(self):
        capa, res = self._resultado(-3.0)
        capas = layers_from_result(res, capa.crs(), tz=self.terreno)
        pk = [c for c in capas if c.name() == "stations"][0]
        nombres = [f.name() for f in pk.fields()]
        for esperado in ("distance", "angle", "P.K."):
            self.assertIn(esperado, nombres)
        ft = next(pk.getFeatures())
        self.assertEqual(ft["P.K."], "0+000")


class TestGrupoDeCapas(unittest.TestCase):
    def setUp(self):
        QgsProject.instance().clear()

    def _capas(self):
        from aqgis_sivil3d.gis.outputs import memory_layer

        crs = QgsCoordinateReferenceSystem(CRS)
        return [
            memory_layer(n, QgsWkbTypes.LineStringZ, crs, fields_eje(), [])
            for n in ("stations", "axis", "TIN", "footprint")
        ]

    def test_nombre_por_defecto_es_alineacion_guion_corredor(self):
        from aqgis_sivil3d.gis.outputs import nombre_grupo

        capa = capa_lineas([])
        capa.setName("EJE-A7")
        self.assertEqual(nombre_grupo(capa), "EJE-A7-corridor")
        self.assertEqual(nombre_grupo(None), "alignment-corridor")

    def test_las_capas_van_dentro_del_grupo_y_no_en_la_raiz(self):
        from qgis.core import QgsLayerTreeGroup

        from aqgis_sivil3d.gis.outputs import cargar_en_grupo

        proyecto = QgsProject.instance()
        grupo = cargar_en_grupo(self._capas(), "prueba-corridor", proyecto)
        self.assertEqual(grupo.name(), "prueba-corridor")
        self.assertEqual(len(grupo.children()), 4)
        raiz = proyecto.layerTreeRoot()
        sueltas = [
            h for h in raiz.children() if not isinstance(h, QgsLayerTreeGroup)
        ]
        self.assertEqual(sueltas, [])

    def test_orden_dentro_del_grupo(self):
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo

        grupo = cargar_en_grupo(self._capas(), "g", QgsProject.instance())
        self.assertEqual(
            [h.name() for h in grupo.children()], ["stations", "axis", "footprint", "TIN"]
        )

    def test_cada_calculo_crea_un_grupo_nuevo(self):
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo

        proyecto = QgsProject.instance()
        g1 = cargar_en_grupo(self._capas(), "alt-corridor", proyecto)
        g2 = cargar_en_grupo(self._capas(), "alt-corridor", proyecto)
        g3 = cargar_en_grupo(self._capas(), "alt-corridor", proyecto)
        self.assertEqual(
            [g1.name(), g2.name(), g3.name()],
            ["alt-corridor", "alt-corridor (2)", "alt-corridor (3)"],
        )


class TestVisorDePerfiles(unittest.TestCase):
    """Motor de dibujo de perfiles y panel acoplado."""

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_perfiles.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 200), (X0 + 500, Y0 + 240)], ["x"])]
        )
        capa.updateExtents()
        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = -2.0
        cls.res = build_corridor(
            capa,
            cls.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=10.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        cls.secciones = [s for s in cls.res.runs[0].sections if s.vertices]

    def test_datos_de_seccion(self):
        from aqgis_sivil3d.ui.profile_view import datos_de_seccion

        d = datos_de_seccion(self.secciones[0])
        self.assertGreater(len(d.proyecto), 4)
        self.assertGreater(len(d.terreno), 20)
        self.assertEqual(len(d.marcas), len(self.secciones[0].vertices))
        self.assertIn("Sta", d.titulo)
        self.assertIn("cut", d.subtitulo)
        self.assertTrue(d.isotropo)

    def test_datos_longitudinal(self):
        from aqgis_sivil3d.ui.profile_view import datos_longitudinal

        d = datos_longitudinal(self.secciones, self.res.runs[0].pks)
        self.assertEqual(len(d.proyecto), len(self.secciones))
        self.assertEqual(len(d.terreno), len(self.secciones))
        xs = [x for x, _z in d.proyecto]
        self.assertEqual(xs, sorted(xs), "las abscisas son PK crecientes")
        self.assertAlmostEqual(xs[0], self.secciones[0].station.s)
        self.assertTrue(d.verticales)

    def test_el_longitudinal_enfrenta_rasante_y_terreno(self):
        from aqgis_sivil3d.ui.profile_view import datos_longitudinal

        d = datos_longitudinal(self.secciones)
        # Con la rasante 2 m bajo el terreno, el proyecto va siempre por debajo.
        for (x1, zp), (x2, zt) in zip(d.proyecto, d.terreno):
            self.assertAlmostEqual(x1, x2)
            self.assertLess(zp, zt)

    def test_datos_masas_no_es_isotropo(self):
        from aqgis_sivil3d.core.medicion import medir
        from aqgis_sivil3d.ui.profile_view import datos_masas

        d = datos_masas(medir(self.secciones))
        self.assertFalse(
            d.isotropo, "el diagrama de masas enfrenta m con m3: escalas independientes"
        )
        self.assertGreater(len(d.proyecto), 2)

    def test_la_vista_se_pinta_sin_reventar(self):
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtGui import QImage, QPainter

        from aqgis_sivil3d.ui.profile_view import ProfileView, datos_de_seccion

        v = ProfileView()
        v.resize(600, 300)
        v.set_datos(datos_de_seccion(self.secciones[0]))
        formato = getattr(
            getattr(QImage, "Format", QImage), "Format_ARGB32"
        )
        img = QImage(QSize(600, 300), formato)
        img.fill(0xFFFFFFFF)
        p = QPainter(img)
        v.render(p)
        p.end()
        distintos = sum(
            1
            for y in range(0, 300, 7)
            for x in range(0, 600, 7)
            if img.pixel(x, y) != 0xFFFFFFFF
        )
        self.assertGreater(distintos, 20, "no se ha dibujado nada")

    def test_vista_vacia_no_revienta(self):
        from aqgis_sivil3d.ui.profile_view import DatosPerfil, ProfileView

        v = ProfileView()
        v.resize(200, 100)
        v.set_datos(DatosPerfil(), "nada")
        self.assertTrue(v.datos.vacio)

    def test_previsualizacion_del_editor_sigue_funcionando(self):
        """El editor usa el mismo motor de dibujo tras el refactor."""
        from aqgis_sivil3d.core.templates import load_template
        from aqgis_sivil3d.ui.section_preview import SectionPreview

        pv = SectionPreview()
        pv.pendiente_terreno = 30.0
        pv.actualizar(load_template("carretera_1x1").materialize(), SectionOptions())
        self.assertIsNotNone(pv._section)
        self.assertGreater(len(pv.datos.proyecto), 4)
        self.assertGreater(len(pv.datos.terreno), 10)

    def _dock(self):
        from qgis.gui import QgsMapCanvas

        from aqgis_sivil3d.ui.profile_dock import ProfileDock

        canvas = QgsMapCanvas()

        class Iface:
            def mainWindow(self):
                return None

            def mapCanvas(self):
                return canvas

        dock = ProfileDock(Iface())
        dock._canvas_ref = canvas  # que no se lo lleve el recolector
        return dock

    def test_panel_carga_el_resultado(self):
        dock = self._dock()
        dock.set_result(self.res)
        self.assertEqual(len(dock.selector), 1)
        self.assertEqual(dock.cmb_pk.count(), len(self.secciones))
        # Sin capa activa el visor abre sin marcar nada: el longitudinal es lo
        # unico que depende de las marcadas, y aparece al marcar.
        self.assertTrue(dock.vista_long.datos.vacio)
        dock.selector.marcar_todas(True)
        self.assertFalse(dock.vista_long.datos.vacio)
        self.assertFalse(dock.vista_sec.datos.vacio)
        self.assertFalse(dock.vista_masas.datos.vacio)
        self.assertIn("m3", dock.lbl_estado.text())

    def test_panel_sin_resultado(self):
        dock = self._dock()
        dock.set_result(None)
        self.assertTrue(dock.selector.vacio)
        self.assertTrue(dock.vista_long.datos.vacio)
        self.assertFalse(dock.cmb_pk.isEnabled())

    def test_navegacion_por_pk(self):
        dock = self._dock()
        dock.set_result(self.res)
        self.assertEqual(dock.cmb_pk.currentIndex(), 0)
        dock._mover(1)
        self.assertEqual(dock.cmb_pk.currentIndex(), 1)
        dock._mover(-5)
        self.assertEqual(dock.cmb_pk.currentIndex(), 0, "no debe pasar del principio")
        dock._mover(10_000)
        self.assertEqual(
            dock.cmb_pk.currentIndex(), len(self.secciones) - 1, "ni del final"
        )

    def test_el_cursor_del_longitudinal_sigue_al_pk(self):
        dock = self._dock()
        dock.set_result(self.res)
        dock.cmb_pk.setCurrentIndex(5)
        self.assertAlmostEqual(
            dock.vista_long.cursor, self.secciones[5].station.s, places=6
        )

    def test_pinchar_en_el_perfil_salta_al_pk_mas_cercano(self):
        dock = self._dock()
        dock.set_result(self.res)
        objetivo = self.secciones[7].station.s
        dock._ir_a_pk(objetivo + 2.0)
        self.assertEqual(dock.cmb_pk.currentIndex(), 7)

    def test_pinchar_en_el_mapa_salta_al_pk_mas_cercano(self):
        dock = self._dock()
        dock.set_result(self.res)
        sec = self.secciones[4]
        dock._pinchado_en_mapa(QgsPointXY(sec.station.x, sec.station.y), None)
        self.assertEqual(dock.cmb_pk.currentIndex(), 4)

    def test_exageracion(self):
        dock = self._dock()
        dock.set_result(self.res)
        dock.sp_exa.setValue(20.0)
        self.assertAlmostEqual(dock.vista_long.exageracion, 20.0)


class TestLaminasYPlanos(unittest.TestCase):
    """Capas de espacio papel, hojas de planta, composiciones y exportacion."""

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_planos.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        # En diagonal, para que la rotacion del atlas tenga algo que hacer.
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 60, Y0 + 100), (X0 + 520, Y0 + 460)], ["x"])]
        )
        capa.updateExtents()
        cls.capa = capa
        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = -2.5
        cls.res = build_corridor(
            capa,
            cls.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=20.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0, muestras_terreno=60),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        # OJO: no llamarlo 'run', que pisaria TestCase.run.
        cls.tramo = cls.res.runs[0]
        cls.secciones = [s for s in cls.tramo.sections if s.vertices]

    # -- capas de dibujo ---------------------------------------------------
    def _hojas(self, columnas=3, filas=4):
        from aqgis_sivil3d.core.paperspace import Reticula, laminas_de_transversales

        return laminas_de_transversales(
            self.secciones,
            Reticula(columnas=columnas, filas=filas, ancho_celda=110.0, alto_celda=60.0),
            escala_automatica=True,
        )

    def test_capas_de_dibujo_sin_sistema_de_referencia(self):
        """Sus coordenadas son milimetros de papel, no grados ni metros."""
        from aqgis_sivil3d.gis.laminas import capas_de_hojas

        capas = capas_de_hojas(self._hojas(), "T")
        self.assertEqual(len(capas), 3)
        for c in capas:
            self.assertTrue(c.isValid())
            self.assertFalse(
                c.crs().isValid(),
                f"{c.name()} no debe llevar CRS: son mm de papel",
            )

    def test_reparto_por_tipo_de_geometria(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas

        capas = {c.name().split(" - ")[-1]: c for c in capas_de_hojas(self._hojas(), "T")}
        self.assertGreater(capas["lineas"].featureCount(), 10)
        self.assertGreater(capas["rellenos"].featureCount(), 0)
        self.assertGreater(capas["rotulos"].featureCount(), 0)
        self.assertEqual(
            QgsWkbTypes.geometryType(capas["lineas"].wkbType()),
            QgsWkbTypes.LineGeometry,
        )
        self.assertEqual(
            QgsWkbTypes.geometryType(capas["rellenos"].wkbType()),
            QgsWkbTypes.PolygonGeometry,
        )

    def test_los_rotulos_llevan_texto_y_angulo(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas

        capas = {c.name().split(" - ")[-1]: c for c in capas_de_hojas(self._hojas(), "T")}
        rot = capas["rotulos"]
        nombres = [f.name() for f in rot.fields()]
        self.assertIn("texto", nombres)
        self.assertIn("angulo", nombres)
        self.assertTrue(rot.labelsEnabled())
        textos = [f["texto"] for f in rot.getFeatures()]
        self.assertTrue(any(t and t.startswith("Sta") for t in textos))

    def test_los_rellenos_estan_categorizados(self):
        from qgis.core import QgsCategorizedSymbolRenderer

        from aqgis_sivil3d.gis.laminas import capas_de_hojas

        capas = {c.name().split(" - ")[-1]: c for c in capas_de_hojas(self._hojas(), "T")}
        self.assertIsInstance(capas["rellenos"].renderer(), QgsCategorizedSymbolRenderer)

    # -- hojas de planta ---------------------------------------------------
    def test_hojas_de_planta(self):
        from aqgis_sivil3d.gis.laminas import hojas_de_planta

        capa = hojas_de_planta(
            self.tramo.alignment, 420.0, 297.0, escala=1000.0, crs=self.crs
        )
        self.assertGreater(capa.featureCount(), 1)
        self.assertTrue(capa.crs().isValid())
        campos = [f.name() for f in capa.fields()]
        for esperado in ("hoja", "pk_ini", "pk_fin", "azimut", "rotacion", "escala"):
            self.assertIn(esperado, campos)

    def test_las_hojas_cubren_todo_el_tramo(self):
        from aqgis_sivil3d.gis.laminas import hojas_de_planta

        capa = hojas_de_planta(
            self.tramo.alignment, 420.0, 297.0, escala=1000.0, crs=self.crs
        )
        fts = sorted(capa.getFeatures(), key=lambda f: f["hoja"])
        self.assertAlmostEqual(fts[0]["pk_ini"], self.tramo.alignment.stations[0].s, places=3)
        self.assertAlmostEqual(
            fts[-1]["pk_fin"], self.tramo.alignment.stations[-1].s, places=3
        )

    def test_las_hojas_se_solapan_lo_pedido(self):
        from aqgis_sivil3d.gis.laminas import hojas_de_planta

        capa = hojas_de_planta(
            self.tramo.alignment, 420.0, 297.0, escala=500.0, solape=0.2, crs=self.crs
        )
        fts = sorted(capa.getFeatures(), key=lambda f: f["hoja"])
        self.assertGreater(len(fts), 2)
        for a, b in zip(fts, fts[1:]):
            self.assertLess(b["pk_ini"], a["pk_fin"], "debe haber solape")

    def test_rotacion_pone_el_eje_horizontal(self):
        from aqgis_sivil3d.gis.laminas import rotacion_para_horizontal

        self.assertAlmostEqual(rotacion_para_horizontal(90.0), 0.0)
        self.assertAlmostEqual(rotacion_para_horizontal(0.0), 90.0)
        self.assertAlmostEqual(rotacion_para_horizontal(180.0), -90.0)
        self.assertAlmostEqual(rotacion_para_horizontal(45.0), 45.0)

    # -- composiciones -----------------------------------------------------
    def test_layout_transversales_una_pagina_por_hoja(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.gis.planos import OpcionesPlano, layout_transversales

        hojas = self._hojas(columnas=2, filas=2)
        capas = capas_de_hojas(hojas, "T")
        lay = layout_transversales(hojas, capas, OpcionesPlano(papel="A3"))
        self.assertEqual(lay.pageCollection().pageCount(), len(hojas))

    def test_el_encuadre_es_uno_a_uno(self):
        """1 unidad de la capa de dibujo = 1 mm de papel, o la escala es mentira."""
        from qgis.core import QgsLayoutItemMap
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.gis.planos import OpcionesPlano, layout_transversales

        hojas = self._hojas()
        lay = layout_transversales(
            hojas, capas_de_hojas(hojas, "T"), OpcionesPlano(papel="A0")
        )
        mapas = [i for i in lay.items() if isinstance(i, QgsLayoutItemMap)]
        self.assertTrue(mapas)
        m = mapas[0]
        self.assertAlmostEqual(m.extent().width(), m.rect().width(), places=3)
        self.assertAlmostEqual(m.extent().height(), m.rect().height(), places=3)

    def test_papel_necesario(self):
        from aqgis_sivil3d.gis.planos import papel_necesario

        self.assertEqual(papel_necesario((0.0, 0.0, 200.0, 150.0), 12.0), "A4")
        self.assertEqual(papel_necesario((0.0, 0.0, 380.0, 260.0), 12.0), "A3")
        self.assertIsNone(papel_necesario((0.0, 0.0, 5000.0, 5000.0), 12.0))

    def test_layout_planta_con_atlas(self):
        from aqgis_sivil3d.gis.laminas import hojas_de_planta
        from aqgis_sivil3d.gis.planos import OpcionesPlano, layout_planta

        capa = hojas_de_planta(
            self.tramo.alignment, 420.0, 297.0, escala=1000.0, crs=self.crs
        )
        QgsProject.instance().addMapLayer(capa, False)
        lay = layout_planta(capa, [capa], OpcionesPlano(papel="A3"))
        atlas = lay.atlas()
        self.assertTrue(atlas.enabled())
        self.assertEqual(atlas.coverageLayer().id(), capa.id())
        self.assertEqual(atlas.count(), capa.featureCount())

    def test_layout_longitudinal(self):
        from aqgis_sivil3d.core.paperspace import Escala, OpcionesDibujo
        from aqgis_sivil3d.core.paperspace import lamina_longitudinal
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.gis.planos import OpcionesPlano, layout_longitudinal

        hoja = lamina_longitudinal(
            self.secciones, opts=OpcionesDibujo(escala=Escala(1000.0, 100.0))
        )
        capas = capas_de_hojas([hoja], "L")
        lay = layout_longitudinal(hoja, capas, OpcionesPlano(papel="A1"))
        self.assertEqual(lay.pageCollection().pageCount(), 1)

    def test_nombre_libre_en_el_gestor(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.gis.planos import (
            OpcionesPlano, anadir_al_proyecto, layout_transversales,
        )

        hojas = self._hojas(columnas=2, filas=2)
        capas = capas_de_hojas(hojas, "T")
        a = anadir_al_proyecto(
            layout_transversales(hojas, capas, OpcionesPlano()), QgsProject.instance()
        )
        b = anadir_al_proyecto(
            layout_transversales(hojas, capas, OpcionesPlano()), QgsProject.instance()
        )
        self.assertNotEqual(a.name(), b.name())

    # -- exportacion -------------------------------------------------------
    def test_exportar_imagen(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.gis.planos import (
            OpcionesPlano, exportar_imagen, layout_transversales,
        )

        hojas = self._hojas(columnas=2, filas=2)
        lay = layout_transversales(
            hojas, capas_de_hojas(hojas, "T"), OpcionesPlano(papel="A3")
        )
        ruta = os.path.join(_TMP, "lamina.png")
        ok, msg = exportar_imagen(lay, ruta, dpi=80)
        self.assertTrue(ok, msg)
        self.assertGreater(os.path.getsize(ruta), 2000)

    def test_exportar_dxf(self):
        from aqgis_sivil3d.gis.laminas import capas_de_hojas, exportar_dxf

        capas = capas_de_hojas(self._hojas(columnas=2, filas=2), "T")
        for c in capas:
            QgsProject.instance().addMapLayer(c, False)
        ruta = os.path.join(_TMP, "lamina.dxf")
        ok, msg = exportar_dxf(capas, ruta)
        self.assertTrue(ok, msg)
        self.assertGreater(os.path.getsize(ruta), 1000)
        with open(ruta, "r", encoding="utf-8", errors="ignore") as fh:
            cabecera = fh.read(400)
        self.assertIn("SECTION", cabecera)

    def test_exportar_dxf_sin_capas(self):
        from aqgis_sivil3d.gis.laminas import exportar_dxf

        ok, msg = exportar_dxf([], os.path.join(_TMP, "vacio.dxf"))
        self.assertFalse(ok)
        self.assertIn("capas", msg)

    # -- dialogo -----------------------------------------------------------
    def test_dialogo_de_planos_se_construye(self):
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        class Iface:
            def mainWindow(self):
                return None

            def activeLayer(self):
                return None

        dlg = PlanosDialog(Iface(), self.res)
        self.assertEqual(len(dlg.selector), len(self.res.runs))
        self.assertEqual(len(dlg.selector.seleccionados()), len(self.res.runs))
        self.assertTrue(dlg.btn.isEnabled())

    def test_dialogo_sin_resultado_no_deja_generar(self):
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        class Iface:
            def mainWindow(self):
                return None

            def activeLayer(self):
                return None

        dlg = PlanosDialog(Iface(), None)
        self.assertFalse(dlg.btn.isEnabled())


class TestSalidasDeMedicion(unittest.TestCase):
    """La medicion de tierras sale como capa."""

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_medicion.tif"), "dem")
        terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 200), (X0 + 400, Y0 + 200)], ["x"])]
        )
        capa.updateExtents()
        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = -2.0
        cls.res = build_corridor(
            capa,
            terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=20.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0, muestras_terreno=60),
                seccion_defecto="Road 1+1",
            ),
        )

    def test_la_capa_de_secciones_lleva_areas_y_cota_roja(self):
        fts = list(features_secciones(self.res))
        nombres = [f.name() for f in fts[0].fields()]
        for esperado in ("cota_roja", "area_des", "area_ter"):
            self.assertIn(esperado, nombres)
        ft = fts[len(fts) // 2]
        self.assertLess(ft["cota_roja"], 0.0, "rasante bajo el terreno")
        self.assertGreater(ft["area_des"], 0.0)

    def test_tabla_de_mediciones(self):
        from aqgis_sivil3d.gis.outputs import tabla_medicion

        capa = tabla_medicion(self.res)
        self.assertTrue(capa.isValid())
        self.assertEqual(
            capa.wkbType(), QgsWkbTypes.NoGeometry, "es una tabla, sin geometria"
        )
        n_secciones = len([s for s in self.res.runs[0].sections if s.vertices])
        self.assertEqual(capa.featureCount(), n_secciones - 1)
        ft = next(capa.getFeatures())
        for esperado in ("vol_desmonte", "vol_terraplen", "vol_neto", "acumulado"):
            self.assertIn(esperado, [f.name() for f in capa.fields()])
        self.assertGreater(ft["vol_desmonte"], 0.0)

    def test_los_volumenes_de_la_tabla_cuadran_con_la_medicion(self):
        from aqgis_sivil3d.core.medicion import medir
        from aqgis_sivil3d.gis.outputs import tabla_medicion

        capa = tabla_medicion(self.res)
        total = sum(f["vol_desmonte"] for f in capa.getFeatures())
        m = medir([s for s in self.res.runs[0].sections if s.vertices])
        self.assertAlmostEqual(total, m.total_desmonte, places=2)


class TestPaqueteYCorredores(unittest.TestCase):
    """Exportar el grupo a un archivo, reabrirlo y seguir trabajando."""

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_paquete.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 300), (X0 + 420, Y0 + 320)], ["x"])]
        )
        capa.updateExtents()
        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = -2.0
        cls.res = build_corridor(
            capa,
            cls.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=20.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0, muestras_terreno=50),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        cls.secciones = [s for s in cls.res.runs[0].sections if s.vertices]

    def _capas(self):
        from aqgis_sivil3d.gis.outputs import tabla_medicion

        capas = layers_from_result(self.res, self.crs, tz=self.terreno, con_pk=True)
        capas.append(tabla_medicion(self.res, "mediciones"))
        return [c for c in capas if c.featureCount()]

    # -- serializacion del corredor ----------------------------------------
    def test_las_secciones_van_y_vuelven_identicas(self):
        from aqgis_sivil3d.core import sesion

        recuperado = sesion.de_dict(sesion.a_dict(self.res, "X", CRS))
        self.assertEqual(len(recuperado.runs), len(self.res.runs))
        a = self.res.runs[0].sections[4]
        b = recuperado.runs[0].sections[4]
        self.assertAlmostEqual(b.station.s, a.station.s, places=6)
        self.assertAlmostEqual(b.z_eje, a.z_eje, places=6)
        self.assertAlmostEqual(b.z_terreno, a.z_terreno, places=6)
        self.assertEqual(b.codes(), a.codes())
        self.assertEqual(len(b.terreno), len(a.terreno))
        self.assertEqual(b.modo_izq, a.modo_izq)

    def test_la_medicion_del_corredor_recuperado_es_la_misma(self):
        from aqgis_sivil3d.core import sesion
        from aqgis_sivil3d.core.medicion import medir

        recuperado = sesion.de_dict(sesion.a_dict(self.res))
        m0 = medir(self.secciones)
        m1 = medir([s for s in recuperado.runs[0].sections if s.vertices])
        self.assertAlmostEqual(m1.total_desmonte, m0.total_desmonte, places=6)
        self.assertAlmostEqual(m1.total_terraplen, m0.total_terraplen, places=6)

    def test_los_pk_de_rotulacion_se_guardan(self):
        from aqgis_sivil3d.core import sesion

        recuperado = sesion.de_dict(sesion.a_dict(self.res))
        self.assertEqual(
            len(recuperado.runs[0].pks), len(self.res.runs[0].pks)
        )

    def test_json_de_ida_y_vuelta_en_disco(self):
        from aqgis_sivil3d.core import sesion

        ruta = os.path.join(_TMP, "corredor.json")
        sesion.guardar(self.res, ruta, "mi corredor", CRS)
        recuperado = sesion.cargar(ruta)
        self.assertEqual(recuperado.nombre, "mi corredor")
        self.assertEqual(recuperado.crs, CRS)
        self.assertEqual(len(recuperado.sections), len(self.res.sections))

    # -- paquete completo --------------------------------------------------
    def test_ciclo_exportar_importar(self):
        from aqgis_sivil3d.gis.paquete import exportar, importar, ruta_json

        gpkg = os.path.join(_TMP, "ciclo.gpkg")
        capas = self._capas()
        ok, mensajes = exportar(capas, gpkg, self.res, "eje-corridor", self.crs)
        self.assertTrue(ok, mensajes)
        self.assertTrue(os.path.exists(gpkg))
        self.assertTrue(os.path.exists(ruta_json(gpkg)))

        QgsProject.instance().clear()
        grupo, corredor, mensajes = importar(gpkg)
        self.assertIsNotNone(grupo, mensajes)
        self.assertIsNotNone(corredor, mensajes)
        self.assertEqual(len(corredor.sections), len(self.res.sections))

    def test_no_se_importan_las_tablas_internas(self):
        from aqgis_sivil3d.gis.paquete import INTERNAS, capas_de_grupo, exportar, importar

        gpkg = os.path.join(_TMP, "internas.gpkg")
        exportar(self._capas(), gpkg, self.res, "x", self.crs)
        QgsProject.instance().clear()
        grupo, _c, _m = importar(gpkg)
        nombres = {c.name() for c in capas_de_grupo(grupo)}
        for interna in INTERNAS:
            self.assertNotIn(interna, nombres)

    def test_los_nombres_con_espacios_se_conservan(self):
        from aqgis_sivil3d.gis.paquete import capas_de_grupo, exportar, importar

        gpkg = os.path.join(_TMP, "nombres.gpkg")
        exportar(self._capas(), gpkg, self.res, "x", self.crs)
        QgsProject.instance().clear()
        grupo, _c, _m = importar(gpkg)
        nombres = {c.name() for c in capas_de_grupo(grupo)}
        self.assertIn("feature lines", nombres)
        self.assertIn("mediciones", nombres)

    def test_los_estilos_vuelven(self):
        from qgis.core import QgsCategorizedSymbolRenderer

        from aqgis_sivil3d.gis.paquete import capas_de_grupo, exportar, importar

        gpkg = os.path.join(_TMP, "estilos.gpkg")
        exportar(self._capas(), gpkg, self.res, "x", self.crs)
        QgsProject.instance().clear()
        grupo, _c, _m = importar(gpkg)
        tin = [c for c in capas_de_grupo(grupo) if c.name().startswith("TIN")]
        self.assertTrue(tin)
        self.assertIsInstance(tin[0].renderer(), QgsCategorizedSymbolRenderer)

    def test_sin_json_se_recuperan_solo_las_capas(self):
        from aqgis_sivil3d.gis.paquete import exportar, importar, ruta_json

        gpkg = os.path.join(_TMP, "sin_json.gpkg")
        exportar(self._capas(), gpkg, self.res, "x", self.crs)
        os.remove(ruta_json(gpkg))
        QgsProject.instance().clear()
        grupo, corredor, mensajes = importar(gpkg)
        self.assertIsNotNone(grupo)
        self.assertIsNone(corredor)
        self.assertTrue(any("no se ha encontrado" in m for m in mensajes))

    def test_exportar_sin_capas(self):
        from aqgis_sivil3d.gis.paquete import exportar

        ok, mensajes = exportar([], os.path.join(_TMP, "vacio.gpkg"))
        self.assertFalse(ok)
        self.assertTrue(any("capas" in m for m in mensajes))

    def test_importar_lo_que_no_existe(self):
        from aqgis_sivil3d.gis.paquete import importar

        grupo, corredor, mensajes = importar(os.path.join(_TMP, "no_existe.gpkg"))
        self.assertIsNone(grupo)
        self.assertIsNone(corredor)
        self.assertTrue(mensajes)

    def test_capas_de_grupo_recorre_subgrupos(self):
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo
        from aqgis_sivil3d.gis.paquete import capas_de_grupo

        QgsProject.instance().clear()
        grupo = cargar_en_grupo(self._capas(), "g", QgsProject.instance())
        self.assertEqual(len(capas_de_grupo(grupo)), len(self._capas()))

    # -- varios corredores en el visor -------------------------------------
    def _dock(self):
        from qgis.gui import QgsMapCanvas

        from aqgis_sivil3d.ui.profile_dock import ProfileDock

        canvas = QgsMapCanvas()

        class Iface:
            def mainWindow(self):
                return None

            def mapCanvas(self):
                return canvas

        dock = ProfileDock(Iface())
        dock._canvas_ref = canvas
        return dock

    def test_el_visor_elige_entre_corredores(self):
        from aqgis_sivil3d.core import sesion

        otro = sesion.de_dict(sesion.a_dict(self.res, "importado"))
        dock = self._dock()
        dock.set_corredores({"A": self.res, "B": otro}, 1.0, activo="A")
        # Una fila por alineacion de cada corredor. Al abrir no sale ninguna
        # marcada (no hay capa activa), asi que aqui se marcan a mano: lo que se
        # comprueba es el dibujo, no la politica de marcado inicial.
        self.assertEqual(len(dock.selector), 2)
        dock.selector.marcar_todas(True)
        self.assertEqual(len(dock.selector.seleccionados()), 2)
        n_a = dock.cmb_pk.count()
        dock.selector.lista.setCurrentRow(1)
        self.assertEqual(dock.selector.actual()[1], "B")
        self.assertEqual(dock.cmb_pk.count(), n_a)
        self.assertFalse(dock.vista_long.datos.vacio)

    def test_el_visor_sin_corredores(self):
        dock = self._dock()
        dock.set_corredores({}, 1.0)
        self.assertTrue(dock.selector.vacio)
        self.assertEqual(dock.selector.seleccionados(), [])
        self.assertTrue(dock.vista_long.datos.vacio)

    def test_el_visor_funciona_con_un_corredor_importado(self):
        from aqgis_sivil3d.core import sesion

        recuperado = sesion.de_dict(sesion.a_dict(self.res, "recuperado"))
        dock = self._dock()
        dock.set_corredores({"recuperado": recuperado}, 1.0)
        self.assertEqual(len(dock.selector), 1)
        dock.selector.marcar_todas(True)
        self.assertGreater(dock.cmb_pk.count(), 5)
        self.assertFalse(dock.vista_sec.datos.vacio)
        self.assertFalse(dock.vista_masas.datos.vacio)
        self.assertIn("m3", dock.lbl_estado.text())

    def test_el_plugin_registra_varios_corredores(self):
        import aqgis_sivil3d
        from qgis.PyQt.QtWidgets import QMainWindow

        class Iface:
            def __init__(self):
                self.w = QMainWindow()

            def mainWindow(self):
                return self.w

            def addPluginToVectorMenu(self, _m, _a):
                pass

            def removePluginVectorMenu(self, _m, _a):
                pass

            def addToolBarIcon(self, _a):
                pass

            def addToolBarWidget(self, _w):
                return None

            def removeToolBarIcon(self, _a):
                pass

        plugin = aqgis_sivil3d.classFactory(Iface())
        a = plugin.guardar_resultado(self.res, 1.0, "eje-corridor")
        b = plugin.guardar_resultado(self.res, 1.0, "eje-corridor")
        self.assertEqual(a, "eje-corridor")
        self.assertEqual(b, "eje-corridor (2)", "no se deben machacar entre si")
        self.assertEqual(len(plugin.corredores), 2)

    def test_el_dialogo_de_planos_elige_corredor(self):
        from aqgis_sivil3d.core import sesion
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        otro = sesion.de_dict(sesion.a_dict(self.res, "B"))

        class Iface:
            def mainWindow(self):
                return None

            def activeLayer(self):
                return None

        dlg = PlanosDialog(Iface(), self.res, corredores={"A": self.res, "B": otro})
        # Las alineaciones de los dos corredores, todas disponibles a la vez.
        self.assertEqual(len(dlg.selector), len(self.res.runs) + len(otro.runs))
        self.assertEqual(
            len(dlg.selector.seleccionados()), len(dlg.selector)
        )
        dlg.selector.solo_actual()
        self.assertEqual(len(dlg.selector.seleccionados()), 1)


def _celdas_dibujadas(capas) -> list:
    """Rotulo de cabecera de cada celda de transversal: uno por seccion."""
    salida = []
    for capa in capas:
        if not capa.name().endswith("rotulos"):
            continue
        for f in capa.getFeatures():
            texto = f["texto"] or ""
            if "Sta " in texto:
                salida.append(texto)
    return salida


def _elegir_juego(dlg, clave: str) -> None:
    """Pone el desplegable de juego de planos en ese modo."""
    indice = [dlg.cmb_hojas.itemData(i) for i in range(dlg.cmb_hojas.count())]
    dlg.cmb_hojas.setCurrentIndex(indice.index(clave))


class IfaceFalso:
    """El ``iface`` de QGIS, lo justo para que el plugin arranque en los tests.

    Vive a nivel de modulo y no dentro de un metodo: una clase con diez metodos
    definida dentro de una funcion cuenta como complejidad de esa funcion, y el
    escaner del repositorio la marcaria.
    """

    def __init__(self, capa_activa=None):
        from qgis.gui import QgsMapCanvas
        from qgis.PyQt.QtWidgets import QMainWindow

        self._ventana = QMainWindow()
        self._canvas = QgsMapCanvas()
        self._capa = capa_activa
        self.docks = []
        self.acciones = []

    def mainWindow(self):
        return self._ventana

    def mapCanvas(self):
        return self._canvas

    def activeLayer(self):
        return self._capa

    def layerTreeView(self):
        return None

    def addDockWidget(self, _area, dock):
        self.docks.append(dock)

    def removeDockWidget(self, dock):
        if dock in self.docks:
            self.docks.remove(dock)

    def addPluginToVectorMenu(self, _menu, accion):
        self.acciones.append(accion)

    def removePluginVectorMenu(self, _menu, accion):
        if accion in self.acciones:
            self.acciones.remove(accion)

    def addToolBarIcon(self, _accion):
        pass

    def addToolBarWidget(self, _widget):
        return None

    def removeToolBarIcon(self, _accion):
        pass


def _titulos(hojas, contiene: str) -> list:
    """Textos de rotulo de las hojas que contienen ese trozo."""
    return [
        e.texto
        for h in hojas
        for e in h.entidades
        if e.texto and contiene in e.texto and len(e.puntos) == 1
    ]


class TestVariasAlineaciones(unittest.TestCase):
    """El minimenu de alineaciones del visor y de los planos.

    Un corredor puede tener varias alineaciones y una sesion varios corredores.
    Las dos herramientas tienen que dejar elegir cuales salen, y ademas hacer lo
    correcto con ellas: dibujarlas juntas donde tiene sentido (longitudinal,
    masas, planta) y por separado donde no (cubicaciones, tiras de perfil).
    """

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_varias.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        # Dos directrices distintas, paralelas y de distinta longitud.
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [
                feature_linea(
                    capa, [(X0 + 100, Y0 + 260), (X0 + 420, Y0 + 280)], ["x"]
                ),
                feature_linea(
                    capa, [(X0 + 100, Y0 + 500), (X0 + 300, Y0 + 520)], ["x"]
                ),
            ]
        )
        capa.updateExtents()
        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = -2.0
        cls.res = build_corridor(
            capa,
            cls.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=20.0),
                section=SectionOptions(paso=0.5, ancho_max=120.0, muestras_terreno=50),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        if len(cls.res.runs) != 2:
            raise RuntimeError("el corredor de prueba debe tener dos tramos")
        cls.tramos = [
            (r, [s for s in r.sections if s.vertices]) for r in cls.res.runs
        ]

    # -- el widget ---------------------------------------------------------
    def _selector(self, corredores=None):
        from aqgis_sivil3d.ui.selector_tramos import SelectorTramos

        sel = SelectorTramos()
        sel.set_corredores(corredores if corredores is not None else {"A": self.res})
        return sel

    def test_una_fila_por_alineacion_y_todas_marcadas(self):
        sel = self._selector()
        self.assertEqual(len(sel), 2)
        self.assertEqual(len(sel.seleccionados()), 2)
        self.assertFalse(sel.vacio)
        self.assertIn("2 of 2", sel.lbl_cuenta.text())

    def test_marcar_ninguna_al_cargar(self):
        from aqgis_sivil3d.ui.selector_tramos import MARCAR_NINGUNA, SelectorTramos

        sel = SelectorTramos()
        sel.set_corredores({"A": self.res}, marcar_todo=MARCAR_NINGUNA)
        self.assertEqual(len(sel), 2)
        self.assertEqual(sel.seleccionados(), [])

    def test_marcar_solo_las_de_la_capa_activa(self):
        """Lo que hace el visor al abrirse."""
        from aqgis_sivil3d.ui.selector_tramos import (
            MARCAR_CAPA_ACTIVA,
            SelectorTramos,
        )

        capa_id = self.res.runs[0].alignment.capa_id
        self.assertTrue(capa_id, "el tramo tiene que saber de que capa sale")
        sel = SelectorTramos()
        sel.set_corredores(
            {"A": self.res}, marcar_todo=MARCAR_CAPA_ACTIVA, capa_activa=capa_id
        )
        # Las dos directrices son de la misma capa, asi que entran las dos.
        self.assertEqual(len(sel.seleccionados()), 2)
        # Y con una capa activa ajena, ninguna.
        sel.set_corredores(
            {"A": self.res}, marcar_todo=MARCAR_CAPA_ACTIVA, capa_activa="otra_capa"
        )
        self.assertEqual(sel.seleccionados(), [])

    def test_sin_capa_activa_no_se_marca_nada(self):
        from aqgis_sivil3d.ui.selector_tramos import (
            MARCAR_CAPA_ACTIVA,
            SelectorTramos,
        )

        sel = SelectorTramos()
        sel.set_corredores({"A": self.res}, marcar_todo=MARCAR_CAPA_ACTIVA)
        self.assertEqual(sel.seleccionados(), [])

    def test_ordenar_por_nombre_y_por_fecha(self):
        from aqgis_sivil3d.core import sesion
        from aqgis_sivil3d.ui.selector_tramos import (
            ORDEN_FECHA,
            ORDEN_NOMBRE,
            SelectorTramos,
        )

        # Dos corredores: el que se llama antes por orden alfabetico se ha
        # creado despues, para que los dos criterios no coincidan.
        viejo = sesion.de_dict(sesion.a_dict(self.res, "Zeta"))
        viejo.creado = "2020-01-01T00:00:00"
        nuevo = sesion.de_dict(sesion.a_dict(self.res, "Alfa"))
        nuevo.creado = "2026-01-01T00:00:00"
        sel = SelectorTramos()
        sel.set_corredores({"Zeta": viejo, "Alfa": nuevo})

        sel.set_orden(ORDEN_FECHA)
        self.assertTrue(sel.lista.item(0).text().startswith("Zeta"))
        sel.set_orden(ORDEN_NOMBRE)
        self.assertTrue(sel.lista.item(0).text().startswith("Alfa"))

    def test_reordenar_no_cambia_el_color_ni_lo_marcado(self):
        """El color identifica la alineacion en el dibujo: no puede bailar."""
        from aqgis_sivil3d.core import sesion
        from aqgis_sivil3d.ui.selector_tramos import (
            ORDEN_FECHA,
            ORDEN_NOMBRE,
            SelectorTramos,
        )

        a = sesion.de_dict(sesion.a_dict(self.res, "Zeta"))
        b = sesion.de_dict(sesion.a_dict(self.res, "Alfa"))
        sel = SelectorTramos()
        sel.set_corredores({"Zeta": a, "Alfa": b})
        sel.marcar_todas(False)
        sel.marcar(0, True)
        antes = {i for i, _n, _r in sel.seleccionados()}
        sel.set_orden(ORDEN_NOMBRE)
        self.assertEqual({i for i, _n, _r in sel.seleccionados()}, antes)
        sel.set_orden(ORDEN_FECHA)
        self.assertEqual({i for i, _n, _r in sel.seleccionados()}, antes)
        # Y el indice que se devuelve sigue siendo el estable, no la fila.
        sel.set_principal(3)
        self.assertEqual(sel.actual()[0], 3)

    def test_con_un_corredor_la_fila_no_repite_su_nombre(self):
        sel = self._selector()
        texto = sel.lista.item(0).text()
        self.assertNotIn("A ·", texto)
        self.assertIn(self.res.runs[0].etiqueta, texto)

    def test_con_varios_corredores_la_fila_dice_de_cual_es(self):
        from aqgis_sivil3d.core import sesion

        otro = sesion.de_dict(sesion.a_dict(self.res, "B"))
        sel = self._selector({"A": self.res, "B": otro})
        self.assertEqual(len(sel), 4)
        self.assertTrue(sel.lista.item(0).text().startswith("A ·"))
        self.assertTrue(sel.lista.item(3).text().startswith("B ·"))
        self.assertEqual([n for _i, n, _r in sel.seleccionados()][2], "B")

    def test_seleccionados_devuelve_el_run_de_cada_fila(self):
        sel = self._selector()
        filas = sel.seleccionados()
        self.assertIs(filas[0][2], self.res.runs[0])
        self.assertIs(filas[1][2], self.res.runs[1])

    def test_todas_ninguna_y_solo_esta(self):
        sel = self._selector()
        avisos = []
        sel.cambiado.connect(lambda: avisos.append(1))
        sel.marcar_todas(False)
        self.assertEqual(sel.seleccionados(), [])
        self.assertIn("0 of 2", sel.lbl_cuenta.text())
        sel.marcar_todas(True)
        self.assertEqual(len(sel.seleccionados()), 2)
        sel.lista.setCurrentRow(1)
        sel.solo_actual()
        self.assertEqual([i for i, _n, _r in sel.seleccionados()], [1])
        self.assertEqual(len(avisos), 3, "cada accion avisa una sola vez")

    def test_marcar_a_mano_avisa(self):
        from aqgis_sivil3d.ui.qtcompat import SIN_MARCAR

        sel = self._selector()
        avisos = []
        sel.cambiado.connect(lambda: avisos.append(1))
        sel.lista.item(0).setCheckState(SIN_MARCAR)
        self.assertEqual(len(avisos), 1)
        self.assertEqual(len(sel.seleccionados()), 1)

    def test_la_fila_actual_es_la_primera_y_se_puede_cambiar(self):
        sel = self._selector()
        cambios = []
        sel.actual_cambiado.connect(lambda: cambios.append(1))
        self.assertEqual(sel.actual()[0], 0)
        sel.lista.setCurrentRow(1)
        self.assertIs(sel.actual()[2], self.res.runs[1])
        self.assertEqual(len(cambios), 1)

    def test_la_fila_actual_no_tiene_que_estar_marcada(self):
        """Se puede mirar la seccion de una alineacion que no sale en el conjunto."""
        sel = self._selector()
        sel.lista.setCurrentRow(1)
        sel.marcar(1, False)
        self.assertEqual([i for i, _n, _r in sel.seleccionados()], [0])
        self.assertEqual(sel.actual()[0], 1)

    def test_cada_alineacion_tiene_su_color(self):
        from aqgis_sivil3d.ui.selector_tramos import COLORES, color_de

        self.assertNotEqual(color_de(0).name(), color_de(1).name())
        self.assertEqual(color_de(len(COLORES)).name(), color_de(0).name())
        sel = self._selector()
        self.assertFalse(
            sel.lista.item(1).icon().isNull(), "falta el color en la lista"
        )

    def test_recargar_deja_el_selector_limpio(self):
        sel = self._selector()
        sel.set_corredores({})
        self.assertTrue(sel.vacio)
        self.assertEqual(sel.seleccionados(), [])
        self.assertIsNone(sel.actual())
        self.assertIn("no alignments", sel.lbl_cuenta.text())

    # -- el visor ----------------------------------------------------------
    def _dock(self):
        from qgis.gui import QgsMapCanvas

        from aqgis_sivil3d.ui.profile_dock import ProfileDock

        canvas = QgsMapCanvas()

        class Iface:
            def mainWindow(self):
                return None

            def mapCanvas(self):
                return canvas

        dock = ProfileDock(Iface())
        dock._canvas_ref = canvas
        dock.set_result(self.res)
        # Al abrir el visor no sale nada marcado si no hay capa activa. Estos
        # tests miran como se dibujan varias a la vez, asi que se marcan aqui.
        dock.selector.marcar_todas(True)
        return dock

    def test_el_visor_dibuja_las_dos_a_la_vez(self):
        dock = self._dock()
        self.assertEqual(len(dock.selector), 2)
        self.assertEqual(
            len(dock.vista_long.datos.extras), 1, "falta la otra alineacion"
        )
        self.assertEqual(len(dock.vista_masas.datos.extras), 1)
        extra = dock.vista_long.datos.extras[0]
        self.assertTrue(extra.discontinua)
        self.assertGreater(len(extra.puntos), 2)
        self.assertIn(self.res.runs[1].etiqueta, extra.etiqueta)

    def test_desmarcar_una_la_quita_del_dibujo(self):
        dock = self._dock()
        dock.selector.solo_actual()
        self.assertEqual(dock.vista_long.datos.extras, [])
        self.assertFalse(dock.vista_long.datos.vacio, "la principal sigue")

    def test_sin_ninguna_marcada_no_se_dibuja_nada(self):
        dock = self._dock()
        dock.selector.marcar_todas(False)
        self.assertTrue(dock.vista_long.datos.vacio)
        self.assertTrue(dock.vista_masas.datos.vacio)
        self.assertIn("No alignment is checked", dock.lbl_estado.text())

    def test_la_seccion_es_la_de_la_alineacion_actual(self):
        dock = self._dock()
        n0 = dock.cmb_pk.count()
        titulo0 = dock.vista_sec.datos.titulo
        dock.selector.lista.setCurrentRow(1)
        self.assertLess(dock.cmb_pk.count(), n0, "la segunda es mas corta")
        self.assertNotEqual(dock.vista_sec.datos.titulo, titulo0)
        self.assertIn(self.res.runs[1].etiqueta, dock.vista_sec.datos.titulo)

    def test_el_estado_resume_las_dos(self):
        dock = self._dock()
        texto = dock.lbl_estado.text()
        self.assertIn("2 alignments", texto)
        self.assertIn("m3", texto)
        for run in self.res.runs:
            self.assertIn(run.etiqueta, texto)

    def test_el_longitudinal_conjunto_se_titula_como_tal(self):
        dock = self._dock()
        self.assertIn("2 alignments", dock.vista_long.datos.titulo)
        # Y la principal queda identificada para no confundirla con la otra.
        self.assertIn(
            self.res.runs[0].etiqueta, dock.vista_long.datos.titulo_proyecto
        )

    def test_el_longitudinal_de_una_sola_no_lleva_leyenda(self):
        dock = self._dock()
        dock.selector.solo_actual()
        self.assertEqual(dock.vista_long.datos.extras, [])
        self.assertEqual(dock.vista_long.datos.titulo_proyecto, "")

    def test_las_vistas_se_pintan_con_las_dos(self):
        """Dibujar de verdad: es donde salen los errores de indices."""
        from qgis.PyQt.QtGui import QImage, QPainter

        formato = getattr(getattr(QImage, "Format", QImage), "Format_ARGB32")
        dock = self._dock()
        for vista in (dock.vista_long, dock.vista_masas, dock.vista_sec):
            vista.resize(600, 300)
            img = QImage(600, 300, formato)
            img.fill(0)
            pintor = QPainter(img)
            vista.render(pintor)
            pintor.end()

    # -- los planos --------------------------------------------------------
    def test_hojas_de_planta_de_varias_alineaciones(self):
        from aqgis_sivil3d.gis.laminas import (
            hojas_de_planta,
            hojas_de_planta_varias,
        )

        alineaciones = [r.alignment for r in self.res.runs]
        sueltas = [
            hojas_de_planta(a, escala=1000.0, crs=self.crs).featureCount()
            for a in alineaciones
        ]
        capa = hojas_de_planta_varias(alineaciones, escala=1000.0, crs=self.crs)
        self.assertEqual(capa.featureCount(), sum(sueltas))
        numeros = [f["hoja"] for f in capa.getFeatures()]
        self.assertEqual(
            numeros, list(range(1, len(numeros) + 1)), "numeracion seguida"
        )
        fids = {f["fid_dir"] for f in capa.getFeatures()}
        self.assertEqual(len(fids), 2, "las dos directrices tienen hojas")

    def test_las_celdas_de_transversales_dicen_de_que_eje_son(self):
        from aqgis_sivil3d.core.paperspace import (
            Reticula,
            laminas_de_transversales,
        )

        secciones = self.tramos[0][1][:4] + self.tramos[1][1][:4]
        hojas = laminas_de_transversales(secciones, Reticula.ajustada(420.0, 297.0))
        textos = _titulos(hojas, "Sta")
        self.assertEqual(len(textos), len(secciones))
        self.assertTrue(all("fid" in t for t in textos), textos[:3])
        self.assertTrue(any("fid 1 " in t for t in textos))
        self.assertTrue(any("fid 2 " in t for t in textos))
        # Con un solo eje no se ensucia el titulo.
        solas = laminas_de_transversales(
            self.tramos[0][1][:4], Reticula.ajustada(420.0, 297.0)
        )
        textos = _titulos(solas, "Sta")
        self.assertTrue(textos)
        self.assertFalse(any("fid" in t for t in textos), textos[:3])

    def test_la_tira_de_longitudinal_lleva_la_etiqueta_del_eje(self):
        from aqgis_sivil3d.core.paperspace import laminas_longitudinal

        hojas = laminas_longitudinal(self.tramos[0][1], etiqueta="tramo 7")
        titulos = _titulos(hojas, "LONGITUDINAL")
        self.assertTrue(titulos)
        self.assertTrue(all("tramo 7" in t for t in titulos), titulos)
        # Sin etiqueta, el titulo queda como estaba.
        sin = _titulos(laminas_longitudinal(self.tramos[0][1]), "LONGITUDINAL")
        self.assertTrue(all(t.startswith("PERFIL LONGITUDINAL   PK") for t in sin), sin)

    def _dialogo(self):
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        class Iface:
            def mainWindow(self):
                return None

            def activeLayer(self):
                return None

        return PlanosDialog(Iface(), self.res)

    def test_el_longitudinal_es_el_de_la_principal(self):
        """Un longitudinal es UN plano: el del recorrido de un eje.

        Las demas alineaciones no llevan su propia tira —eso serian planos
        distintos— sino que aparecen donde cortan ese plano vertical.
        """
        dlg = self._dialogo()
        tramos = [("A", r, ss) for r, ss in self.tramos]
        dlg.selector.set_principal(0)
        capas = dlg._longitudinal(tramos, "T", "", [])
        self.assertTrue(capas)
        rotulos = next(c for c in capas if c.name().endswith("rotulos"))
        titulos = [
            f["texto"]
            for f in rotulos.getFeatures()
            if "LONGITUDINAL" in (f["texto"] or "")
        ]
        self.assertTrue(titulos)
        # Todas las hojas caen dentro del recorrido de la principal.
        principal = self.tramos[0][1]
        largo = principal[-1].station.s
        for texto in titulos:
            trozo = texto.split("PK ", 1)[1]
            ini = float(trozo.split(" a ")[0])
            fin = float(trozo.split(" a ")[1].split()[0])
            self.assertGreaterEqual(ini, -1.0)
            self.assertLessEqual(fin, largo + 1.0, f"se sale del eje: {texto}")

    def test_cambiar_la_principal_cambia_el_longitudinal(self):
        dlg = self._dialogo()
        tramos = [("A", r, ss) for r, ss in self.tramos]
        largos = []
        for indice in (0, 1):
            dlg.selector.set_principal(indice)
            capas = dlg._longitudinal(tramos, "T", "", [])
            rotulos = next(c for c in capas if c.name().endswith("rotulos"))
            finales = []
            for f in rotulos.getFeatures():
                texto = f["texto"] or ""
                if "LONGITUDINAL" in texto:
                    trozo = texto.split("PK ", 1)[1]
                    finales.append(float(trozo.split(" a ")[1].split()[0]))
            largos.append(max(finales))
        # Los dos ejes de este caso tienen longitudes distintas.
        self.assertNotAlmostEqual(largos[0], largos[1], delta=1.0)

    def test_una_hoja_de_cubicaciones_por_eje(self):
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_TODAS

        dlg = self._dialogo()
        dlg.chk_cubicaciones.setChecked(True)
        _elegir_juego(dlg, HOJAS_TODAS)
        layouts: list = []
        dlg._transversales([("A", r, ss) for r, ss in self.tramos], "T", "", layouts)
        registro = dlg.log.toPlainText()
        for run, _ss in self.tramos:
            self.assertIn(f"earthworks {run.etiqueta}:", registro)

    def test_generar_con_las_dos_marcadas(self):
        dlg = self._dialogo()
        dlg.chk_pl.setChecked(False)
        dlg.chk_pdf.setChecked(False)
        dlg.chk_dxf.setChecked(False)
        dlg.ed_carpeta.setText("")
        dlg.generar()
        registro = dlg.log.toPlainText()
        self.assertIn("2 alignments", registro)
        self.assertIn("Done.", registro)
        self.assertNotIn("Error", registro)


class TestCurvaDeEmbalse(unittest.TestCase):
    """Cota-volumen-superficie de un vaso, contra la formula del cono.

    Para ``z = 100 + 0.2 r``, a la cota ``e`` el radio mojado es ``(e-100)/0.2``,
    la superficie es ``pi r^2`` y el volumen ``pi r^2 (e-100)/3``. Con celda de
    2 m el resultado discretizado se queda a menos del 1 %.
    """

    CENTRO = (X0 + 300.0, Y0 + 300.0)

    @classmethod
    def setUpClass(cls):
        cls.ruta = escribir_vaso("vaso_conico.tif")
        cls.crs = QgsCoordinateReferenceSystem(CRS)

    def setUp(self):
        from qgis.PyQt.QtWidgets import QMessageBox

        # La capa se rehace en cada test y se mete en el proyecto: el combo de
        # capas del dialogo solo admite capas registradas, y al limpiar el
        # proyecto el objeto de C++ desaparece, asi que no vale compartirla.
        QgsProject.instance().clear()
        self.dem = QgsRasterLayer(self.ruta, "vaso")
        QgsProject.instance().addMapLayer(self.dem)
        # Ningun aviso modal puede quedarse abierto: se recogen en una lista.
        self.avisos: list = []
        self._modales = (
            QMessageBox.warning,
            QMessageBox.critical,
            QMessageBox.information,
        )

        def recoge(*a, **_k):
            self.avisos.append(a[2] if len(a) > 2 else "")
            return None

        QMessageBox.warning = staticmethod(recoge)
        QMessageBox.critical = staticmethod(recoge)
        QMessageBox.information = staticmethod(recoge)

    def tearDown(self):
        from qgis.PyQt.QtWidgets import QMessageBox

        (
            QMessageBox.warning,
            QMessageBox.critical,
            QMessageBox.information,
        ) = self._modales

    def _teorico(self, cota: float):
        r = (cota - 100.0) / 0.2
        return math.pi * r * r, math.pi * r * r * (cota - 100.0) / 3.0

    # -- lectura del raster -------------------------------------------------
    def test_info_del_raster(self):
        from aqgis_sivil3d.gis.embalse import info_raster

        info = info_raster(self.dem)
        self.assertEqual((info["ancho"], info["alto"]), (300, 300))
        self.assertAlmostEqual(info["area_celda"], 4.0, places=6)
        self.assertAlmostEqual(info["nodata"], -9999.0)
        self.assertAlmostEqual(info["min"], 100.0, delta=0.5)
        self.assertIn("25830", info["crs"])

    def test_la_curva_cuadra_con_el_cono(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva

        curva = calcular_curva(self.dem, cota_ini=100.0, cota_fin=140.0, paso=0.5)
        for cota in (110.0, 120.0, 130.0):
            area, vol = self._teorico(cota)
            self.assertAlmostEqual(
                curva.area_en(cota) / area, 1.0, delta=0.02, msg=f"area a {cota}"
            )
            self.assertAlmostEqual(
                curva.volumen_en(cota) / vol, 1.0, delta=0.02, msg=f"volumen a {cota}"
            )

    def test_sin_rango_se_cubica_todo_el_raster(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva, info_raster

        info = info_raster(self.dem)
        curva = calcular_curva(self.dem, paso=2.0)
        self.assertAlmostEqual(curva.cotas[0], info["min"], places=3)
        self.assertAlmostEqual(curva.cotas[-1], info["max"], places=3)
        self.assertEqual(curva.n_celdas, 300 * 300)

    def test_el_camino_del_proveedor_da_lo_mismo_que_gdal(self):
        """Un WCS o un raster de memoria no los abre GDAL: hay dos caminos."""
        from aqgis_sivil3d.core.embalse import cotas as vector_cotas
        from aqgis_sivil3d.core.embalse import curva_de_bloques
        from aqgis_sivil3d.gis.embalse import bloques_gdal, bloques_qgis

        v = vector_cotas(100.0, 130.0, 1.0)
        por_gdal = curva_de_bloques(bloques_gdal(self.ruta), v, 4.0)
        por_qgis = curva_de_bloques(bloques_qgis(self.dem), v, 4.0)
        self.assertEqual(por_gdal.n_celdas, por_qgis.n_celdas)
        for a, b in zip(por_gdal.vol_m3, por_qgis.vol_m3):
            self.assertAlmostEqual(a, b, delta=max(1.0, abs(a) * 1e-6))

    def test_el_nodata_no_entra_en_la_cuenta(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva

        ruta = escribir_dem("vaso_con_hueco.tif", nodata_esquina=True)
        capa = QgsRasterLayer(ruta, "hueco")
        curva = calcular_curva(capa, paso=1.0)
        self.assertEqual(curva.n_celdas, 300 * 300 - 100)
        self.assertGreater(curva.cota_min, -9000.0, "el -9999 no puede colarse")

    # -- recorte ------------------------------------------------------------
    def test_recortar_deja_solo_el_vaso(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva, recortar

        pol = capa_poligono(self.CENTRO, 150.0)
        ruta, mensajes = recortar(
            self.dem, pol, destino=os.path.join(_TMP, "recorte_150.tif")
        )
        self.assertIsNotNone(ruta, mensajes)
        capa = QgsRasterLayer(ruta, "recorte")
        self.assertTrue(capa.isValid())
        stats = capa.dataProvider().bandStatistics(1)
        # El radio es 150 m y la pendiente 0.2: la cota maxima ronda 130.
        self.assertAlmostEqual(float(stats.maximumValue), 130.0, delta=1.0)
        curva = calcular_curva(capa, paso=0.5)
        radio = math.sqrt(curva.area_m2[-1] / math.pi)
        self.assertAlmostEqual(radio, 150.0, delta=2.0)

    def test_recortar_solo_los_seleccionados(self):
        from aqgis_sivil3d.gis.embalse import recortar

        pol = capa_poligono(self.CENTRO, 100.0)
        ruta, mensajes = recortar(
            self.dem, pol, solo_seleccionados=True
        )
        self.assertIsNone(ruta, "sin seleccion no hay nada que recortar")
        self.assertTrue(any("seleccionados" in m for m in mensajes))
        pol.selectAll()
        ruta, mensajes = recortar(self.dem, pol, solo_seleccionados=True)
        self.assertIsNotNone(ruta, mensajes)

    def test_recortar_reproyecta_el_poligono(self):
        """El area de recorte puede venir en otro CRS: es lo normal."""
        from qgis.core import QgsCoordinateTransform

        from aqgis_sivil3d.gis.embalse import recortar

        pol = capa_poligono(self.CENTRO, 120.0)
        geo = QgsVectorLayer("Polygon?crs=EPSG:4326", "geo", "memory")
        ct = QgsCoordinateTransform(
            self.crs, QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance()
        )
        for f in pol.getFeatures():
            g = QgsGeometry(f.geometry())
            self.assertEqual(g.transform(ct), 0)
            nuevo = QgsFeature()
            nuevo.setGeometry(g)
            geo.dataProvider().addFeatures([nuevo])
        geo.updateExtents()
        ruta, mensajes = recortar(self.dem, geo)
        self.assertIsNotNone(ruta, mensajes)
        capa = QgsRasterLayer(ruta, "recorte_geo")
        stats = capa.dataProvider().bandStatistics(1)
        self.assertAlmostEqual(float(stats.maximumValue), 124.0, delta=2.0)

    def test_una_capa_sin_poligonos_no_recorta(self):
        from aqgis_sivil3d.gis.embalse import recortar

        vacia = QgsVectorLayer(f"Polygon?crs={CRS}", "vacia", "memory")
        ruta, mensajes = recortar(self.dem, vacia)
        self.assertIsNone(ruta)
        self.assertTrue(mensajes)

    # -- estilo -------------------------------------------------------------
    def test_el_estilo_del_vaso_estira_la_rampa(self):
        from aqgis_sivil3d.gis.estilos import RAMPA_VASO, estilo_vaso

        capa = QgsRasterLayer(self.ruta, "para_estilar")
        self.assertTrue(estilo_vaso(capa, 115.0, 161.0))
        ren = capa.renderer()
        self.assertAlmostEqual(ren.classificationMin(), 115.0)
        self.assertAlmostEqual(ren.classificationMax(), 161.0)
        items = ren.shader().rasterShaderFunction().colorRampItemList()
        self.assertEqual(len(items), len(RAMPA_VASO))
        # Los extremos son los pedidos y la rampa va de azul oscuro a claro.
        self.assertAlmostEqual(items[0].value, 115.0)
        self.assertAlmostEqual(items[-1].value, 161.0)
        self.assertEqual(items[0].color.name(), "#08306b")
        self.assertEqual(items[-1].color.name(), "#baefff")
        # Y la orilla es semitransparente, que es lo que deja ver el terreno.
        self.assertEqual(items[0].color.alpha(), 255)
        self.assertEqual(items[-1].color.alpha(), 102)

    def test_el_estilo_aguanta_un_rango_nulo(self):
        from aqgis_sivil3d.gis.estilos import estilo_vaso

        capa = QgsRasterLayer(self.ruta, "plano")
        self.assertTrue(estilo_vaso(capa, 120.0, 120.0))
        ren = capa.renderer()
        self.assertGreater(ren.classificationMax(), ren.classificationMin())

    def test_capa_de_vaso_carga_y_estila(self):
        from aqgis_sivil3d.gis.embalse import capa_de_vaso, recortar

        pol = capa_poligono(self.CENTRO, 110.0)
        ruta, _m = recortar(self.dem, pol)
        capa = capa_de_vaso(ruta, "vaso recortado")
        self.assertIsNotNone(capa)
        self.assertEqual(capa.name(), "vaso recortado")
        ren = capa.renderer()
        self.assertEqual(type(ren).__name__, "QgsSingleBandPseudoColorRenderer")
        stats = capa.dataProvider().bandStatistics(1)
        self.assertAlmostEqual(ren.classificationMax(), float(stats.maximumValue), places=3)

    def test_capa_de_vaso_con_una_ruta_mala(self):
        from aqgis_sivil3d.gis.embalse import capa_de_vaso

        self.assertIsNone(capa_de_vaso(os.path.join(_TMP, "no_existe.tif")))

    # -- la vista -----------------------------------------------------------
    def test_la_vista_dibuja_y_exporta(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva
        from aqgis_sivil3d.ui.curva_view import CurvaView, datos_de_lectura

        curva = calcular_curva(self.dem, cota_ini=100.0, cota_fin=140.0, paso=1.0)
        v = CurvaView()
        v.resize(700, 500)
        v.set_curva(curva, "prueba")
        img = v.imagen(900, 600, 1.4)
        self.assertEqual((img.width(), img.height()), (900, 600))
        ruta = os.path.join(_TMP, "curva.png")
        self.assertTrue(img.save(ruta, "PNG"))
        self.assertGreater(os.path.getsize(ruta), 1000)
        # La lectura de un punto da los tres numeros con unidades.
        c, vol, area = datos_de_lectura(curva, 120.0)
        self.assertIn("msnm", c)
        self.assertIn("hm3", vol)
        self.assertIn("ha", area)

    def test_la_vista_vacia_no_falla(self):
        from aqgis_sivil3d.ui.curva_view import CurvaView

        v = CurvaView()
        v.resize(400, 300)
        v.limpiar("nada")
        img = v.imagen(400, 300)
        self.assertEqual(img.width(), 400)

    def test_pinchar_en_la_vista_fija_la_cota(self):
        from aqgis_sivil3d.gis.embalse import calcular_curva
        from aqgis_sivil3d.ui.curva_view import CurvaView

        curva = calcular_curva(self.dem, cota_ini=100.0, cota_fin=140.0, paso=1.0)
        v = CurvaView()
        v.resize(700, 500)
        v.set_curva(curva)
        v.imagen(700, 500)  # deja los paneles calculados
        i = v.indice_de(123.4)
        self.assertAlmostEqual(curva.cotas[i], 123.0, delta=1.0)

    # -- el dialogo ---------------------------------------------------------
    def _dialogo(self):
        from aqgis_sivil3d.ui.embalse_dialog import EmbalseDialog

        class Iface:
            def mainWindow(self):
                return None

        return EmbalseDialog(Iface())

    def test_el_dialogo_se_construye_y_lee_el_dem(self):
        dlg = self._dialogo()
        dlg.cmb_dem.setLayer(self.dem)
        self.assertIn("300 x 300", dlg.lbl_info.text())
        self.assertIn("25830", dlg.lbl_info.text())
        # El rango se rellena solo con los extremos del raster.
        self.assertAlmostEqual(dlg.sp_ini.value(), 100.0, delta=0.5)
        self.assertFalse(dlg.sp_ini.isEnabled(), "en automatico no se editan")
        dlg.chk_auto.setChecked(False)
        self.assertTrue(dlg.sp_ini.isEnabled())

    def test_sin_recorte_solo_csv_y_png(self):
        dlg = self._dialogo()
        dlg.cmb_dem.setLayer(self.dem)
        dlg.sp_paso.setValue(2.0)
        dlg.ed_carpeta.setText(_TMP)
        antes = set(QgsProject.instance().mapLayers().keys())
        dlg.calcular()
        self.assertIsNotNone(dlg.curva)
        self.assertEqual(
            set(QgsProject.instance().mapLayers().keys()),
            antes,
            "sin recorte no se carga ninguna capa",
        )
        base = dlg._base()
        self.assertTrue(os.path.isfile(os.path.join(_TMP, base + ".csv")), base)
        self.assertTrue(os.path.isfile(os.path.join(_TMP, base + ".png")), base)
        self.assertIn("hm3", dlg.lbl_estado.text())

    def test_con_recorte_carga_el_dem_estilado(self):
        dlg = self._dialogo()
        pol = capa_poligono(self.CENTRO, 140.0)
        QgsProject.instance().addMapLayer(pol)
        dlg.cmb_dem.setLayer(self.dem)
        dlg.chk_recorte.setChecked(True)
        dlg.cmb_pol.setLayer(pol)
        dlg.sp_paso.setValue(1.0)
        dlg.ed_carpeta.setText(_TMP)
        dlg.calcular()
        self.assertIsNotNone(dlg.curva)
        rasters = [
            c
            for c in QgsProject.instance().mapLayers().values()
            if isinstance(c, QgsRasterLayer) and "basin" in c.name()
        ]
        self.assertTrue(
            any(c.name().endswith("· basin") for c in rasters),
            [c.name() for c in QgsProject.instance().mapLayers().values()],
        )
        recorte = next(c for c in rasters if c.name().endswith("· basin"))
        self.assertEqual(
            type(recorte.renderer()).__name__, "QgsSingleBandPseudoColorRenderer"
        )
        # Y la curva es la del recorte, no la del DEM entero.
        self.assertLess(dlg.curva.cotas[-1], 130.0)
        # Los archivos llevan sufijo para no machacar los del DEM completo.
        base = dlg._base()
        self.assertTrue(os.path.isfile(os.path.join(_TMP, base + ".csv")), base)

    def test_el_recorte_sin_capa_de_poligonos_avisa(self):
        dlg = self._dialogo()
        dlg.cmb_dem.setLayer(self.dem)
        dlg.chk_recorte.setChecked(True)
        dlg.cmb_pol.setLayer(None)
        dlg.calcular()
        self.assertTrue(any("polygon" in a for a in self.avisos), self.avisos)
        self.assertIsNone(dlg.curva)

    def test_el_paso_ridiculo_se_rechaza(self):
        dlg = self._dialogo()
        dlg.cmb_dem.setLayer(self.dem)
        dlg.chk_auto.setChecked(False)
        dlg.sp_ini.setValue(0.0)
        dlg.sp_fin.setValue(8000.0)
        dlg.sp_paso.setValue(0.001)
        dlg.calcular()
        self.assertTrue(any("maximum" in a for a in self.avisos), self.avisos)
        self.assertIsNone(dlg.curva, "no se puede haber cubicado nada")

    def test_guardar_a_mano_escribe_los_dos(self):
        dlg = self._dialogo()
        self.assertIsNotNone(self.dem.dataProvider())
        dlg.cmb_dem.setLayer(self.dem)
        dlg.sp_paso.setValue(4.0)
        dlg.chk_auto_guardar.setChecked(False)
        dlg.calcular()
        self.assertIsNotNone(dlg.curva)
        csv = os.path.join(_TMP, "a_mano.csv")
        png = os.path.join(_TMP, "a_mano.png")
        self.assertTrue(dlg._escribir_csv(csv))
        self.assertTrue(dlg._escribir_png(png))
        with open(csv, encoding="utf-8-sig") as f:
            lineas = f.read().strip().split(chr(10))
        self.assertEqual(len(lineas), len(dlg.curva.cotas) + 1)
        self.assertGreater(os.path.getsize(png), 1000)


def _click(
    x: float,
    y: float,
    mover: bool = False,
    tipo: str = "",
    derecho: bool = False,
    mods=None,
):
    """Evento de raton para probar la vista sin interfaz.

    Los enums van por ``miembro()``: en PyQt6 no existen planos, y estos son
    justo los que hacen falta para simular la digitalizacion.
    """
    from qgis.PyQt.QtCore import QEvent, QPointF, Qt
    from qgis.PyQt.QtGui import QMouseEvent

    from aqgis_sivil3d.ui.qtcompat import (
        BOTON_DERECHO,
        BOTON_IZQUIERDO,
        miembro,
    )

    clase = tipo or ("MouseMove" if mover else "MouseButtonPress")
    boton = BOTON_DERECHO if derecho else BOTON_IZQUIERDO
    return QMouseEvent(
        miembro(QEvent, clase, "Type"),
        QPointF(x, y),
        boton,
        boton,
        mods if mods is not None else miembro(Qt, "NoModifier", "KeyboardModifier"),
    )


def _tecla(clave: str):
    """Evento de teclado por nombre de tecla (``Key_Escape``, ``Key_Delete``)."""
    from qgis.PyQt.QtCore import QEvent, Qt
    from qgis.PyQt.QtGui import QKeyEvent

    from aqgis_sivil3d.ui.qtcompat import miembro

    return QKeyEvent(
        miembro(QEvent, "KeyPress", "Type"),
        miembro(Qt, clave, "Key"),
        miembro(Qt, "NoModifier", "KeyboardModifier"),
    )


def _rueda(vista, delta: int, x: float, y: float) -> None:
    from qgis.PyQt.QtCore import QPoint, QPointF, Qt
    from qgis.PyQt.QtGui import QWheelEvent

    from aqgis_sivil3d.ui.qtcompat import miembro

    evento = QWheelEvent(
        QPointF(x, y),
        QPointF(x, y),
        QPoint(0, 0),
        QPoint(0, delta),
        miembro(Qt, "NoButton", "MouseButton"),
        miembro(Qt, "NoModifier", "KeyboardModifier"),
        miembro(Qt, "ScrollUpdate", "ScrollPhase"),
        False,
    )
    vista.wheelEvent(evento)


class TestEditorDeRasantes(unittest.TestCase):
    """El perfil longitudinal editable y la escritura de la rasante en la Z."""

    @classmethod
    def setUpClass(cls):
        cls.ruta_dem = escribir_dem("dem_editor_rasante.tif", pendiente=0.10)
        cls.crs = QgsCoordinateReferenceSystem(CRS)

    def setUp(self):
        from qgis.PyQt.QtWidgets import QMessageBox

        QgsProject.instance().clear()
        self.dem = QgsRasterLayer(self.ruta_dem, "dem")
        QgsProject.instance().addMapLayer(self.dem)
        self.capa = capa_lineas(
            [], [QgsField("n", QMetaType.Type.QString, len=20)]
        )
        self.capa.dataProvider().addFeatures(
            [
                feature_linea(
                    self.capa,
                    [(X0 + 60, Y0 + 150), (X0 + 300, Y0 + 260), (X0 + 540, Y0 + 180)],
                    ["A"],
                )
            ]
        )
        self.capa.updateExtents()
        QgsProject.instance().addMapLayer(self.capa)
        self.avisos: list = []
        self._modales = (QMessageBox.warning, QMessageBox.question)

        def recoge(*a, **_k):
            self.avisos.append(a[2] if len(a) > 2 else "")
            return None

        from aqgis_sivil3d.ui.qtcompat import BOTON_SI

        QMessageBox.warning = staticmethod(recoge)
        QMessageBox.question = staticmethod(lambda *a, **k: BOTON_SI)

    def tearDown(self):
        from qgis.PyQt.QtWidgets import QMessageBox

        QMessageBox.warning, QMessageBox.question = self._modales

    # -- perfil del terreno bajo la directriz -------------------------------
    def test_abscisas_y_punto_en(self):
        from aqgis_sivil3d.gis.rasante import abscisas, punto_en

        pts = [(0.0, 0.0), (100.0, 0.0), (100.0, 50.0)]
        self.assertEqual(abscisas(pts), [0.0, 100.0, 150.0])
        self.assertEqual(punto_en(pts, 50.0), (50.0, 0.0))
        self.assertEqual(punto_en(pts, 125.0), (100.0, 25.0))
        # Fuera de la linea se devuelven los extremos, no un error.
        self.assertEqual(punto_en(pts, -5.0), (0.0, 0.0))
        self.assertEqual(punto_en(pts, 999.0), (100.0, 50.0))

    def test_el_perfil_del_terreno_pasa_por_los_vertices(self):
        from aqgis_sivil3d.gis.rasante import abscisas, perfil_del_terreno

        terreno = make_terrain(self.dem, self.crs)
        pts = list(next(self.capa.getFeatures()).geometry().asPolyline())
        pts = [(p.x(), p.y()) for p in pts]
        perfil = perfil_del_terreno(pts, terreno.z, paso=10.0)
        self.assertGreater(len(perfil), 20)
        marcas = [round(s, 6) for s, _z in perfil]
        for s in abscisas(pts):
            self.assertIn(round(s, 6), marcas, "falta un vertice de la directriz")
        # Y las cotas son las del DEM en cada punto.
        from aqgis_sivil3d.gis.rasante import punto_en

        for s, z in perfil[::7]:
            x, y = punto_en(pts, s)
            self.assertAlmostEqual(z, terreno.z(x, y), places=4)

    def test_sin_terreno_no_hay_perfil(self):
        from aqgis_sivil3d.gis.rasante import perfil_del_terreno

        self.assertEqual(perfil_del_terreno([(0, 0), (10, 0)], None), [])
        self.assertEqual(perfil_del_terreno([(0, 0)], lambda x, y: 1.0), [])

    def test_el_hueco_del_dem_se_omite(self):
        from aqgis_sivil3d.gis.rasante import perfil_del_terreno

        pts = [(0.0, 0.0), (100.0, 0.0)]
        perfil = perfil_del_terreno(
            pts, lambda x, _y: None if x > 50 else 10.0, paso=10.0
        )
        self.assertTrue(perfil)
        self.assertLessEqual(max(s for s, _z in perfil), 50.0 + 1e-9)

    # -- leer y escribir la rasante en la geometria --------------------------
    def _capa_z(self):
        from qgis.core import QgsLineString, QgsPoint

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "eje3d", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("n", QMetaType.Type.QString, len=20)]
        )
        capa.updateFields()
        f = QgsFeature(capa.fields())
        f.setGeometry(
            QgsGeometry(
                QgsLineString(
                    [
                        QgsPoint(X0 + 60, Y0 + 150, 200.0),
                        QgsPoint(X0 + 300, Y0 + 260, 210.0),
                        QgsPoint(X0 + 540, Y0 + 180, 205.0),
                    ]
                )
            )
        )
        f.setAttributes(["A"])
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        return capa

    def test_rasante_de_geometria_lee_la_z(self):
        from aqgis_sivil3d.gis.rasante import rasante_de_geometria

        capa = self._capa_z()
        pts = [
            (v.x(), v.y(), v.z())
            for v in next(capa.getFeatures()).geometry().constGet().vertices()
        ]
        r = rasante_de_geometria(pts)
        self.assertEqual(len(r), 3)
        self.assertAlmostEqual(r[0].z, 200.0)
        self.assertAlmostEqual(r[2].z, 205.0)
        self.assertAlmostEqual(r.z_en(0.0), 200.0)

    def test_una_capa_2d_no_da_rasante(self):
        from aqgis_sivil3d.gis.rasante import rasante_de_geometria

        pts = [(0.0, 0.0), (100.0, 0.0)]
        self.assertTrue(rasante_de_geometria(pts).vacia)

    def test_puntos_con_rasante_densifica_el_acuerdo(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.gis.rasante import puntos_con_rasante

        pts = [(0.0, 0.0), (200.0, 0.0), (400.0, 0.0)]
        r = Rasante.de_puntos([(0, 100), (200, 90), (400, 100)])
        r.set_acuerdo(1, 100.0)
        sin = puntos_con_rasante(pts, r, paso=0.0)
        self.assertEqual(len(sin), 3, "sin paso, solo los vertices de la linea")
        con = puntos_con_rasante(pts, r, paso=10.0)
        self.assertGreater(len(con), 30)
        # La parabola queda recogida: en el vertice sube A*L/8 = 1.25 m.
        z_en_200 = next(z for x, _y, z in con if abs(x - 200.0) < 1e-6)
        self.assertAlmostEqual(z_en_200, 91.25, places=6)
        # Y los extremos del acuerdo estan entre los puntos.
        xs = [round(x, 3) for x, _y, _z in con]
        self.assertIn(150.0, xs)
        self.assertIn(250.0, xs)

    def test_aplicar_a_una_capa_con_z_edita_en_el_sitio(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.gis.rasante import aplicar_rasante

        capa = self._capa_z()
        fid = next(capa.getFeatures()).id()
        r = Rasante.de_puntos([(0.0, 300.0), (600.0, 306.0)])
        ok, mensajes, nueva = aplicar_rasante(capa, r, fid=fid, paso=25.0)
        self.assertTrue(ok, mensajes)
        self.assertIsNone(nueva, "la capa admite Z: no hace falta copia")
        vs = list(next(capa.getFeatures()).geometry().constGet().vertices())
        self.assertGreater(len(vs), 20, "se ha densificado")
        self.assertAlmostEqual(vs[0].z(), 300.0, places=3)
        self.assertGreater(vs[-1].z(), 300.0)
        # La planta no se toca: la rasante solo cambia la Z.
        self.assertAlmostEqual(vs[0].x(), X0 + 60, places=3)

    def test_aplicar_a_una_capa_2d_crea_la_copia(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.gis.rasante import aplicar_rasante

        fid = next(self.capa.getFeatures()).id()
        r = Rasante.de_puntos([(0.0, 220.0), (300.0, 214.0), (600.0, 222.0)])
        r.set_acuerdo(1, 120.0)
        ok, mensajes, nueva = aplicar_rasante(self.capa, r, fid=fid, paso=10.0)
        self.assertTrue(ok, mensajes)
        self.assertIsNotNone(nueva)
        self.assertTrue(QgsWkbTypes.hasZ(nueva.wkbType()))
        ft = next(nueva.getFeatures())
        self.assertEqual(ft["n"], "A", "los atributos viajan")
        zs = [v.z() for v in ft.geometry().constGet().vertices()]
        self.assertAlmostEqual(min(zs), 214.0 + 0.02 * 120.0 / 8.0, delta=0.6)

    def test_aplicar_con_un_fid_que_no_existe(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.gis.rasante import aplicar_rasante

        r = Rasante.de_puntos([(0.0, 100.0), (600.0, 100.0)])
        ok, mensajes, _n = aplicar_rasante(self.capa, r, fid=9999)
        self.assertFalse(ok)
        self.assertTrue(any("9999" in m for m in mensajes))

    def test_aplicar_una_rasante_vacia(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.gis.rasante import aplicar_rasante

        ok, mensajes, _n = aplicar_rasante(self.capa, Rasante(), fid=1)
        self.assertFalse(ok)
        self.assertTrue(any("dos vertices" in m for m in mensajes))

    # -- la vista ----------------------------------------------------------
    def _vista(self):
        from aqgis_sivil3d.core.rasante_geom import Rasante
        from aqgis_sivil3d.ui.rasante_view import RasanteView

        v = RasanteView()
        v.resize(800, 400)
        v.set_terreno([(s, 200.0 + 0.01 * s) for s in range(0, 601, 10)])
        v.set_rasante(Rasante.de_puntos([(0, 200), (300, 208), (600, 204)]))
        v._caja = v._geometria()
        return v

    def test_la_vista_transforma_en_los_dos_sentidos(self):
        v = self._vista()
        for s, z in ((0.0, 200.0), (300.0, 208.0), (555.5, 203.25)):
            q = v.px(s, z)
            s2, z2 = v.datos(q.x(), q.y())
            self.assertAlmostEqual(s2, s, places=3)
            self.assertAlmostEqual(z2, z, places=3)

    def test_la_vista_captura_vertices_tiradores_y_segmentos(self):
        from aqgis_sivil3d.core.rasante_geom import BEZIER

        v = self._vista()
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        self.assertEqual(v._que_hay_en(q.x(), q.y()), ("vertice", 1))
        v.rasante.set_tipo(0, BEZIER)
        c = v.rasante[0].control[0]
        q = v.px(c[0], c[1])
        self.assertEqual(v._que_hay_en(q.x(), q.y()), ("control", 0, 0))
        s_med = 150.0
        q = v.px(s_med, v.rasante.z_en(s_med))
        self.assertEqual(v._que_hay_en(q.x(), q.y()), ("segmento", 0))
        # Lejos de todo, nada.
        self.assertIsNone(v._que_hay_en(5.0, 5.0))

    def test_las_herramientas_de_tipo_cambian_el_segmento(self):
        from aqgis_sivil3d.ui.rasante_view import H_ARCO, H_BEZIER, H_NURBS

        for herramienta, esperado in (
            (H_ARCO, "arco"),
            (H_BEZIER, "bezier"),
            (H_NURBS, "nurbs"),
        ):
            v = self._vista()
            v.herramienta = herramienta
            q = v.px(150.0, v.rasante.z_en(150.0))
            v.mousePressEvent(_click(q.x(), q.y()))
            self.assertEqual(v.rasante[0].tipo, esperado)
            self.assertTrue(v.rasante[0].control)
            # Y la forma no ha cambiado: los controles nacen sobre la cuerda.
            self.assertAlmostEqual(v.rasante.z_en(150.0), 204.0, places=2)

    def test_insertar_y_borrar_con_el_raton(self):
        from aqgis_sivil3d.ui.rasante_view import H_BORRAR, H_INSERTAR

        v = self._vista()
        v.herramienta = H_INSERTAR
        q = v.px(150.0, 210.0)
        v.mousePressEvent(_click(q.x(), q.y()))
        self.assertEqual(len(v.rasante), 4)
        self.assertAlmostEqual(v.rasante[1].s, 150.0, delta=1.0)
        v.herramienta = H_BORRAR
        v._caja = v._geometria()
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mousePressEvent(_click(q.x(), q.y()))
        self.assertEqual(len(v.rasante), 3)

    def test_arrastrar_un_vertice(self):
        from aqgis_sivil3d.ui.rasante_view import H_MOVER

        v = self._vista()
        v.herramienta = H_MOVER
        z0 = v.rasante[1].z
        q = v.px(v.rasante[1].s, z0)
        v.mousePressEvent(_click(q.x(), q.y()))
        self.assertEqual(v.seleccion, ("vertice", 1))
        v.mouseMoveEvent(_click(q.x(), q.y() - 30, mover=True))
        v.mouseReleaseEvent(_click(q.x(), q.y() - 30))
        self.assertGreater(v.rasante[1].z, z0, "arrastrar hacia arriba sube la cota")

    def test_el_ajuste_al_terreno_pega_el_vertice(self):
        from aqgis_sivil3d.ui.rasante_view import H_MOVER

        v = self._vista()
        v.herramienta = H_MOVER
        v.ajustar_terreno = True
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mousePressEvent(_click(q.x(), q.y()))
        v.mouseMoveEvent(_click(q.x(), q.y() - 40, mover=True))
        v.mouseReleaseEvent(_click(q.x(), q.y() - 40))
        s = v.rasante[1].s
        self.assertAlmostEqual(v.rasante[1].z, v._z_terreno(s), places=6)

    def test_el_ajuste_a_valores_redondos(self):
        from aqgis_sivil3d.ui.rasante_view import H_INSERTAR

        v = self._vista()
        v.herramienta = H_INSERTAR
        v.paso_s = 25.0
        v.paso_cota = 0.5
        q = v.px(163.0, 205.3)
        v.mousePressEvent(_click(q.x(), q.y()))
        nuevo = v.rasante[1]
        self.assertAlmostEqual(nuevo.s % 25.0, 0.0, places=6)
        self.assertAlmostEqual((nuevo.z * 2) % 1.0, 0.0, places=6)

    def test_el_zoom_estrecha_la_ventana(self):
        v = self._vista()
        antes = v._limites()
        _rueda(v, 120, 400.0, 200.0)
        despues = v._limites()
        self.assertLess(despues[1] - despues[0], antes[1] - antes[0])
        v.encajar()
        self.assertEqual(v._limites(), antes)

    def test_la_vista_se_pinta_con_todo_puesto(self):
        from qgis.PyQt.QtGui import QImage, QPainter

        from aqgis_sivil3d.core.rasante_geom import BEZIER, NURBS

        v = self._vista()
        v.rasante.set_tipo(0, BEZIER)
        v.rasante.set_tipo(1, NURBS)
        v.rasante.set_acuerdo(1, 80.0)
        v.pks = [(0.0, "0+000"), (300.0, "0+300")]
        v.seleccion = ("vertice", 1)
        v._cursor = (250.0, 206.0)
        formato = getattr(getattr(QImage, "Format", QImage), "Format_ARGB32")
        img = QImage(800, 400, formato)
        img.fill(0)
        p = QPainter(img)
        v.render(p)
        p.end()
        # Se ha dibujado algo: mas de un color en el lienzo.
        colores = {
            img.pixel(x, y) for x in range(0, 800, 9) for y in range(0, 400, 9)
        }
        self.assertGreater(len(colores), 3)

    # -- el panel ----------------------------------------------------------
    def _editor(self):
        from qgis.gui import QgsMapCanvas

        from aqgis_sivil3d.ui.rasante_editor import RasanteEditor

        canvas = QgsMapCanvas()

        class Iface:
            def mainWindow(self):
                return None

            def mapCanvas(self):
                return canvas

        ed = RasanteEditor(Iface())
        ed._canvas_ref = canvas
        ed.cmb_capa.setLayer(self.capa)
        ed.cmb_dem.setLayer(self.dem)
        return ed

    def test_el_editor_arranca_con_la_directriz_y_el_dem(self):
        ed = self._editor()
        self.assertEqual(ed.cmb_tramo.count(), 1)
        self.assertGreater(len(ed.vista.terreno), 10)
        self.assertFalse(ed.rasante.vacia, "arranca del terreno solo")
        self.assertEqual(ed.tabla.rowCount(), len(ed.rasante))
        self.assertIn("vertices", ed.lbl_estado.text())

    def test_del_terreno_y_numero_de_vertices(self):
        ed = self._editor()
        ed.sp_n_vertices.setValue(8)
        ed.desde_terreno()
        self.assertEqual(len(ed.rasante), 8)
        self.assertEqual(ed.tabla.rowCount(), 8)
        # Y esta pegada al terreno.
        for v in ed.rasante.vertices:
            self.assertAlmostEqual(v.z, ed.vista._z_terreno(v.s), places=4)

    def test_de_la_z_de_la_capa(self):
        ed = self._editor()
        capa = self._capa_z()
        QgsProject.instance().addMapLayer(capa)
        ed.cmb_capa.setLayer(capa)
        self.assertEqual(len(ed.rasante), 3, "se lee la Z que ya tenia")
        self.assertAlmostEqual(ed.rasante[0].z, 200.0)
        self.assertIn("the layer Z", ed.lbl_estado.text())

    def test_la_tabla_edita_la_rasante(self):
        ed = self._editor()
        ed.desde_terreno()
        ed.tabla.item(0, 1).setText("250,5")
        self.assertAlmostEqual(ed.rasante[0].z, 250.5, places=6)
        ed.tabla.item(1, 0).setText("120")
        self.assertAlmostEqual(ed.rasante[1].s, 120.0, places=6)

    def test_las_columnas_calculadas_no_se_editan(self):
        from aqgis_sivil3d.ui.qtcompat import ITEM_EDITABLE

        ed = self._editor()
        ed.desde_terreno()
        for columna in (2, 4, 5):
            item = ed.tabla.item(0, columna)
            self.assertFalse(bool(item.flags() & ITEM_EDITABLE), columna)

    def test_la_k_desde_el_panel(self):
        ed = self._editor()
        ed.desde_terreno()
        ed.vista.seleccionar_vertice(1)
        ed.sp_k.setValue(20.0)
        ed._aplicar_k()
        k = ed.rasante.parametro_k(1)
        self.assertIsNotNone(k)
        self.assertAlmostEqual(k, 20.0, places=3)
        self.assertIn("20", ed.tabla.item(1, 4).text())

    def test_la_k_en_un_extremo_avisa(self):
        ed = self._editor()
        ed.desde_terreno()
        ed.vista.seleccionar_vertice(0)
        ed.sp_k.setValue(20.0)
        ed._aplicar_k()
        self.assertIn("inner one", ed.lbl_estado.text())

    def test_el_desplegable_de_tipo_cambia_el_segmento(self):
        from aqgis_sivil3d.core.rasante_geom import NURBS, TIPOS

        ed = self._editor()
        ed.desde_terreno()
        ed.vista.seleccionar_vertice(1)
        ed.cmb_tipo.setCurrentIndex(TIPOS.index(NURBS))
        self.assertEqual(ed.rasante[1].tipo, NURBS)
        self.assertEqual(ed.tabla.item(1, 2).text(), "NURBS")

    def test_la_herramienta_activa_es_exclusiva(self):
        from aqgis_sivil3d.ui.rasante_view import H_INSERTAR, H_MOVER

        ed = self._editor()
        ed.set_herramienta(H_INSERTAR)
        self.assertEqual(ed.vista.herramienta, H_INSERTAR)
        self.assertTrue(ed.botones[H_INSERTAR].isChecked())
        self.assertFalse(ed.botones[H_MOVER].isChecked())

    def test_el_editor_marca_en_planta(self):
        ed = self._editor()
        ed.desde_terreno()
        ed._raton_en(150.0, 210.0)
        self.assertIsNotNone(ed._marca)
        self.assertIsNotNone(ed._banda)
        ed.limpiar_mapa()
        self.assertIsNone(ed._marca)

    def test_aplicar_desde_el_panel(self):
        ed = self._editor()
        ed.desde_terreno()
        ed.sp_paso_aplicar.setValue(10.0)
        n_antes = len(ed.rasante)
        antes = set(QgsProject.instance().mapLayers().keys())
        ed.aplicar()
        nuevas = set(QgsProject.instance().mapLayers().keys()) - antes
        self.assertEqual(len(nuevas), 1, "la capa era 2D: se crea la copia con Z")
        nueva = QgsProject.instance().mapLayer(next(iter(nuevas)))
        self.assertTrue(QgsWkbTypes.hasZ(nueva.wkbType()))
        self.assertIn("rasante", ed.lbl_estado.text())
        self.assertEqual(
            len(ed.rasante), n_antes, "la rasante editada no se pierde al aplicar"
        )

    def test_aplicar_sobre_una_capa_con_z_y_volver_a_leerla(self):
        ed = self._editor()
        capa = self._capa_z()
        QgsProject.instance().addMapLayer(capa)
        ed.cmb_capa.setLayer(capa)
        ed.desde_terreno()
        ed.vista.seleccionar_vertice(1)
        ed.sp_k.setValue(15.0)
        ed._aplicar_k()
        ed.sp_paso_aplicar.setValue(5.0)
        ed.aplicar()
        cotas_editor = [
            round(z, 3) for z in ed.rasante.cotas_en([0.0, 100.0, 200.0])
        ]
        ed.desde_z()
        cotas_capa = [round(z, 3) for z in ed.rasante.cotas_en([0.0, 100.0, 200.0])]
        for a, b in zip(cotas_editor, cotas_capa):
            self.assertAlmostEqual(a, b, delta=0.02)

    def test_el_editor_sin_dem_no_revienta(self):
        ed = self._editor()
        ed.cmb_dem.setLayer(None)
        self.assertEqual(ed.vista.terreno, [])
        ed.desde_terreno()
        self.assertIn("DEM", ed.lbl_estado.text())

    # -- interaccion: modos frente a acciones -------------------------------
    def test_las_acciones_de_tipo_vuelven_a_mover(self):
        """Lo que hacia que los tiradores «no se pudiesen mover»."""
        from aqgis_sivil3d.ui.rasante_view import H_BEZIER, H_MOVER

        ed = self._editor()
        ed.desde_terreno()
        ed.set_herramienta(H_BEZIER)
        self.assertEqual(ed.vista.herramienta, H_BEZIER, "queda armada")
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        s_med = (v.rasante[0].s + v.rasante[1].s) / 2
        q = v.px(s_med, v.rasante.z_en(s_med))
        v.mousePressEvent(_click(q.x(), q.y()))
        self.assertEqual(v.rasante[0].tipo, H_BEZIER)
        self.assertEqual(v.herramienta, H_MOVER, "la accion devuelve el mando")
        self.assertTrue(ed.botones[H_MOVER].isChecked())
        self.assertFalse(ed.botones[H_BEZIER].isChecked())

    def test_arrastrar_el_tirador_justo_despues_de_convertir(self):
        from aqgis_sivil3d.ui.rasante_view import H_BEZIER

        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        ed.vista.seleccion = ("segmento", 0)
        ed.set_herramienta(H_BEZIER)
        v._caja = v._geometria()
        c0 = tuple(v.rasante[0].control[0])
        q = v.px(*c0)
        s_med = (v.rasante[0].s + v.rasante[1].s) / 2
        z_antes = v.rasante.z_en(s_med)
        v.mousePressEvent(_click(q.x(), q.y()))
        self.assertEqual(v.seleccion, ("control", 0, 0), "coge el tirador")
        v.mouseMoveEvent(_click(q.x(), q.y() - 50, mover=True))
        v.mouseReleaseEvent(_click(q.x(), q.y() - 50))
        self.assertGreater(v.rasante[0].control[0][1], c0[1], "el tirador sube")
        self.assertGreater(v.rasante.z_en(s_med), z_antes, "y la curva le sigue")
        self.assertEqual(len(v.rasante[0].control), 2, "sigue siendo la misma Bezier")

    def test_la_accion_se_aplica_al_segmento_seleccionado(self):
        from aqgis_sivil3d.core.rasante_geom import NURBS

        ed = self._editor()
        ed.desde_terreno()
        ed.vista.seleccion = ("segmento", 1)
        ed.set_herramienta(NURBS)
        self.assertEqual(ed.rasante[1].tipo, NURBS, "sin tener que pinchar otra vez")
        n = len(ed.rasante[1].control)
        ed.set_herramienta("control")
        self.assertEqual(len(ed.rasante[1].control), n + 1)

    def test_la_pista_dice_que_hacer(self):
        from aqgis_sivil3d.ui.rasante_view import H_ARCO, H_MOVER, PISTAS

        ed = self._editor()
        ed.desde_terreno()
        self.assertIn("Drag", ed.lbl_pista.text())
        ed.vista.seleccion = None
        ed.set_herramienta(H_ARCO)
        self.assertEqual(ed.lbl_pista.text(), PISTAS[H_ARCO])
        ed.set_herramienta(H_MOVER)
        self.assertEqual(ed.lbl_pista.text(), PISTAS[H_MOVER])

    def test_escape_vuelve_a_mover(self):
        from aqgis_sivil3d.ui.rasante_view import H_INSERTAR, H_MOVER

        ed = self._editor()
        ed.desde_terreno()
        ed.set_herramienta(H_INSERTAR)
        ed.vista.keyPressEvent(_tecla("Key_Escape"))
        self.assertEqual(ed.vista.herramienta, H_MOVER)
        self.assertTrue(ed.botones[H_MOVER].isChecked())

    def test_doble_clic_mete_vertice(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        n = len(v.rasante)
        s_med = (v.rasante[0].s + v.rasante[1].s) / 2
        q = v.px(s_med, v.rasante.z_en(s_med) + 2.0)
        v.mouseDoubleClickEvent(_click(q.x(), q.y(), tipo="MouseButtonDblClick"))
        self.assertEqual(len(v.rasante), n + 1)
        self.assertEqual(v.seleccion[0], "vertice")

    def test_el_boton_derecho_borra_el_vertice(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        n = len(v.rasante)
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mousePressEvent(_click(q.x(), q.y(), derecho=True))
        self.assertEqual(len(v.rasante), n - 1)
        self.assertIsNone(v.seleccion)

    def test_el_resalte_dice_que_se_puede_coger(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mouseMoveEvent(_click(q.x(), q.y(), mover=True))
        self.assertEqual(v._resaltado, ("vertice", 1))
        v.mouseMoveEvent(_click(5.0, 5.0, mover=True))
        self.assertIsNone(v._resaltado)
        v.leaveEvent(None)
        self.assertIsNone(v._resaltado)

    # -- varios vertices a la vez -------------------------------------------
    def test_ctrl_clic_acumula_vertices(self):
        from aqgis_sivil3d.ui.qtcompat import MOD_CONTROL

        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        for i in (1, 2):
            q = v.px(v.rasante[i].s, v.rasante[i].z)
            v.mousePressEvent(_click(q.x(), q.y(), mods=MOD_CONTROL))
            v.mouseReleaseEvent(_click(q.x(), q.y(), tipo="MouseButtonRelease"))
        self.assertEqual(v.seleccion_multiple, {1, 2})
        # Y volver a pulsarlo lo quita del grupo.
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mousePressEvent(_click(q.x(), q.y(), mods=MOD_CONTROL))
        self.assertEqual(v.seleccion_multiple, {2})

    def test_arrastrar_mueve_todo_el_grupo(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        v.seleccionar_varios([1, 2])
        antes = [(x.s, x.z) for x in v.rasante.vertices]
        q = v.px(v.rasante[1].s, v.rasante[1].z)
        v.mousePressEvent(_click(q.x(), q.y()))
        v.mouseMoveEvent(_click(q.x(), q.y() - 40, mover=True))
        v.mouseReleaseEvent(_click(q.x(), q.y() - 40, tipo="MouseButtonRelease"))
        subidas = [v.rasante[i].z - antes[i][1] for i in range(len(antes))]
        self.assertGreater(subidas[1], 0.5)
        self.assertAlmostEqual(subidas[1], subidas[2], places=6)
        for i in (0, 3):
            self.assertAlmostEqual(subidas[i], 0.0, places=9)

    def test_la_ventana_de_goma_selecciona(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.resize(800, 400)
        v._caja = v._geometria()
        v.limpiar_seleccion()
        zs = [x.z for x in v.rasante.vertices]
        # La ventana se abre con holgura: si un borde cae justo sobre el vertice,
        # que entre o no depende del redondeo a pixel.
        margen = (v.rasante[2].s - v.rasante[1].s) * 0.25
        a = v.px(v.rasante[1].s - margen, max(zs) + 5.0)
        b = v.px(v.rasante[2].s + margen, min(zs) - 5.0)
        v.mousePressEvent(_click(a.x(), a.y()))
        self.assertIsNotNone(v._goma, "pinchar en vacio abre la ventana")
        v.mouseMoveEvent(_click(b.x(), b.y(), mover=True))
        v.mouseReleaseEvent(_click(b.x(), b.y(), tipo="MouseButtonRelease"))
        self.assertIsNone(v._goma)
        self.assertEqual(v.seleccion_multiple, {1, 2})

    def test_supr_borra_todo_el_grupo(self):
        ed = self._editor()
        ed.sp_n_vertices.setValue(6)
        ed.desde_terreno()
        v = ed.vista
        n = len(v.rasante)
        v.seleccionar_varios([1, 2, 3])
        v.keyPressEvent(_tecla("Key_Delete"))
        self.assertEqual(len(v.rasante), n - 3)
        self.assertEqual(v.seleccion_multiple, set())

    def test_seleccionar_todos_y_limpiar(self):
        ed = self._editor()
        ed.desde_terreno()
        v = ed.vista
        v.seleccionar_todos()
        self.assertEqual(len(v.seleccion_multiple), len(v.rasante))
        v.limpiar_seleccion()
        self.assertEqual(v.seleccion_multiple, set())
        self.assertIsNone(v.seleccion)

    def test_el_boton_simplificar_del_panel(self):
        ed = self._editor()
        capa = self._capa_z_larga()
        QgsProject.instance().addMapLayer(capa)
        ed.sp_tolerancia.setValue(0.0)
        ed.cmb_capa.setLayer(capa)
        ed.desde_z()
        n = len(ed.rasante)
        self.assertGreater(n, 20, "sin tolerancia se leen todos los vertices")
        ed.sp_tolerancia.setValue(0.10)
        ed.simplificar()
        self.assertLess(len(ed.rasante), n)
        self.assertIn("Simplified", ed.lbl_pista.text())

    def test_leer_la_z_no_hereda_todos_los_vertices(self):
        """Lo que hacia inmanejable una rasante leida de una directriz larga."""
        ed = self._editor()
        capa = self._capa_z_larga()
        QgsProject.instance().addMapLayer(capa)
        ed.sp_tolerancia.setValue(0.05)
        ed.cmb_capa.setLayer(capa)
        self.assertLess(len(ed.rasante), 15, "la rasante se simplifica al leerla")
        self.assertGreaterEqual(len(ed.rasante), 2)
        self.assertIn("plan vertices", ed.lbl_estado.text())

    def _capa_z_larga(self):
        """Directriz de 120 vertices con una rasante de dos rampas escrita."""
        from qgis.core import QgsLineString, QgsPoint

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "eje_largo", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("n", QMetaType.Type.QString, len=10)]
        )
        capa.updateFields()
        puntos = []
        for i in range(120):
            s = i * 5.0
            z = 200.0 + (0.03 * s if s < 300 else 9.0 - 0.02 * (s - 300))
            puntos.append(QgsPoint(X0 + 60 + s, Y0 + 200 + 0.2 * s, z))
        f = QgsFeature(capa.fields())
        f.setGeometry(QgsGeometry(QgsLineString(puntos)))
        f.setAttributes(["L"])
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        return capa

    def test_una_capa_sin_lineas_deja_el_editor_vacio(self):
        ed = self._editor()
        vacia = capa_lineas([], [QgsField("n", QMetaType.Type.QString, len=5)])
        QgsProject.instance().addMapLayer(vacia)
        ed.cmb_capa.setLayer(vacia)
        self.assertEqual(ed.cmb_tramo.count(), 0)
        self.assertTrue(ed.rasante.vacia)
        self.assertEqual(ed.tabla.rowCount(), 0)


class TestSesionDelProyecto(unittest.TestCase):
    """Reabrir un proyecto y que las herramientas encuentren los corredores.

    Las secciones resueltas viven en memoria, no en las capas: sin guardarlas al
    lado del proyecto, al reabrirlo el visor y los planos decian «no hay
    corredores» aunque el grupo de capas estuviese delante.
    """

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        cls.ruta_dem = escribir_dem("dem_sesion.tif")
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        dem = QgsRasterLayer(cls.ruta_dem, "dem")
        terreno = make_terrain(dem, cls.crs)
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=20)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 300), (X0 + 420, Y0 + 320)], ["x"])]
        )
        capa.updateExtents()
        cls.res = build_corridor(
            capa,
            terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=100.0),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        cls.capas_res = [
            c
            for c in layers_from_result(cls.res, cls.crs, tz=terreno, con_pk=True)
            if c.featureCount()
        ]

    def setUp(self):
        QgsProject.instance().clear()
        self.ruta_proyecto = os.path.join(
            _TMP, f"proyecto_{self._testMethodName}.qgz"
        )

    def _iface(self):
        return IfaceFalso()

    # -- el archivo de sesion ----------------------------------------------
    def test_sin_proyecto_guardado_no_hay_archivo(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        self.assertEqual(sesion_proyecto.ruta_de_sesion(), "")
        self.assertEqual(sesion_proyecto.guardar({"A": self.res}), "")

    def test_el_archivo_va_al_lado_del_proyecto(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        ruta = sesion_proyecto.guardar({"A": self.res})
        self.assertTrue(os.path.isfile(ruta), ruta)
        self.assertTrue(ruta.endswith(sesion_proyecto.SUFIJO_SESION))
        # QGIS normaliza las barras del nombre de proyecto a "/".
        self.assertEqual(
            os.path.normcase(os.path.abspath(os.path.dirname(ruta))),
            os.path.normcase(os.path.abspath(os.path.dirname(self.ruta_proyecto))),
        )

    def test_ida_y_vuelta_de_la_sesion(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        sesion_proyecto.guardar({"mi corredor": self.res})
        corredores, mensajes = sesion_proyecto.cargar()
        self.assertIn("mi corredor", corredores)
        self.assertTrue(any("recuperados" in m for m in mensajes))
        recuperado = corredores["mi corredor"]
        self.assertEqual(len(recuperado.runs), len(self.res.runs))
        a = [s for s in self.res.runs[0].sections if s.vertices]
        b = [s for s in recuperado.runs[0].sections if s.vertices]
        self.assertEqual(len(a), len(b))
        self.assertAlmostEqual(b[3].z_eje, a[3].z_eje, places=6)

    def test_sin_corredores_se_borra_el_archivo(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        ruta = sesion_proyecto.guardar({"A": self.res})
        self.assertTrue(os.path.isfile(ruta))
        sesion_proyecto.guardar({})
        self.assertFalse(
            os.path.isfile(ruta), "un archivo vacio haria creer que hay corredores"
        )

    def test_un_archivo_ilegible_no_rompe_nada(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        with open(sesion_proyecto.ruta_de_sesion(), "w", encoding="utf-8") as fh:
            fh.write("esto no es json")
        corredores, mensajes = sesion_proyecto.cargar()
        self.assertEqual(corredores, {})
        self.assertTrue(mensajes)

    # -- desde un GeoPackage exportado -------------------------------------
    def test_se_recupera_de_un_gpkg_cargado(self):
        from aqgis_sivil3d.gis import sesion_proyecto
        from aqgis_sivil3d.gis.paquete import exportar, importar

        gpkg = os.path.join(_TMP, "sesion_paquete.gpkg")
        ok, _m = exportar(self.capas_res, gpkg, self.res, "eje-corridor", self.crs)
        self.assertTrue(ok)
        QgsProject.instance().clear()
        grupo, _c, _m = importar(gpkg)
        self.assertIsNotNone(grupo)
        corredores, mensajes = sesion_proyecto.de_paquetes()
        self.assertEqual(len(corredores), 1)
        self.assertTrue(any("recuperado" in m for m in mensajes))

    def test_un_gpkg_sin_json_no_aporta_nada(self):
        from aqgis_sivil3d.gis import sesion_proyecto
        from aqgis_sivil3d.gis.paquete import exportar, importar, ruta_json

        gpkg = os.path.join(_TMP, "sesion_sin_json.gpkg")
        exportar(self.capas_res, gpkg, self.res, "eje-corridor", self.crs)
        os.remove(ruta_json(gpkg))
        QgsProject.instance().clear()
        importar(gpkg)
        corredores, _m = sesion_proyecto.de_paquetes()
        self.assertEqual(corredores, {})

    # -- el plugin entero ---------------------------------------------------
    def test_el_plugin_recupera_al_abrir_el_proyecto(self):
        """El caso de la queja: sesion nueva, proyecto viejo con sus capas."""
        import aqgis_sivil3d
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo

        # Sesion 1: se calcula, se carga el grupo y se guarda el proyecto.
        plugin = aqgis_sivil3d.classFactory(self._iface())
        plugin.initGui()
        cargar_en_grupo(
            [c.clone() for c in self.capas_res], "eje-corridor", QgsProject.instance()
        )
        plugin.guardar_resultado(self.res, 1.0, "eje-corridor")
        QgsProject.instance().write(self.ruta_proyecto)
        plugin.unload()

        # Sesion 2: QGIS arranca de cero y se abre ese proyecto.
        QgsProject.instance().clear()
        plugin2 = aqgis_sivil3d.classFactory(self._iface())
        plugin2.initGui()
        self.assertEqual(len(plugin2.corredores), 0, "proyecto vacio")
        QgsProject.instance().read(self.ruta_proyecto)
        self.assertGreaterEqual(
            len(plugin2.corredores), 1, "los corredores tienen que volver solos"
        )
        self.assertIsNotNone(plugin2.ultimo_resultado)
        dock = plugin2.abrir_perfiles()
        self.assertGreaterEqual(len(dock.selector), 1)
        # El visor abre sin nada marcado; en cuanto se marca, dibuja.
        dock.selector.marcar_todas(True)
        self.assertFalse(dock.vista_long.datos.vacio)
        plugin2.unload()

    def test_los_planos_tambien_los_encuentran(self):
        import aqgis_sivil3d
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        plugin = aqgis_sivil3d.classFactory(self._iface())
        plugin.initGui()
        # El grupo tiene que estar en el proyecto: es la prueba de que el
        # corredor sigue vivo cuando se reabre.
        cargar_en_grupo(
            [c.clone() for c in self.capas_res], "eje-corridor", QgsProject.instance()
        )
        QgsProject.instance().write(self.ruta_proyecto)
        plugin.guardar_resultado(self.res, 1.0, "eje-corridor")
        plugin.unload()

        QgsProject.instance().clear()
        plugin2 = aqgis_sivil3d.classFactory(self._iface())
        plugin2.initGui()
        QgsProject.instance().read(self.ruta_proyecto)
        dlg = PlanosDialog(
            self._iface(), plugin2.ultimo_resultado, corredores=plugin2.corredores
        )
        self.assertGreaterEqual(len(dlg.selector), 1)
        plugin2.unload()

    # -- alineaciones que ya no estan cargadas ------------------------------
    def test_un_corredor_sin_nada_cargado_se_descarta(self):
        """El bug: el archivo de sesion devolvia alineaciones viejas y rotas."""
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        sesion_proyecto.guardar({"eje-corridor": self.res})
        # Se reabre sin el grupo de capas y sin la capa de directrices.
        QgsProject.instance().clear()
        QgsProject.instance().read(self.ruta_proyecto)
        corredores, mensajes = sesion_proyecto.recuperar()
        self.assertEqual(corredores, {})
        self.assertTrue(any("se descarta" in m for m in mensajes), mensajes)

    def test_con_su_grupo_cargado_se_conserva(self):
        from aqgis_sivil3d.gis import sesion_proyecto
        from aqgis_sivil3d.gis.outputs import cargar_en_grupo

        QgsProject.instance().write(self.ruta_proyecto)
        sesion_proyecto.guardar({"eje-corridor": self.res})
        cargar_en_grupo(
            [c.clone() for c in self.capas_res], "eje-corridor", QgsProject.instance()
        )
        corredores, _m = sesion_proyecto.recuperar()
        self.assertIn("eje-corridor", corredores)

    def test_con_su_capa_de_directrices_cargada_se_conserva(self):
        """Recien calculado: todavia no hay grupo, pero la capa esta."""
        from aqgis_sivil3d.gis import sesion_proyecto

        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=20)])
        QgsProject.instance().addMapLayer(capa)
        run = self.res.runs[0]
        previo = run.alignment.capa_id
        run.alignment.capa_id = capa.id()
        try:
            vivos, _m = sesion_proyecto.filtrar_por_capas({"sin grupo": self.res})
            self.assertIn("sin grupo", vivos)
        finally:
            run.alignment.capa_id = previo

    def test_el_grupo_con_sufijo_tambien_cuenta(self):
        """Al recalcular, el grupo sale como 'X (2)' y sigue siendo suyo."""
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().layerTreeRoot().addGroup("eje-corridor (2)")
        vivos, _m = sesion_proyecto.filtrar_por_capas({"eje-corridor": self.res})
        self.assertIn("eje-corridor", vivos)

    def test_la_capa_de_directrices_queda_anotada(self):
        """Sin esto no se puede saber si la alineacion sigue existiendo."""
        for run in self.res.runs:
            self.assertTrue(run.alignment.capa_id)
            self.assertTrue(run.alignment.capa_nombre)

    def test_la_capa_sobrevive_al_guardado(self):
        from aqgis_sivil3d.core import sesion

        ida = sesion.a_dict(self.res, "x")
        vuelta = sesion.de_dict(ida)
        self.assertEqual(
            vuelta.runs[0].alignment.capa_id, self.res.runs[0].alignment.capa_id
        )
        self.assertEqual(
            vuelta.runs[0].alignment.capa_nombre,
            self.res.runs[0].alignment.capa_nombre,
        )

    def test_un_archivo_viejo_sin_capa_no_revienta(self):
        """Los archivos de antes no llevan la anotacion: manda el grupo."""
        from aqgis_sivil3d.core import sesion
        from aqgis_sivil3d.gis import sesion_proyecto

        bruto = sesion.a_dict(self.res, "antiguo")
        for tramo in bruto["tramos"]:
            del tramo["alineacion"]["capa_id"]
            del tramo["alineacion"]["capa_nombre"]
        viejo = sesion.de_dict(bruto)
        self.assertEqual(viejo.runs[0].alignment.capa_id, "")
        vivos, _m = sesion_proyecto.filtrar_por_capas({"antiguo": viejo})
        self.assertEqual(vivos, {}, "sin grupo y sin capa, no queda nada")
        QgsProject.instance().layerTreeRoot().addGroup("antiguo")
        vivos, _m = sesion_proyecto.filtrar_por_capas({"antiguo": viejo})
        self.assertIn("antiguo", vivos)

    def test_limpiar_el_proyecto_vacia_los_corredores(self):
        import aqgis_sivil3d

        plugin = aqgis_sivil3d.classFactory(self._iface())
        plugin.initGui()
        plugin.guardar_resultado(self.res, 1.0, "eje-corridor")
        self.assertEqual(len(plugin.corredores), 1)
        QgsProject.instance().clear()
        self.assertEqual(
            len(plugin.corredores), 0, "otro proyecto, otros corredores"
        )
        plugin.unload()

    def test_no_se_machaca_lo_calculado_en_esta_sesion(self):
        from aqgis_sivil3d.gis import sesion_proyecto

        QgsProject.instance().write(self.ruta_proyecto)
        sesion_proyecto.guardar({"eje-corridor": self.res})
        encontrados, _m = sesion_proyecto.recuperar(
            ya_registrados={"eje-corridor": self.res}
        )
        self.assertEqual(
            encontrados, {}, "lo de la sesion de trabajo siempre es mas reciente"
        )


class TestPlanosConVariasAlineaciones(unittest.TestCase):
    """Que sale en los planos cuando hay mas de un trazado.

    El caso real: dos ejes paralelos y cercanos (una carretera y su reposicion).
    """

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        dem = QgsRasterLayer(escribir_dem("dem_planos_v2.tif"), "MDT")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        cls.ruta_dem = dem.source()
        # Dos ejes paralelos a 40 m.
        capa = capa_lineas([], [QgsField("n", QMetaType.Type.QString, len=12)])
        capa.dataProvider().addFeatures(
            [
                feature_linea(capa, [(X0 + 60, Y0 + 300), (X0 + 500, Y0 + 300)], ["a"]),
                feature_linea(capa, [(X0 + 60, Y0 + 340), (X0 + 500, Y0 + 340)], ["b"]),
            ]
        )
        capa.updateExtents()
        cls.res = build_corridor(
            capa,
            cls.terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=60.0),
                seccion_defecto="Road 1+1",
                intervalo_pk=100.0,
            ),
        )
        cls.tramos = [
            ("obra", r, [s for s in r.sections if s.vertices]) for r in cls.res.runs
        ]

    def setUp(self):
        QgsProject.instance().clear()
        self.dem = QgsRasterLayer(self.ruta_dem, "MDT")
        QgsProject.instance().addMapLayer(self.dem)
        self.directriz = capa_lineas(
            [], [QgsField("n", QMetaType.Type.QString, len=12)]
        )
        self.directriz.setName("ejes_obra")
        self.directriz.dataProvider().addFeatures(
            [
                feature_linea(
                    self.directriz, [(X0 + 60, Y0 + 300), (X0 + 500, Y0 + 300)], ["a"]
                )
            ]
        )
        self.directriz.updateExtents()
        QgsProject.instance().addMapLayer(self.directriz)
        # Ruido: lo que NO debe salir en el plano.
        for nombre in ("catastro", "lindes"):
            capa = QgsVectorLayer(f"Polygon?crs={CRS}", nombre, "memory")
            QgsProject.instance().addMapLayer(capa)
        for c in layers_from_result(self.res, self.crs, tz=self.terreno, con_pk=True):
            if c.featureCount():
                QgsProject.instance().addMapLayer(c)

    def _dialogo(self):
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        return PlanosDialog(IfaceFalso(), self.res)

    # -- la alineacion principal -------------------------------------------
    def test_la_principal_es_un_desplegable(self):
        dlg = self._dialogo()
        self.assertEqual(dlg.selector.cmb_principal.count(), 2)
        self.assertEqual(dlg.selector.principal()[0], 0)
        dlg.selector.set_principal(1)
        self.assertEqual(dlg.selector.principal()[0], 1)
        self.assertIn("fid 2", dlg.selector.etiqueta_principal())

    def test_la_lista_y_el_desplegable_van_juntos(self):
        dlg = self._dialogo()
        dlg.selector.lista.setCurrentRow(1)
        self.assertEqual(
            dlg.selector.cmb_principal.currentIndex(), 1, "la lista mueve el combo"
        )
        dlg.selector.set_principal(0)
        self.assertEqual(
            dlg.selector.lista.currentRow(), 0, "y el combo mueve la lista"
        )

    def test_solo_esta_deja_la_principal(self):
        dlg = self._dialogo()
        dlg.selector.set_principal(1)
        dlg.selector.solo_actual()
        marcadas = [i for i, _n, _r in dlg.selector.seleccionados()]
        self.assertEqual(marcadas, [1])

    # -- el selector de capas -----------------------------------------------
    def test_de_partida_solo_se_marcan_las_del_corredor(self):
        dlg = self._dialogo()
        marcadas = {c.name() for c in dlg.selector_capas.marcadas()}
        self.assertIn("TIN", marcadas)
        self.assertIn("axis", marcadas)
        self.assertIn("ejes_obra", marcadas, "la directriz tambien")
        self.assertNotIn("catastro", marcadas, "el ruido del proyecto se queda fuera")
        self.assertNotIn("lindes", marcadas)
        self.assertNotIn("MDT", marcadas, "un DEM en gris tapa el dibujo")

    def test_el_plano_solo_lleva_las_capas_marcadas(self):
        dlg = self._dialogo()
        n = len(dlg._capas_de_fondo())
        dlg.selector_capas.marcar_todas(False)
        self.assertEqual(dlg._capas_de_fondo(), [])
        dlg.selector_capas.marcar_todas(True)
        self.assertGreater(len(dlg._capas_de_fondo()), n)

    def test_el_boton_del_corredor(self):
        dlg = self._dialogo()
        dlg.selector_capas.marcar_todas(True)
        dlg.selector_capas.solo_corredor()
        marcadas = {c.name() for c in dlg.selector_capas.marcadas()}
        self.assertIn("TIN", marcadas)
        self.assertNotIn("catastro", marcadas)
        self.assertNotIn("ejes_obra", marcadas, "la directriz no es una salida")

    def test_las_capas_de_espacio_papel_no_se_listan(self):
        """Sus coordenadas son milimetros: en el mapa saldrian en otro continente."""
        from aqgis_sivil3d.core.paperspace import Reticula, laminas_de_transversales
        from aqgis_sivil3d.gis.laminas import capas_de_hojas
        from aqgis_sivil3d.ui.selector_capas import es_de_plano

        hojas = laminas_de_transversales(
            self.tramos[0][2][:4], Reticula.ajustada(420.0, 297.0)
        )
        capas = capas_de_hojas(hojas, "prueba")
        self.assertTrue(capas)
        for capa in capas:
            self.assertFalse(es_de_plano(capa), capa.name())

    # -- las hojas de planta -------------------------------------------------
    def test_la_principal_manda_en_las_hojas(self):
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_PRINCIPAL, HOJAS_TODAS

        dlg = self._dialogo()
        runs = [r for _n, r, _s in self.tramos]
        indice = [dlg.cmb_hojas.itemData(i) for i in range(dlg.cmb_hojas.count())]
        dlg.cmb_hojas.setCurrentIndex(indice.index(HOJAS_PRINCIPAL))
        capas = dlg._planta(runs, "T", "", [])
        hojas_p = next(c for c in capas if "hoja" in c.name().lower())
        n_principal = hojas_p.featureCount()
        dlg.cmb_hojas.setCurrentIndex(indice.index(HOJAS_TODAS))
        capas = dlg._planta(runs, "T", "", [])
        hojas_t = next(c for c in capas if "hoja" in c.name().lower())
        self.assertEqual(
            hojas_t.featureCount(),
            n_principal * 2,
            "con dos ejes paralelos, 'todas' imprime el doble de hojas",
        )
        # Y con la principal, todas las hojas son de su fid.
        dlg.cmb_hojas.setCurrentIndex(indice.index(HOJAS_PRINCIPAL))
        capas = dlg._planta(runs, "T", "", [])
        hojas_p = next(c for c in capas if "hoja" in c.name().lower())
        fids = {f["fid_dir"] for f in hojas_p.getFeatures()}
        self.assertEqual(len(fids), 1)

    # -- que alineaciones llevan planos propios ------------------------------
    def test_los_transversales_son_los_de_la_principal(self):
        """Un plano de transversales es el de UN eje, como el longitudinal.

        Salian los transversales de todas las alineaciones marcadas mezclados en
        la misma lamina, que son planos distintos impresos juntos: las demas
        tienen que salir como traza sobre los cortes de la principal.
        """
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_PRINCIPAL

        dlg = self._dialogo()
        _elegir_juego(dlg, HOJAS_PRINCIPAL)
        for indice in (0, 1):
            dlg.selector.set_principal(indice)
            dibujados = dlg._tramos_a_dibujar(self.tramos)
            self.assertEqual(len(dibujados), 1)
            self.assertIs(dibujados[0][1], self.tramos[indice][1])

    def test_con_un_juego_por_alineacion_salen_todas(self):
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_TODAS

        dlg = self._dialogo()
        _elegir_juego(dlg, HOJAS_TODAS)
        self.assertEqual(len(dlg._tramos_a_dibujar(self.tramos)), len(self.tramos))

    def test_el_modo_manda_en_las_secciones_dibujadas(self):
        """Lo que acaba en la lamina, no solo lo que decide el reparto."""
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_PRINCIPAL, HOJAS_TODAS

        dlg = self._dialogo()
        dlg.selector.set_principal(0)
        dlg.chk_cubicaciones.setChecked(False)
        dibujadas = {}
        for clave in (HOJAS_PRINCIPAL, HOJAS_TODAS):
            _elegir_juego(dlg, clave)
            capas = dlg._transversales(self.tramos, "T", "", [])
            self.assertTrue(capas)
            dibujadas[clave] = _celdas_dibujadas(capas)
        self.assertEqual(len(dibujadas[HOJAS_PRINCIPAL]), len(self.tramos[0][2]))
        self.assertEqual(
            len(dibujadas[HOJAS_TODAS]),
            sum(len(ss) for _n, _r, ss in self.tramos),
            "con un juego por alineacion salen las secciones de las dos",
        )
        # Con una sola alineacion el rotulo no lleva el fid: no hace falta.
        self.assertFalse(any("fid" in t for t in dibujadas[HOJAS_PRINCIPAL]))
        self.assertTrue(all("fid" in t for t in dibujadas[HOJAS_TODAS]))

    def test_las_cruces_solo_se_calculan_de_lo_que_se_dibuja(self):
        """No hace falta cortar las secciones de un eje que no lleva plano."""
        from aqgis_sivil3d.ui.planos_dialog import HOJAS_PRINCIPAL

        dlg = self._dialogo()
        _elegir_juego(dlg, HOJAS_PRINCIPAL)
        dlg.selector.set_principal(0)
        dlg.chk_otros.setChecked(True)
        cruces = dlg._cruces_de(self.tramos)
        de_la_principal = {id(s) for s in self.tramos[0][2]}
        self.assertTrue(cruces)
        for clave in cruces:
            self.assertIn(clave, de_la_principal)

    # -- los otros corredores en el dibujo ----------------------------------
    def test_las_transversales_ensenan_el_otro_eje(self):
        dlg = self._dialogo()
        dlg.chk_otros.setChecked(True)
        cruces = dlg._cruces_de(self.tramos)
        self.assertTrue(cruces, "los dos ejes van a 40 m: tienen que verse")
        etiqueta, puntos = next(iter(cruces.values()))[0]
        self.assertTrue(etiqueta.startswith("fid"))
        # El signo depende de a que lado cae: la normal apunta a la derecha del
        # avance, y este eje va en +X con el otro en +Y, o sea a su izquierda.
        offsets = [o for o, _z in puntos]
        medio = sum(offsets) / len(offsets)
        self.assertAlmostEqual(abs(medio), 40.0, delta=8.0, msg="a unos 40 m del eje")
        self.assertLess(medio, 0.0, "el otro eje queda a la izquierda")

    def test_la_casilla_apaga_la_superposicion(self):
        dlg = self._dialogo()
        dlg.chk_otros.setChecked(False)
        self.assertEqual(dlg._cruces_de(self.tramos), {})
        self.assertEqual(
            dlg._cortes_del_longitudinal(self.tramos[0][1], self.tramos), []
        )

    def test_el_longitudinal_solo_lleva_la_principal(self):
        """Un longitudinal es UN plano: el del recorrido de la principal."""
        dlg = self._dialogo()
        layouts = []
        dlg.selector.set_principal(0)
        capas = dlg._longitudinal(self.tramos, "T", "", layouts)
        self.assertTrue(capas)
        rotulos = next(c for c in capas if c.name().endswith("rotulos"))
        titulos = [
            f["texto"]
            for f in rotulos.getFeatures()
            if "LONGITUDINAL" in (f["texto"] or "")
        ]
        self.assertTrue(titulos)
        # Los PK del dibujo no pueden pasar del recorrido de la principal.
        principal = self.tramos[0][2]
        largo = principal[-1].station.s
        hojas = next(c for c in capas if "hoja" in c.name().lower() or True)
        del hojas
        for texto in titulos:
            trozo = texto.split("PK ", 1)[1]
            fin = float(trozo.split(" a ")[1].split()[0])
            self.assertLessEqual(fin, largo + 1.0)

    def test_los_ejes_paralelos_no_cortan_el_longitudinal(self):
        """Si no lo cruzan, no aparecen: no es una comparacion, es un corte."""
        dlg = self._dialogo()
        dlg.chk_otros.setChecked(True)
        cortes = dlg._cortes_del_longitudinal(self.tramos[0][1], self.tramos)
        self.assertEqual(cortes, [], "van paralelos a 40 m: no se cruzan")

    def test_con_un_solo_tramo_no_hay_nada_que_superponer(self):
        dlg = self._dialogo()
        dlg.chk_otros.setChecked(True)
        uno = self.tramos[:1]
        self.assertEqual(dlg._cruces_de(uno), {})
        self.assertEqual(dlg._cortes_del_longitudinal(uno[0][1], uno), [])

    def _dock(self):
        """El visor de perfiles con estos dos ejes, que van a 40 m."""
        from aqgis_sivil3d.ui.profile_dock import ProfileDock

        dock = ProfileDock(IfaceFalso())
        dock.set_result(self.res)
        # Sin capa activa no sale nada marcado; aqui se comprueba que una
        # alineacion ensena a la otra, asi que tienen que estar las dos.
        dock.selector.marcar_todas(True)
        return dock

    # -- lo que se ve en la seccion del visor -------------------------------
    def test_la_seccion_ensena_las_otras_alineaciones(self):
        """Lo que se veia en los planos tiene que verse tambien en el visor."""
        dock = self._dock()
        self.assertEqual(len(dock.selector), 2)
        # Los dos ejes de este caso van paralelos y cerca: se cruzan en el plano
        # de corte de cada seccion.
        con_traza = 0
        for i in range(dock.cmb_pk.count()):
            dock.cmb_pk.setCurrentIndex(i)
            if dock.vista_sec.datos.extras:
                con_traza += 1
        self.assertGreater(con_traza, 0, "la otra alineacion tiene que verse")

    def test_la_traza_ajena_va_a_trazos_y_con_su_color(self):
        from aqgis_sivil3d.ui.selector_tramos import color_de

        dock = self._dock()
        for i in range(dock.cmb_pk.count()):
            dock.cmb_pk.setCurrentIndex(i)
            extras = dock.vista_sec.datos.extras
            if extras:
                self.assertTrue(extras[0].discontinua)
                self.assertEqual(extras[0].color.name(), color_de(1).name())
                self.assertIn(self.res.runs[1].etiqueta, extras[0].etiqueta)
                return
        self.fail("ninguna seccion mostro la otra alineacion")

    def test_desmarcar_la_otra_la_quita_de_la_seccion(self):
        dock = self._dock()
        dock.selector.solo_actual()
        for i in range(dock.cmb_pk.count()):
            dock.cmb_pk.setCurrentIndex(i)
            self.assertEqual(dock.vista_sec.datos.extras, [])

    def test_la_traza_no_desborda_el_ancho_de_la_seccion(self):
        """Si entrase entera, la seccion de verdad quedaria del tamano de una raya."""
        dock = self._dock()
        for i in range(dock.cmb_pk.count()):
            dock.cmb_pk.setCurrentIndex(i)
            secciones = dock._secciones()
            if not dock.vista_sec.datos.extras or i >= len(secciones):
                continue
            from aqgis_sivil3d.ui.profile_dock import ANCHO_CRUCES

            sec = secciones[i]
            limite = max(max(sec.ancho_izq, sec.ancho_der) * 3.0, ANCHO_CRUCES)
            for serie in dock.vista_sec.datos.extras:
                for offset, _z in serie.puntos:
                    self.assertLessEqual(abs(offset), limite)

    def test_generar_los_tres_planos(self):
        dlg = self._dialogo()
        dlg.chk_pdf.setChecked(False)
        dlg.chk_dxf.setChecked(False)
        dlg.ed_carpeta.setText("")
        dlg.generar()
        registro = dlg.log.toPlainText()
        self.assertIn("Done.", registro)
        self.assertNotIn("Error", registro)
        self.assertIn("other corridors", registro)
        self.assertIn("background layers", registro)


class TestAnchoDeLosPaneles(unittest.TestCase):
    """Un panel acoplado no puede ser mas ancho que la ventana.

    Si lo es, Qt recorta la barra de titulo y desaparece la X de cerrar. Paso de
    verdad: el editor de rasantes llego a pedir 2905 px de ancho minimo.
    """

    #: Con esto cabe en cualquier pantalla, incluso acoplado a un lado.
    MAXIMO = 400

    def _iface(self):
        return IfaceFalso()

    def test_el_visor_de_perfiles_puede_encogerse(self):
        from aqgis_sivil3d.ui.profile_dock import ProfileDock

        dock = ProfileDock(self._iface())
        self.assertLessEqual(dock.minimumSizeHint().width(), self.MAXIMO)

    def test_el_editor_de_rasantes_puede_encogerse(self):
        from aqgis_sivil3d.ui.rasante_editor import RasanteEditor

        ed = RasanteEditor(self._iface())
        self.assertLessEqual(ed.minimumSizeHint().width(), self.MAXIMO)

    def test_los_dos_paneles_se_pueden_cerrar(self):
        from qgis.PyQt.QtWidgets import QDockWidget

        from aqgis_sivil3d.ui.profile_dock import ProfileDock
        from aqgis_sivil3d.ui.rasante_editor import RasanteEditor
        from aqgis_sivil3d.ui.qtcompat import miembro

        cerrable = miembro(QDockWidget, "DockWidgetClosable", "DockWidgetFeature")
        for panel in (ProfileDock(self._iface()), RasanteEditor(self._iface())):
            # En PyQt6 las banderas no se convierten a int: se comprueba con el
            # propio operador, que vale en las dos versiones.
            self.assertTrue(
                bool(panel.features() & cerrable),
                f"{type(panel).__name__} sin boton de cerrar",
            )


class TestVentanasQueCaben(unittest.TestCase):
    """Ningun dialogo puede pedir mas espacio del que hay en la pantalla.

    Si lo pide, Qt lo fuerza, la ventana se sale y los botones quedan fuera. Con
    un dialogo modal eso deja QGIS esperando a algo que no se ve: parece colgado.
    Paso de verdad con el generador de planos, que llego a pedir 1318x1355.
    """

    #: Cabe de sobra en cualquier monitor, incluso en un portatil pequeno.
    MAXIMO_ANCHO = 800
    MAXIMO_ALTO = 600

    def _minimo(self, w) -> tuple:
        """Lo que de verdad limita: el minimo explicito, y si no, el calculado."""
        ms = w.minimumSize()
        ancho = ms.width() or w.minimumSizeHint().width()
        alto = ms.height() or w.minimumSizeHint().height()
        return ancho, alto

    def _dialogos(self) -> list:
        from aqgis_sivil3d.plugin import library_path
        from aqgis_sivil3d.core.library import default_library
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor
        from aqgis_sivil3d.ui.corridor_dialog import CorridorDialog
        from aqgis_sivil3d.ui.embalse_dialog import EmbalseDialog
        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        iface = IfaceFalso()
        return [
            ("Generar planos", PlanosDialog(iface, None)),
            ("Extruir seccion tipo", CorridorDialog(iface, library_path())),
            ("Curva de embalse", EmbalseDialog(iface)),
            ("Editor de secciones", AssemblyEditor(default_library(), library_path())),
        ]

    def test_todos_los_dialogos_se_pueden_encoger(self):
        for nombre, dlg in self._dialogos():
            ancho, alto = self._minimo(dlg)
            self.assertLessEqual(ancho, self.MAXIMO_ANCHO, f"{nombre}: ancho minimo")
            self.assertLessEqual(alto, self.MAXIMO_ALTO, f"{nombre}: alto minimo")

    def test_ninguno_se_abre_mas_grande_que_la_pantalla(self):
        from qgis.PyQt.QtWidgets import QApplication

        pantalla = QApplication.primaryScreen()
        if pantalla is None:
            self.skipTest("sin pantalla")
        disponible = pantalla.availableGeometry()
        for nombre, dlg in self._dialogos():
            self.assertLessEqual(dlg.width(), disponible.width(), nombre)
            self.assertLessEqual(dlg.height(), disponible.height(), nombre)

    def test_la_botonera_esta_fuera_del_area_de_desplazamiento(self):
        """Los botones tienen que verse aunque el cuerpo no quepa entero."""
        from qgis.PyQt.QtWidgets import QDialogButtonBox, QScrollArea

        from aqgis_sivil3d.ui.planos_dialog import PlanosDialog

        dlg = PlanosDialog(IfaceFalso(), None)
        botoneras = dlg.findChildren(QDialogButtonBox)
        self.assertTrue(botoneras)
        for caja in botoneras:
            padre = caja.parent()
            while padre is not None and padre is not dlg:
                self.assertNotIsInstance(
                    padre, QScrollArea, "la botonera no puede ir dentro del scroll"
                )
                padre = padre.parent()

    def test_ajustar_a_pantalla_no_se_pasa(self):
        from qgis.PyQt.QtWidgets import QApplication, QDialog

        from aqgis_sivil3d.ui.dialogos import ajustar_a_pantalla

        pantalla = QApplication.primaryScreen()
        if pantalla is None:
            self.skipTest("sin pantalla")
        disponible = pantalla.availableGeometry()
        d = QDialog()
        ajustar_a_pantalla(d, 99999, 99999)
        self.assertLessEqual(d.width(), disponible.width())
        self.assertLessEqual(d.height(), disponible.height())
        # Un tamano razonable se respeta tal cual...
        d2 = QDialog()
        ajustar_a_pantalla(d2, 500, 400)
        self.assertEqual((d2.width(), d2.height()), (500, 400))
        # ...pero por debajo del minimo manda el minimo.
        d3 = QDialog()
        ajustar_a_pantalla(d3, 100, 80)
        self.assertGreaterEqual(d3.width(), 320)
        self.assertGreaterEqual(d3.height(), 240)


class TestDocumentacion(unittest.TestCase):
    """El texto de presentacion y la ayuda incluida en el plugin."""

    RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _metadata(self) -> dict:
        import configparser

        cp = configparser.ConfigParser()
        cp.read(os.path.join(self.RAIZ, "metadata.txt"), encoding="utf-8")
        return dict(cp["general"])

    # -- presentacion ------------------------------------------------------
    def test_autoria_en_orden(self):
        self.assertEqual(self._metadata()["author"], "Rafael Vázquez, Claude")

    def test_no_queda_autoria_de_terceros(self):
        """Se pidio quitar TYPSA de la autoria: no debe quedar en ningun texto."""
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda

        m = self._metadata()
        for texto in (m["author"], m["about"], m["about[es]"], leer_ayuda()):
            self.assertNotIn("TYPSA", texto)

    def test_la_licencia_viaja_dentro_del_paquete(self):
        """El LICENSE va en el ZIP y es el texto oficial, sin nada delante.

        Empezar el archivo con un aviso propio impide que GitHub y los detectores
        automaticos reconozcan la licencia (la marcan como NOASSERTION). El aviso
        de copyright va en el codigo y en el README, que es donde toca.
        """
        ruta = os.path.join(self.RAIZ, "LICENSE")
        self.assertTrue(os.path.exists(ruta), "falta LICENSE dentro del paquete")
        with open(ruta, "r", encoding="utf-8") as fh:
            texto = fh.read()
        self.assertTrue(
            texto.lstrip().startswith("GNU GENERAL PUBLIC LICENSE"),
            "el LICENSE debe empezar por el texto oficial",
        )
        self.assertIn("Version 3, 29 June 2007", texto)
        self.assertIn("END OF TERMS AND CONDITIONS", texto)
        self.assertGreater(len(texto), 30_000, "el texto de la GPL esta incompleto")

    def test_la_presentacion_cita_la_licencia(self):
        m = self._metadata()
        for texto in (m["about"], m["about[es]"]):
            self.assertIn("GPL", texto)
        self.assertNotIn("MIT", m["about"])

    def test_el_punto_de_entrada_lleva_el_aviso_gpl(self):
        """La GPL pide que el aviso vaya en el codigo, no solo en un archivo."""
        import aqgis_sivil3d

        doc = aqgis_sivil3d.__doc__ or ""
        self.assertIn("Copyright (C) 2026 Rafael Vazquez", doc)
        self.assertIn("Licencia Publica General GNU", doc)

    def test_el_correo_de_contacto(self):
        """Un alias con '+', no la direccion a secas: el metadata viaja en el ZIP."""
        self.assertEqual(
            self._metadata()["email"],
            "pypadopoulos+qgisplugin@gmail.com",
        )

    def test_la_presentacion_en_ingles_menciona_todas_las_funcionalidades(self):
        """El 'about' por defecto es el ingles: es lo que ve todo el mundo."""
        about = self._metadata()["about"].lower()
        for concepto in (
            "cross section editor",
            "benched slope",
            "cut and fill",
            "preview",
            "library",
            "expression",
            "bisector",
            "bilinear",
            "tin",
            "merge",
            "daylight",
            "footprint",
            "2dm",
            "earthwork",
            "average end areas",
            "prismoidal",
            "mass haul",
            "bulking",
            "profile viewer",
            "longitudinal",
            "plan sheets",
            "atlas",
            "data band",
            "cross section sheets",
            "standard scales",
            ".qpt",
            "pdf",
            "dxf",
            "geopackage",
            "processing",
            "help",
        ):
            self.assertIn(concepto, about, f"falta '{concepto}' en el about en ingles")

    def test_la_presentacion_en_espanol_menciona_todas_las_funcionalidades(self):
        about = self._metadata()["about[es]"].lower()
        for concepto in (
            "editor de secciones",
            "banquetas",
            "desmonte",
            "terraplen",
            "previsualizacion",
            "libreria",
            "expresion",
            "bisectriz",
            "bilineal",
            "tin",
            "fusion",
            "daylight",
            "huella",
            "2dm",
            "medicion",
            "areas medias",
            "prismatoide",
            "diagrama de masas",
            "esponjamiento",
            "visor de perfiles",
            "longitudinal",
            "planta",
            "atlas",
            "guitarra",
            "transversales",
            "cubicaciones",
            "escalas normalizadas",
            ".qpt",
            "pdf",
            "dxf",
            "geopackage",
            "processing",
            "ayuda",
        ):
            self.assertIn(
                concepto, about, f"falta '{concepto}' en el about en espanol"
            )

    def test_hay_descripcion_en_los_dos_idiomas(self):
        m = self._metadata()
        # La de por defecto es la inglesa; el espanol va como traduccion.
        self.assertIn("cross sections", m["description"])
        self.assertIn("secciones tipo", m["description[es]"])
        self.assertNotEqual(m["description"], m["description[es]"])
        self.assertNotEqual(m["about"], m["about[es]"])

    def test_la_presentacion_cita_la_autoria(self):
        about = self._metadata()["about"]
        self.assertIn("Rafael", about)
        self.assertIn("Claude", about)
        self.assertLess(about.index("Rafael"), about.index("Claude"))

    def test_las_etiquetas_obligatorias_estan(self):
        """Son las que se han pedido para que el plugin se encuentre buscando."""
        etiquetas = [t.strip() for t in self._metadata()["tags"].split(",")]
        for esperada in ("Civil3D", "3D", "alignment", "civil engineering"):
            self.assertIn(esperada, etiquetas, f"falta la etiqueta '{esperada}'")

    def test_no_hay_etiquetas_repetidas(self):
        etiquetas = [t.strip().lower() for t in self._metadata()["tags"].split(",")]
        repetidas = {t for t in etiquetas if etiquetas.count(t) > 1}
        self.assertEqual(repetidas, set(), f"etiquetas repetidas: {repetidas}")

    def test_metadata_completo(self):
        m = self._metadata()
        for clave in (
            "name",
            "description",
            "description[es]",
            "about",
            "about[es]",
            "version",
            "author",
            "email",
        ):
            self.assertTrue(m.get(clave, "").strip(), clave)
        self.assertEqual(m["name"], "AQGIS-Sivil3D")
        self.assertEqual(m["hasprocessingprovider"], "yes")

    def test_la_version_es_estable(self):
        """Lo que exige el repositorio oficial: version y marca de experimental."""
        import re

        m = self._metadata()
        self.assertRegex(m["version"], r"^\d+\.\d+\.\d+$")
        self.assertGreaterEqual(int(m["version"].split(".")[0]), 1)
        self.assertEqual(m.get("experimental", "False").lower(), "false")
        self.assertEqual(m.get("deprecated", "False").lower(), "false")
        del re
        # Y la ayuda tiene que decir la misma version que el metadata.
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda

        self.assertIn(m["version"], leer_ayuda())

    def test_los_enlaces_del_metadata(self):
        """El repositorio oficial comprueba que sean publicos y accesibles."""
        m = self._metadata()
        for clave in ("repository", "tracker", "homepage"):
            self.assertTrue(
                m.get(clave, "").startswith("https://"), f"{clave}: {m.get(clave)}"
            )

    def test_el_codigo_pasa_las_reglas_del_escaner(self):
        """Dos reglas de Bandit que el escaner de plugins.qgis.org aplica siempre.

        ``B101`` (assert suelto, que desaparece con ``python -O``) y ``B110``
        (``except`` que se traga el error sin dejar rastro). Los enums de Qt sin
        ambito y las APIs de PyQt5 tienen su propia guarda mas abajo.
        """
        import re

        salto = chr(10)
        raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        fallos = []
        for actual, _dirs, ficheros in os.walk(raiz):
            if "__pycache__" in actual:
                continue
            for nombre in ficheros:
                if not nombre.endswith(".py"):
                    continue
                ruta = os.path.join(actual, nombre)
                with open(ruta, "r", encoding="utf-8") as fh:
                    texto = fh.read()
                relativo = os.path.relpath(ruta, raiz)
                for n, linea in enumerate(texto.split(salto), 1):
                    if re.match(r"\s*assert\s", linea):
                        fallos.append(f"{relativo}:{n}: assert (B101)")
                # Como Bandit: solo cuenta cuando se traga *cualquier* error. Un
                # except tipado con pass es una decision explicita y documentada.
                for hallazgo in re.finditer(
                    r"except\s*(Exception|BaseException)?\s*:\s*\n\s*pass\b", texto
                ):
                    n = texto[: hallazgo.start()].count(salto) + 1
                    fallos.append(f"{relativo}:{n}: except/pass (B110)")
        self.assertEqual(
            fallos,
            [],
            "el escaner del repositorio se quejaria:" + salto + salto.join(fallos),
        )

    # -- ayuda -------------------------------------------------------------
    def test_la_ayuda_esta_empaquetada(self):
        from aqgis_sivil3d.ui.ayuda_dialog import ruta_ayuda

        self.assertTrue(os.path.exists(ruta_ayuda()), ruta_ayuda())
        self.assertGreater(os.path.getsize(ruta_ayuda()), 10_000)

    def test_la_ayuda_documenta_cada_funcionalidad(self):
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda, secciones

        html = leer_ayuda()
        anclas = {a for a, _t in secciones(html)}
        for esperada in (
            "que-es",
            "instalacion",
            "conceptos",
            "editor",
            "elementos",
            "calculo",
            "fusion",
            "salidas",
            "mediciones",
            "visor",
            "planos",
            "rasante",
            "embalse",
            "paquete",
            "alternativas",
            "processing",
            "problemas",
            "limitaciones",
            "autoria",
        ):
            self.assertIn(esperada, anclas, f"falta la seccion '{esperada}'")

    def test_todas_las_secciones_tienen_titulo(self):
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda, secciones

        for ancla, titulo in secciones(leer_ayuda()):
            self.assertTrue(titulo.strip(), ancla)
            self.assertNotIn("<", titulo, "el titulo no debe llevar etiquetas")

    def test_la_ayuda_nombra_la_autoria_y_la_licencia(self):
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda

        html = leer_ayuda()
        self.assertIn("Rafael Vázquez", html)
        self.assertIn("Claude", html)
        self.assertIn("GPL", html)

    def test_el_dialogo_de_ayuda_construye_su_indice(self):
        from aqgis_sivil3d.ui.ayuda_dialog import AyudaDialog, leer_ayuda, secciones

        dlg = AyudaDialog()
        self.assertEqual(dlg.indice.count(), len(secciones(leer_ayuda())))
        self.assertGreater(len(dlg.texto.toPlainText()), 5000)

    def test_el_dialogo_salta_a_una_seccion(self):
        from aqgis_sivil3d.ui.ayuda_dialog import AyudaDialog

        dlg = AyudaDialog(ancla="planos")
        item = dlg.indice.currentItem()
        self.assertIsNotNone(item)
        self.assertIn("rawings", item.text())
        self.assertTrue(dlg.ir_a("mediciones"))
        self.assertIn("easurement", dlg.indice.currentItem().text())

    def test_la_busqueda_encuentra_y_da_la_vuelta(self):
        from aqgis_sivil3d.ui.ayuda_dialog import AyudaDialog

        dlg = AyudaDialog()
        dlg.ed_buscar.setText("bulking factor")
        dlg._buscar()
        self.assertEqual(dlg.lbl_busqueda.text(), "")
        dlg.ed_buscar.setText("xyzzy-no-existe")
        dlg._buscar()
        self.assertIn("no matches", dlg.lbl_busqueda.text())

    def test_las_anclas_que_usan_los_dialogos_existen(self):
        """Los botones de ayuda contextual no pueden apuntar a nada."""
        from aqgis_sivil3d.ui.ayuda_dialog import leer_ayuda, secciones

        anclas = {a for a, _t in secciones(leer_ayuda())}
        for usada in ("editor", "calculo", "planos", "visor", "rasante", "embalse"):
            self.assertIn(usada, anclas)

    def test_hay_accion_de_ayuda_en_el_menu(self):
        import aqgis_sivil3d
        from qgis.PyQt.QtWidgets import QMainWindow

        class Iface:
            def __init__(self):
                self.w = QMainWindow()
                self.acciones = []

            def mainWindow(self):
                return self.w

            def addPluginToVectorMenu(self, _m, a):
                self.acciones.append(a)

            def removePluginVectorMenu(self, _m, a):
                self.acciones.remove(a)

            def addToolBarIcon(self, _a):
                pass

            def addToolBarWidget(self, _w):
                return None

            def removeToolBarIcon(self, _a):
                pass

        iface = Iface()
        plugin = aqgis_sivil3d.classFactory(iface)
        plugin.initGui()
        ayuda = [a for a in iface.acciones if "help" in a.text().lower()]
        self.assertEqual(len(ayuda), 1)
        self.assertFalse(ayuda[0].icon().isNull(), "la ayuda debe tener icono")
        plugin.unload()


class TestCotaDelEje(unittest.TestCase):
    """Las tres procedencias de la cota del eje."""

    @classmethod
    def setUpClass(cls):
        from aqgis_sivil3d.core.library import default_library

        # Terreno plano inclinado: z = 200 + 0.20 * (y - Y0)
        dem = QgsRasterLayer(escribir_dem("dem_cota.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.crs = QgsCoordinateReferenceSystem(CRS)
        cls.lib = default_library()

    def _capa_2d(self):
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=60)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + 200), (X0 + 400, Y0 + 200)], ["x"])]
        )
        capa.updateExtents()
        return capa

    def _capa_3d(self, z0=260.0, z1=275.0):
        from qgis.core import QgsLineString, QgsPoint

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "d3", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("s", QMetaType.Type.QString, len=60)]
        )
        capa.updateFields()
        f = QgsFeature(capa.fields())
        f.setGeometry(
            QgsGeometry(
                QgsLineString(
                    [
                        QgsPoint(X0 + 100, Y0 + 200, z0),
                        QgsPoint(X0 + 400, Y0 + 200, z1),
                    ]
                )
            )
        )
        f.setAttributes(["x"])
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        return capa

    def _calcular(self, capa, cota_eje, constante=0.0, desnivel=0.0):
        from aqgis_sivil3d.core.library import default_library

        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = desnivel
        return build_corridor(
            capa,
            self.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=200.0, muestras_terreno=40),
                seccion_defecto="Road 1+1",
                cota_eje=cota_eje,
                cota_constante=constante,
            ),
        )

    def test_del_terreno(self):
        from aqgis_sivil3d.gis.build import COTA_TERRENO

        res = self._calcular(self._capa_2d(), COTA_TERRENO)
        for sec in res.runs[0].sections:
            self.assertAlmostEqual(sec.z_eje, sec.z_terreno, places=6)

    def test_de_la_z_de_la_directriz(self):
        from aqgis_sivil3d.gis.build import COTA_DIRECTRIZ

        res = self._calcular(self._capa_3d(), COTA_DIRECTRIZ)
        secs = res.runs[0].sections
        self.assertAlmostEqual(secs[0].z_eje, 260.0, places=3)
        self.assertAlmostEqual(secs[-1].z_eje, 275.0, places=3)

    def test_valor_constante(self):
        """Todos los PK a la misma cota: plataforma horizontal."""
        from aqgis_sivil3d.gis.build import COTA_CONSTANTE

        res = self._calcular(self._capa_2d(), COTA_CONSTANTE, constante=250.0)
        secs = res.runs[0].sections
        self.assertGreater(len(secs), 5)
        for sec in secs:
            self.assertAlmostEqual(sec.z_eje, 250.0, places=6)
        # Y el terreno se sigue muestreando, que es lo que da la cota roja.
        self.assertTrue(all(s.z_terreno is not None for s in secs))
        self.assertNotAlmostEqual(secs[0].z_terreno, 250.0, places=1)

    def test_el_desnivel_del_eje_se_suma_a_la_constante(self):
        from aqgis_sivil3d.gis.build import COTA_CONSTANTE

        res = self._calcular(
            self._capa_2d(), COTA_CONSTANTE, constante=250.0, desnivel=-0.5
        )
        for sec in res.runs[0].sections:
            self.assertAlmostEqual(sec.z_eje, 249.5, places=6)

    def test_la_constante_no_necesita_directriz_3d(self):
        """Una capa 2D vale: la cota no sale de la geometria."""
        from aqgis_sivil3d.gis.build import COTA_CONSTANTE

        res = self._calcular(self._capa_2d(), COTA_CONSTANTE, constante=245.0)
        self.assertFalse(res.runs[0].alignment.tiene_z)
        self.assertFalse(
            any("sin cota" in a for a in res.runs[0].warnings),
            "no debe avisar de falta de Z",
        )

    def test_con_constante_la_cota_roja_es_la_diferencia(self):
        from aqgis_sivil3d.gis.build import COTA_CONSTANTE

        res = self._calcular(self._capa_2d(), COTA_CONSTANTE, constante=250.0)
        for sec in res.runs[0].sections:
            self.assertAlmostEqual(
                sec.cota_roja, 250.0 - sec.z_terreno, places=6
            )

    def test_el_dialogo_ofrece_la_constante(self):
        """El recuento de opciones lo comprueba TestOffsetDesdeElTerreno."""
        from aqgis_sivil3d.plugin import library_path
        from aqgis_sivil3d.ui.corridor_dialog import CorridorDialog

        class Iface:
            def mainWindow(self):
                return None

        d = CorridorDialog(Iface(), library_path())
        self.assertIn("constant", d.cmb_cota.itemText(2))
        d.cmb_cota.setCurrentIndex(0)
        self.assertFalse(d.sp_cota.isEnabled())
        d.cmb_cota.setCurrentIndex(2)
        self.assertTrue(d.sp_cota.isEnabled())

    def test_el_algoritmo_ofrece_la_constante(self):
        from qgis.core import QgsProcessingParameterEnum

        from aqgis_sivil3d.processing.alg_corridor import CorridorAlgorithm

        alg = CorridorAlgorithm()
        alg.initAlgorithm({})
        params = {p.name(): p for p in alg.parameterDefinitions()}
        self.assertIn("COTA_CONSTANTE", params)
        enum = params["COTA_EJE"]
        self.assertIsInstance(enum, QgsProcessingParameterEnum)
        self.assertIn("onstant", enum.options()[2])


class TestEscribirCotaEnZ(unittest.TestCase):
    """Poner la Z de la directriz a una cota, en la capa o en una copia."""

    PTS = [(X0 + 100, Y0 + 200), (X0 + 250, Y0 + 220), (X0 + 400, Y0 + 200)]

    def _capa_2d(self):
        capa = capa_lineas([], [QgsField("nombre", QMetaType.Type.QString, len=20)])
        capa.dataProvider().addFeatures([feature_linea(capa, self.PTS, ["A"])])
        capa.updateExtents()
        return capa

    def _capa_3d(self, z=100.0):
        from qgis.core import QgsLineString, QgsPoint

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "d3", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("nombre", QMetaType.Type.QString, len=20)]
        )
        capa.updateFields()
        f = QgsFeature(capa.fields())
        f.setGeometry(
            QgsGeometry(QgsLineString([QgsPoint(x, y, z) for x, y in self.PTS]))
        )
        f.setAttributes(["A"])
        capa.dataProvider().addFeatures([f])
        capa.updateExtents()
        return capa

    @staticmethod
    def _zetas(capa):
        zs = []
        for f in capa.getFeatures():
            for v in f.geometry().constGet().vertices():
                zs.append(v.z())
        return zs

    # -- deteccion ---------------------------------------------------------
    def test_admite_z(self):
        from aqgis_sivil3d.gis.rasante import admite_z

        self.assertFalse(admite_z(self._capa_2d()))
        self.assertTrue(admite_z(self._capa_3d()))

    def test_con_z_pone_todos_los_vertices(self):
        from aqgis_sivil3d.gis.rasante import con_z

        f = next(self._capa_2d().getFeatures())
        g = con_z(f.geometry(), 246.5)
        self.assertIsNotNone(g)
        self.assertTrue(QgsWkbTypes.hasZ(g.wkbType()))
        zs = [v.z() for v in g.constGet().vertices()]
        self.assertEqual(len(zs), len(self.PTS))
        for z in zs:
            self.assertAlmostEqual(z, 246.5, places=6)

    def test_con_z_reemplaza_la_z_que_hubiera(self):
        from aqgis_sivil3d.gis.rasante import con_z

        f = next(self._capa_3d(z=100.0).getFeatures())
        g = con_z(f.geometry(), 250.0)
        for v in g.constGet().vertices():
            self.assertAlmostEqual(v.z(), 250.0, places=6)

    def test_con_z_geometria_vacia(self):
        from aqgis_sivil3d.gis.rasante import con_z

        self.assertIsNone(con_z(QgsGeometry(), 100.0))
        self.assertIsNone(con_z(None, 100.0))

    # -- capa que admite Z: se edita en el sitio ---------------------------
    def test_capa_3d_se_edita_en_el_sitio(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_3d(z=100.0)
        ok, mensajes, nueva = asignar_cota(capa, 246.0)
        self.assertTrue(ok, mensajes)
        self.assertIsNone(nueva, "no debe crear una capa nueva si la original vale")
        for z in self._zetas(capa):
            self.assertAlmostEqual(z, 246.0, places=6)
        self.assertFalse(capa.isEditable(), "los cambios deben quedar guardados")

    def test_los_atributos_no_se_tocan(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_3d()
        asignar_cota(capa, 246.0)
        self.assertEqual(next(capa.getFeatures())["nombre"], "A")

    # -- capa 2D: se crea una copia ----------------------------------------
    def test_capa_2d_genera_una_copia_con_z(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_2d()
        ok, mensajes, nueva = asignar_cota(capa, 246.0)
        self.assertTrue(ok, mensajes)
        self.assertIsNotNone(nueva, "una capa 2D no puede guardar Z")
        self.assertTrue(QgsWkbTypes.hasZ(nueva.wkbType()))
        self.assertEqual(nueva.featureCount(), capa.featureCount())
        for z in self._zetas(nueva):
            self.assertAlmostEqual(z, 246.0, places=6)
        # La original se queda como estaba: no se toca lo que no se puede tocar.
        self.assertFalse(QgsWkbTypes.hasZ(capa.wkbType()))
        self.assertTrue(any("2D" in m for m in mensajes))

    def test_la_copia_conserva_campos_crs_y_atributos(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_2d()
        _ok, _m, nueva = asignar_cota(capa, 246.0)
        self.assertEqual(
            [f.name() for f in nueva.fields()], [f.name() for f in capa.fields()]
        )
        self.assertEqual(nueva.crs().authid(), capa.crs().authid())
        self.assertEqual(next(nueva.getFeatures())["nombre"], "A")

    def test_el_nombre_de_la_copia_dice_la_cota(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        _ok, _m, nueva = asignar_cota(self._capa_2d(), 246.5)
        self.assertIn("246.5", nueva.name())

    # -- solo los seleccionados -------------------------------------------
    def test_solo_seleccionados(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_3d(z=100.0)
        f2 = QgsFeature(capa.fields())
        f2.setGeometry(
            QgsGeometry.fromPolylineXY(
                [QgsPointXY(X0 + 500, Y0 + 300), QgsPointXY(X0 + 600, Y0 + 300)]
            )
        )
        f2.setAttributes(["B"])
        capa.dataProvider().addFeatures([f2])
        ids = [f.id() for f in capa.getFeatures() if f["nombre"] == "A"]
        capa.selectByIds(ids)

        ok, mensajes, _n = asignar_cota(capa, 246.0, solo_seleccionados=True)
        self.assertTrue(ok, mensajes)
        for f in capa.getFeatures():
            zs = [v.z() for v in f.geometry().constGet().vertices()]
            if f["nombre"] == "A":
                self.assertAlmostEqual(zs[0], 246.0, places=6)
            else:
                self.assertNotAlmostEqual(zs[0], 246.0, places=3)

    def test_sin_seleccion_no_hace_nada(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa_3d()
        capa.removeSelection()
        ok, mensajes, _n = asignar_cota(capa, 246.0, solo_seleccionados=True)
        self.assertFalse(ok)
        self.assertTrue(any("seleccionado" in m for m in mensajes))

    # -- errores -----------------------------------------------------------
    def test_capa_que_no_es_de_lineas(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        puntos = QgsVectorLayer(f"PointZ?crs={CRS}", "p", "memory")
        ok, mensajes, _n = asignar_cota(puntos, 100.0)
        self.assertFalse(ok)
        self.assertTrue(any("lineas" in m for m in mensajes))

    def test_capa_invalida(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        ok, mensajes, _n = asignar_cota(None, 100.0)
        self.assertFalse(ok)
        self.assertTrue(mensajes)

    # -- el resultado sirve para calcular con la Z de la directriz --------
    def test_despues_se_puede_calcular_con_la_z_de_la_directriz(self):
        from aqgis_sivil3d.core.library import default_library
        from aqgis_sivil3d.gis.build import COTA_DIRECTRIZ
        from aqgis_sivil3d.gis.rasante import asignar_cota

        dem = QgsRasterLayer(escribir_dem("dem_rasante.tif"), "dem")
        terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        capa = self._capa_2d()
        _ok, _m, nueva = asignar_cota(capa, 246.0)
        res = build_corridor(
            nueva,
            terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=200.0, muestras_terreno=40),
                seccion_defecto="Road 1+1",
                cota_eje=COTA_DIRECTRIZ,
            ),
        )
        secs = res.runs[0].sections
        self.assertGreater(len(secs), 3)
        for sec in secs:
            self.assertAlmostEqual(sec.z_eje, 246.0, places=3)
        self.assertTrue(res.runs[0].alignment.tiene_z)

    # -- boton del dialogo -------------------------------------------------
    def test_el_boton_solo_esta_activo_con_cota_constante(self):
        from aqgis_sivil3d.plugin import library_path
        from aqgis_sivil3d.ui.corridor_dialog import CorridorDialog

        class Iface:
            def mainWindow(self):
                return None

        d = CorridorDialog(Iface(), library_path())
        for indice, esperado in ((0, False), (1, False), (2, True)):
            d.cmb_cota.setCurrentIndex(indice)
            self.assertEqual(d.btn_cota_a_z.isEnabled(), esperado, f"indice {indice}")


class TestOffsetDesdeElTerreno(unittest.TestCase):
    """Cuarto modo de cota: rasante paralela al terreno."""

    @classmethod
    def setUpClass(cls):
        # Terreno plano inclinado: z = 200 + 0.20 * (y - Y0), constante en x.
        dem = QgsRasterLayer(escribir_dem("dem_offset.tif"), "dem")
        cls.terreno = make_terrain(dem, QgsCoordinateReferenceSystem(CRS))
        cls.dem = dem
        cls.crs = QgsCoordinateReferenceSystem(CRS)

    def _capa(self, y0=200.0, y1=200.0):
        """Directriz en X (terreno constante) o en diagonal (terreno variable)."""
        capa = capa_lineas([], [QgsField("s", QMetaType.Type.QString, len=20)])
        capa.dataProvider().addFeatures(
            [feature_linea(capa, [(X0 + 100, Y0 + y0), (X0 + 400, Y0 + y1)], ["x"])]
        )
        capa.updateExtents()
        return capa

    def _calcular(self, capa, offset, desnivel=0.0):
        from aqgis_sivil3d.core.library import default_library
        from aqgis_sivil3d.gis.build import COTA_OFFSET_TERRENO

        lib = default_library()
        lib["Road 1+1"].eje["desnivel"] = desnivel
        return build_corridor(
            capa,
            self.terreno,
            lib.assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=200.0, muestras_terreno=40),
                seccion_defecto="Road 1+1",
                cota_eje=COTA_OFFSET_TERRENO,
                offset_terreno=offset,
            ),
        )

    def test_la_rasante_va_paralela_al_terreno(self):
        """La cota roja es el offset en todos los PK, suba o baje el terreno."""
        res = self._calcular(self._capa(y0=150.0, y1=350.0), -0.5)
        secs = res.runs[0].sections
        self.assertGreater(len(secs), 5)
        # El terreno cambia a lo largo del eje...
        zs = [s.z_terreno for s in secs]
        self.assertGreater(max(zs) - min(zs), 5.0)
        # ...pero el desnivel respecto a el es siempre el mismo.
        for sec in secs:
            self.assertAlmostEqual(sec.z_eje, sec.z_terreno - 0.5, places=6)
            self.assertAlmostEqual(sec.cota_roja, -0.5, places=6)

    def test_offset_positivo_es_terraplen(self):
        res = self._calcular(self._capa(), +1.5)
        for sec in res.runs[0].sections:
            self.assertAlmostEqual(sec.cota_roja, 1.5, places=6)
        # Y la medicion lo confirma: relleno, no excavacion.
        from aqgis_sivil3d.core.medicion import medir

        m = medir([s for s in res.runs[0].sections if s.vertices])
        self.assertGreater(m.total_terraplen, 0.0)

    def test_offset_negativo_es_desmonte(self):
        from aqgis_sivil3d.core.medicion import medir

        res = self._calcular(self._capa(), -1.5)
        m = medir([s for s in res.runs[0].sections if s.vertices])
        self.assertGreater(m.total_desmonte, 0.0)

    def test_offset_cero_es_como_apoyarse_en_el_terreno(self):
        from aqgis_sivil3d.core.library import default_library
        from aqgis_sivil3d.gis.build import COTA_TERRENO

        capa = self._capa(y0=150.0, y1=350.0)
        a = self._calcular(capa, 0.0)
        b = build_corridor(
            capa,
            self.terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=200.0, muestras_terreno=40),
                seccion_defecto="Road 1+1",
                cota_eje=COTA_TERRENO,
            ),
        )
        for sa, sb in zip(a.runs[0].sections, b.runs[0].sections):
            self.assertAlmostEqual(sa.z_eje, sb.z_eje, places=6)

    def test_el_desnivel_de_la_seccion_se_suma(self):
        res = self._calcular(self._capa(), -0.30, desnivel=-0.20)
        for sec in res.runs[0].sections:
            self.assertAlmostEqual(sec.cota_roja, -0.50, places=6)

    def test_el_espesor_es_constante_a_diferencia_de_la_cota_fija(self):
        """Es justo lo que distingue este modo del de valor constante."""
        from aqgis_sivil3d.gis.build import COTA_CONSTANTE
        from aqgis_sivil3d.core.library import default_library

        capa = self._capa(y0=150.0, y1=350.0)
        offset = self._calcular(capa, -1.0)
        rojas_offset = {round(s.cota_roja, 3) for s in offset.runs[0].sections}
        self.assertEqual(len(rojas_offset), 1, "con offset el espesor es constante")

        fija = build_corridor(
            capa,
            self.terreno,
            default_library().assemblies,
            BuildOptions(
                stations=StationOptions(paso=25.0),
                section=SectionOptions(paso=0.5, ancho_max=200.0, muestras_terreno=40),
                seccion_defecto="Road 1+1",
                cota_eje=COTA_CONSTANTE,
                cota_constante=240.0,
            ),
        )
        rojas_fija = {round(s.cota_roja, 3) for s in fija.runs[0].sections}
        self.assertGreater(len(rojas_fija), 3, "con cota fija el espesor varia")

    # -- drapear la Z ------------------------------------------------------
    def test_drapear_pone_la_z_del_terreno_mas_el_offset(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = self._capa(y0=150.0, y1=350.0)
        ok, mensajes, nueva = asignar_cota(
            capa, 0.0, terreno=self.terreno, offset=-0.5
        )
        self.assertTrue(ok, mensajes)
        self.assertIsNotNone(nueva, "la capa de prueba es 2D")
        for f in nueva.getFeatures():
            for v in f.geometry().constGet().vertices():
                esperado = self.terreno.z(v.x(), v.y()) - 0.5
                self.assertAlmostEqual(v.z(), esperado, places=4)

    def test_el_drapeado_da_cotas_distintas_en_cada_vertice(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        _ok, _m, nueva = asignar_cota(
            self._capa(y0=150.0, y1=350.0), 0.0, terreno=self.terreno, offset=0.0
        )
        zs = [
            v.z()
            for f in nueva.getFeatures()
            for v in f.geometry().constGet().vertices()
        ]
        self.assertGreater(max(zs) - min(zs), 5.0, "debe seguir al terreno")

    def test_el_nombre_de_la_copia_drapeada(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        _ok, _m, nueva = asignar_cota(
            self._capa(), 0.0, terreno=self.terreno, offset=-0.5
        )
        self.assertIn("terreno", nueva.name())
        self.assertIn("-0.5", nueva.name())

    def test_drapear_con_nodata_deja_la_directriz_sin_tocar(self):
        from aqgis_sivil3d.gis.rasante import asignar_cota

        def hueco(x, y):
            return None if x > X0 + 250 else self.terreno.z(x, y)

        ok, mensajes, _n = asignar_cota(
            self._capa(), 0.0, terreno=hueco, offset=0.0
        )
        self.assertFalse(ok)
        self.assertTrue(any("convertir" in m or "omitidas" in m for m in mensajes))

    def test_drapear_una_capa_3d_la_edita_en_el_sitio(self):
        from qgis.core import QgsLineString, QgsPoint

        from aqgis_sivil3d.gis.rasante import asignar_cota

        capa = QgsVectorLayer(f"LineStringZ?crs={CRS}", "d3", "memory")
        capa.dataProvider().addAttributes(
            [QgsField("s", QMetaType.Type.QString, len=20)]
        )
        capa.updateFields()
        f = QgsFeature(capa.fields())
        f.setGeometry(
            QgsGeometry(
                QgsLineString(
                    [
                        QgsPoint(X0 + 100, Y0 + 150, 0.0),
                        QgsPoint(X0 + 400, Y0 + 350, 0.0),
                    ]
                )
            )
        )
        f.setAttributes(["x"])
        capa.dataProvider().addFeatures([f])
        ok, mensajes, nueva = asignar_cota(
            capa, 0.0, terreno=self.terreno, offset=1.0
        )
        self.assertTrue(ok, mensajes)
        self.assertIsNone(nueva)
        for ft in capa.getFeatures():
            for v in ft.geometry().constGet().vertices():
                self.assertAlmostEqual(
                    v.z(), self.terreno.z(v.x(), v.y()) + 1.0, places=4
                )

    # -- interfaz ----------------------------------------------------------
    def test_el_dialogo_ofrece_las_cuatro(self):
        from aqgis_sivil3d.plugin import library_path
        from aqgis_sivil3d.ui.corridor_dialog import MODOS_COTA, CorridorDialog

        class Iface:
            def mainWindow(self):
                return None

        d = CorridorDialog(Iface(), library_path())
        self.assertEqual(d.cmb_cota.count(), 4)
        self.assertEqual(len(MODOS_COTA), 4)
        self.assertIn("offset", d.cmb_cota.itemText(3).lower())
        # El campo y el boton se activan con las dos opciones que llevan valor.
        for indice, esperado in ((0, False), (1, False), (2, True), (3, True)):
            d.cmb_cota.setCurrentIndex(indice)
            self.assertEqual(d.sp_cota.isEnabled(), esperado, f"campo, indice {indice}")
            self.assertEqual(
                d.btn_cota_a_z.isEnabled(), esperado, f"boton, indice {indice}"
            )

    def test_el_campo_admite_valores_negativos(self):
        from aqgis_sivil3d.plugin import library_path
        from aqgis_sivil3d.ui.corridor_dialog import CorridorDialog

        class Iface:
            def mainWindow(self):
                return None

        d = CorridorDialog(Iface(), library_path())
        d.cmb_cota.setCurrentIndex(3)
        d.sp_cota.setValue(-0.35)
        self.assertAlmostEqual(d.sp_cota.value(), -0.35)

    def test_el_algoritmo_ofrece_las_cuatro(self):
        from aqgis_sivil3d.processing.alg_corridor import (
            MODOS_COTA,
            CorridorAlgorithm,
        )

        alg = CorridorAlgorithm()
        alg.initAlgorithm({})
        params = {p.name(): p for p in alg.parameterDefinitions()}
        self.assertIn("OFFSET_TERRENO", params)
        self.assertEqual(len(params["COTA_EJE"].options()), 4)
        self.assertEqual(len(MODOS_COTA), 4)


class TestCompatibilidadPyQt(unittest.TestCase):
    """Guardas contra las APIs de PyQt5 que PyQt6 (QGIS 4) elimino.

    Estos fallos no aparecen al importar el modulo, solo al pulsar el boton, asi
    que se cazan leyendo el codigo fuente. Es lo que se nos escapo con
    ``exec_()``: el plugin importaba y arrancaba, y reventaba al abrir el
    dialogo.
    """

    RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _fuentes(self):
        import glob

        for patron in ("*.py", "*/*.py"):
            for ruta in glob.glob(os.path.join(self.RAIZ, patron)):
                if os.sep + "tests" + os.sep in ruta:
                    continue
                with open(ruta, "r", encoding="utf-8") as fh:
                    yield os.path.relpath(ruta, self.RAIZ), fh.read()

    def test_encuentra_las_fuentes(self):
        nombres = [n for n, _ in self._fuentes()]
        self.assertIn("plugin.py", nombres)
        self.assertGreater(len(nombres), 15)

    def test_sin_apis_eliminadas_en_pyqt6(self):
        import re

        PROHIBIDO = {
            r"\.exec_\(": "exec_() -> usar qtcompat.ejecutar_modal()",
            r"\bQRegExp\b": "QRegExp -> QRegularExpression",
            r"\bQDesktopWidget\b": "QDesktopWidget -> QScreen",
            r"\.setMargin\(": "setMargin() -> setContentsMargins()",
            r"\bQt\.MidButton\b": "MidButton -> MouseButton.MiddleButton",
            r"QApplication\.desktop\(": "desktop() -> primaryScreen()",
        }
        fallos = []
        for nombre, texto in self._fuentes():
            for patron, mensaje in PROHIBIDO.items():
                for n, linea in enumerate(texto.split("\n"), 1):
                    if re.search(patron, linea):
                        fallos.append(f"{nombre}:{n}: {mensaje}")
        self.assertEqual(fallos, [], "APIs de PyQt5 no validas en PyQt6:\n" + "\n".join(fallos))

    def test_sin_enums_planos_de_qt(self):
        """``Qt.AlignCenter`` no existe en PyQt6; hay que pasar por qtcompat."""
        import re

        fallos = []
        for nombre, texto in self._fuentes():
            if nombre.endswith("qtcompat.py"):
                continue  # es justo el modulo que los resuelve
            for n, linea in enumerate(texto.split("\n"), 1):
                if re.search(r"(?<![\w.])Qt\.[A-Z]", linea):
                    fallos.append(f"{nombre}:{n}: {linea.strip()}")
        self.assertEqual(
            fallos, [], "enums de Qt sin ambito (usa ui/qtcompat.py):\n" + "\n".join(fallos)
        )

    def test_ejecutar_modal_resuelve_el_metodo(self):
        from qgis.PyQt.QtWidgets import QDialog

        from aqgis_sivil3d.ui.qtcompat import ejecutar_modal

        d = QDialog()
        metodo = getattr(d, "exec", None) or getattr(d, "exec_", None)
        self.assertIsNotNone(metodo, "QDialog sin exec() ni exec_()")
        self.assertTrue(callable(ejecutar_modal))


class TestInterfaz(unittest.TestCase):
    """Construye los dialogos de verdad y ejercita sus acciones.

    No se llama a ``exec()`` porque bloquearia; todo lo demas (construccion,
    seleccion en el arbol, edicion de parametros, previsualizacion) si se
    ejecuta, que es donde estan los errores de API de Qt.
    """

    def setUp(self):
        from aqgis_sivil3d.core.library import default_library

        self.lib = default_library()
        self.ruta = os.path.join(_TMP, "secciones_ui.json")
        self.lib.save(self.ruta)

    def test_editor_se_construye_y_previsualiza(self):
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        ed = AssemblyEditor(self.lib, self.ruta)
        self.assertEqual(ed.lista.count(), len(self.lib))
        self.assertIsNotNone(ed._asm)
        ed.panel_izq._seleccionar("fijos", 0)
        self.assertIsNotNone(ed.form._element)
        ed._refrescar_preview()
        self.assertIsNotNone(ed.preview._section)
        self.assertGreater(len(ed.preview._section.vertices), 2)

    def test_editor_anadir_mover_y_quitar(self):
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        ed = AssemblyEditor(self.lib, self.ruta)
        p = ed.panel_izq
        n0 = len(ed._asm.izquierda.fijos)

        # Sin seleccion previa, el elemento nuevo se anade al final de la cadena.
        p._anadir("fijos", "vertical")
        self.assertEqual(len(ed._asm.izquierda.fijos), n0 + 1)
        self.assertEqual(p._actual(), ("fijos", n0))
        self.assertEqual(ed._asm.izquierda.fijos[n0].tipo, "vertical")

        # Subir lo mueve una posicion y la seleccion lo sigue.
        p._mover(-1)
        self.assertEqual(p._actual(), ("fijos", n0 - 1))
        self.assertEqual(ed._asm.izquierda.fijos[n0 - 1].tipo, "vertical")

        # No se puede subir mas alla del principio.
        for _ in range(n0 + 3):
            p._mover(-1)
        self.assertEqual(p._actual(), ("fijos", 0))
        self.assertEqual(len(ed._asm.izquierda.fijos), n0 + 1)

        # Duplicar inserta la copia justo detras y selecciona la copia.
        p._duplicar()
        self.assertEqual(len(ed._asm.izquierda.fijos), n0 + 2)
        self.assertEqual(
            [e.tipo for e in ed._asm.izquierda.fijos[:2]], ["vertical", "vertical"]
        )
        self.assertEqual(p._actual(), ("fijos", 1))

        # Quitar afecta al elemento seleccionado, no al primero.
        p._seleccionar("fijos", 0)
        p._quitar()
        p._seleccionar("fijos", 0)
        p._quitar()
        self.assertEqual(len(ed._asm.izquierda.fijos), n0)
        self.assertTrue(all(e.tipo != "vertical" for e in ed._asm.izquierda.fijos))

    def test_seleccionar_en_un_lado_no_vacia_el_formulario(self):
        """Regresion: refrescar el otro panel borraba el elemento en edicion."""
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        ed = AssemblyEditor(self.lib, self.ruta)
        ed.panel_izq._seleccionar("fijos", 0)
        elemento = ed.form._element
        self.assertIsNotNone(elemento)
        ed._params_cambiados()  # refresca los dos paneles
        self.assertIs(ed.form._element, elemento)

    def test_copiar_rama_al_otro_lado(self):
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        ed = AssemblyEditor(self.lib, self.ruta)
        ed._asm.derecha.fijos = []
        ed._copiar_rama(-1)
        self.assertEqual(
            [e.codigo for e in ed._asm.derecha.fijos],
            [e.codigo for e in ed._asm.izquierda.fijos],
        )

    def test_editor_guarda_la_libreria(self):
        from aqgis_sivil3d.core.library import AssemblyLibrary
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        destino = os.path.join(_TMP, "guardado_ui.json")
        ed = AssemblyEditor(self.lib, destino)
        ed._guardar_y_cerrar()
        self.assertTrue(os.path.exists(destino))
        self.assertEqual(AssemblyLibrary.load(destino).names(), self.lib.names())

    def test_parametro_invalido_no_rompe_la_previsualizacion(self):
        from aqgis_sivil3d.ui.assembly_editor import AssemblyEditor

        ed = AssemblyEditor(self.lib, self.ruta)
        ed.panel_izq._seleccionar("fijos", 0)
        elemento = ed.form._element
        clave = elemento.definicion().params[0].name
        elemento.params[clave] = "esto no es un numero"
        ed._refrescar_preview()
        self.assertIsNone(ed.preview._section)
        self.assertIn("Invalid parameter", ed.preview._mensaje)

    def test_dialogo_del_corredor_se_construye(self):
        from aqgis_sivil3d.ui.corridor_dialog import CorridorDialog

        class Iface:
            def mainWindow(self):
                return None

        d = CorridorDialog(Iface(), self.ruta)
        self.assertEqual(d.cmb_seccion.count(), len(self.lib))
        self.assertFalse(d.sp_celda.isEnabled())
        d.chk_fusion.setChecked(True)
        self.assertTrue(d.sp_celda.isEnabled())
        d.log("prueba")
        d.log("aviso", aviso=True)

    def test_plugin_registra_y_desregistra(self):
        import aqgis_sivil3d
        from qgis.PyQt.QtWidgets import QMainWindow

        class Iface:
            def __init__(self):
                self.w = QMainWindow()
                self.acciones = []

            def mainWindow(self):
                return self.w

            def addPluginToVectorMenu(self, _m, a):
                self.acciones.append(a.text())

            def removePluginVectorMenu(self, _m, a):
                self.acciones.remove(a.text())

            def addToolBarIcon(self, a):
                pass

            def addToolBarWidget(self, w):
                return None

            def removeToolBarIcon(self, a):
                pass

        iface = Iface()
        plugin = aqgis_sivil3d.classFactory(iface)
        plugin.initGui()
        # Corredor, editor de secciones, planos, exportar, importar, perfiles,
        # rasantes, embalse, ayuda e idioma.
        self.assertEqual(len(iface.acciones), 10)
        for esperado in (
            "profiles",
            "drawings",
            "Export",
            "Import",
            "alignment editor",
            "Reservoir",
            "help",
        ):
            self.assertTrue(
                any(esperado.lower() in a.lower() for a in iface.acciones), esperado
            )
        reg = QgsApplication.processingRegistry()
        self.assertTrue(any(a.id() == "aqgis:corredor" for a in reg.algorithms()))
        for accion in plugin.acciones:
            self.assertFalse(accion.icon().isNull(), accion.text())
        plugin.unload()
        self.assertEqual(iface.acciones, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
